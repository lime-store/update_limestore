<?php 

namespace core\classes\Services\Warehouse\Traits;

use core\classes\Utils\Utils;
use core\classes\System\Main;
use core\classes\dbWrapper\db;
use core\classes\Products;
use core\classes\System\Init;

trait Transfer 
{


    /**
     * Добавить трансфер
     * 
     * @param array @data массив с даннми
     * @param int $warehousId id склада
     */
    public static function addTransfer(array $data, int $warehouseId)
    {
        $option = [
            'before' => ' UPDATE stock_list SET ',
            'after' => ' WHERE stock_id = :id ',
            'post_list' => [
                'id' => [
                    'query' => false,
                    'bind' => 'id'
                ],
                'count' => [
                    'query' => ' stock_list.stock_count = stock_list.stock_count - :product_count ',
                    'bind' => 'product_count'
                ]
            ]
        ];
        try {
            db::beginTransaction();
            foreach($data as $key => $row) {
                $productId      = $row['id'];
                $transferCount  = $row['count'];
                $getProduct     = Products::getProductById($productId);
                $initialCount   = $getProduct['stock_count'];

                Products::logProductStockChange(
                    $productId,
                    $initialCount,
                    ($initialCount - $transferCount),
                    'transferOut'
                );

                db::update($option, $row);
            
                db::insert('transfer_list', [
                    [
                        'warehouse_id'          => $warehouseId,
                        'transfer_date'         => Utils::getDateMY(),
                        'transfer_full_date'    => Utils::getDateDMY(),
                        'stock_id'              => $productId,
                        'count'                 => $transferCount,
                        'description'           => $row['description']
                    ]
                ]);    

            }    
            
            db::commit();

            return true;
        } catch (\Throwable $e) {
            db::rollBack();
            throw $e;
        } 
    }


    /**
     * 
     */
    public function getTransferByDate($date = null, $controllerIndex)
    {
        $data_page = Init::initController($controllerIndex);
        $page_config = $data_page['page_data_list'];
        
        
        $data_page['sql']['query']['body'] = $data_page['sql']['query']['body'] . "  AND transfer_list.transfer_date = :mydateyear";
        $data_page['sql']['bindList']['mydateyear'] = $date ?? date("m.Y");
        
        return Main::prepareData($data_page['sql'], $data_page['page_data_list']);
    }



}