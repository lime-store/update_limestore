<?php 
// here include config file
    require_once $_SERVER['DOCUMENT_ROOT'].'/db/config.php';

    if(!file_exists($_SERVER['DOCUMENT_ROOT'].'/backup/')) {
        mkdir($_SERVER['DOCUMENT_ROOT'].'/backup/', 0700);
    }

    $db_backup_dir = $_SERVER['DOCUMENT_ROOT'].'/backup/db/';

	//создаем папку для бэкапа бд
	if(!file_exists($db_backup_dir)) {
		mkdir($db_backup_dir, 0700);
	}    

    $dir = $db_backup_dir.'db'.date('-(d.m.Y)-(H-i)').'.sql';
    
    $dump_dir = dirname($_SERVER['DOCUMENT_ROOT']) . '/mysql/bin/mysqldump';
    
    exec("$dump_dir --user=".DBUSER." --password=".DBPASS." --host=".DBHOST." ".DBNAME." --result-file={$dir} 2>&1", $output);
