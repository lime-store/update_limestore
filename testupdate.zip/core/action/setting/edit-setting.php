<?php 
use Core\Classes\System\Settings;
use Core\Classes\Utils\Utils;

if(!empty($_POST['name'])) {
    $name = $_POST['name'];
    $state = $_POST['state'] ?? 0;
    return Settings::changeSettingState($name, $state);
}