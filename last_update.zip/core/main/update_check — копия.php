<?php

	define('root_dir', $_SERVER['DOCUMENT_ROOT']);

	$root_dir = root_dir;

	//версия пользоватея
	$current_version = file_get_contents($root_dir.'/version.txt');
	//версия на сервере
	$last_version = 'https://raw.githubusercontent.com/lime-sklad/update_limestore/master/version.txt';


	// Создаем поток
	$opts = array(
	  'http'=>array(
	    'method'=>"GET",
	    'header'=>"Accept-language: en\r\n" .
	              "Cookie: foo=bar\r\n"
	  )
	);

	$context = stream_context_create($opts);

	//получем версию с репозитория
	$get_verison = file_get_contents('https://raw.githubusercontent.com/lime-sklad/update_limestore/master/version.txt', false, $context);
	//чистим от пробелов
	$get_verison = trim($get_verison);

	//версия пользователя
	$current_version = trim($current_version);

	if($current_version !== $get_verison) {
	   if(!isset($_POST['download_upd'])) {
	   		show_upd_notify();
	   }

		if(isset($_POST['download_upd'])) {
		    exec('curl https://github.com/lime-sklad/update_limestore/raw/master/last_update.zip -L -o update.zip');
			//запускаем установку обнов.
			ls_install_update($root_dir);
		}
	} 
	 
	function ls_install_update($root_dir) {	 
		$zip = new ZipArchive;
		if($zip->open('update.zip') === TRUE) {
			$zip->extractTo($root_dir);
		    $zip->close();
		    echo "Удачно";
		}
	}


	function show_upd_notify() {
	?>
		<div class="update_modal">
		  <div class="update_modal_wrapper">
		    <div class="update_modal_content upd_modal_console">
		      
		      <div class="upd_console_header">
		        <div class="upd_console_hdr_list">
		          <div class="upd_console_logo">LS$</div>
		          <div class="upd_console_name">LS:\limestore\update</div>
		        </div>
		      </div>
		      
		      <div class="upd_console_content_wrp">
		        <div class="upd_console_cmd_list">
		          <div class="upd_console_cmd">
		            <div class="upd_console_cmd_name">$lime@store></div>
		            <div class="upd_console_content_descripton">Yeniləmə yüklənir</div>
		            <div class="upd_console_load">
		              <div></div> 
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>            
		            </div>            
		          </div>
		          
		          <div class="upd_console_cmd">
		            <div class="upd_console_cmd_name">$lime@store></div>
		            <div class="upd_console_content_descripton upd_warning_notify">PROQRAMI BAĞLAMAYIN!</div>   
		          </div> 
		          
		        </div>  
		      </div>
		      
		    </div>
		  </div>
		</div>
		<div class="update_block">
			<div class="upd_wrapper">
				<div class="upd_header">
					<span class="">Yeniləmə mövcuddur</span>
				</div>
				<div class="upd_dwnld">
					<button class="btn download_btn_s download_btn">Yükləyin</button>
				</div>
			</div>
		</div>
	<?php
	}

?> 

<script type="text/javascript">
	$('body').on('click', '.download_btn', function(){	
		var $get_preloader = $('.update_modal');
		$get_preloader.fadeIn();
		alert('Yeniləmələr yüklənir, zəhmət olmasa yükləmənin sonuna qədər gözləyin. \n Davam etmək üçün "OK" düyməsini basın');

		setTimeout(function(){
			get_request_upd();
		}, 3000);

		function get_request_upd() {
			var download_upd = 'dsfds';
			var link_path = 'core/main/update_check';
			$.ajax({
				type: 'POST',
				url: link_path,
				data: {
					download_upd: download_upd
				},
				cache: false,
				async: false,
				success: (data) => {
					document.location.href = "./";
				}			

			});
		}

	});
</script>

<style type="text/css">

.update_modal * {
	font-family: monospace;
}

.update_modal {
	position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    right: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: none;
    z-index: 100;
}

.update_modal_wrapper {
    display: flex;
    width: 100%;
    height: 100%;
    justify-content: center;
    align-items: center;
}

.upd_modal_console {
    width: 660px;
    height: 340px;
    background: #000;
    display: flex;
    flex-direction: column;
    border: 3px solid #555;
}

.upd_console_header {
    width: 100%;
    height: 50px;
    background: #555;
}

.upd_console_hdr_list {
    width: 100%;
    display: flex;
    height: 100%;
    align-items: center;
    margin-left: 10px;
}

.upd_console_logo {
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid #333;
    background: #000;
    color: green;
    font-size: 11px;
    border-radius: 7px;
    margin-right: 7px;
}

.upd_console_name {
    font-size: 14px;
    color: #fff;
}

.upd_console_cmd_name {
    color: green;
    font-size: 16px;
    margin-right: 10px;
}

.upd_console_content_wrp {
    width: 100%;
    height: 100%;
    overflow: hidden;
    overflow-y: scroll;  
}

.upd_console_cmd_list {
    padding: 15px 10px;
    width: 100%;
    height: 100%;
}

.upd_console_cmd {
    display: flex;
    align-items: center;
    width: 100%;
    height: 44px;
    flex-direction: row;
}

.upd_console_content_descripton {
    font-size: 14px;
    color: #dddd;
}

.upd_console_load {
    display: flex;
    margin-left: 10px;
}
.upd_console_load div {
    width: 20px;
    height: 20px;
    background: #ddd;
    animation: upd_load 1.5s infinite ease;
    opacity: 0;
}
.upd_warning_notify {
   color: rgba(255, 0, 0, 0.5)!important;
}

.upd_console_load div:nth-child(1) {
    animation-delay: 0.6s;
}

.upd_console_load div:nth-child(2) {
    animation-delay: 0.7s;
}

.upd_console_load div:nth-child(3) {
    animation-delay: 0.8s;
}
.upd_console_load div:nth-child(4) {
    animation-delay: 0.9s;
}
.upd_console_load div:nth-child(5) {
    animation-delay: 1s;
}
.upd_console_load div:nth-child(6) {
    animation-delay: 1.1s;
}

.upd_console_load div:nth-child(7) {
    animation-delay: 1.2s;
}

.upd_console_load div:nth-child(8) {
    animation-delay: 1.3s;
}

.upd_console_load div:nth-child(9) {
    animation-delay: 1.4s;
}
.upd_console_load div:nth-child(10) {
    animation-delay: 1.5s;
}
.upd_console_load div:nth-child(11) {
    animation-delay: 1.6s;
}
.upd_console_load div:nth-child(12) {
    animation-delay: 1.7s;
}


@keyframes upd_load {
    0% {
        opacity: 0;
    }                     
    100% {
        opacity: 100%;
    }  
}	

	.update_block {
	    position: absolute;
	    right: 0;
	    top: 60px;
	}

	.update_block div {
	    box-sizing: border-box;
	}

	.upd_wrapper {
	    width: 350px;
	    height: 63px;
	    margin: 21px;
	    display: flex;
	    justify-content: unset;
	    align-items: center;
	    padding: 18px;
	    /* background: red; */
	    box-sizing: border-box;
	    z-index: 20;
	    background: #f2f2f2f2;
	    box-shadow: 0 0 20px 0px rgba(197, 197, 197, 0.6);
	    border-radius: 10px;
	    position: relative;
	    transition: .5s;
	}

	.upd_wrapper:hover {
	    box-shadow: 0 0 20px 0px rgb(34, 111, 181, 0.5);
	}

	.upd_header {
	    /* padding: 0 10px; */
	    width: 50%;
	    height: 100%;
	    display: flex;
	    align-items: center;
	}

	.upd_header>span {
	    font-size: 16px;
	    color: #333;
	}

	.upd_dwnld {
	    position: absolute;
	    right: 10px;
	    transition: .5s;
	}

	.upd_dwnld:hover {
	    right: 15px;
	}

	.download_btn_s {
	    border-radius: 22px;
	    border: 0;
	    background: #226fb5;
	    color: #fff;
	    width: 113px;
	    height: 38px;
	    font-size: 16px;
	    text-transform: uppercase;
	    cursor: pointer;
	    outline: 0;
	    opacity: 0.8;
	    transition: .5s;
	}

	.download_btn_s:hover {
	    opacity: 1;
	} 
</style>