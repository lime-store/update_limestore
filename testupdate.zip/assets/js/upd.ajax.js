$.ajaxSetup({	
	url: 'ajax_route.php',
    beforeSend: function() {
		pageData.preloaderShow();
    },
    complete: function() {
		pageData.preloaderHide();	
	},
});


const ajaxHistoryData = {};

function setAjaxHistory(data) {
	Object.keys(ajaxHistoryData).forEach(key => delete ajaxHistoryData[key]);
	Object.assign(ajaxHistoryData, data);
}

function sendAjaxHistory() {
	$.ajax({
		url: 	  ajaxHistoryData.url,
		type: 	  ajaxHistoryData.type,
		data: 	  ajaxHistoryData.data,
		dataType: ajaxHistoryData.dataType,
		success: (data) => {
			if(ajaxHistoryData.data.tab !== 'undefined') {
				if(ajaxHistoryData.data.tab == 'tab_report_day' || ajaxHistoryData.data.tab == 'tab_report_phone') {
					$('.content').remove();					
					$('.main').append(data);
				}
			}
		
			if(data.table) {
				pageData.innerTable(data.table);
			}
		
			if(data.total) {
				pageData.innerTableFooter(data.total);
			}
		}
	});
}



$(document).ready(function() {
	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: 'core/action/update/check_new_version.php',
			route: 'checkNewVersion',
		},
		dataType: 'json',
		async: true,
		beforeSend: function() {
		},
		complete: function() {
		},		
		success: (data) => {
			$(document).find('.top-nav-list').prepend(data.nav);
		}
	});
});



$(document).ready(function() {
	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: 'core/action/quizModal/quizModal.php',
			route: 'quizModal',
		},
		dataType: 'json',
		async: true,
		beforeSend: function() {
		},
		complete: function() {
		},		
		success: (data) => {
			if(data.type == 'success') {
				$('.app').append(data.view)	;
				pageData.overlayShow();
			}
		}
	});
});



$(document).ready(function() {
	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			route: 'check_date',
			url: '/core/main/check_date.php',
		},
		async: true,
		beforeSend: function( ){
		},
		complete: function() {
		},		
		success: (data) => {
			$('.app-container').html(data.content);			
		}
	});
});


$(document).ready(function() {
	createBackup();
});



/**
 * download update
 */
$(document).on('click', '.download-update', function(){
	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			route: 'downloadUpdate',
			url: '/core/action/update/download_update.php',
			get_modal: true
		},
		dataType: 'json',
		success: (data) => {
			if(data.success) {
				pageData.overlayShow();
				$('body').append(data.success);
			}
			if(data.error) {
				$('.update-modal').html(data.error);
			}
		}
	});
});



/** 
 * LOGIN  
 */
	$(document).on('submit', '.login-form', function(e){
		e.preventDefault();
		var user_login = $('.user-login').val();
		var user_password = $('.user-password').val();
		if(validate_all_input($('.input'))) {
			$.ajax({
				type: 'POST',
				url: 'core/auth/auth.php',
				dataType: 'json',
				data: {
					login: user_login,
					password: user_password
				},
				success: (data) => {
					if(data.success) {
						window.location.reload();
					} 
					
					if(data.error) {
						pageData.alert_notice('error', data.error);
					}
				}
			});
		}

	});




/** 
 * MENU START
 */ 
$('body').on('click', '.get_page_action', function(){
    //смотри в option.php
    //получаем ссылку на страницу
    var $result = $('.main');
    var tab = $(this).data('tab');
    var data_page = $(this).data('page-route');

	

    $.ajax({
        type: 'POST',
        url:  'page/route.php',
        data: {
            tab: tab,
            data_page_route: data_page
        },
        success: (data) => {
            //проверка данных на json
            if(data.error) {
                notice_modal('text', 'error');
            } else {
                $result.html(data);
            }

            ui_selected_sidebar(tab);
            ui_selected_tab();
            visible_menu('hide');

			const content_title = $('.content__title').text();

			$('title').html(`Lime Store > ${content_title}`);

			if(data_page == 'report') {
				setAjaxHistory({
					type: 'POST',
					url: 'page/route.php',
					dataType: 'html',
					data: {
						tab: tab,
						page: data_page
					}
				});
			} 			
        }			
    });
});


//tab
$('body').on('click', '.tab-button', function(){
    $tab_active = 'tab_activ';
    var $result = $('.main')
    var tab = $(this).data('tab');
    var data_page = $(this).data('page');

	$.ajax({
		url:  'page/route.php',
		type: 'POST',
		data: {				
			page: data_page,
			tab: tab,
		},
		success: (data) => {
            $('.tab-button').removeClass($tab_active);
			$('.content').remove();
			$(this).addClass($tab_active);
            ui_selected_tab();
            //проверка данных на json
            if(data.error) {
                notice_modal('text', 'error');
            } else {
                $result.append(data);
            }
			
			if(data_page == 'report') {
				setAjaxHistory({
					type: 'POST',
					url: 'page/route.php',
					dataType: 'html',
					data: {
						tab: tab,
						page: data_page
					}
				});
			}		
		}
	});

	$(this).blur();
	 			
});

//endtab


/** MENU END */

/** send filter / search / autocomplete start */

//фильтрация товара
function send_filter(filter_list) {
	//переключаем состяние на активный
	$.ajax({
		type: 'POST',
		url:  'ajax_route.php',
		data: {
			url: 'core/action/stock/get_filter_stock.php',
			route: 'filtredProducts', 
			data: {
				id: filter_list,
				page: pageData.page(),
				type: pageData.type()
			}
		},
        dataType: 'JSON',
		success: (data) => { 

			//выводим в талицу данные
			if(data.table) {
				pageData.innerTable(data.table);	
			}
			if(data.total) {
				pageData.innerTableFooter(data.total);
            }

			setAjaxHistory({
				type: 'POST',
				url: 'ajax_route.php',
				dataType: 'json',
				data: {
					url: 'core/action/stock/get_filter_stock.php',
					route: 'filtredProducts', 
					data: {
						id: filter_list,
						page: pageData.page(),
						type: pageData.type()
					}
				}
			});
		}				
	});
}

function send_autocomplete($this) {
    var $delay = 450;
	var min_value_length = 1;   

	var $search_container = $this.closest('.search-container');
	var $append_to = $this.closest($search_container).find('.search-list-content');
    var $preloader = $this.closest($search_container).find('.preloader');
	var search_data = $this.val().trim();
	var data_name = $this.attr('data-name');
	var autocmplt_type = $append_to.attr('data-auto-cmplt-type');
	var option_class_list = $append_to.attr('data-option-class-list');
	var $table = $('.table-list');

	let data_page = $append_to.attr('data-search-page') || pageData.page();

	if(search_data.length > min_value_length) {
		$preloader.addClass('flex-cntr').removeClass('hide');
		clearTimeout($this.data('timer'));
		$this.data('timer', setTimeout(function(){
			$.ajax({
				type: 'POST',
				url: 'ajax_route.php',
				data: {
					url: '/core/action/search/autocomplete.php',
					route: 'autocomplete',
					data: {
						value: search_data,
						action: data_name,
						page: data_page,
						type: pageData.type(),
						autocmplt_type: autocmplt_type,
						option_class_list: option_class_list,
					}
				},
				beforeSend: () => {
				},
				complete: () => {
					$preloader.removeClass('flex-cntr').addClass('hide');
				},
				success: (data) => {
					if(data.length <= 0) {
						$append_to.html('Heç nə tapılmadı');
					} else {
						$append_to.html(data);
					}
				}
			});

		}, $delay));					
	} else {
		$append_to.html('no result');
	}	
}

$(document).on('click', '.search-item', function() {
    reset_all_filter();
	//делаем поиск по значению 
	// var search_item_value = $(this).find('.stock-info-text').text();
	var search_item_value = $(this).data('sort-value');

	//for report sort data 
    var sort_data = $(this).data('sort');
    
    var $search_main_table = $('.stock_list_tbody');
	//тут мы получаем тип таблицы (terminal, stock, report и тд)

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			route: 'search',
			url: 'core/action/search/search.php',
			data: {
				search_item_value	: search_item_value, 
				page				: pageData.page(), 
				type			    : pageData.type(),
				sort_data 			: sort_data
			}
		},
		dataType: 'json',
		success: (data) => {
			//выводим в талицу данные
			if(data.table) {
				pageData.innerTable(data.table);	
			}
			if(data.total) {
				pageData.innerTableFooter(data.total);
			}

			setAjaxHistory({
				type: 'POST',
				url: 'ajax_route.php',
				dataType: 'json',
				data: data.postData
			});
		}			
	});
});

/** end send filter */

/** order start*/
$('body').on('click', '.open-edit-modal', function() {
	$modal = $('.modal_view_stock_order');


	pageData.preloaderShow();
	pageData.overlayShow();
	$('.get_order_action').removeClass('click');

	//получаем id проддукта от родительсокого эелемента
	var product_id = $(this).closest('.stock-list').attr("id");		
	//report_order_id
	var order_id = $(this).find('.get_report_order_id').attr('data-sort-value');


	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		cache: false,
		data:{
			url: 'core/action/modal/modal.php',
			route: 'modal',
			data: {
				product_id : product_id,
				order_id: order_id, 
				type  : pageData.type(), 
				page  : pageData.page()
			}
		},
		success: (data) => {
			pageData.rightSideModal(data);
		}			

	});
});
/** end order */












// изменить категорию
$('body').on('click', '.submit-save-category', function() {
	let prepare_data = {};

	const category_id = $('.category-id').data('id');

	prepare_data['category_id'] = category_id;

	$('.edit').each(function(){
		if($(this).data('fields-name') && $(this).hasClass('edited')) {
			var data_name = $(this).data('fields-name');
			var val = $(this).val();
			prepare_data[data_name] = val;
		}
	});

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			prepare_data,
			url: 'core/action/category/edit-category.php',
			route: 'editCategory',
		},
		dataType: "json",
		success: (data) => {
			pageData.alert_notice(data.type, data.text)
			
			if(data.type == 'success') {	
				for (key in prepare_data) {
					pageData.update_table_row(key, prepare_data[key], category_id);
				}

				createBackup();

				$(document).trigger('editCategory', {id: category_id});
			}
		}			

	});

});

/** удалить категория start */
$(document).on('click', '.delete-category', function() {
	const id = $(this).data('delete-id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: 'core/action/category/delete-category.php',
			route: 'deleteCategory',
			id: id
		},
		dataType: 'json',
		success: (data) => {
			pageData.alert_notice('success', data.success);
			
			if(data.type == 'success') {
				pageData.rightSideModalHide();
				pageData.overlayHide();

				var $stock = $(`#${id}.stock-list`); 

				$stock.hide(1000, function() {
					$stock.remove();
				});

				createBackup();

				$(document).trigger('deleteCategory', {id: id});
			}
		}
	});
});
/** удалить категория end */







// изменить категорию
$('body').on('click', '.submit-save-provider', function() {
	let prepare_data = {};

	const provider_id = $('.provider-id').data('id');

	prepare_data['provider_id'] = provider_id;

	$('.edit').each(function(){
		if($(this).data('fields-name') && $(this).hasClass('edited')) {
			var data_name = $(this).data('fields-name');
			var val = $(this).val();
			prepare_data[data_name] = val;
		}
	});

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/provider/edit-provider.php',
			route: 'editProvider',
			prepare_data,
		},
		dataType: "json",
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success') {				
				for (key in prepare_data) {
					pageData.update_table_row(key, prepare_data[key], provider_id);
				}

				createBackup();

				$(document).trigger('editProvider', {id: provider_id});
			}
		}			

	});
});


/** удалить поставщик start */
$(document).on('click', '.delete-provider', function() {
	const id = $(this).data('delete-id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: 'core/action/provider/delete-provider.php',
			route: 'deleteProvider',
			id: id,
		},
		dataType: 'json',
		success: (data) => {
			pageData.alert_notice(data.type, data.text);
			if(data.type == 'success') {
				pageData.rightSideModalHide();
				pageData.overlayHide();

				var $stock = $(`#${id}.stock-list`); 

				$stock.hide(1000, function() {
					$stock.remove();
				});

				createBackup();

				$(document).trigger('deleteProvider', {id: id});
			}

		}
	});
});
/** удалить поставщик end */


/**
 * добавить расходы
 */
$(document).on('click', '.add-submit-rasxod', function() {
	if(is_required_input($(this).closest('.stock-from-container').find('.form-input'))) {
		prepare_data = prepare_form_fields($(this).closest('.stock-from-container'));
		$.ajax({
			type: 'POST',
			url: 'ajax_route.php',
			data: {
				url: 'core/action/expense/add_expense.php',
				route: 'addExpense',
				post_data: prepare_data,
				page: pageData.page(),
				type: pageData.type()
			},
			dataType: "json",
			success: (data) => {
				pageData.alert_notice(data.type, data.text);

				if(data.type == 'success') {
					$('.form-input').val('');

					if(data.table) {
						return pageData.prependTable(data.table);
					}

					createBackup();
				}
			}	
		});
	}
});



// добавить поставщика
$('body').on('click', '.add-submit-provider', function() {
	let prepare_data = {};

	if($(this).closest('.modal-form').length) {
		if(is_required_input($(this).closest('.modal-form').find('.form-input'))) {
			prepare_data = prepare_form_fields($(this).closest('.modal-form'));
			$.ajax({
				type: 'POST',
				url: 'ajax_route.php',
				data: {
					route: 'addProvider',
					url: '/core/action/provider/add-provider.php',
					post_data: prepare_data,
					page: pageData.page(),
					type: pageData.type()
				},
				dataType: "json",
				success: (data) => {
					var error 	= data['error'];
					var success = data['success'];
					
					if(error) {
						pageData.alert_notice('error', error);
					}
	
					if(success) {
						pageData.alert_notice('success', 'Ок');
						$('.form-input').val('');
	
						if(data.table) {
							closeAndRemoveModal();
							return pageData.prependTable(data.table);
						}

						createBackup();
					}
				}			
	
			});
		}
	}
});

$(document).on('click', '.load-provider-add-modal', function() {
	remove_modal();

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/provider/addProviderModal.php',
			route: 'addProviderModal',
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);
		}
	});
});


/**
 * изменить данные расхода
 */
 $('body').on('click', '.submit-save-rasxod', function() {
	let prepare_data = {};

	if(is_required_input($(this).closest('.modal_order_form').find('.input-required'))) {
		const rasxod_id = $('.rasxod-id').data('id');

		prepare_data['rasxod_id'] = rasxod_id;
	
		$('.edit').each(function(){
			if($(this).data('fields-name') && $(this).hasClass('edited')) {
				var data_name = $(this).data('fields-name');
				var val = $(this).val();
				prepare_data[data_name] = val;
			}
		});
	
		$.ajax({
			type: 'POST',
			url: 'ajax_route.php',
			data: {
				url: 'core/action/expense/edit_expense.php',
				route: 'editExpense',
				data: prepare_data
			},
			dataType: "json",
			success: (data) => {
				if(data.type == 'success') {
					pageData.alert_notice(data.type, data.text);
	
					for (key in prepare_data) {
						pageData.update_table_row(key, prepare_data[key], rasxod_id);

						createBackup();
					}				
				} else {
					pageData.alert_notice('error', error)
				}
			}			
	
		});
	}
});


/**
 * удалить расход
 */
 $(document).on('click', '.delete-rasxod', function() {
	const id = $(this).data('delete-id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: 'core/action/expense/delete_expense.php',
			route: 'deleteExpense',
			id: id
		},
		dataType: 'json',
		success: (data) => {
			pageData.alert_notice(data.type, data.text);
			
			if(data.type == 'success') {
				pageData.rightSideModalHide();
				pageData.overlayHide();

				var $stock = $(`#${id}.stock-list`); 

				$stock.hide(1000, function() {
					$stock.remove();
				});

				createBackup();
			}

		}
	});
});


// загрузить баркоды товара
 $(document).on('click', '.load-product-barcode', function() {
	var data = $(this).data('value');

	remove_modal();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/barcode/edit_product_barcode_modal.php',
			route: 'editProductBarcodeModal',
			data: data
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);

			createBackup();
		}
	});
});

// загрузить баркоды товара
 $(document).on('click', '.print-barcode-modal', function() {
	var data = $(this).data('value');

	remove_modal();
	
	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/barcode/_barcode_modal.php',
			route: 'printProductBarcodeModal',
			data: data
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);
		}
	});
});

// загрузить баркоды товара
 $(document).on('click', '.generate-new-barcode', function() {
	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/barcode/generate_new_barcode.php',
			route: 'generateBarcode',
		},
		dataType: 'json',
		success: (data) => {
			$(this).closest('.fields').find('.form-input').val(data.res);
		}
	});
});


// добавить категорию
$('body').on('click', '.add-submit-category', function() {
	let prepare_data = {};


	if($(this).closest('.modal-form').length) {
		if(is_required_input($(this).closest('.modal-form').find('.form-input'))) {
			prepare_data = prepare_form_fields($(this).closest('.modal-form'));
			$.ajax({
				type: 'POST',
				url: 'ajax_route.php',
				data: {
					route: 'addCategory',
					url: 'core/action/category/add_category.php',
					post_data: prepare_data,
					page: pageData.page(),
					type: pageData.type()
				},
				dataType: "json",
				success: (data) => {
					pageData.alert_notice(data.type, data.text);
					
					if(data.type == 'success') {
						$('.form-input').val('');
	
						if(data.table) {
							closeAndRemoveModal();
							return pageData.prependTable(data.table);
						}

						createBackup();
					}
				}			
	
			});
		}
	}
});

$(document).on('click', '.load-category-add-modal', function() {
	remove_modal();

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/payment-method/paymentMethodModal.php',
			route: 'addCategoryModal',
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);

			createBackup();
		}
	});
});


$(document).on('click', '.load-analytics-top-selling-products-on-table', function() {
	let pick_date = $(this).data('id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			date: pick_date,
			url: '/core/action/analytics/table-get-top-selling-by-interval.php',
			route: 'analyticsTableTopProductsByInterval'
		},
		dataType: 'json',
		success: (data) => {
			if(data.table) {
				pageData.innerTable(data.table);
			}

			if(data.total) {
				pageData.innerTableFooter(data.total);
			}
		}
	});
});

$(document).on('click', '.load-analytics-no-selling-products-on-table', function() {
	let pick_date = $(this).data('id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			date: pick_date,
			url: '/core/action/analytics/table-get-no-selling-by-interval.php',
			route: 'analyticsTableNoSalesProductsByInterval'
		},
		dataType: 'json',
		success: (data) => {
			if(data.table) {
				pageData.innerTable(data.table);
			}
		}
	});
});

$(document).on('click', '.load-analytics-top-selling-category-on-table', function() {
	let pick_date = $(this).data('id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			date: pick_date,
			url: '/core/action/analytics/table-get-top-selling-category-by-interval.php',
			route: 'analyticsTableTopCategoryByInterval'
		},
		dataType: 'json',
		success: (data) => {
			if(data.table) {
				pageData.innerTable(data.table);
			}

			if(data.total) {
				pageData.innerTableFooter(data.total);
			}
		}
	});
});

// 
$(document).on('click', '.load-analytics-top-seller-on-table', function() {
	let pick_date = $(this).data('id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			date: pick_date,
			url: '/core/action/analytics/table-get-top-seller.php',
			route: 'analyticsTableTopSeller'
		},
		dataType: 'json',
		success: (data) => {
			if(data.table) {
				pageData.innerTable(data.table);
			}

			if(data.total) {
				pageData.innerTableFooter(data.total);
			}
		}
	});
});


$(document).on('click', '.getOutOfStockProducts', function() {
	$.ajax({
		type: 'POST',
		data: {
			'route': 'getOutOfStockProducts'
		},
		dataType: 'json',
		success: (data) => {
			pageData.overlayShow();
			$('.container').append(data.res);
		}
	});
});




// сохранить баркод
$(document).on('click', '.save-edit-stock-barcode', function() {
	var productId = $(this).data('id');

	let new_barcode_list = [];
	let removed_barcode_list = [];
	let edited_barcode_list = [];


	$('.edit-barcode-input').each(function(index, key){
		
		// НОВЫЙ БАРКОД
		if($(this).hasClass('new') && !$(this).parent().hasClass('hide')) {
			new_barcode_list.push($(this).val());
		}

		// УДАЛЕННЫЫЙ БАРКОД
		if(!$(this).hasClass('new') && $(this).parent().hasClass('hide')) {
			removed_barcode_list.push($(this).data('barcode-id'));		
		}		

		if($(this).hasClass('deleted')) {
			removed_barcode_list.push($(this).data('barcode-id'));
		}			

		// ИЗМЕНЕННЫЙ БАРКОД
		if(!$(this).hasClass('new') && !$(this).parent().hasClass('hide')) {
			if($(this).hasClass('edited')) {
				edited_barcode_list.push({
					barcodeId: $(this).data('barcode-id'),
					value: $(this).val()
				});
			}
		}		
	});

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: 'core/action/barcode/set_product_barcode.php',
			route: 'setProductBarcode',
			productId: productId,
			new_barcode_list: new_barcode_list,
			removed_barcode_list: removed_barcode_list,
			edited_barcode_list: edited_barcode_list
		},
		dataType: 'json',
		success: (data) => {				
			pageData.alert_notice(data.type, data.text);

				$('.edit-barcode-input').removeClass(['edited', 'new']);

				$(this).closest('.modal-container').find('.form-fields.hide').remove();
			
			if(data.newAddedBarcode) {
				data.newAddedBarcode.forEach((item) => {
					 $('.edit-barcode-input').each(function() {
						var val = $(this).val();

						if(item.barcodeValue == val) {
							$(this).attr('data-barcode-id', item.barcodeId);
						}
					 });
				});
			}

			createBackup();
		}
	});
});



// создать новый фильтер
$(document).on('click', '.submit-create-filter', function() {
	let filter_option_list = [];
	var filter_title = $('.add-filter-title').val(); 


	$('.add-filter-option').each(function() {
		if($(this).val() !== '') {
			filter_option_list.push({'value': $(this).val()}); 
		}
	});


	if(is_required_input($(this).closest('.modal-form').find('.input-required'))) { 
		$.ajax({
			type: 'POST',
			url: 'ajax_route.php',
			data: {
				route: 'addFilter',
				url: 'core/action/filter/add-filter.php',
				filter_title: filter_title,
				filter_option: filter_option_list,
				page: pageData.page(),
				type: pageData.type()				
			},
			dataType: 'json',
			success: (data) => {
				pageData.alert_notice(data.type, data.text);

				if(data.type == 'success') {
					$('.form-input').val('');
					closeAndRemoveModal();
					pageData.prependTable(data.table);					
				}
			}
		});
	}	
});

$(document).on('click', '.load-filter-form-add-modal', function() {
	remove_modal();

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/filter/createFilterModal.php',
			route: 'addFilterFormModal',
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);
		}
	});
});


// изменить фильтер
$(document).on('click', '.submit-save-edited-filter', function() {
	let edit_option_list = [];
	let deleted_option_list = [];
	let add_new_option = [];


	var filter_id = $(this).closest('.modal_order_form').data('order-id');
	let filter_name = $('.edit-filter-name-input').val();

	$('.edit-filter-option').each(function() {
		if($(this).hasClass('edited') && !$(this).hasClass('new')) {
			edit_option_list.push({
				'id': $(this).data('id'),
				'value': $(this).val()
			});
		}
	});

	$('.input-removed').each(function() {
		if(!$(this).hasClass('new')) {
			deleted_option_list.push($(this).data('id'));
		}
	});

	$('.form-input.new').each(function() {
		if(!$(this).hasClass('input-removed')) {
			add_new_option.push({
				'value': $(this).val(),
				'type_id': filter_id
			});
		}
	});
	
		$.ajax({
			type: 'POST',
			url: 'ajax_route.php',
			data: {
				route: 'editFilter',
				url: 'core/action/filter/edit-filter.php',
				filter_id: filter_id,
				filter_name: filter_name,
				option_list: edit_option_list,
				deleted_option_list: deleted_option_list,
				add_new_option: add_new_option,
				page: pageData.page(),
				type: pageData.type()
			},
			dataType: 'json',
			success: (data) => {
				pageData.alert_notice(data.type, data.text);


				if(data.type == 'success') {
					pageData.update_table_row('filter_name', filter_name, filter_id);
				}				
			}
		});
		
});

$(document).on('click', '.delete-filter', function(){
	var id = $(this).data('delete-id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			route: 'deleteFilter',
			url: 'core/action/filter/deleteFilter.php',
			id: id
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

            if(data.type == 'success') {
				pageData.rightSideModalHide();
				pageData.overlayHide();

				var $stock = $(`.stock-list#${id}`); 

				$stock.hide(1000, function() {
					$stock.remove();
				});
            }				
		}
	});
});


// расширенный поиск 
$(document).on('click', '.advanced-search-submit', function() {
	
	let stock_category_list = [];
	let stock_provider_list = [];


	// Название продукта
	var stock_name = $(this).closest('.stock-from-container').find('.advanced-search-input--stock-name').val();

	var stock_description = $(this).closest('.stock-from-container').find('.advanced-search-input--stock-description').val();


	// Категория
	$(this).closest('.stock-from-container').find('.advanced-search-input--stock-category').each(function(){
		let id = $(this).val();
		if(id.length > 0) {
			stock_category_list.push(id);
		}
	});


	// Поставщик
	$(this).closest('.stock-from-container').find('.advanced-search-input--stock-provider').each(function(){
		let id = $(this).val();

		if(id.length > 0) {
			stock_provider_list.push(id);
		}
	});

	// месяц для отчета
	let report_month = $(this).closest('.stock-from-container').find('.advanced-search-input--report-month-picker').val();
	let report_day = $(this).closest('.stock-from-container').find('.advanced-search-input--report-day-picker').val();

	const post_list = {};
	$('.advanced').each(function(){
		let val = $(this).val();

		var data_fields = $(this).data('fields-name');

		if(val) {
			if($(`.advanced[data-fields-name=${data_fields}]`).length > 1) {
				if(!post_list[data_fields]) {
					post_list[data_fields] = [];
				}
		
				post_list[data_fields].push($(this).val());
			} else {
				post_list[data_fields] = [val];
			}


		}

	});



	// data-
	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: 'core/action/search/advanced_search.php',
			route: 'advancedSearch',
			data: {
				page: pageData.page(),
				type: pageData.type(),
				post_list: post_list,
			}
		},
		dataType: 'json',		
		success: (data) => {


			if(data.table) {
				pageData.innerTable(data.table);	
			}
			if(data.total) {
				pageData.innerTableFooter(data.total);
			}	
			
			setAjaxHistory({
				type: 'POST',
				url: 'ajax_route.php',
				data: {
					url: 'core/action/search/advanced_search.php',
					route: 'advancedSearch',
					data: {
						page: pageData.page(),
						type: pageData.type(),
						post_list: post_list,
					}
				},
				dataType: 'json'	
			});
		}
	});

});


// добавляем новый инпут для форымы
$(document).on('click', '.append-new-input', function() {

	let fields_name = $(this).data('fields-name');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: 'core/action/add_more_fields.php',
			route: 'appendMoreFields',
			data: {
				fields_name: fields_name
			}
		},
		beforeSend: function( ){
			
		},
		complete: function() {
		
		},		
		dataType: 'json',
		success: (data) => {
			$(this).closest('.input-container').before(data.fields);
		}
	});
});



// отправить ключь лицензии
$(document).ready(function(){
	$('.send-license-key').on('click', function() {

		var key = $('.license-key').val();

		$.ajax({
			type: 'POST',
			url: 'ajax_route.php',
			data: {
				route: 'activeLicense',
				url: 'core/action//action/active_license.php',
				data: key,
			},
			dataType: 'json',
			success: (data) => {
				
				if(data.alert_type == 'error') {
					pageData.alert_notice(data.alert_type, data.text);
				} else {
					$('.link-container').removeClass('display-none').addClass('flex');
				}
			}
		});
	
	});
	
});




$(document).on('click', '.add-seller', function() {
	var seller_name = $('.add-seller-name').val();
	var seller_password = $('.add-seller-password').val();

	if(is_required_input($(this).closest('.modal-form').find('.form-input'))) {

		$.ajax({
			type: 'POST',
			url: 'ajax_route.php',
			dataType: 'json',
			data: {
				route: 'addUser',
				url: '/core/action/admin/user/add-user.php',
				seller_name: seller_name,
				seller_password: seller_password,
				page: pageData.page(),
				type: pageData.type()
			},
			success: (data) => {
				pageData.alert_notice(data.type, data.text);

				if(data.type == 'success') {
					$(document).trigger('addSeller');
					
					pageData.prependTable(data.table);
					// pageData

					closeAndRemoveModal();

					createBackup();

				}
			}
		});
	} 
});

$(document).on('click', '.load-user-add-modal', function() {
	remove_modal();

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/admin/user/addUserModalForm.php',
			route: 'addUserModalForm',
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);
			createBackup();
		}
	});
});

$(document).on('click', '.switcher-new-state', function() {
	if(!$(this).hasClass('old')) {
		$(this).addClass('new');
	}
});

$(document).on('click', '.submit-save-seller-info', function() {
	let prepare_data = prepare_forms($(this).closest('.modal_order_form'), $('.edit-seller.edited'));

	$item = $(this).closest('.modal_order_form').find('.edit-seller');

	var id = $('.edit-seller-id').val();

	prepare_data['seller_id'] = id;

	let newAccessData = [];
	let delAccessData = [];

	let newAccessAction = [];
	let delAccessAction = [];

	let newAccessPage = [];
	let deleteAccesspage = [];
	
	let userDiscountLimit = $('.user-access-discount-limit').val() ?? 0;

	$('.user-access-data-switcher').each(function() {
		if($(this).hasClass('new') && $(this).hasClass('switcher-active')) {
			newAccessData.push($(this).data('id'));
		}

		if($(this).hasClass('old') && !$(this).hasClass('switcher-active')) {
			delAccessData.push($(this).data('id'));
		}
	});

	$('.user-access-action-switcher').each(function() {
		if($(this).hasClass('new') && $(this).hasClass('switcher-active')) {
			newAccessAction.push($(this).data('id'));
		}

		if($(this).hasClass('old') && !$(this).hasClass('switcher-active')) {
			delAccessAction.push($(this).data('id'));
		}
	});	

	$('.user-access-page-switcher').each(function() {
		if($(this).hasClass('new') && $(this).hasClass('switcher-active')) {
			newAccessPage.push($(this).data('id'));
		}

		if($(this).hasClass('old') && !$(this).hasClass('switcher-active')) {
			deleteAccesspage.push($(this).data('id'));
		}
	});		

	if(is_required_input($item)) {
		$.ajax({
			type: 'POST',
			url: 'ajax_route.php',
			dataType: 'json',
			data: {
				route: 'editUser',
				url: 'core/action/admin/seller/edit-user.php',
				prepare_data: prepare_data,
				newAccessData: newAccessData,
				delAccessData: delAccessData,
				newAccessAction: newAccessAction,
				delAccessAction: delAccessAction,
				newAccessPage: newAccessPage,
				deleteAccesspage: deleteAccesspage,
				userDiscountLimit: userDiscountLimit
			},
			success: (data) => {
				pageData.alert_notice(data.type, data.text);

				if(data.type == 'success') {
					for (key in prepare_data) {
						pageData.update_table_row(key, prepare_data[key], id);
					}

					$('.switcher-new-state').removeClass(['old', 'new']);
					$('.switcher-new-state.switcher-active').addClass('old');
				}

				createBackup();
			}	
		});
	}

	$('.edit-seller').removeClass('edited');
});


$(document).on('click', '.delete-seller', function() {
	var seller_id = $(this).data('delete-id');
	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			route: 'deleteUser',
			url: 'core/action/admin/seller/delete_seller.php',
			seller_id: seller_id,
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);


            if(data.type == 'success') {
				pageData.rightSideModalHide();
				pageData.overlayHide();

				var $stock = $(`.stock-list#${seller_id}`); 

				$stock.hide(1000, function() {
					$stock.remove();
				});

				createBackup();
            }			
		}	
	});
});


$(document).on('click', '.add-warehouse', function() {
	$this_form = $(this).closest('.modal-form');
	const prepare = prepare_form_data($this_form, '.warehouse-add-input', 'fields-name');

	$.ajax({
		type: 'POST',	 	
		url: 'ajax_route.php',
		data: {
			route: 'addWarehouse',
			url: '/core/action/warehouse/add-warehouse.php',
			page: pageData.page(),
			type: pageData.type(),
			data_row: prepare
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);
			
			$('.form-input').val('');

			if(data.table) {
				closeAndRemoveModal();
				return pageData.prependTable(data.table);
			}			

			createBackup();
		}
	});
});

$(document).on('click', '.load-warehouse-add-modal', function() {
	remove_modal();

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/warehouse/addWarehouseModalForm.php',
			route: 'addWarehouseModalForm',
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);
		}
	});
});


$(document).on('click', '.submit-save-warehouse', function() {
	const prepare = prepare_forms($(this).closest('.modal_order_form'), '.edit-warehouse-input', 'data-fields-name');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			route: 'editWarehouseInfo',
			url: 'core/action/warehouse/edit-warehouse.php',
			prepare: prepare
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			for (key in prepare) {
				pageData.update_table_row(key, prepare[key], prepare.warehouse_id);
			}

			createBackup();
		}
	});
});

$(document).on('click', '.delete-warehouse', function() {
	const id = $(this).data('delete-id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			route: 'deleteWarehouse',
			url: 'core/action/warehouse/delete-warehouse.php',
			id: id
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			pageData.rightSideModalHide();
			pageData.overlayHide();

			var $stock = $(`.stock-list#${id}`); 

			$stock.hide(1000, function() {
				$stock.remove();
			});

			createBackup();
		}
	});
});


$(document).on('click', '.submit-save-edited-payment-method', function(){

	const prepare_data = prepare_form_data($(this).closest('.modal_order_form'), '.edit-payment-method-info.edited', 'fields-name');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			prepare_data,
			route: 'editPaymentMethod',
			url: 'core/action/payment-method/edit-payment-method.php',
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			for (key in prepare_data) {
				pageData.update_table_row(key, prepare_data[key], prepare_data.payment_method_id);
			}	

			createBackup();
		}
	});

});



$(document).on('click', '.add-payment-method', function() {

	const prepare_data = prepare_form_data(
		$(this).closest('.modal-form'),
		'.create-payment-method-input.edited',
		'fields-name'		
	);


	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			route: 'addPaymentMethod',
			url: 'core/action/payment-method/add-payment-method.php',
			prepare_data: prepare_data,
			page: pageData.page(),
			type: pageData.type()
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);	
			
			if(data.type == 'success') {
				closeAndRemoveModal();
				pageData.prependTable(data.table);
				$('.form-input').val('');		
				
				createBackup();
			}
		}
	});
});

$(document).on('click', '.load-payment-method-modal', function() {
	remove_modal();

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/payment-method/paymentMethodModal.php',
			route: 'paymentMethodModal',
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);
		}
	});
});



$(document).on('click', '.delete-payment-method', function() {
	const id = $(this).data('delete-id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: 'core/action/payment-method/delete-payment-method.php',
			route: 'deletePaymentMethod',
			payment_method_id: id
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success') {
				var $item = $(`#${id}.stock-list`); 

				$item.hide(1000, function() {
					$item.remove();
				});
				pageData.overlayHide();
				pageData.rightSideModalHide();
	
				createBackup();
			}
		}
	});
});



$(document).on('click', '.toggleSettingSwitcher', function() {
	var state = $(this).attr('data-radio-state');
	let name = $(this).attr('data-fields-name');
	let id = $(this).attr('data-id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/setting/edit-setting.php',
			route: 'toggleSetting',
			state: state,
			name: name,
			id: id
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			var $item = $(`#${id}.stock-list`); 

			$item.hide(1000, function() {
				$item.remove();
			});
			
			pageData.overlayHide();
			pageData.rightSideModalHide();
		}
	});
});

$(document).on('keyup', '.set-barcode-label-width', function() {
	var $this = $(this);
	var $delay = 450;
	clearTimeout($this.data('timer'));
	$this.data('timer', setTimeout(function(){
		$.ajax({
			url: 'ajax_route.php',
			type: 'POST',
			data: {
				url: '/core/action/barcode/setBarcodeLabelSize.php',
				route: 'setBarcodeLabelSize',
				width: $this.val()
			},
			success: (data) => {
				console.log(data);
			}
		});

	}, $delay));
});


$(document).on('keyup', '.set-barcode-label-height', function() {
	var $this = $(this);
	var $delay = 450;
	clearTimeout($this.data('timer'));
	$this.data('timer', setTimeout(function(){
		$.ajax({
			url: 'ajax_route.php',
			type: 'POST',
			data: {
				url: '/core/action/barcode/setBarcodeLabelSize.php',
				route: 'setBarcodeLabelSize',
				height: $this.val()
			},
			success: (data) => {
				console.log(data);
			}
		});
	}, $delay));
});


$(document).on('click', '.add-general-info', function() {
	if(validate_all_input($('.general-info-input'))) {
		var companyName 		= $('.general-info-company-name').val();
		var companyContact 		= $('.general-info-contact-number').val();
		var companyDescription 	= $('.general-info-company-description').val();
		var companyAdress 		= $('.general-info-company-adress').val();

		// general-info-company-name
		// general-info-contact-number
		// general-info-company-description
		// general-info-company-adress
		
		$.ajax({
			url: 'ajax_route.php',
			type: 'POST',
			data: {
				route: 'setСompanyInfo',
				url: '/',
				companyName: companyName,
				companyContact: companyContact,
				companyDescription: companyDescription,
				companyAdress: companyAdress
			},
			dataType: 'json',
			success: (data) => {
				pageData.alert_notice(data.type, data.text);

				closeAndRemoveModal();
			}
		});
	}
});


$(document).on('click', '.notify-button', function() {
	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/notify/notify.php',
			route: 'changeNotifyState',
			changeNotifyState: true,
		},
		dataType: 'json',
		beforeSend: () => {},
		complete: () => {},
		success: (data) => {
			pageData.hideNotifyIndicator();
		}
	});
});


$(document).on('click', '.notify-item', function() {
	let custom_id = $(this).attr('data-id');
	let notify_id = $(this).attr('data-notify-id');
	let notify_title = $(this).find('.notify-title').text();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/notify/notify.php',
			route: 'getNotifyModal',
			getNotifyModal: true,
			customId: custom_id,
			notifyId: notify_id,
			notifyTitle: notify_title
		},
		dataType: 'json',
		success: (data) => {
			pageData.overlayShow();
			$('.container').append(data.res);
		}
	});
});

$(document).on('click', '.load-customer-add-modal', function() {
	remove_modal();

	const controllerIndex = $(this).attr('data-controller-index');
	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/customer/addCustomerModal.php',
			route: 'addCustomerModal',
			controllerIndex: controllerIndex
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);
		}
	});
});

$(document).on('click', '.add-customer', function() {
	$container = $('.modal-content');

	if(!is_required_input($container.find('.form-input'))) {
		return;
	}

	const prepare_data = prepare_form_data($container, '.add-customer-fields', 'fields-name');

	$.ajax({
		url: 'ajax_route.php',
		type: 'POST',
		dataType: 'json',
		data: {
			url: '/core/action/cusotmer/addCustomer.php',
			route: 'addCustomer',
			prepare_data: prepare_data,
			page: pageData.page(),
			type: pageData.type(),
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success') {
				pageData.overlayHide();
				closeAndRemoveModal();
				pageData.prependTable(data.table);
			}
		}
	});
});	

$(document).on('click', '.delete-customer', function() {
	const id = $(this).attr('data-delete-id');


	$.ajax({
		url: 'ajax_route.php',
		type: 'POST',
		dataType: 'json',
		data: {
			url: '/core/action/cusotmer/deleteCustomer.php',
			route: 'deleteCustomer',
			id: id,
			page: pageData.page(),
			type: pageData.type(),
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success') {
				pageData.rightSideModalHide();
				pageData.overlayHide();
				
				var $stock = $(`#${id}.stock-list`); 
				
				$stock.hide(1000, function() {
					$stock.remove();
				});
			}
		}
	});
});	



$(document).on('click', '.get-wholesale-order-report-modal', function() {
	const transaction_id = $(this).closest('.stock-list').find('.wholesale-transaction-id').attr('data-sort-value');

	$.ajax({
		type: 'POST',
		data: {
			'route': 'getWholesaleOrderReportModal',
			'page': pageData.page(),
			'transaction_id': transaction_id
		},
		dataType: 'json',
		success: (data) => {
			if(data.type) {
				pageData.alert_notice(data.type, data.text);
			} else {
				pageData.overlayShow();
				$('.container').append(data.res);
			}
		}
	});
});


$(document).on('click', '.choseBranchModal', function() {
	$.ajax({
		type: 'POST',
		data: {
			'route': 'chooseLocalBranch'
		},
		dataType: 'json',
		success: (data) => {
			pageData.overlayShow();
			$('.container').append(data.res);
		}
	});
});


$(document).on('click', '.activeLocalBranch', function() {
	const branchIndex = $(this).attr('data-branch-index');

	$.ajax({
		type: 'POST',
		data: {
			route: 'activeLocalBranch',
			branchIndex: branchIndex
		},
		success: (data) => {
			window.location.href = '/core/auth/logout?logout';
		}
	});
});

$(document).on('click', '.get-customer-balance-history', function() {
	const getCustomerId = $(this).closest('.stock-list').attr('id');

	$.ajax({
		url: 'ajax_route',
		type: 'POST',
		dataType: 'json',
		data: {
			url: '/core/action/customer/getCustomerHistoryBalance.php',
			route: 'getCustomerBalanceHistory',
			customerId: getCustomerId,
		},
		success: (data) => {
			pageData.overlayShow();
			$('.container').append(data.res);
		}
	});
});

$(document).on('click', '.update-customer', function() {
	$container = $('.modal_order_form');

	const prepare_data = prepare_form_data($container, '.edit-customer.edited', 'fields-name');
	
	$.ajax({
		url: 'ajax_route.php',
		type: 'POST',
		dataType: 'json',
		data: {
			route: 'editCustomer',
			prepare_data: prepare_data,
		},
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success') {
				for (key in prepare_data) {	
					pageData.update_table_row(key, prepare_data[key], Utils.getId__editModal());
				}
			}
		}
	});
});

$(document).on('click', '.create-new-customer-modal-form', function() {
	remove_modal();

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/customer/createCustomerForm.php',
			route: 'createCustomerForm',
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);
		}
	});
});

function createBackup() {
	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			route: 'createBackup',
			url: 'core/action/backup/make-backup.php',
		},
		async: true,
		beforeSend: function( ){
		},
		complete: function() {
		},		
		success: () => {
		}
	});
}
