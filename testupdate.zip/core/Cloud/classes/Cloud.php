<?php 

namespace core\Cloud\classes;
use core\classes\System\Constants;

class Cloud 
{
    // в классе init в методе нужно зарегистрировать в методе customControllerList
    public static function initControllerList() :array
    {
        return [
            'cloud_stock'             =>  Constants::RETAIL_CONTROLLER_DIR.'/stock/stock.controller.php',
            'cloud_transfer'          =>  Constants::CLOUD_DIR.'controller/transfer/transfer-form.controller.php',
            'cloud_admin'         	  =>  Constants::CLOUD_DIR.'controller/admin/admin.controller.php',
        ];
    }
}

