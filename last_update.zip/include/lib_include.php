<script src="/lib/js_lib/jquery-3.5.1.js?v=<?php echo time(); ?>"></script>
<script src="js/function.js?v=<?php echo time(); ?>"></script>
<script src="js/ajax.js?v=<?php echo time(); ?>"></script>
<script src="/lib/js_lib/print.min.js?v=<?php echo time(); ?>"></script>



<script type="text/javascript" language="javascript" src="lib/js_lib/data_tables/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="lib/js_lib/data_tables/dataTables.buttons.min.js"></script>
<script type="text/javascript" language="javascript" src="lib/js_lib/data_tables/jszip.min.js"></script>
<script type="text/javascript" language="javascript" src="lib/js_lib/data_tables/buttons.html5.min.js"></script>