<?php 

// if(!isset($_SESSION['user'])) {
//     $login_dir = '/login.php';
// 	header("Location: $login_dir");
// 	exit();      
// }

// test 
use core\classes\Privates\AccessManager;
use core\classes\System\Constants;
use core\classes\Utils\Utils;

require_once 'start.php';

session_write_close();

$routeLis = [
	//general
	'checkNewVersion'			=> ROOT.'/core/action/update/check_new_version.php',
	'downloadUpdate'			=> ROOT.'/core/action/update/download_update.php',
	'check_date'				=> ROOT.'/core/main/check_date.php',
	'activeLicense'				=> ROOT.'/core/main/license/active-license.php',
	'createBackup'				=> ROOT.'/core/action/backup/telegramBotDatabaseBackup.php',
	'setСompanyInfo'			=> ROOT.'/core/action/setting/setCompanyInfo.php',
	'quizModal'					=> ROOT.'/core/action/quizModal/quizModal.php',
	'changeNotifyState'			=> ROOT.'/core/action/notify/notify.php',
	'getNotifyModal'			=> ROOT.'/core/action/notify/notify.php',
	'chooseLocalBranch'			=> ROOT.'/core/action/branch/chooseLocalBranch.php',
	'activeLocalBranch'			=> ROOT.'/core/action/branch/activeLocalBranch.php',
	
	// products
	'addProduct'			=> ROOT.'/core/action/stock/add_stock.php',
	'editProduct'			=> ROOT.'/core/action/stock/edit_product.php',
	'deleteProducts'		=> ROOT.'/core/action/stock/delete_products.php',
	'getProductsById' 		=> ROOT.'/core/action/stock/get_products_by_id.php',
	'filtredProducts'		=> ROOT.'/core/action/stock/get_filter_stock.php',
	'editProductBarcodeModal' => ROOT.'/core/action/barcode/edit_product_barcode_modal.php',
	'printProductBarcodeModal' => ROOT.'/core/action/barcode/print_barcode_modal.php',
	'setProductBarcode'		=> ROOT.'/core/action/barcode/set_product_barcode.php',
	'generateBarcode'		=> ROOT.'/core/action/barcode/generate_new_barcode.php',
	'getOutOfStockProducts'	=> ROOT.'/core/action/stock/outOfStockProducts/getOutOfStockProducts.php',
	'getProductHistory'		=> ROOT.'/core/action/stock/get_products_history.php',
	'getProductHistoryByTransaction' => ROOT.'/core/action/stock/get_product_history_transaction.php',

	// checkout
	'addToCart' 			=> ROOT.'/core/action/cart/cart_item_row.php',
	'checkout'				=> ROOT.'/core/action/cart/checkout.php',
	'applyCashback'			=> ROOT.'/core/action/customer/applyCustomerCashback.php',
	'spendCashback'			=> ROOT.'/core/action/customer/spendCustomerCashback.php',
	'cashbackPayModal'		=> ROOT.'/core/action/customer/cashbackPayModal.php',

	'search'				=> ROOT.'/core/action/search/search.php',
	'autocomplete' 			=> ROOT.'/core/action/search/autocomplete.php',
	'advancedSearch'		=> ROOT.'/core/action/search/advanced_search.php',
	
	'modal'					=> ROOT.'/core/action/modal/modal.php',
	'appendMoreFields'		=> ROOT.'/core/action/add_more_fields.php',

	'appendStoriesModal'		=> ROOT.'/core/action/stories/appendStoriesModal.php',
	'getStories'				=> ROOT.'/core/action/stories/getStories.php',

	// report
	'editReport'			=> ROOT.'/core/action/report/edit.php',
	'deleteReport'			=> ROOT.'/core/action/report/delete.php',
	'refaundReport'			=> ROOT.'/core/action/report/refaund.php',
	'searchTransactionId'	=> ROOT.'/core/action/report/search.php',
	
	'includeStats'			=> ROOT.'/core/pulgin/stats_card/stats_report.php',
	'reportChart'			=> ROOT.'/core/pulgin/charts/report_month_chart_stats.php',
	'reportChartCategory'	=> ROOT.'/core/pulgin/charts/report_category_charts.php',
	'reportChartProvider'	=> ROOT.'/core/pulgin/charts/report_provider_charts.php',
	'reportTopProducts'		=> ROOT.'//core/pulgin/charts/report_top_products.php',

	'modal__getReportByTransaction'		=> ROOT.'/core/action/report/modal__getReportBYTransaction.php',

	//cash register
	'loadDepositModal'		=> ROOT.'/core/action/cash-register/modal/deposit.php',
	'loadWithdrawModal'		=> ROOT.'/core/action/cash-register/modal/withdraw.php',
	'applyDeposit'			=> ROOT.'/core/action/cash-register/apply-deposit.php',
	'applyWithdraw'			=> ROOT.'/core/action/cash-register/apply-withdraw.php',
	'filterCashRegister'	=> ROOT.'/core/action/cash-register/filterCashRegister.php',

	'analyticsChartsTopProductsByInterval' => ROOT.'/core/action/analytics/charts-get-top-selling-by-interval.php',
	'analyticsTableTopProductsByInterval' => ROOT.'/core/action/analytics/table-get-top-selling-by-interval.php',
	'analyticsTableNoSalesProductsByInterval' => ROOT.'/core/action/analytics/table-get-no-selling-by-interval.php',
	'analyticsChartsTopCategoryByInterval' => ROOT.'/core/action/analytics/charts-get-top-category.php',
	'analyticsChartsTopProviderByInterval' => ROOT.'/core/action/analytics/charts-get-top-provider-by-interval.php',
	'analyticsTableTopCategoryByInterval' => ROOT.'/core/action/analytics/table-get-top-selling-category-by-interval.php',
	'analyticsChartsTopSellerByInterval' 	=> ROOT.'/core/action/analytics/charts-top-seller-interval.php',
	'analyticsTableTopSeller' 	=> ROOT.'/core/action/analytics/table-get-top-seller.php',
	
	
	'scanBarcode' 			=> ROOT.'/core/action/barcode/scanBarcode.php',	
	'changeA4BarcodeCount'  => ROOT.'/core/action/barcode/generateMultipleBarcode.php',

	// expense
	'editExpense'			=> ROOT.'/core/action/expense/edit_expense.php',
	'deleteExpense'			=> ROOT.'/core/action/expense/delete_expense.php',
	'addExpense'			=> ROOT.'/core/action/expense/add_expense.php',

	// transfer
	'addTransfer'			=> ROOT.'/core/action/warehouse-transfer/add-transfer.php',

	// arrival
	'addArrivalProducts'	=> ROOT.'/core/action/arrival-products/add-arrival-products.php',

	// writeoff
	'addWriteOff'			=> ROOT.'/core/action/write-off-products/add-write-off-products.php',


	//admin
	'addUser'				=> ROOT.'/core/action/admin/user/add-user.php',
	'deleteUser'			=> ROOT.'/core/action/admin/user/delete-user.php',
	'editUser'				=> ROOT.'/core/action/admin/user/edit-user.php',
	'addUserModalForm'		=> ROOT.'/core/action/admin/user/addUserModalForm.php',

	//category
	'addCategory' 			=> ROOT.'/core/action/category/add-category.php',
	'editCategory' 			=> ROOT.'/core/action/category/edit-category.php',
	'deleteCategory' 		=> ROOT.'/core/action/category/delete-category.php',
	'addCategoryModal' 		=> ROOT.'/core/action/category/addCategoryModal.php',


	//warehouse
	'addWarehouse'			=> ROOT.'/core/action/warehouse/add-warehouse.php',
	'editWarehouseInfo'		=> ROOT.'/core/action/warehouse/edit-warehouse.php',
	'deleteWarehouse'		=> ROOT.'/core/action/warehouse/delete-warehouse.php',
	'addWarehouseModalForm'	=> ROOT.'/core/action/warehouse/addWarehouseModalForm.php',

	//payment method
	'addPaymentMethod'		=> ROOT.'/core/action/payment-method/add-payment-method.php',
	'editPaymentMethod'		=> ROOT.'/core/action/payment-method/edit-payment-method.php',
	'deletePaymentMethod'	=> ROOT.'/core/action/payment-method/delete-payment-method.php',
	'paymentMethodModal'	=> ROOT.'/core/action/payment-method/paymentMethodModal.php',

	// provider
	'addProvider'			=> ROOT.'/core/action/provider/add-provider.php',
	'editProvider'			=> ROOT.'/core/action/provider/edit-provider.php',
	'deleteProvider'		=> ROOT.'/core/action/provider/delete-provider.php',
	'addProviderModal'		=> ROOT.'/core/action/provider/addProviderModal.php',
	
	// filter
	'addFilter'				=> ROOT.'/core/action/filter/add-filter.php',
	'deleteFilter'			=> ROOT.'/core/action/filter/delete-filter.php',
	'editFilter'			=> ROOT.'/core/action/filter/edit-filter.php',
	'addFilterFormModal'	=> ROOT.'/core/action/filter/createFilterModal.php',

	'toggleSetting'			=> ROOT.'/core/action/setting/edit-setting.php',
	'setBarcodeLabelSize'	=> ROOT.'/core/action/barcode/setBarcodeLabelSize.php',

	'sendfirebase'			=> ROOT.'/sendfirebase.php',
	'appSync'				=> ROOT.'/core/main/webSync.php',


	//customer
	'addCustomerModal' 	    		=> Constants::ROOT_DIR.'/core/action/Wholesale/customer/addCustomerModal.php',
	'getCustomerBalanceHistory'  	=> Constants::ROOT_DIR.'/core/action/customer/getCustomerHistoryBalance.php',
	'getCustomerInfo'				=> ROOT.'/core/action/customer/getCustomerInfo.php',
	'createCustomerForm'			=> ROOT.'/core/action/customer/createCustomerForm.php',
	'editCustomer'					=> ROOT.'/core/action/customer/editCustomer.php',
	'addCustomer'					=> ROOT.'/core/action/customer/addCustomer.php',
	'deleteCustomer'				=> ROOT.'/core/action/customer/deleteCustomer.php',

	'getWholesaleOrderReportModal'  => Constants::ROOT_DIR.'/core/action/Wholesale/report/showReportOrder.php',


	//cloud product
	'cloudProductTransfer'			=> Constants::CLOUD_DIR.'action/product/product-transfer.php',
	'cloudEditProduct'				=> Constants::CLOUD_DIR.'action/product/product-edit.php',
	'cloudDeleteProduct'			=> Constants::CLOUD_DIR.'action/product/product-delete.php',
	//cloud category
	'cloudEditCategory'				=> Constants::CLOUD_DIR.'action/category/edit-category.php',
	'cloudDeleteCategory'			=> Constants::CLOUD_DIR.'action/category/delete-category.php',
	//cloud provider
	'cloudEditProvider'				=> Constants::CLOUD_DIR.'action/provider/edit-provider.php',
	'cloudDeleteProvider'			=> Constants::CLOUD_DIR.'action/provider/delete-provider.php',
	//cloud admin
	'cloudGetBranchUsers'			=> Constants::CLOUD_DIR.'/action/admin/getBranchUsers.php',
	'setUserBranch'					=> Constants::CLOUD_DIR.'/action/admin/setUserBranch.php',
];

$route = $_POST['route'];

AccessManager::accessActionRoute($route, function($hasAccess) {
	if($hasAccess) {
		echo Utils::abort([
			'type' => 'error',
			'text' => 'access denied!'
		]);

		die;
	}
});

require $routeLis[$route]; 

