<?php 
/**
 * В этом файле мы будуем мигрировать базу данных с версии на версию
 * Будут проверяться и синхронизироваться таблцы базы данных
 * 
 */
// require_once $_SERVER['DOCUMENT_ROOT'].'/core/main/auto_install_dbsql.php';

header('Location: /');

exit();