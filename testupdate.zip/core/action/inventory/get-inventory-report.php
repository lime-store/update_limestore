<?php
header('Content-type: Application/json');

use core\classes\Inventory\Inventory;
use core\classes\Utils\Utils;

require __DIR__.'/_helpers.php';

$inventoryId = (int) ($_POST['inventory_id'] ?? 0);

if($inventoryId <= 0) {
    Utils::errorAbort('Sayim seçilməyib');
    return;
}

try {
    $report = Inventory::report($inventoryId);
} catch (\Throwable $e) {
    Utils::errorAbort(inventoryErrorMessage($e));
    return;
}

Utils::abort([
    'type'         => 'success',
    'text'         => 'Sayım hesabatı',
    'report_modal' => renderInventoryReportModal($report),
]);
