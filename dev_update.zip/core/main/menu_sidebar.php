<?php 
	require_once($_SERVER['DOCUMENT_ROOT'].'/function.php');
	get_product_root_dir();

?>




<div class="sidebar_menu_block">
	<div class="sider_bar_menu_header">
		<span class="module_order_desrioption">Menu</span>
	</div>
	<div class="sider_bar_list_wrp">
		<ul class="sider_bar_list">
			<li class="menu_list">
				<a href="javascript:void(0)" class="sidebar_link select_page_main" data-link="<?php echo $menu_link_for_terminal ?>">
					<div class="sidebar_menu_image">
						<img src="img/icon/sidebar/store.png">
					</div>					
					<span class="sidebar_menu_link_nmae">Malların satışı</span>
				</a>
			</li>
			<li class="menu_list">
				<a href="javascript:void(0)" class="sidebar_link select_page_main" data-link="<?php echo $menu_link_for_stock ?>">
					<div class="sidebar_menu_image">
						<img src="img/icon/sidebar/stock.png">
					</div>					
					<span class="sidebar_menu_link_nmae">Malların alışı</span>
				</a>
			</li>
			<li class="menu_list">
				<a href="javascript:void(0)" class="sidebar_link select_page_main" data-link="<?php echo $menu_link_for_report ?>">
					<div class="sidebar_menu_image">
						<img src="img/icon/sidebar/report.png">
					</div>					
					<span class="sidebar_menu_link_nmae">Hesabat</span>
				</a>
			</li>
			<li class="menu_list">
				<a href="javascript:void(0)" class="sidebar_link select_page_main" data-link="<?php echo $menu_link_for_note ?>">
					<div class="sidebar_menu_image">
						<img src="img/icon/sidebar/note.png">
					</div>					
					<span class="sidebar_menu_link_nmae">Sifarişlər</span>
				</a>
			</li>
			<li class="menu_list">
				<a href="javascript:void(0)" class="sidebar_link select_page_main" data-link="<?php echo $menu_link_for_raxdod ?>">
					<div class="sidebar_menu_image">
						<img src="img/icon/sidebar/rasxod.png">
					</div>					
					<span class="sidebar_menu_link_nmae">Xərc (Rasxod)</span>
				</a>
			</li>
			<li class="menu_list">
				<a href="javascript:void(0)" class="sidebar_link select_page_main" data-link="<?php echo $menu_link_for_recycle ?>">
					<div class="sidebar_menu_image">
						<img src="img/icon/sidebar/trash.png">
					</div>					
					<span class="sidebar_menu_link_nmae">Zibil qutusu</span>
				</a>
			</li>																	
		</ul>
	</div>
</div>