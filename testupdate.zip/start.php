<?php
require_once 'vendor/autoload.php';

require_once 'autoload.php';

use core\classes\Utils\Utils;

use core\classes\Privates\AccessManager;
use core\classes\System\Init;
use core\classes\System\LicenseManager;


// $loader = new \Twig\Loader\FilesystemLoader($_SERVER['DOCUMENT_ROOT'].'/core/template/');
// $twig = new \Twig\Environment($loader);

$System = new \core\classes\System\System;

$Render = new \core\classes\Services\RenderTemplate;

$db = new \core\classes\dbWrapper\db;

$main = new \core\classes\System\Main;

$accessManager = new AccessManager;

$init = Init::getInstance();

$utils = new Utils;

$licenseManager = new LicenseManager;

$productsFilter = new \core\classes\Services\ProductsFilter;

$category = new \core\classes\Services\Category;

$provider = new \core\classes\Services\Provider;

$user = new \core\classes\Privates\User;

$products = new \core\classes\Products;
