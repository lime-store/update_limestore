<?php

namespace core\Cloud\classes\Sync\Traits;

use core\classes\Products;
use core\classes\Services\BaseService;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\dbWrapper\db;
use core\classes\Services\Warehouse\Warehouse;

trait Category
{
    /**
     * 
     */
    public static function getSyncedBranchesForCategory(int $categoryId)
    {
        return qb::select('branch_id')
            ->from('products_category_list')
            ->where('id_from_category', $categoryId)
            ->where('status', BaseService::CLOUD_PAYLOAD_STATUS['done'])
            ->innerJoin('sync_queue', 'sync_queue.product_id = products_category_list.id_from_stock')
            ->groupBy('sync_queue.branch_id')
            ->get();        
    }

    /**
     * 
     */
    public static function editCategoryTask(int $categoryId)
    {
        $branches = self::getSyncedBranchesForCategory($categoryId);
        
        $category = qb::select('*')
                    ->from('stock_category')
                    ->where('category_id', $categoryId)
                    ->first()
                    ->get();

        if(empty($branches) && empty($category)) {
            return;
        }

        foreach($branches as $branch) {
            db::insert('sync_queue', [
                [
                    'branch_id'     => $branch['id'],
                    'product_id'    => 0,
                    'action'        => BaseService::CLOUD_PAYLOAD_ACTION['editCategory'],
                    'status'        => BaseService::CLOUD_PAYLOAD_STATUS['pending'],
                    'payload'       => json_encode([
                        'categoryInfo'  => $category,
                    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                ]
            ]);
        }
    }

    /**
     * 
     */
    public static function deleteCategoryTask(int $categoryId)
    {
        $branches = self::getSyncedBranchesForCategory($categoryId);
        
        $category = qb::select('*')
                    ->from('stock_category')
                    ->where('category_id', $categoryId)
                    ->first()
                    ->get();

        if(empty($branches) && empty($category)) {
            return;
        }

        foreach($branches as $branch) {
            db::insert('sync_queue', [
                [
                    'branch_id'     => $branch['id'],
                    'product_id'    => 0,
                    'action'        => BaseService::CLOUD_PAYLOAD_ACTION['deleteCategory'],
                    'status'        => BaseService::CLOUD_PAYLOAD_STATUS['pending'],
                    'payload'       => json_encode([
                        'categoryInfo'  => $category,
                    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                ]
            ]);
        }        
    }
}
