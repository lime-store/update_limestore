<?php 
	require_once '../../function.php';
	// //Показывать товары которые находться в базе больше 15 дней 
	// settShowOldProduct();

	// //кнопка компактного меню на странице
	// modalNavigationBtn();

	// //выводим компакнтное меню на странице 
	// getModalSideBarNav();

	// //блок для принта чека
	// printModal();

	// //выводим перекючения вкладок 
	// getCurrentTab(); 


	//получаем тип таблицы
	get_table_svervice_type();

	//получем категорию товара
	get_product_category();

	//заголовок таблицы
	get_table_header();		

?>

	<div class="view_stock_box_wrp">
		<div class="search_filter_wrapper">
			<?php
				/*фильтр*/ get_filter_root();
				/*начало тут выводим поиск*/  search_input($terminal, $product_akss); 
			?>
			
		</div>
		<div class="stock_view_wrapper">
			<div class="stock_view_list ls-custom-scrollbar">
	<table class="stock_table">
		<thead>
				<tr>
					<?php 
						echo  $tabel_header['th_serial'];
						echo  $tabel_header['th_prod_name'];
						echo  $tabel_header['th_buy_price'];
						echo  $tabel_header['th_sale_price'];
						echo  $tabel_header['th_count'];
						echo  $tabel_header['th_category'];
					?>						
				  </tr>
		</thead>
		<tbody class="stock_list_tbody" data-stock-src="<?php echo  $terminal; ?>" data-category="<?php echo $product_akss; ?>">				  
				<?php 
					$product_category = $product_akss;
					$akss_stock_list = [];
					$akss_stock_view = $dbpdo->prepare("SELECT * FROM stock_list 
												   WHERE stock_count > 0 
												   AND stock_visible = 0
												   AND stock_type = ?
												   GROUP BY stock_id DESC");
					$akss_stock_view->execute([$product_category]);
					if($akss_stock_view->rowCount()>0) {
						while ($akss_stock_row = $akss_stock_view->fetch(PDO::FETCH_BOTH))
							$akss_stock_list[] = $akss_stock_row;

						foreach ($akss_stock_list as $akss_stock_row)
						{
							$stock_id 				= $akss_stock_row['stock_id'];
							$stock_name 			= $akss_stock_row['stock_name'];
							$stock_first_price		= $akss_stock_row['stock_first_price'];
							$stock_second_price 	= $akss_stock_row['stock_second_price'];
							$stock_count 			= $akss_stock_row['stock_count'];
							$stock_provider 		= $akss_stock_row['stock_provider'];
							$stock_get_date 		= $akss_stock_row['stock_get_fdate'];

							$get_product_table = array( 'stock_id'  			=> 	$stock_id,
													    'stock_name' 			=> 	$stock_name,
													    'stock_first_price' 	=> 	$stock_first_price, 
													    'stock_second_price' 	=> 	$stock_second_price,
													    'stock_count'			=>  $stock_count,
													    'stock_provider'		=> 	$stock_provider,
													    'stock_get_date'		=>  $stock_get_date, 
													    'manat_image' 			=>  $manat_image
													);
							get_terminal_akss_table_row($get_product_table);

						}
					}

				?>
					</tbody>
				</table>
			</div>
		</div>
		
	</div>


<?php 
	//выводим модальное окно для оформления заказа
	get_modal_tamplate_checkout_tem();
?>	