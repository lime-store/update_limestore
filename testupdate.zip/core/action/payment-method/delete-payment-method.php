<?php

use core\classes\Utils\Utils;

header('Content-type: Application/json');

$Payment = new core\classes\Cart\Payment;

if(empty($_POST['payment_method_id'])) {
    return Utils::abort([
        'type' => 'error',
        'texy' => 'Empty'
    ]);
    exit;
}

if($_POST['payment_method_id'] != 1 || $_POST['payment_method_id'] != 2) {
    return Utils::errorAbort('Этот способ оплаты удалить нельзя');
}

$Payment->deletePaymentMethod([
    'payment_method_id' => $_POST['payment_method_id']
]);

echo $utils::successAbort('Ok');