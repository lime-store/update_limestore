<?php

use core\classes\System\Migration;

Migration::createTableIfNotExist('log_product_stock_history', "
        CREATE TABLE log_product_stock_history (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            
            product_id BIGINT UNSIGNED NOT NULL,

            quantity_before decimal(10,2) NOT NULL DEFAULT 0,
            quantity_change decimal(10,2) NOT NULL DEFAULT 0,         -- дельта: +10, -3, и т.д.
            quantity_after  decimal(10,2) NOT NULL DEFAULT 0,         -- остаток ПОСЛЕ операции (важно!)
            
            reference_type VARCHAR(50) NULL,                          -- например 'order', 'invoice', 'manual'
            reference_id BIGINT UNSIGNED NULL,                        -- id связанной сущности (заказа, накладной)
            
            comment VARCHAR(255) NULL,                                -- человекочитаемая причина
            
            user_id BIGINT UNSIGNED NULL,                             -- кто внёс изменение
            
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            
            INDEX idx_product_branch (product_id, id),
            INDEX idx_reference (reference_type, reference_id)
        );
");


Migration::createTableIfNotExist('cash_registers', "
        CREATE TABLE cash_registers (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            payment_method int(11) NULL,
            transaction_id BIGINT UNSIGNED NULL,

            amount_before decimal(10,2) NOT NULL DEFAULT 0,
            amount_change decimal(10,2) NOT NULL DEFAULT 0,         
            current_balance  decimal(10,2) NOT NULL DEFAULT 0,         
            
            type VARCHAR(50) NULL,

            comment VARCHAR(255) NULL,

            user_id BIGINT UNSIGNED NULL,

            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            
            INDEX idx_cash_register_id (id, user_id),
            INDEX idx_cash_register_type (type)
        );
");