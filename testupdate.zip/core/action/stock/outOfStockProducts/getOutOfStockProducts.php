<?php

use Core\Classes\System\Init;
use Core\Classes\Utils\Utils;
header('Content-type: Application/json');

$initStockController = Init::getControllerData('stock')->getAllData();

$sql = $initStockController['sql'];

$sql['query']['body'] = " AND stock_list.stock_visible = 0 
                         AND stock_list.min_quantity_stock = 0
                         AND stock_list.stock_count <= 0 ";


$table_result = $main->prepareData($sql, $initStockController['page_data_list']);

$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/custom_modal/u_modal.twig' => [
            'modalController' => [
                'title' => 'Stokda olmayan məhsullar',
                'closeButtonClassList' => 'removeModal',
            ],
            'modalContent' => [
                'path' => '/component/table/table_wrapper.twig',
            ],
            'containerClassList' => 'large-modal',
            'class_list' => '',
            'table' => $table_result['result'], 
             
		]  
	]
]);


$utils::abort([
	'res' => $total,
]);
