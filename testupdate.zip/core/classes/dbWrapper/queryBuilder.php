<?php

namespace core\classes\dbWrapper;

use core\classes\dbWrapper\db;

class queryBuilder
{
    // -------------------------------------------------------------------------
    // Части запроса храним раздельно (а не одной строкой), это и чинит баги
    // с повторным where()/orderBy()/limit() и т.д.
    // -------------------------------------------------------------------------
    private string  $selectCols       = '*';
    private string  $fromTable        = '';
    private array   $joins            = [];
    private array   $whereConditions  = [];
    private array   $groupByCols      = [];
    private array   $havingConditions = [];
    private array   $orderByParts     = [];
    private ?int    $limitValue       = null;
    private ?int    $offsetValue      = null;

    // готовый "сырой" запрос для insert/update/delete/raw() — если задан,
    // buildQuery() отдаёт его как есть, минуя select-конструктор
    private ?string $customQuery = null;

    private array  $bindList = [];
    private        $result   = [];
    private bool   $executed = false;
    private        $stmt     = null;
    private int    $bindCounter = 0;

    private array  $settings = [
        'fetch_type'   => \PDO::FETCH_ASSOC,
        'placeholders' => 'named',
        'bindType'     => 'bindValue',
        'cursor'       => true, // как и раньше — по умолчанию PDO::CURSOR_SCROLL
    ];

    // -------------------------------------------------------------------------
    // Построение запроса (старый API — сигнатуры не менялись)
    // -------------------------------------------------------------------------

    public static function select(string $select = '*')
    {
        $instance = new static();
        $instance->selectCols = $select;
        return $instance;
    }

    public function addSelect(string $select)
    {
        $this->selectCols = $this->selectCols === '*'
            ? $select
            : $this->selectCols . ", $select";
        return $this;
    }

    public function from(string $tableName)
    {
        $this->fromTable = $tableName;
        return $this;
    }

    public function where(string $where, $value = null)
    {
        // новое: where('col', $value) — сам создаёт плейсхолдер и биндит значение.
        // старое: where('col = :col') — сырое условие, бинды через bindList() как раньше.
        // отличаем режимы через func_num_args(), а не через $value !== null,
        // чтобы where('col', null) тоже можно было забиндить как NULL, если понадобится
        if (func_num_args() >= 2) {
            $key = ':w_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $where) . '_' . $this->bindCounter++;
            $this->bindList[$key] = $value;
            $where = "$where = $key";
        }

        // раньше: повторный вызов давал "WHERE a WHERE b " — синтаксическая ошибка.
        // теперь условия просто копятся и клеятся через AND
        $this->whereConditions[] = $where;
        return $this;
    }

    public function whereBetween(string $column, $from, $to)
    {
        $keyFrom = ':wb_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $column) . '_' . $this->bindCounter++;
        $keyTo   = ':wb_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $column) . '_' . $this->bindCounter++;

        $this->bindList[$keyFrom] = $from;
        $this->bindList[$keyTo]   = $to;

        return $this->where("$column BETWEEN $keyFrom AND $keyTo");
    }
    
    public function join(string $join)
    {
        $this->joins[] = "JOIN $join";
        return $this;
    }

    public function innerJoin(string $tableName, string $on, array $bindConditions = [])
    {
        $on = $this->appendJoinBindConditions($on, $bindConditions);
        $this->joins[] = "INNER JOIN $tableName ON $on";
        return $this;
    }

    public function leftJoin(string $tableName, string $on, array $bindConditions = [])
    {
        $on = $this->appendJoinBindConditions($on, $bindConditions);
        $this->joins[] = "LEFT JOIN $tableName ON $on";
        return $this;
    }

    private function appendJoinBindConditions(string $on, array $bindConditions): string
    {
        // новое: innerJoin('images', 'images.product_id = products.id', ['images.is_main' => 1])
        // сам добавит "AND images.is_main = :j_images_is_main_0" и забиндит значение.
        // старое: innerJoin($table, $on) без третьего аргумента — работает как раньше
        foreach ($bindConditions as $column => $value) {
            $key = ':j_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $column) . '_' . $this->bindCounter++;
            $this->bindList[$key] = $value;
            $on .= " AND $column = $key";
        }
        return $on;
    }

    public function orderBy(string $colName, string $direction = 'ASC')
    {
        // раньше: повторный вызов давал два "ORDER BY" подряд — ошибка SQL
        $this->orderByParts[] = "$colName $direction";
        return $this;
    }

    public function groupBy(string $colName)
    {
        $this->groupByCols[] = $colName;
        return $this;
    }

    public function having(string $having)
    {
        $this->havingConditions[] = $having;
        return $this;
    }

    public function limit(int $limit)
    {
        // раньше: повторный вызов дублировал "LIMIT N LIMIT M" — ошибка SQL.
        // теперь просто перезаписывает значение, как и ожидается интуитивно
        $this->limitValue = $limit;
        return $this;
    }

    public function offset(int $offset)
    {
        $this->offsetValue = $offset;
        return $this;
    }

    public function bindList(array $bindList)
    {
        // поведение как раньше: полностью заменяет список биндов
        $this->bindList = $bindList;
        return $this;
    }

    public function setSettings(array $settings)
    {
        $this->settings = array_merge($this->settings, $settings);
        return $this;
    }

    // -------------------------------------------------------------------------
    // Условия — новое, но не конфликтует со старым API
    // -------------------------------------------------------------------------

    public function andWhere(string $where, $value = null)
    {
        if (func_num_args() >= 2) {
            return $this->where($where, $value);
        }
        return $this->where($where);
    }

    public function orWhere(string $where, $value = null)
    {
        if (func_num_args() >= 2) {
            $key = ':w_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $where) . '_' . $this->bindCounter++;
            $this->bindList[$key] = $value;
            $where = "$where = $key";
        }

        if (empty($this->whereConditions)) {
            $this->whereConditions[] = $where;
            return $this;
        }
        $last = array_pop($this->whereConditions);
        $this->whereConditions[] = "$last OR $where";
        return $this;
    }

    public function whereIn(string $column, array $values)
    {
        if (empty($values)) {
            // пустой IN() — валидный эквивалент "никогда не true"
            return $this->where('1 = 0');
        }

        $placeholders = [];
        foreach (array_values($values) as $value) {
            $key = ':in_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $column) . '_' . $this->bindCounter++;
            $placeholders[] = $key;
            $this->bindList[$key] = $value;
        }

        return $this->where("$column IN (" . implode(', ', $placeholders) . ')');
    }

    public function whereNull(string $column)
    {
        return $this->where("$column IS NULL");
    }

    public function whereNotNull(string $column)
    {
        return $this->where("$column IS NOT NULL");
    }

    // -------------------------------------------------------------------------
    // RAW — новое
    // -------------------------------------------------------------------------

    public static function raw(string $sql, array $bindings = [])
    {
        $instance = new static();
        $instance->customQuery = $sql;
        $instance->bindList = $bindings;
        return $instance;
    }

    // -------------------------------------------------------------------------
    // Выполнение запроса
    // -------------------------------------------------------------------------

    private function buildQuery(): string
    {
        if ($this->customQuery !== null) {
            return trim($this->customQuery);
        }

        $sql = "SELECT {$this->selectCols} ";
        $sql .= "FROM {$this->fromTable} ";

        foreach ($this->joins as $join) {
            $sql .= "$join ";
        }

        if (!empty($this->whereConditions)) {
            $sql .= 'WHERE ' . implode(' AND ', $this->whereConditions) . ' ';
        }

        if (!empty($this->groupByCols)) {
            $sql .= 'GROUP BY ' . implode(', ', $this->groupByCols) . ' ';
        }

        if (!empty($this->havingConditions)) {
            $sql .= 'HAVING ' . implode(' AND ', $this->havingConditions) . ' ';
        }

        if (!empty($this->orderByParts)) {
            $sql .= 'ORDER BY ' . implode(', ', $this->orderByParts) . ' ';
        }

        if ($this->limitValue !== null) {
            $sql .= "LIMIT {$this->limitValue} ";
        }

        if ($this->offsetValue !== null) {
            $sql .= "OFFSET {$this->offsetValue} ";
        }

        return trim($sql);
    }

    public function execute()
    {
        $sql = $this->buildQuery();

        $placeholders = $this->settings['placeholders'];
        $fetchType    = $this->settings['fetch_type'];
        $bindType     = $this->settings['bindType'];

        $driverOptions = !empty($this->settings['cursor'])
            ? [\PDO::ATTR_CURSOR => \PDO::CURSOR_SCROLL]
            : [];

        try {
            $stmt = db::$dbpdo->prepare($sql, $driverOptions);

            if ($placeholders === 'named') {
                foreach ($this->bindList as $key => $value) {
                    if ($bindType === 'bindParam') {
                        $stmt->bindParam($key, $value);
                    } else {
                        $stmt->bindValue($key, $value);
                    }
                }
                $stmt->execute();
            } elseif ($placeholders === 'positional') {
                $stmt->execute($this->bindList);
            } else {
                $stmt->execute();
            }

            $this->stmt = $stmt;

            // fetchAll имеет смысл только для SELECT — на INSERT/UPDATE/DELETE
            // раньше это молча упало бы или вернуло мусор
            if (stripos(ltrim($sql), 'SELECT') === 0) {
                $this->result = $stmt->fetchAll($fetchType);
            } else {
                $this->result = [];
            }

            $stmt->closeCursor();
            $this->executed = true;
        } catch (\PDOException $e) {
            // пробрасываем то же исключение, но с контекстом запроса — сильно
            // экономит время при отладке
            throw new \PDOException(
                $e->getMessage() . ' | Query: ' . $sql . ' | Bindings: ' . json_encode($this->bindList, JSON_UNESCAPED_UNICODE),
                (int) $e->getCode(),
                $e
            );
        }

        return $this;
    }

    private function ensureExecuted(): void
    {
        if (!$this->executed) {
            $this->execute();
        }
    }

    // -------------------------------------------------------------------------
    // Получение результата
    // -------------------------------------------------------------------------

    public function all(): array
    {
        $this->ensureExecuted();
        return (array) $this->result;
    }

    public function first()
    {
        $this->ensureExecuted();
        $this->result = $this->result[0] ?? [];
        return $this;
    }

    public function last(?string $orderByColumn = null, string $direction = 'DESC')
    {
        if ($orderByColumn !== null) {
            $this->orderByParts = ["$orderByColumn $direction"];
        } elseif (!empty($this->orderByParts)) {
            // разворачиваем заданный orderBy — LIMIT 1 после разворота даёт
            // настоящую последнюю запись по этой сортировке
            $this->orderByParts = array_map(function ($part) {
                if (preg_match('/^(.+)\s+(ASC|DESC)$/i', $part, $m)) {
                    return $m[1] . ' ' . (strtoupper($m[2]) === 'ASC' ? 'DESC' : 'ASC');
                }
                return "$part DESC";
            }, $this->orderByParts);
        } else {
            // без сортировки "последняя запись" не определена — лучше явная
            // ошибка, чем тихий возврат случайной строки
            throw new \LogicException(
                'last() требует orderBy() перед собой либо явную колонку: last(\'id\')'
            );
        }

        $this->limit(1);
        $this->executed = false;
        $this->execute();
        $this->result = $this->result[0] ?? [];

        return $this;
    }

    public function columnName(string $columnName)
    {
        $this->ensureExecuted();

        // старый сценарий использования: вызывается после first(), когда
        // $result — это одна строка (ассоц. массив)
        if (is_array($this->result) && array_key_exists($columnName, $this->result)) {
            $this->result = $this->result[$columnName];
            return $this;
        }

        // новое: если result — список строк, отдаём массив значений колонки
        // (раньше в этом случае метод молча возвращал null)
        $this->result = array_column((array) $this->result, $columnName);
        return $this;
    }

    public function get()
    {
        $this->ensureExecuted();
        return $this->result;
    }

    // -------------------------------------------------------------------------
    // Новые хелперы
    // -------------------------------------------------------------------------

    public function value(string $columnName)
    {
        $this->ensureExecuted();
        $row = $this->result[0] ?? null;
        return $row[$columnName] ?? null;
    }

    public function pluck(string $columnName): array
    {
        $this->ensureExecuted();
        return array_column((array) $this->result, $columnName);
    }

    public function count(): int
    {
        $this->ensureExecuted();
        return count((array) $this->result);
    }

    public function exists(): bool
    {
        $this->ensureExecuted();
        return count((array) $this->result) > 0;
    }

    public function rowCount(): int
    {
        return $this->stmt ? $this->stmt->rowCount() : 0;
    }

    public function lastInsertId()
    {
        return db::$dbpdo->lastInsertId();
    }

    public function toSql(): string
    {
        return $this->buildQuery();
    }

    public function getBindings(): array
    {
        return $this->bindList;
    }

    public function __toString(): string
    {
        return $this->toSql();
    }
}