<?php
use Core\Classes\System\Init;
use Core\Classes\Utils\Utils;
use Core\Classes\Report;
use core\classes\Services\tableFooter;

header('Content-type: Application/json');


if(empty($_POST['transaction_id'])) {
	Utils::errorAbort('cant find transaction id'); 
	exit;
}

$transaction_id = $_POST['transaction_id'];

$initStockController = Init::getControllerData('report')->getAllData();

$table_result = $main->prepareCustomData(Report::getReportByColumn('transaction_id', $transaction_id, [0, 3]), [
	'get_data' => [
            'sales_date'  		    => 'order_date',
            'name'			 	    => 'stock_name',
            'description'		    => 'stock_phone_imei',
            'report_note'		    => 'order_who_buy',
            'second_price'		    => 'order_stock_sprice',
            'count'				    => 'order_stock_count',
            'report_total_amount'   => 'order_stock_total_price',
            'report_profit'		    => 'order_total_profit',
            'report_order_date'		=> 'order_my_date',
	]
]);


$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/custom_modal/u_modal.twig' => [
            'modalController' => [
                'title' => 'Satış fakturası',
                'closeButtonClassList' => 'removeModal',
            ],
            'modalContent' => [
                'path' => '/component/include_once_component.twig',
            ],
            'containerClassList' => 'large-modal',
            'class_list' => '',
			'includs' => [
				'getOutOfStockProducts' => [
					'/component/parts/input.twig' => [
						'inputClassList' => 'btn-input getOutOfStockProducts',
						'inputIcon' => [
							'icon' => 'las la-calendar-times',
						],
						'attr' => [
							'type' => 'button',
							'value' => 'Stokda olmayan məhsullar'
						]
					]
				],				
				'table' => [
					'/component/table/table_wrapper.twig' => [
						'table' => $table_result['result'] 
					] 
				],
				'footer' => [
					'/component/table/table_footer_wrapper.twig' => [
						'table_total' => tableFooter::getData([
							'sum_total_sales',
							'sum_profit'
						], $table_result['base_result'])
					]
				]
			]
		]  
	]
]);




$utils::abort([
	'res' => $total
]);
