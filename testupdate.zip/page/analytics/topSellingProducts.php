<?php

use Core\Classes\Report;
use Core\Classes\System\Main;
use Core\Classes\Utils\Utils;

$data_page = $main->initController($page);

$page_config = $data_page['page_data_list'];

if (array_key_exists('form_fields_list', $page_config)) {
    $form_fields = $page_config['form_fields_list'];
} else {
    $form_fields = false;
}

//параметры поиска
$search_arr = array(
    'input_class'      => 'search-auto area-input',     //классы поля ввода поиска
    'parent_class'     => 'search-container-width',             //класс для родителя инпута
    'input_placeholder' => 'Axtar', //заполнить/оставить пустым или
    'reset' => true,
    'input_icon' => [
        'icon' => 'la-search',
    ],
    'widget_class_list' => '',
    'widget_container_class_list' => 'flex-cntr',
    'autocomplete'      => array(
        'type' => 'search',
        'parent_modify_class' => '',
        'autocomlete_class_list' => 'get_item_by_filter search-item area-closeable selectable-search-item'
    )
);


// Utils::log(                            $main->getReportDateList([
//     'table_name' 	=> 'stock_order_report',
//     'col_name' 		=> 'order_date',
//     'order'			=> 'order_real_time DESC',
//     'query'			=> ' WHERE order_stock_count > 0 AND stock_order_visible = 0 ',
//     'default'		=> date('d.m.Y')
// ]));

$report_date_list = $main->getReportDateList([
	'table_name' 	=> 'stock_order_report',
	'col_name' 		=> 'order_my_date',
	'order'			=> 'order_real_time DESC',
	'query'			=> ' WHERE order_stock_count > 0 AND stock_order_visible = 0 ',
	'default'		=> date('m.Y')
]);

$table_result = $main->prepareData($data_page['sql'], $data_page['page_data_list']);

$topSellingProductsOfLastThreeMonth = Report::getTopSellingProductsOfInterval(3, 'total_count');

echo $Render->view('/component/inner_container.twig', [
    'renderComponent' => [
        '/component/include_once_component.twig' => [
            'includs' => [
                [
                    '/component/pulgin/charts/chartsScript.twig' => []
                ],
                [
                    '/component/related_component/include_widget.twig' => [
                        '/component/buttons/select/select-button.twig' => [
                            'main' => [
                                'class_list' => [
                                    'init_element' => ' widget-fields ',
                                    'container' => ' widget-fields-container',
                                    'input_parent' => 'width-100 input-dropdown-parent'
                                ]
                            ],
                            'input' => [
                                'label' => 'Axtar',
                                'icon' => 'las la-calendar-alt',
                                'class_list' => ' scroll-auto form-input area-button input-dropdown',
                                'attribute' => [
                                    'type' => 'button',
                                    'placeholder' => 'Some'
                                ]
                            ],
                            'list' => [
                                'class_list' => [
                                    'container' => 'form-fields-autocomplete ',
                                    'ul_list' => 'width-100 select-list unset-min-width',
                                    'list_item_container' =>'',
                                    'list_item_link' => 'selectable-search-item area-closeable select-category-id select-hidden-fields-input input-dropdown-auto-list-li load-multiple-charts load-analytics-top-selling-products-on-table'
                                ],
                                'default_first' => true,                    
                                'list_data' => [
                                    [
                                        'custom_value' => 'Son 3 ayda olan satışlar',
                                        'custom_data_id' => '3'
                                    ],
                                    [
                                        'custom_value' => 'Son 1 ayda olan satışlar ',
                                        'custom_data_id' => '1'
                                    ],                                    
                                    [
                                        'custom_value' => 'Son 6 ayda olan satışlar',
                                        'custom_data_id' => '6'
                                    ], 
                                    [
                                        'custom_value' => 'Son 12 ayda olan satışlar',
                                        'custom_data_id' => '12'
                                    ],                                                                        
                                ],
                            ]
                        ],
                    ]
                ],                 
                [
                    '/component/pulgin/charts/pieChartsContainer.twig' => [
                        'includs' =>[                    
                            [
                                '/component/pulgin/charts/chartsLoader.twig' => [
                                    'classList' => 'reloadTopProducts ',
                                    'wrapperClassList' => 'width-100',
                                    'chartsType' => 'doughnut',
                                    'chartsName' => 'reportTopProductsByInterval',
                                    'scriptUrl' => 'core/action/analytics/charts-get-top-selling-by-interval.php',
                                    'scriptRoute' => 'analyticsChartsTopProductsByInterval',
                                    'dataValue' => 'total_amount',
                                    'setLabel' => 'Ən çox satılan məhsullar (məbləğə görə)',
                                    'customData' => [
                                        'orderBy' => 'total_amount',
                                    ]
                                ]					
                            ], 
                            [
                                '/component/pulgin/charts/chartsLoader.twig' => [
                                    'classList' => 'reloadTopProducts ',
                                    'wrapperClassList' => 'width-100',
                                    'chartsType' => 'doughnut',
                                    'chartsName' => 'reportTopProductsByIntervals',
                                    'scriptUrl' => 'core/action/analytics/charts-get-top-selling-by-interval.php',
                                    'scriptRoute' => 'analyticsChartsTopProductsByInterval',
                                    'dataValue' => 'total_profit',
                                    'setLabel' => 'Ən çox satılan məhsullar (mənfəətə görə)',
                                    'customData' => [
                                        'orderBy' => 'total_profit',
                                    ]                                    
                                ]					
                            ],                                                           
                        ]
                    ]
                ],
                [
                    '/component/related_component/include_widget.twig' => [
                        '/component/widget/title.twig' => [
                            'title' => 'ən çox satılan məhsullar (ədəd olaraq)',
                            'classList' => 'margin-0 mrgn-top-100 sub-title',
                        ],
                    ],                    
                    '/component/table/table_wrapper.twig' => [
                        'table' => $main->compareData($topSellingProductsOfLastThreeMonth, $page_config),
                        'table_tab' => $page,
                        'table_type' => $type,
                        // 'classList' => 'stock-list'
                    ],
                    '/component/table/table_footer_wrapper.twig' => [
                        'table_total' => $utils->compareTableFooterData(['total_count', 'total_amount', 'total_profit'], $topSellingProductsOfLastThreeMonth)
                    ],                                    
                ],
            ]
        ],
    ]
]);
