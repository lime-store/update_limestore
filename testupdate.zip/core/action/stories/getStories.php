<?php

use Core\Classes\Utils\Stories;
use Core\Classes\Utils\Utils;
$contentData = Stories::getStories();

// test
// $contentData = [
//     [
//         'message' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Consectetur dolores rerum tenetur delectus laboriosam error natus adipisci reprehenderit labore voluptatibus? Tempore quos voluptate numquam perferendis corrupti molestiae eos laborum sed.',
//         'type' => 'video',
//         'url' => 'https://res.cloudinary.com/dk1cgdxad/video/upload/v1714247071/jjj_nxte8n.mp4'
//     ],
//     [
//         'message' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Consectetur dolores rerum tenetur delectus laboriosam error natus adipisci reprehenderit labore voluptatibus? Tempore quos voluptate numquam perferendis corrupti molestiae eos laborum sed.',
//         'type' => 'image',
//         'url' => 'https://res.cloudinary.com/dk1cgdxad/image/upload/v1714831345/%D0%98%D0%B7%D0%BE%D0%B1%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5_WhatsApp_2024-05-03_%D0%B2_12.44.16_395d3a0e_fvrtg9.jpg'
//     ],    
// ];

$tpl = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/stories/stories-row.twig' => [
            'contentData' => $contentData
        ]
    ]
]);

Utils::abort([
    'res' => $tpl
]);
