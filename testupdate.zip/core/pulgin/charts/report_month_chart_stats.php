<?php

use Core\Classes\Privates\accessManager;

header('Content-Type: application/json');

$Charts = new \Core\Classes\Utils\Charts;

$data = accessManager::isDataAvailable('th_total_circ_money') == false ?: $Charts->getReportChartList();
$profit = accessManager::isDataAvailable('th_profit') == false ?: $Charts->getReportChartListProfit();

echo json_encode(['turnover' => $data, 'profit' => $profit]);