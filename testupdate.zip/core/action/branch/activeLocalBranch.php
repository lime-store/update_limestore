<?php

use core\classes\System\Settings;

$branchIndex = $_POST['branchIndex'];

Settings::appendSettingsJSON([
    'branch' => [
        'active' => $branchIndex
    ]
]);


