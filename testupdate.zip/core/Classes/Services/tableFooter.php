<?php 
namespace core\classes\Services;

use Core\Classes\Privates\accessManager;
use Core\Classes\Utils\Utils;
use Core\Classes\System\Init;

class tableFooter
{
    public static $list = [
        // Количество товара @arra
        'stock_count'                   => [],
        // Количнство посика
        'search_result'                 => 0,
        // Сумма себестоимости товара
        'sum_first_price'               => [],
        // Сумма маржи
        'sum_profit'                    => 0,
        // Количество заказа
        'sum_order_count'               => 0,
        // Сумма расхода
        'sum_rasxod'                    => 0,
        // Сумма продаж
        'sum_sales'                     => 0,
        // Сумма продаж по формуле (сумма продаж - сумма возврата = итоговая сумма продажи)
        'final_sales'                   => 0,
        // Сумма маржи
        'sum_margin'                    => 0,
        // Сумма оплаты картой
        'sum_card_money'                => 0,
        //Сумма возврата
        'sum_refaund'                   => 0,

        // Количество общих продаж по промежутку даты
        'total_count'                   => 0,
        // Сумма продаж по промежутку даты
        'total_amount'                  => 0,
        // Выручка по промежутку даты
        'total_profit'                  => 0,


        'wholesale_order'               => 0,
        'wholesale_refaund'             => 0,
        'wholesale_final_order'         => 0,
        'wholesale_profit'              => 0,
    ];

    public static $result = [];

    public static function getData($foterList, $data)
    {
        foreach ($data as $stock) {
            // КОЛИЧЕСТВО ТОВАРА
            if (array_key_exists('stock_count', $stock)) {
                if ($stock['stock_count'] > 0) {
                    self::$list['stock_count'][] = $stock['stock_count'];
                }

                // себестоимость товара
                if (array_key_exists('stock_first_price', $stock)) {
                    if ($stock['stock_count'] > 0) {
                        self::$list['sum_first_price'][] = $stock['stock_first_price'] * $stock['stock_count'];
                    }
                }
            }

            // analytics
            if(array_key_exists('total_count', $stock))  {
                self::$list['total_count'] += $stock['total_count'];
            }     
            
            // analytics
            if(array_key_exists('total_amount', $stock)) {
                self::$list['total_amount'] += $stock['total_amount'];
            }    
            
            // analytics
            if(array_key_exists('total_profit', $stock)) {
                self::$list['total_profit'] += $stock['total_profit'];
            }             
                     
            // ВЫГОДА В ОТЧЕТЕ
            if (array_key_exists('order_total_profit', $stock) && array_key_exists('stock_order_visible', $stock)) {
                if($stock['stock_order_visible'] == 0) {
                    self::$list['sum_profit'] += $stock['order_total_profit'];
                }
            }

            // ВЫГОДА В ОТЧЕТЕ
            if (array_key_exists('wholesale_profit', $stock) && array_key_exists('stock_order_visible', $stock)) {
                if($stock['stock_order_visible'] == 0) {
                    self::$list['wholesale_profit'] += $stock['wholesale_profit'];
                }
            }            
            
            // КОЛИЧЕСТВО ЗАКАЗА
            if (array_key_exists('order_stock_count', $stock)) {
                if ($stock['order_stock_count'] > 0) {
                    self::$list['sum_order_count'] += $stock['order_stock_count'];
                }
            }    
            
            // РАСХОД
            if (array_key_exists('rasxod_money', $stock)) {
                self::$list['sum_rasxod'] += $stock['rasxod_money'];
            }

            // СУММА ЗАКАЗА
            if (array_key_exists('order_stock_total_price', $stock)) {
                self::$list['sum_sales'] += $stock['order_stock_total_price'];
            }


            // СУММА ЗАКАЗА
            if (array_key_exists('wholesale_order', $stock)) {
                self::$list['wholesale_order'] += $stock['wholesale_order'];

                if (array_key_exists('stock_order_visible', $stock)) {
                    if ($stock['stock_order_visible'] == 3) {
                        self::$list['wholesale_refaund'] += $stock['wholesale_order'];
                        self::$list['wholesale_profit'] = self::$list['wholesale_profit'] - $stock['wholesale_profit'];
                        self::$list['wholesale_order'] = self::$list['wholesale_order'] - $stock['wholesale_order'];
                    }
                }
            }            

            // СПОСОБ ОПЛАТЫ
            if (array_key_exists('payment_method', $stock)) {
                if ($stock['payment_method'] == 2) {
                    self::$list['sum_card_money'] += $stock['order_stock_total_price'];
                }
            }            

            if (array_key_exists('stock_order_visible', $stock)) {
                if ($stock['stock_order_visible'] == 3) {
                    self::$list['sum_refaund'] += $stock['order_stock_total_price'];
                    self::$list['sum_profit'] = self::$list['sum_profit']  - $stock['order_total_profit'];
                    self::$list['sum_sales'] = self::$list['sum_sales'] - $stock['order_stock_total_price'];
                }
            }    
            
            self::$list['final_sales'] = self::$list['sum_sales'] - self::$list['sum_refaund'];
            self::$list['wholesale_final_order'] = self::$list['wholesale_order'] - self::$list['wholesale_refaund'];

            self::$list['search_result'] = count($data);
        }



        return self::compare($foterList);
    }

    

    public static function compare($foterList) {
        foreach($foterList as $type) {
            //количество товара
            switch ($type) {
                case 'stock_count':
                    self::getSalesCount(array_sum(self::$list[$type]));
                    break;
                case 'refaund':
                    self::getSalesRefaund(self::$list['sum_refaund']);
                    break;
                case 'final_sales':
                    self::getFinalSales(self::$list['final_sales']);
                    break;
                case 'card_cash':
                    self::getSalesRow(self::$list['sum_card_money'], 'Kart');
                    break;
                case 'sum_total_sales':
                    self::getReportSales(self::$list['sum_sales']);
                    break;
                case 'search_count':
                    self::getCountRow(self::$list['search_result'], 'Tapıldı');
                    break;    
                case 'sum_first_price':
                    self::getProductsFirstPriceSum(array_sum(self::$list['sum_first_price']));
                    break;
                case 'sum_profit':
                    self::getSalesRow(self::$list['sum_profit'], 'Ümumi mənfəət');
                    break;
                case 'stock_order_count':
                    self::getCountRow(self::$list['sum_order_count'], 'Qaimə');
                    break;
                case 'sum_total_rasxod':
                    self::getSalesRow(self::$list['sum_rasxod'], 'Ümumi xərc');
                    break;
                case 'sum_margin':
                    self::getSalesRow((self::$list['sum_profit'] - self::$list['sum_rasxod']), 'Xalis mənfəət');
                    break;
                case 'sum_total_sales_margin':
                    self::getSalesRow(((self::$list['sum_sales'] - self::$list['sum_rasxod']) - self::$list['sum_card_money'] - self::$list['sum_refaund']), 'Qaliq (kassa)');
                    break;

                case 'total_count':
                    self::getCountRow(self::$list['total_count'], 'Ümumi say');
                    break; 
                case 'total_amount':
                    self::getSalesRow(self::$list['total_amount'], 'Toplam məbləğ');
                    break; 
                case 'total_profit':
                    self::getSalesRow(self::$list['total_profit'], 'Toplam mənfəət');
                    break;  
                    
                case 'wholesale_order':
                    self::getReportSales(self::$list['wholesale_order']);
                    break;
                case 'wholesale_refaund':
                    self::getSalesRefaund(self::$list['wholesale_refaund']);
                    break;
                case 'wholesale_final_order':
                    self::getFinalSales(self::$list['wholesale_final_order']);
                    break;
                case 'wholesale_profit':
                    self::getSalesRow(self::$list['wholesale_profit'], 'Ümumi mənfəət');
                    break;                                               
            }
        }      

        return self::$result;
    }


    public static function updateData($data)
    {
        $ControllerData = Init::getControllerData(Utils::getPostPage())->getAllData();

        $table_footer_list = $ControllerData['page_data_list']['table_total_list'];

        $resData = [];

        foreach ($data as $index => $row) {
            //количество товара
            switch ($index) {
                case 'stock_count':
                    $oldCount           =  Utils::stringToInt($row['oldFooterCount'] ?? 0);
                    $oldProductCount    =  Utils::stringToInt($row['oldItemCount'] ?? 0);
                    $newProductCount    =  Utils::stringToInt($row['newItemCount'] ?? $oldProductCount);

                    $oldCount = $oldCount - $oldProductCount;

                    self::$list['stock_count'][] = $oldCount + $newProductCount;
                    break;
                case 'sum_first_price':
                    $oldFooterPrice     =  Utils::stringToFloat($row['oldFooterPrice']  ?? 0);
                    $oldProductPrice    =  Utils::stringToFloat($row['oldProductPrice'] ?? 0);
                    $newProductPrice    =  Utils::stringToFloat($row['newProductPrice'] ?? $oldProductPrice);
                    $oldProductCount    =  Utils::stringToInt($row['oldProductCount'] ?? 0);
                    $newProductCount    =  Utils::stringToInt($row['newProductCount'] ?? $oldProductCount);

                    $footerPrice = $oldFooterPrice - ($oldProductPrice * $oldProductCount);

                    self::$list['sum_first_price'][] = $footerPrice + ($newProductPrice * $newProductCount);
                    break;

                case 'sum_total_sales';
                    break;
            }
        }

        return self::compare($table_footer_list);
    }




    public static function getSalesCount($value) {
        return array_push(self::$result, [
                    'title' => 'Ümumi say',
                    'value' => Utils::prettyPrintNumber($value),
                    'class_list' => 'tf-res-stock-count',
                    'mark'     => [
                        'mark_text' => 'ədəd',
                        'mark_modify_class' => ''
                    ]
                ]);
    }

    public static function getSalesRefaund($value) {
        return  array_push(self::$result, [
                    'title' => 'Qeri qaytarma',
                    'value' => Utils::prettyPrintNumber($value),
                    'class_list' => 'tf-res-stock-sum',
                    'mark'     => [
                        'mark_modify_class' => 'mark-icon-manat button-icon-right manat-icon--black'
                    ]
                ]);
    }

    
    public static function getFinalSales($value) {
        return array_push(self::$result, [
            'title' => 'Toplam satış',
            'value' => Utils::prettyPrintNumber($value),
            'class_list' => 'tf-res-stock-sum',
            'mark'     => [
                'mark_modify_class' => 'mark-icon-manat button-icon-right manat-icon--black'
            ]
        ]);        
    }
    
    public static function getReportSales($value) {
        return array_push(self::$result, [
            'title' => 'Satış',
            'value' => Utils::prettyPrintNumber($value),
            'class_list' => 'tf-total-report',
            'mark'     => [
                'mark_modify_class' => 'mark-icon-manat button-icon-right manat-icon--black'
            ]
        ]);
    }

    public static function getProductsFirstPriceSum($value) {
        if (AccessManager::checkDataPremission('th_buy_price')) {
            return array_push(self::$result, [
                'title' => 'Malların ümumi dəyəri',
                'class_list' => 'tf-res-stock-sum',
                'value' => Utils::prettyPrintNumber($value),
                'mark'     => [
                    'mark_modify_class' => 'mark-icon-manat button-icon-right manat-icon--black'
                ]
            ]);
        }        
    }
    
    public static function getSalesRow($value, $title) {
        return array_push(self::$result, [
                    'title' => $title,
                    'value' => Utils::prettyPrintNumber($value),
                    'mark'     => [
                        'mark_modify_class' => 'mark-icon-manat button-icon-right manat-icon--black'
                    ]
               ]);        
    }

    public static function getCountRow($value, $title) {
        return array_push(self::$result, [
            'title' => $title,
            'value' =>  Utils::prettyPrintNumber($value),
            'mark'     => [
                'mark_text' => 'ədəd',
                'mark_modify_class' => ''
            ]
        ]);        
    }    
}