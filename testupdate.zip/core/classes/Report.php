<?php 
namespace core\classes;

use core\classes\Cart\Checkout;
use core\classes\dbWrapper\db;
use core\classes\Traits\ReportStatsCard;
use core\classes\System\Main;
use core\classes\Utils\Utils;
use core\classes\dbWrapper\queryBuilder as QB;
use core\classes\dbWrapper\updateBuilder;
use core\classes\Privates\CashRegisters;
use core\classes\Privates\User;
use core\classes\Services\BaseService;
use core\classes\System\Init;

class Report {
    use ReportStatsCard;

    public $main;
    public static $index = 'report'; 
    
    public function __construct()
    {
        $this->main = new Main;
    }


    /**
     * 
     */
    public static function getOrderByTransactionId(int $transactionId)
    {
        return db::select([
            'table_name' => 'stock_order_report',
            'col_list' => '*, ROUND(sum(stock_order_report.order_stock_total_price), 3) as transaction_order_total',
            'query' => [
                'base_query' => ' 
                    WHERE stock_order_report.stock_order_visible IN (0, 3) 
                    AND stock_order_report.transaction_id = :id 
                    AND stock_order_report.order_stock_count > 0
                
                ',
                'sort_by' => ' GROUP BY stock_order_report.transaction_id DESC ORDER BY stock_order_report.transaction_id DESC '
            ],            
            'bindList' => [
                ':id' => $transactionId
            ]
            
        ])->get();
    }

    /**
     * 
     */
    public static function getReportByTransactionPrepareData(int $transactionId) {
        $getController = Init::initController('report');
        unset($getController['page_data_list']['get_data']['report_order_edit']);
        
        $getController['sql']['query']['base_query'] = 'INNER JOIN stock_list ON stock_list.stock_id  != 0 
                                                        INNER JOIN stock_order_report ON stock_order_report.stock_order_visible IN (0, 2, 3) 
                                                        AND stock_order_report.transaction_id = :transaction_id ';
        $getController['sql']['bindList'] = [':transaction_id' => $transactionId];

        return Main::prepareData($getController['sql'], $getController['page_data_list']);
    }

    /**
     * @param int $id  id отчета
     * @return array
     *  Получить отчет по id
     */
    public static function getReportById(int $id)
    {
        return db::select([
            'table_name' => 'stock_order_report',
            'col_list' => '*',
            'query' => [
                'base_query' => ' LEFT JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id  
                                    WHERE stock_order_report.order_stock_id = :id ',
                'sort_by' => ' GROUP BY stock_order_report.order_stock_id DESC ORDER BY stock_order_report.order_stock_id DESC  '
            ],            
            'bindList' => [
                ':id' => $id
            ]
            
        ])->first()->get();
    }

    /**
     *  Получить отчет по id
     */
    public static function getReportByColumn(string $columnName, $value, array $visible = [0])
    {
        $visiblePos = implode(',', array_fill(0, count($visible), '?'));

        $myBinds = array_merge([$value], array_values($visible));

        $data_page = Init::getControllerData('report')->getAllData();

        $data_page['sql']['query']['body'] = $data_page['sql']['query']['body']  . " AND  $columnName = ? AND stock_order_report.stock_order_visible  IN ($visiblePos)";
        $data_page['sql']['bindList'] = $myBinds;

        return db::select($data_page['sql'], ['placeholders' => 'positional'])->get();
        
        exit;
        return db::select([
            'table_name' => 'stock_order_report',
            'col_list' => '*',
            'query' => [
                'base_query' => " LEFT JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id  
                                    WHERE ",
                'sort_by' => ' GROUP BY stock_order_report.order_stock_id DESC ORDER BY stock_order_report.order_stock_id DESC  '
            ],            
            'bindList' => $myBinds
        ], ['placeholders' => 'positional'])->get();
    }


    /**
     * Получить отчет за месяц
     */
    public function getMonthlyReport($month = false, $controllerIndex = 'report')
    {

        $data_page = Init::getControllerData($controllerIndex)->getAllData();

        $data_page['sql']['query']['body'] = $data_page['sql']['query']['body']  . "  AND stock_order_report.order_my_date = :mydateyear";
        $data_page['sql']['bindList']['mydateyear'] = !empty($month) ? $month : date('m.Y');
        

        return $this->main->prepareData($data_page['sql'], $data_page['page_data_list']);
    }

    /**
     *  Поулчить отчет за день
     */
    public function getDailyReport($day = false, $controllerIndex = 'report')
    {
        $data_page = Init::getControllerData($controllerIndex)->getAllData();
                
        $data_page['sql']['query']['body'] = $data_page['sql']['query']['body'] . "  AND stock_order_report.order_date = :mayday ";
        $data_page['sql']['bindList']['mayday'] = !empty($day) ? $day : date('d.m.Y');
        
        return $this->main->prepareData($data_page['sql'], $data_page['page_data_list']);
    }    


    /**
     * 
     */
    public function getTopSellingProductsOfMonth($date) 
    {
        return db::select([
            'table_name' => 'stock_order_report',
            'col_list' => "  order_my_date as smonth, order_stock_name,  SUM(order_total_profit) AS total_profit ",
            'query' => [
                'base_query' => '',
                'body' => " WHERE stock_order_report.order_my_date = :mydate
                            AND stock_order_visible = 0 ",
                'sort_by' => ' GROUP BY stock_order_report.stock_id ASC ORDER BY total_profit DESC ',
                'limit' => ' limit 10 '
            ],
            'bindList' => [
                ':mydate' => $date
            ],
        ])->get();
    } 

    /**
     * 
     */
    public static function getLastReport()
    {
       $report = Init::getControllerData(self::$index)->getAllData();
       $report['sql']['query']['limit'] = 'limit 1';
       return db::select($report['sql'])->get();
    }


    /**
     * Редактировать отчет продажи 
     * @param array $data
     * @return json
     */
    public function editReport($data, $transactionId = false) 
    {
        $option = [
            'before' => ' UPDATE stock_order_report JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id SET ',
            'after' => ' WHERE order_stock_id = :report_id  ',
            'post_list' => [
                'report_order_id' => [
                    'query' => false,
                    'bind' => 'report_id',
                    'require' => true
                ],
                // 'edit_report_order_tags' => [
                //     'query' => ' stock_order_report.payment_method = :payment_tags_id ',
                //     'bind' => 'payment_tags_id',
                //     'require' => false
                // ],
                'edit_report_order_note' => [
                    'query' => ' stock_order_report.order_who_buy = :order_note ',
                    'bind' => 'order_note',
                    'require' => false
                ],
                // 'report_edit_order_count' => [
                //     'query' => '  stock_list.stock_count =  stock_list.stock_count + stock_order_report.order_stock_count ',
                //     'bind' => false,
                //     'require' => false                    
                // ],
            ]
        ];
        
        if(array_key_exists('edit_report_order_note', $data) && empty($data['edit_report_order_note'])) {
            $data['edit_report_order_note'] = ' ';
        }

        if(!empty($data['edit_report_order_tags']) && !empty($transactionId)) {
            updateBuilder::table('stock_order_report')
                            ->set('payment_method', $data['edit_report_order_tags'])
                            ->where('transaction_id', $transactionId)
                            ->execute();

            CashRegisters::editPaymentMethod($transactionId, $data['edit_report_order_tags']);
        }

        $required = [
            // 'edit_report_order_tags',
            'edit_report_order_note',
            // 'report_edit_order_count'
        ];

        if (!empty(array_intersect($required, array_keys($data)))) {
            db::update($option, $data);
        }

        
        // if(array_key_exists('report_edit_order_count', $data)) {
        //     $this->changeOrderCount($data);
        // }

        if(array_key_exists('report_edit_price', $data)) {
            $this->changeOrderPrice($data);
        }
    }



    /**
     * Возврат товара, по количеству
     * 
     * @param array $data = Array (
     *      [report_order_id]           => int 1234
     *      [report_edit_order_count]   => int 123
     *      [report_edit_price]         => int 12
     *   )
     */
    public function changeOrderCount($data)
    {
        // products count refaund
        $option2 = [
            'before' => ' UPDATE stock_order_report JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id SET ',
            'after' => ' WHERE order_stock_id = :report_id  ',
            'post_list' => [
                'report_order_id' => [
                    'query' => false,
                    'bind' => 'report_id',
                    'require' => true
                ],                
                'report_edit_order_count' => [
                    'query' => ' 
                        stock_list.stock_count = stock_list.stock_count - :changeCount1,
                        stock_order_report.order_stock_count = :changeCount2,
                        stock_order_report.max_refaund_quantity = :changeCount3
                    ',
                    'bind' => [
                        'changeCount1',
                        'changeCount2',
                        'changeCount3',
                    ],
                    'require' => false
                ],
            ]
        ];

        return db::update($option2, $data);        
    }


    /**
     * Изменяем цену в отчете 
     * 
     * @param array @data
     */
    public function changeOrderPrice($data) 
    {
        // products price change
        $option3 = [
            'before' => ' UPDATE stock_order_report JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id SET ',
            'after' => ' WHERE order_stock_id = :report_id  ',
            'post_list' => [
                'report_order_id' => [
                    'query' => false,
                    'bind' => 'report_id',
                    'require' => true
                ],                
                'report_edit_price' => [
                    'query' => ' stock_order_report.order_stock_sprice = :new_price, 
                                 stock_order_report.order_stock_total_price = :new_price2 * stock_order_report.order_stock_count,
                                 stock_order_report.order_total_profit = stock_order_report.order_stock_total_price - (stock_list.stock_first_price * stock_order_report.order_stock_count) 
                    ',
                    'bind' => [
                        'new_price',
                        'new_price2'
                    ],
                    'require' => false                    
                ]
            ]
        ];

        return db::update($option3, $data);        
    }




    /**
     * Возврат товара (продажи)
     * @param array $data
     * @return json 
     */
    public function deleteReport($data) 
    {
        $option = [
            'before' => " UPDATE stock_list
                          JOIN stock_order_report ON stock_order_report.order_stock_id = :delete_id
                          SET stock_list.stock_count = 
                            CASE 
                                WHEN stock_order_report.stock_order_visible = 3
                                THEN stock_list.stock_count - stock_order_report.order_stock_count
                                ELSE stock_list.stock_count + stock_order_report.order_stock_count
                            END,    
                          stock_order_report.stock_order_visible = 2,
                          stock_list.stock_return_status = 1 ",
            'after' => "  WHERE stock_list.stock_id = stock_order_report.stock_id ",    
            'post_list' => [
                'report_id' => [
                    'query' => false,
                    'bind' => 'delete_id'
                ]
            ]
        ];   

        db::update($option, $data);
    }


    public static function addReport($res)
    {
        return db::insert('stock_order_report', $res);
    }   

    /**
     * 
     */
    public static function setReportEditableState($reportId, bool $hasEditable)
    {

        $option = [
            'before' => " UPDATE stock_order_report
                          SET stock_order_report.has_editable = :val ",
            'after' => "  WHERE stock_order_report.order_stock_id = :report_id ",    
            'post_list' => [
                'report_id' => [
                    'query' => false,
                    'bind' => 'report_id'
                ],
                'val' => [
                    'query' => false,
                    'bind' => 'val'
                ]
            ]
        ];   
        
        db::update($option, [
            'report_id' => $reportId,
            'val' => $hasEditable,
        ]);
    }

    /**
     * Добавляет возврат в бд
     */
    public static function refaundOrder($orderId, $refaundQuantity)
    {
        $getOrder = self::getReportById($orderId);
        $getProduct = Products::getProductById($getOrder['stock_id']);

        if($getOrder['stock_order_visible'] == 3) {
            return false;
        }

        $prepare = Checkout::prepareOrderData([
            'ProductsData'    => $getOrder,
            'id'              => $getOrder['stock_id'],
            'order_price'     => $getOrder['order_stock_sprice'],
            'order_count'     => $refaundQuantity,
            'description'     => $getOrder['order_who_buy'],
            'payment_method'  => $getOrder['payment_method'],
            'sales_man'       => $getOrder['sales_man'],
            'transaction_id'  => $getOrder['transaction_id'],
            'reportType'      => $getOrder['reportType'],
            'discount'        => 0,
            'customer_id'     => $getOrder['customer_id'],
            'cashback_amount' => 0,
        ]);
        
        $prepare[$getOrder['stock_id']]['stock_order_visible'] = '3';
        
        self::addReport($prepare);

        Products::logProductStockChange(
            $getProduct['stock_id'],
            $getProduct['stock_count'],
            ($getProduct['stock_count'] + $refaundQuantity),
            'refaund',
            $getOrder['transaction_id'],
        );

        CashRegisters::withdraw(
            ($refaundQuantity * $getOrder['order_stock_sprice']),
            'refaund',
            User::getCurrentUser('get_id'),
            $getOrder['payment_method'],
            $getOrder['transaction_id'],
        );

        Products::increaseProductCount([
            'stock_id'       => $getOrder['stock_id'],
            'product_count'  => $refaundQuantity
        ]);

    
        return true;
    }

    /**
     * 
     */
    public static function getMaxRefaundQuantity($reportId)
    {
        $report = self::getReportById($reportId);
        return $report['max_refaund_quantity'];
    }


    /**
     * @return bool если количество равно или меньше чем можно сделать возврат
     *              то выводим true иначе false
     */
    public static function canRefaundQuantity($reportId, int $count)
    {
        $maxCount = self::getMaxRefaundQuantity($reportId);
    
        if(!empty($count) && $count <= $maxCount && $count > 0) {
            return true;
        }

        return false;
    }


    public function getDifferenceOrderCount(int $orderCount, int $changeCount) {

    }

    /**
     * 
     */
    public static function increaseRefaundQuantity(array $data) 
    {
        $option = [
            'before' => " UPDATE stock_order_report SET ",
            'after' => " WHERE stock_order_report.order_stock_id = :report_id ",
            'post_list' => [
                'report_id' => [
                    'query' => false,
                    'bind' => 'report_id'
                ],
                'refaund_quantity' => [
                    'query' => "stock_order_report.max_refaund_quantity = stock_order_report.max_refaund_quantity + :refaund_quantity",
                    'bind' => 'refaund_quantity'
                ]
            ]
        ];

        db::update($option, $data);
    }

    /**
     * 
     */
    public static function decreaseRefaundQuantity(array $data)
    {
        $option = [
            'before' => " UPDATE stock_order_report SET ",
            'after' => " WHERE stock_order_report.order_stock_id = :report_id ",
            'post_list' => [
                'report_id' => [
                    'query' => false,
                    'bind' => 'report_id'
                ],
                'refaund_quantity' => [
                    'query' => "stock_order_report.max_refaund_quantity = stock_order_report.max_refaund_quantity - :refaund_quantity",
                    'bind' => 'refaund_quantity'
                ]
            ]
        ];

        db::update($option, $data);
    }



    /**
     * 
     */
    public static function getTopSellingProductsOfInterval($interval = 3, $orderBy = 'total_amount')
    {
        // $date = new \DateTime();
        // $date->modify("-$interval months");
        // Utils::log();
        return db::select([
            'table_name' => 'stock_order_report',
            'col_list' => "*, ( 
                                    (
                                    ROUND(SUM(CASE WHEN stock_order_visible = 0 THEN stock_order_report.order_stock_total_price  ELSE 0 END), 3)
                                    ) - 
                                    (
                                    ROUND(SUM(CASE WHEN stock_order_visible = 3 THEN stock_order_report.order_stock_total_price  ELSE 0 END), 3)
                                    ) 
                                ) AS total_amount,

                                ( 
                                    (
                                    SUM(CASE WHEN stock_order_visible = 0 THEN stock_order_report.order_stock_count  ELSE 0 END)
                                    ) - 
                                    (
                                    SUM(CASE WHEN stock_order_visible = 3 THEN stock_order_report.order_stock_count  ELSE 0 END)
                                    ) 
                                ) AS total_count,
                                 
                                ( 
                                    (
                                    ROUND(SUM(CASE WHEN stock_order_visible = 0 THEN stock_order_report.order_total_profit  ELSE 0 END), 3)
                                    ) - 
                                    (
                                    ROUND(SUM(CASE WHEN stock_order_visible = 3 THEN stock_order_report.order_total_profit  ELSE 0 END), 3)
                                    ) 
                                ) AS total_profit                              
                              ",
            'query' => [
                'base_query' => '',
                'body' => " 
                LEFT JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id
    
                WHERE CONCAT(SUBSTRING(stock_order_report.order_my_date, 4, 4), '-', SUBSTRING(stock_order_report.order_my_date, 1, 2)) BETWEEN ? AND ?
                      AND stock_order_report.stock_order_visible IN (0, 3) ",
                'sort_by' => " GROUP BY stock_order_report.stock_id  ORDER BY $orderBy DESC ",
                'limit' => ' LIMIT 10'
            ],
            'bindList' => [
                date('Y-m', strtotime("-" . ($interval - 1) . " months")),
                date('Y-m'),
            ],
        ], ['placeholders' => 'positional'])->get();
    }

    /**
     * 
     */
    public static function getNoSalesProductsOfInterval($interval = 3) 
    {
        return db::select([
            'table_name' => 'stock_list',
            'col_list' => "*, stock_list.stock_id",
            'query' => [
                'base_query' => '',
                'body' => " 
                LEFT JOIN stock_order_report ON stock_order_report.stock_id = stock_list.stock_id 
    
                AND CONCAT(SUBSTRING(stock_order_report.order_my_date, 4, 4), '-', SUBSTRING(stock_order_report.order_my_date, 1, 2)) BETWEEN ? AND ?
                      AND stock_order_report.stock_order_visible = 0 
                LEFT JOIN stock_barcode_list ON stock_barcode_list.br_stock_id = stock_list.stock_id 
                        WHERE stock_order_report.order_stock_id IS NULL 
                            AND stock_list.stock_count > 0
                            AND stock_list.stock_visible = 0

                            
                      ",
                'sort_by' => " GROUP BY stock_list.stock_id ORDER BY stock_list.stock_id DESC ",
                'limit' => ' LIMIT 300'
            ],
            'bindList' => [
                date('Y-m', strtotime("-" . ($interval - 1) . " months")),
                date('Y-m'),
            ],
        ], ['placeholders' => 'positional'])->get();
    }
    

    public static function getTopSellingCategoryByInterval($interval = 3)
    {
        $data = db::select([
            'table_name' => 'stock_order_report',
            'col_list'   => '
                stock_category.category_name, stock_category.category_id,
                ( 
                    (
                      ROUND(SUM(CASE WHEN stock_order_visible = 0 THEN order_total_profit ELSE 0 END), 3)
                    ) - 
                    (
                     ROUND(SUM(CASE WHEN stock_order_visible = 3 THEN order_total_profit ELSE 0 END), 3)
                    ) 
                ) AS total_profit,

                ( 
                    (
                      ROUND(SUM(CASE WHEN stock_order_visible = 0 THEN order_stock_total_price ELSE 0 END), 3)
                    ) - 
                    (
                     ROUND(SUM(CASE WHEN stock_order_visible = 3 THEN order_stock_total_price ELSE 0 END), 3)
                    ) 
                ) AS total_amount      
            ',
            'query' => [
                'body' => "
                    INNER JOIN products_category_list 
                        ON products_category_list.id_from_stock = stock_order_report.stock_id 
                    INNER JOIN stock_category 
                        ON stock_category.category_id = products_category_list.id_from_category AND stock_category.visible = ?
                    WHERE 
                        stock_order_report.stock_order_visible IN (0, 3)
                        AND stock_order_report.order_stock_count > 0 
                        AND CONCAT(SUBSTRING(stock_order_report.order_my_date, 4, 4), '-', 
                                   SUBSTRING(stock_order_report.order_my_date, 1, 2)) BETWEEN ? AND ?
                ",
                'sort_by' => "GROUP BY stock_category.category_id ORDER BY total_profit DESC",
            ],
            'bindList' => [
                BaseService::VISIBLE_STATE['visible'],
                date('Y-m', strtotime("-" . ($interval - 1) . " months")),
                date('Y-m'),
            ]
        ], ['placeholders' => 'positional'])->get();

        return $data;
    }

    public static function getTopSellingProviderByInterval($interval = 3)
    {
        return db::select([
            'table_name' => ' stock_order_report ',
            'col_list'	=> ' provider_name,
                            ( 
                                (
                                ROUND(SUM(CASE WHEN stock_order_visible = 0 THEN order_total_profit ELSE 0 END), 3)
                                ) - 
                                (
                                ROUND(SUM(CASE WHEN stock_order_visible = 3 THEN order_total_profit ELSE 0 END), 3)
                                ) 
                            ) AS total_profit
            ',
        
            'query' => array(
                'base_query' => "",
                'body' =>  "
                            INNER JOIN products_provider_list ON products_provider_list.id_from_stock = stock_order_report.stock_id 
                                    AND stock_order_report.stock_order_visible = 0
                                    AND stock_order_report.order_stock_count > 0 
                                    AND CONCAT(SUBSTRING(stock_order_report.order_my_date, 4, 4), '-', 
                                        SUBSTRING(stock_order_report.order_my_date, 1, 2)) BETWEEN ? AND ?
                                    
                            INNER JOIN 
                                stock_provider ON stock_provider.provider_id = products_provider_list.id_from_provider AND stock_provider.visible = ?
                ",
                "joins" => "  ",		
                'sort_by' => " GROUP BY stock_provider.provider_id ORDER BY total_profit DESC",
            ),
            'bindList' => array(
                BaseService::VISIBLE_STATE['visible'],
                date('Y-m', strtotime("-" . ($interval - 1) . " months")),
                date('Y-m'),
            )             
        ], ['placeholders' => 'positional'])->get();
    }    

    /**
     * 
     */
    public static function isValidReportType($type = 'RETAIL')
    {
        $reportTypeList = [
            'RETAIL',
            'WHOLESALE'
        ];

        return in_array($type, $reportTypeList);
    }


    /**
     *  
     */
    public static function getReportBySeller($date = null)
    {
        return db::select([
            'table_name' => ' stock_order_report ',
            'col_list'	=> '*, 
                            ( 
                                (
                                ROUND(SUM(CASE WHEN stock_order_visible = 0 THEN order_stock_total_price ELSE 0 END), 3)
                                ) - 
                                (
                                ROUND(SUM(CASE WHEN stock_order_visible = 3 THEN order_stock_total_price ELSE 0 END), 3)
                                ) 
                            ) AS total_sales,

                            ROUND(SUM(CASE WHEN stock_order_visible = 3 THEN order_stock_total_price ELSE 0 END), 3) as total_refaund
            ',

            'query' => array(
                'base_query' =>  " LEFT JOIN user_control ON user_control.user_visible != 555 ",
                'body' =>  "
                            WHERE stock_order_report.stock_order_visible IN (0, 3) AND stock_order_report.order_my_date = :mydateyear
                            AND stock_order_report.order_stock_count > 0
                            AND user_control.user_id = stock_order_report.sales_man
                            AND stock_order_report.reportType = 'RETAIL'
                                ",
                "joins" => "                                 
                                ",		
                'sort_by' => " GROUP BY user_control.user_id DESC
                            ORDER BY total_sales DESC ",
            ),
            'bindList' => array(
                'mydateyear' => $date ?? Utils::getDateMY()
            )                
        ])->get();        
    } 


    public static function addCashbackAmountToReport(int $transactionId, float $usedAmount)
    {   
        $option = [
            'before' => " UPDATE stock_order_report
                          SET stock_order_report.used_cashback_amount = :val ",
            'after' => "  WHERE stock_order_report.transaction_id = :transaction_id ",    
            'post_list' => [
                'transaction_id' => [
                    'query' => false,
                    'bind' => 'transaction_id'
                ],
                'val' => [
                    'query' => false,
                    'bind' => 'val'
                ]
            ]
        ];   
        
        db::update($option, [
            'val' => $usedAmount,
            'transaction_id' => $transactionId,
        ]);
    }

    /**
     * 
     */
    public static function getOrderTotalByTransactionId(int $transactionId)
    {
        $result = qb::select('SUM(order_stock_total_price) as orderSum')
                ->from('stock_order_report')
                ->where('transaction_id = :transactionId')
                ->bindList([
                    'transactionId' => $transactionId
                ])
                ->columnName('orderSum')
                ->execute()
                ->first()
                ->get();

        return $result['orderSum'];
    }
} 
