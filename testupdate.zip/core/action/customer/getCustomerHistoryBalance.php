<?php

use core\classes\Products;
use core\classes\Services\Customer\Customer;

use core\classes\Services\Warehouse\Traits\Arrival;
use core\classes\Utils\Utils;
use core\classes\System\Main;
use core\classes\Traits\TableHeaderList as TH;


header('Content-type: Application/json');

$id = $_POST['customerId'];

$customerName = Customer::getCustomerInfo($id, 'name');

$data_page = $init->initController('retailCustomer');

$blanaceHistoryList = Customer::getCustomerBalanceHistory($id);

foreach ($blanaceHistoryList as &$item)
{   $item['balanceChange'] = 0;

    if($item['earned_amount'] > 0) {
        $earned = $item['earned_amount'];
        $item['balanceChange'] = "+$earned";
    }

    if($item['spend_amount'] > 0) {
        $spend = $item['spend_amount'];
        $item['balanceChange'] = "-$spend";
    }
}

$table_result = Main::compareData($blanaceHistoryList, [
    'sort_key' => 'id',
    'get_data' => [
        'id'                => 'id',
        'date'              => 'date_full',
        'transactions'      => 'transaction_id',
        'balance_before'    => 'balance_before',
        'change_balance'    => 'balanceChange',
        'balance'           => 'balance_amount',
    ],
    'get_data@template' => [
        'id'                => TH::getTableHeaderByTemplate('id', 'th_w60', [
            'link_class'    => 'stock-link-text-both'
        ]),
        'transactions'      => TH::getTableHeaderByTemplate('transaction', 'th_w100', [
            'link_class'    => 'stock-link-text-both'
        ]),        
        'date'              => TH::getTableHeaderByTemplate('Tarix', 'width-auto', [
            'link_class'    => 'stock-link-text-both'
        ]),
        'balance_before'    => TH::getTableHeaderByTemplate('Evvelki balans', 'th_w90', [
            'link_class'    => 'stock-link-text-both ', 
            'mark' => [
                'mark_modify_class' => 'manat-icon--font'
            ]       
        ]),
        'change_balance'     => TH::getTableHeaderByTemplate('Change', 'th_w90', [
            'link_class'    => 'mark mark-tags mark-text',
            'mark'				=> array(
                'mark_text' 		=> '',
                'mark_modify_class' => 'manat-icon--font',
                'mark_operation_class' => true
            )        
        ]),        
        'balance'           => TH::getTableHeaderByTemplate('Balans', 'th_w90', [
            'link_class'    => 'stock-link-text-both', 
            'mark' => [
                'mark_modify_class' => 'manat-icon--font'
            ] 
        ]),
    ]
]);



$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/custom_modal/u_modal.twig' => [
            'modalController' => [
                'title' => "Bonus tarixçəsi",
                'closeButtonClassList' => 'removeModal',
            ],
            'modalContent' => [
                'path' => '/component/include_once_component.twig',
            ],
            'includs' => [
                'd' => [
                    '/component/widget/title.twig' => [
                        'title' => $customerName,
                        'classList' => 'margin-0 mrgn-top-100 sub-title',
                    ],
                    '/component/table/table_wrapper.twig' => [
                        'table' => $table_result
                    ],
                ]
            ],
            'containerClassList' => 'large-modal',  
		]  
	]
]);


$utils::abort([
	'res' => $total,
]);
