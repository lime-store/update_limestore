<?php
use core\classes\Utils\Utils;
use core\classes\System\Settings;

// Utils::log(Settings::getSetting('showPriceOnBarcodeLabel'));
// Utils::log(Settings::getSetting('appSync'));

$showPriceOnBarcodeLabel = (object) Settings::getSetting('showPriceOnBarcodeLabel');
$showCompanyNameOnBarcode = (object) Settings::getSetting('showCompanyNameOnBarcode');
$showProductNameOnBarcode = (object) Settings::getSetting('showProductNameOnBarcode');
$appSync                 = (object) Settings::getSetting('appSync');
$dbBackup                = (object) Settings::getSetting('telegram_backup');
$jsonSettings            = (object) Settings::getSettingsJSON();
$barcodeA4               = (object) Settings::getSetting('printA4Barcode');
$customerCashsback       = (object) Settings::getSetting('customerCashback');

echo $Render->view('/component/inner_container.twig', [
    'renderComponent' => [
        '/component/form/fields/settings/settings.twig' => [
            'includs' => [
                'companyInfo' => [
                    //appSync
                    '/component/form/fields/settings/companyInfo.twig' => [
                        'companyInfo' => $jsonSettings->generalInfo,
                    ]                    
                ],                
                'otherSettings' => [
                    //appSync
                    '/component/form/fields/settings/other.twig' => [            
                        [
                            'label' => [
                                'classList' => 'switcher-label',
                                'value' => 'Müştəri keşbeki',
                            ],
                            'button' => [
                                'classList' => 'switcher-new-state toggleSettingSwitcher',
                                'value' => $customerCashsback->state,
                                'attr' => [
                                    'data-radio-state' => $customerCashsback->state,
                                    'data-fields-name' => $customerCashsback->name,
                                    'data-id'          => $customerCashsback->id
                                ]
                            ] 
                        ], 
                        [
                            'label' => [
                                'classList' => 'switcher-label',
                                'value' => 'Data backup ',
                            ],
                            'button' => [
                                'classList' => 'switcher-new-state toggleSettingSwitcher',
                                'value' => $dbBackup->state,
                                'attr' => [
                                    'data-radio-state' => $dbBackup->state,
                                    'data-fields-name' => $dbBackup->name,
                                    'data-id'          => $dbBackup->id
                                ]
                            ] 
                        ],                
                        [
                            'label' => [
                                'classList' => 'switcher-label',
                                'value' => 'Web App-ilə sinxronizasiya ',
                            ],
                            'button' => [
                                'classList' => 'switcher-new-state toggleSettingSwitcher',
                                'value' => $appSync->state,
                                'attr' => [
                                    'data-radio-state' => $appSync->state,
                                    'data-fields-name' => $appSync->name,
                                    'data-id'          => $appSync->id
                                ]
                            ] 
                        ],
                    ]                    
                ],
                'barcoeLabelWidth' => [
                    '/component/form/fields/settings/barcode.twig' => [
                        'switcher' => [
                            [
                                'label' => [
                                    'classList' => 'switcher-label',
                                    'value' => 'Barkod A4 (x56)',
                                ],
                                'button' => [
                                    'classList' => ' switcher-new-state  toggleSettingSwitcher',
                                    'value' => $barcodeA4->state,
                                    'attr' => [
                                        'data-radio-state' => $barcodeA4->state,
                                        'data-fields-name' => $barcodeA4->name,
                                        'data-id'          => $barcodeA4->id
                                    ]
                                ] 
                            ],
                            // barcodeLabel
                            [
                                'label' => [
                                    'classList' => 'switcher-label',
                                    'value' => 'Barkodda qiyməti göstərmək',
                                ],
                                'button' => [
                                    'classList' => ' switcher-new-state  toggleSettingSwitcher',
                                    'value' => $showPriceOnBarcodeLabel->state,
                                    'attr' => [
                                        'data-radio-state' => $showPriceOnBarcodeLabel->state,
                                        'data-fields-name' => $showPriceOnBarcodeLabel->name,
                                        'data-id'          => $showPriceOnBarcodeLabel->id
                                    ]
                                ] 
                            ],
                            [
                                'label' => [
                                    'classList' => 'switcher-label',
                                    'value' => 'Barkodda mağaza adı göstərmək',
                                ],
                                'button' => [
                                    'classList' => ' switcher-new-state  toggleSettingSwitcher',
                                    'value' => $showCompanyNameOnBarcode->state,
                                    'attr' => [
                                        'data-radio-state' => $showCompanyNameOnBarcode->state,
                                        'data-fields-name' => $showCompanyNameOnBarcode->name,
                                        'data-id'          => $showCompanyNameOnBarcode->id
                                    ]
                                ] 
                            ], 
                            [
                                'label' => [
                                    'classList' => 'switcher-label',
                                    'value' => 'Barkodda mehsulun adı göstərmək',
                                ],
                                'button' => [
                                    'classList' => ' switcher-new-state  toggleSettingSwitcher',
                                    'value' => $showProductNameOnBarcode->state,
                                    'attr' => [
                                        'data-radio-state' => $showProductNameOnBarcode->state,
                                        'data-fields-name' => $showProductNameOnBarcode->name,
                                        'data-id'          => $showProductNameOnBarcode->id
                                    ]
                                ] 
                            ],                                                                                     
                        ],
                        'barcodeLabelSize' => [
                            'width' => Settings::getSettingsJSON()->stickerWidth,
                            'height' => Settings::getSettingsJSON()->stickerHeight
                        ]          
                    ] 
                ]
            ]
        ]
    ]
]);