<?php

use core\classes\Cart\Payment;
use core\classes\Privates\AccessManager;
use core\classes\Traits\TableHeaderList as TH;

$user = new \core\classes\Privates\User;
$Payment = new Payment;

return [
    'tab' => [
        'is_main' => true,
        'title'             => 'Kassa',
        'icon'              => [
            'img_big'           => 'assets/img/svg/070-file hosting.svg',
            'img_small'         => '',
            'modify_class'      => 'las la-wallet'
        ],
        'link'              => '/page/base.php',        
        'template_src'      => '/page/base_tpl.twig',
        'background_color'  => 'rgba(72, 61, 139, 0.1)',
        'tab' => array(
            'list' => [
                'tab_report_cash_register',
            ],
            'active' => 'tab_report_cash_register'          
        )
    ],          
    'sql' => [
        'table_name' => ' cash_registers ',

        // current_balance больше НЕ читаем из таблицы — считаем на лету,
        // по строкам, прошедшим фильтр в joins (payment_method = 1 или NULL).
        // PARTITION BY НЕ ставим, т.к. NULL и 1 должны быть одной цепочкой.
        'col_list'  => ' cash_registers.*, c.user_name, pm.title, pm.tags_id,
            SUM(cash_registers.amount_change) OVER (
                ORDER BY cash_registers.id
                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
            ) AS running_balance ',

        'query' => array(
            'base_query' =>  "",
            'body' =>  " ",
            "joins" => " LEFT JOIN user_control c ON c.user_id = cash_registers.user_id
                         LEFT JOIN payment_method_list as pm ON pm.id = cash_registers.payment_method  
            ",    
            'limit' => "limit 100",
            'sort_by' => " ORDER BY cash_registers.id DESC ",
        ),
        'bindList' => array(
        )        
            
    ],
    'page_data_list' => [
        'sort_key' => 'id',
        'get_data' => [
            'id'                => 'id',
            'date'              => 'created_at',
            'description'       => 'comment',
            'payment_method'    => 'payment_method',
            'user'              => 'user_name',
            'transaction_type'  => 'type',
            'change'            => 'amount_change',
            'balance'           => 'running_balance', // было: 'current_balance'
            'showTransactiodn'   => 'transaction_id'
        ],
        'get_data@template' => [
            'id' => TH::getTableHeaderByTemplate('id', 'th_w40', [
                'link_class'    => 'stock-link-text-both'
            ]),
            'date' => TH::getTableHeaderByTemplate('Tarix', 'th_w120', [
                'link_class'    => 'stock-link-text-both'
            ]),
            'payment_method' => TH::getTableHeaderByTemplate('Ödəniş üsulu', 'th_w60 text-center', [                
            ]),            
            'user' => TH::getTableHeaderByTemplate('Satıcı', 'th_w60 text-center', [
                'link_class'    => 'mark mark-tags mark-text mark-primary',
                'td_class'  => 'text-center',
            ]),
            'change' => TH::getTableHeaderByTemplate('Dəyişiklik', 'th_w40 text-center', [
                'link_class'    => 'mark mark-tags mark-text',
                'td_class'  => 'text-center',
                'mark'              => array(
                    'mark_text'         => '',
                    'mark_modify_class' => 'manat-icon--font',
                    'mark_operation_class' => true
                )  
            ]),
            'balance' => TH::getTableHeaderByTemplate('Kassa qalıq', 'th_w40 text-center', [
                'link_class'    => 'stock-link-text-both',
                'td_class'  => 'text-center',
                'mark' => array(
                    'mark_modify_class' => 'manat-icon--font',
                )                  
            ]),
            'transaction_type' => TH::getTableHeaderByTemplate('Əməliyyat növü', 'th_w60 text-center', [
                'link_class'    => 'stock-link-text-both',
                'td_class'  => 'text-center',
            ]),
            'description' => TH::getTableHeaderByTemplate('Qeyd', 'th_w160', [
                'link_class'    => 'stock-link-text-both'
            ]),
            'showTransactiodn'     => TH::getTableHeaderByTemplate('Göstər', 'th_w100 text-center', [
                'hideIfNotValue'     => true,
                'modify_class'          => 'th_w60',
                'td_class'          => 'table-ui-reset',
                'link_class'        => 'las la-eye btn btn-secondary width-100 table-ui-btn tr-hide-value modal-show-report-by-transaction',
                'data_sort'         => '',
                'mark'              => false
            ]),            
        ],
        'stats_card' => [
            'daily_cash',
            'daily_card',
            'total_cash',
            'total_card',

        ],        
        'table_total_list'  => [            
        ],
        'modal' => [
            'template_block' => 'report_return',
            'modal_fields' => array(
            )
        ],
        'filter_fields' => [
        ],
    ]
];