<!-- цсс -->
<link rel="stylesheet" type="text/css" href="/css/fonts.css">
<link rel="stylesheet" type="text/css" href="/css/style.css?v=<?php echo time(); ?>">
<link rel="stylesheet" type="text/css" href="/css/template.css?v=<?php echo time(); ?>">
<link rel="stylesheet" type="text/css" href="/css/animations.css?v=<?php echo time(); ?>">

<!-- ЖС скрипты -->
<script  src="/lib/js_lib/jquery-3.3.1.min.js?v=<?php echo time(); ?>"></script>
<script  src="/lib/js_lib/jquery.pos.js?v=<?php echo time(); ?>"></script>
<script defer="" src="/js/function.js?v=<?php echo time(); ?>"></script>
<script defer="" src="/js/ajax.js?v=<?php echo time(); ?>"></script>

<!-- Библиотеки для таблицы (нахер не нужны, но боюсь удалять, вдруг что то сломаю, пусть будут) -->
<script defer="" src="/lib/js_lib/data_tables/jquery.dataTables.min.js"></script>
<script defer="" src="/lib/js_lib/data_tables/dataTables.buttons.min.js"></script>
<script defer="" src="/lib/js_lib/data_tables/jszip.min.js"></script>
<script defer="" src="/lib/js_lib/data_tables/buttons.html5.min.js"></script>