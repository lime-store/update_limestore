<?php

use core\classes\Utils\Utils;
use core\classes\Products;
use core\classes\System\Settings;

header('Content-type: Application/json');



$stock_id = $_POST['data'];


$res = $products->getProductBarcodeList($stock_id);

$prod = Products::getProductById($stock_id);

$settingJSON = (object) Settings::getSettingsJSON();

$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
	      '/component/modal/custom_modal/u_modal.twig' => [
                  'containerClassList' => 'small-modal',
                  'modalController' => [
                        'title' => 'PRINT',
                        'closeButtonClassList' => 'removeModal'
                  ],
                  'modalContent' => [
                        'path' => '/component/modal/barcode/print_barcode_modal.twig',		
                  ],
                  'res'      => $res,
                  'stock_id' => $stock_id,
                  'product_name' => Settings::getSettingState('showProductNameOnBarcode') ? $prod['stock_name'] : '',
                  'price'    =>  Settings::getSettingState('showPriceOnBarcodeLabel') ? $prod['stock_second_price'] : '',
                  'width' => $settingJSON->stickerWidth,
                  'height' => $settingJSON->stickerHeight,
                  'companyName' => Settings::getSettingState('showCompanyNameOnBarcode') ? $settingJSON->generalInfo['companyName'] : '',
                  'barcodeA4' => Settings::getSettingState('printA4Barcode')
		]  
	]
]);


 $utils::abort([
	'res' => $total,
]);
