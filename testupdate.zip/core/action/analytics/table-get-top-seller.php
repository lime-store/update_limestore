<?php
use Core\Classes\Report;
use core\classes\Services\tableFooter;
use Core\Classes\System\Init;
use Core\Classes\Utils\Utils;

header('Content-Type: application/json');

$Report = new Report;
$orderBy = 'totla_sales';
$date = Utils::getDateMY();

$get_page = $init->initController('analytics');

$page_config = $get_page['page_data_list'];

if(!empty($_POST['date'])) {
    $date = $_POST['date'];
}

$data = Report::getReportBySeller($date);

$table = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_row.twig' => [
            'table' => $main->compareData($data, [
                'get_data' => $page_config['custom_get_data']['get_date_seller']
            ]),
            'table_tab' => 'analytics',
            'table_type' => ''       
        ]
    ]
]);


return $utils::abort([
    'table' => $table
]);