<?php
namespace core\classes\System;
use core\classes\dbWrapper\db;
use core\classes\Utils\Utils;
use core\classes\Traits\Token;

class System 
{
    use Token;
    
    /** 
     * открываем сессию и авторизуем пользователя
     * @param string $login
     * @param string $pass
    */
    public function auth($login, $password) 
    {
        $userData = db::select([
            'table_name' => 'user_control',
            'col_list' => '*',
            'query' => [
                'base_query' => '',
                'body' => ' WHERE `user_name` = :login ',
                'joins' => '',
                'sort_by' => ' LIMIT 1'
            ],
            'bindList' => array(
                'login' => $login
            )
        ])->first()->get();

        if(!empty($userData)) {
            if($userData['user_password'] == $password) {
                self::setUserSession($userData['user_id']);
            
                echo Utils::abort([
                    'success' => 'ok'
                ]);

                return true;
            } 	
        } 

        echo Utils::abort([
            'error' => 'Логин или пароль не правильный'
        ]);        
    }

    /**
     * 
     */
    public static function logout(callable $callback)
    {
        self::unsetUserSession();
        $callback(self::hasUserSession());
    }


    /**
     * @return boolean  true if session active 
     * @return boolean  false if session in not active
     */
    public static function hasUserSession()
    {
        if(isset($_SESSION['user'])) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * unset session
     * @return boolean
     */
    public static function unsetUserSession()
    {
        session_destroy();
        session_write_close();        
        unset($_SESSION['user']);
    }

    /**
     * 
     */
    public static function setUserSession($id)
    {
        $_SESSION['user'] = $id;
        $_SESSION['time_start_login'] = time();        
    }

}