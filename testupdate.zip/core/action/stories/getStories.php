<?php

use Core\Classes\Utils\Stories;
use Core\Classes\Utils\Utils;
$contentData = Stories::getStories();

// test
// $contentData = [
//     [
//         'message' => 'message',
//         'type' => 'image',
//         'url' => 'http://localhost/assets/img/pattern/mountains-02.jpeg'
//     ]
// ];

$tpl = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/stories/stories-row.twig' => [
            'contentData' => $contentData
        ]
    ]
]);

Utils::abort([
    'res' => $tpl
]);
