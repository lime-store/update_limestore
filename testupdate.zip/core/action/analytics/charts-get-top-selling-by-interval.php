<?php
use core\classes\Utils\Charts;
use core\classes\Report;
use core\classes\Utils\Utils;

header('Content-Type: application/json');

$Charts = new Charts;
$Report = new Report;
$orderBy = 'total_amount';
$date = 3;

if(!empty($_POST['date'])) {
    $date = $_POST['date'];
}

if(!empty($_POST['customData'])) {
    if(!empty($_POST['customData']['orderBy'])) {
        $orderBy = $_POST['customData']['orderBy'];
    }
}

$data = Report::getTopSellingProductsOfInterval($date, $orderBy);

$res = $Charts->getPieChartsData($data, 'stock_name', $orderBy);

echo json_encode($res);