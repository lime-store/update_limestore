<?php 

require_once $_SERVER['DOCUMENT_ROOT'].'/function.php';

//подключаем шаблоны
ls_include_tpl();


if(isset($_POST['value'])) {
	if(!empty($_POST['value'])) {

		$action = $_POST['action'];
		$search = trim($_POST['value']);
		$search_list = [];
		if($action == 'name') {
			$query = 'SELECT DISTINCT stock_name as res 
					  FROM stock_list 
					  WHERE stock_name LIKE :name 
					  GROUP BY stock_name DESC 
					  LIMIT 100';

		}
		if($action == 'category') {
			$query = 'SELECT DISTINCT stock_provider as res 
					  FROM stock_list 
					  WHERE stock_provider LIKE :name 
					  GROUP BY stock_provider DESC 
					  LIMIT 100';
		}

		$search_value_stmt = $dbpdo->prepare($query);
		$search_value_stmt->bindValue('name', "%{$search}%"); 
		$search_value_stmt->execute();


		if($search_value_stmt->rowCount() > 0) {
			while ($search_value_row = $search_value_stmt->fetch(PDO::FETCH_BOTH))
				$search_list[] = $search_value_row;
			foreach ($search_list as $search_value_row) {
					$search_val = $search_value_row['res'];
					get_autocomplete_list_tpl($search_val, '');
			}
		} else {
			get_autocomplete_list_tpl($search, ' <not result');
		}
	}
}
