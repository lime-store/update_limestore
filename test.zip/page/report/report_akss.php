<?php 
	require_once '../../function.php';
	// //Показывать товары которые находться в базе больше 15 дней 
	// settShowOldProduct();

	// //кнопка компактного меню на странице
	// modalNavigationBtn();

	// //выводим компакнтное меню на странице 
	// getModalSideBarNav();

	// //блок для принта чека
	// printModal();

	// //выводим перекючения вкладок 
	// getCurrentTab(); 


	//получаем тип таблицы
	get_table_svervice_type();

	//получем категорию товара
	get_product_category();
	$product_category = $product_akss;

	//выводим фильт по дате	
	filt_report_date($product_akss, $dbpdo, $order_myear, 'report'); 

	ls_include_tpl();

?>


<div class="view_stock_wrapper">
	<div class="view_stock_box_wrp">
		<!-- начало вывода статистики за месяц -->
		<?php require_once $_SERVER['DOCUMENT_ROOT'].'/core/pulgin/stats_card/stats_report.php'; ?>	
		<!-- конец статистики за месяц -->
		

		<!-- начало тут выводим поиск -->
		<div class="report_search_wrapper">

			<?php advanced_option_load_tpl(); ?>
	
			<div class="report_search_item">	
				<div class="report_search_box">
					<?php 
						search_input($arr = array(
							'product_type' => $report,
							'product_category' => $product_akss,
							'auto_complete' => 'show',
							'product_class' => 'auto-cmplt-input stock_auto_compelete',
							'parent_class' => 'auto-cmplt-parent search_filter',
							'label' => 'hide',
							'label_title' => '',
							'clear_button' => 'show' 
						)); 
					?>
				</div>
			</div>	
		</div>
		<!-- конец поиска -->

		<div class="stock_view_wrapper">
			<div class="stock_view_list ls-custom-scrollbar">
				<table class="stock_table">
					<thead>
						<tr>
							<?php 
								check_th_access_tpl(array(
									'th_serial' 		=> true,
									'th_day_sale'		=> true,
									'th_prod_name' 		=> true,
									'th_sale_price' 	=> true,
									'th_category'		=> true,
									'th_report_note' 	=> true,
									'th_count' 			=> true,
									'th_profit'			=> true
								));									
							?>							
						</tr>
					</thead>
					<tbody class="stock_list_tbody" data-stock-src="<?php echo $report; ?>" data-category="<?php echo $product_akss; ?>">	

						<?php 
							$report_list = [];
							$report_stmt = $dbpdo->prepare("SELECT *
								FROM user_control 
								INNER JOIN stock_order_report ON stock_order_report.order_my_date = :mydateyear
								AND stock_order_report.stock_order_visible = 0
								AND stock_order_report.stock_type = :product_category
								AND stock_order_report.order_stock_count > 0

								LEFT JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id
								GROUP BY stock_order_report.order_stock_id DESC
								ORDER BY stock_order_report.order_stock_id DESC
								");
							$report_stmt->bindParam('mydateyear', $order_myear, PDO::PARAM_INT);
							$report_stmt->bindParam('product_category', $product_category, PDO::PARAM_INT);
							$report_stmt->execute();

							   if($report_stmt->rowCount() > 0){
									while ($report_row = $report_stmt->fetch(PDO::FETCH_BOTH))
										$report_list[] = $report_row;
										foreach ($report_list as $report_row)
										{
											$stock_id 			= $report_row['order_stock_id'];
											$order_date 		= $report_row['order_date'];
											$stock_name 		= $report_row['order_stock_name'];
											$stock_sprice 		= $report_row['order_stock_sprice'];
											$stock_provider 	= $report_row['stock_provider'];
											$stock_count 		= $report_row['order_stock_count'];
											$order_note 		= $report_row['order_who_buy'];
											$stock_profit 		= $report_row['order_total_profit'];

											echo '<tr class="stock-list" id="'.$stock_id.'">';		
												 check_td_access_tpl(array(
													'th_serial' 		=> $stock_id,
													'th_day_sale'		=> $order_date,
													'th_prod_name' 	  	=> $stock_name,
													'th_sale_price' 	=> $stock_sprice,
													'th_provider' 		=> $stock_provider,
													'th_report_note'	=> $order_note,
													'th_count'			=> $stock_count,
													'th_profit'			=> $stock_profit
												));										
											echo '</tr>';
										}
									//выводим выручку за меясц
									get_total_all_profit_phone($dbpdo, $order_myear, $product_category,$manat_image);
							    }

						?>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
