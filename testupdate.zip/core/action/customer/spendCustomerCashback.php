<?php

use core\classes\Services\Customer\Customer;
use core\classes\Report;

$reportInfo = Report::getLastReport()[0];
$transactionId      = $reportInfo['transaction_id'];
$orderInfo = Report::getOrderByTransactionId($transactionId)[0];
$customer_id        = $reportInfo['customer_id'];
$orderSum           = $orderInfo['transaction_order_total'];
$spendAmount        = $_POST['spendAmount'];

Customer::spendCashback($customer_id, $spendAmount, $transactionId);

$getOrder = Report::getReportByColumn('transaction_id', $transactionId);


$reportCashback = $spendAmount / count($getOrder);


Report::addCashbackAmountToReport($transactionId, $reportCashback);

$utils::successAbort('ok');