<?php 
require_once $_SERVER['DOCUMENT_ROOT'].'/function.php';

/******CHECK FILTER TABLE NAME******/
$filter_tbname = 'filter';

$filter_tb_sql = "CREATE TABLE `".$filter_tbname."` (
				  `filter_id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
				  `filter_type` varchar(255) NOT NULL,
				  `filter_value` varchar(255) NOT NULL,
				  `filter_visible` int(11) NOT NULL DEFAULT 0
				) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

$filter_insert_sql = '';
$filter_data = array(
					array("color", "Black"),
					array("color", "Red"),
					array("color", "Gold"),
					array("color", "Rose Gold"),
					array("color", "Rose"),
					array("color", "Yellow"),
					array("color", "Pink"),
					array("color", "Gray"),
					array("color", "Blue"),
					array("color", "Blue"),
					array("storage", "256"),
					array("storage", "512"),
					array("color", "test pink"),
					array("ram", "test 8")
				);
//создаем таблицу и заполняем ее 30.08
check_table_exists($filter_tbname, $filter_tb_sql, $filter_data);


//добавляю к таблице новые столбцы
// $filter_column_name = array(
// 	array("col_name",	 "int(11) NOT NULL"),
// );
//дополнить таблицу столбцами
// check_table_column_exists($filter_tbname, $filter_column_name);		
/******END FILTER******************/




/******CHECK STOCK_FILTER TABLE NAME******/
$stock_filter_tbname = 'stock_filter';
$stock_filter_sql = "CREATE TABLE `".$stock_filter_tbname."` (
					  `stock_filter_id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
					  `stock_id` int(11) NOT NULL,
					  `filter_color_id` int(11) NOT NULL,
					  `filter_storage_id` int(11) NOT NULL,
					  `filter_ram_id` int(11) NOT NULL,
					  `filter_used_id` int(11) NOT NULL
					) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
$filter_data = '';
//создаем таблицу и заполняем ее 30.08
check_table_exists($stock_filter_tbname, $stock_filter_sql, $filter_data);

//добавляю к таблице новые столбцы
 // $stock_filter_column_name = array(
 // 	array("column name", "column param"),
 // );

//дополнить таблицу столбцами
//check_table_column_exists($stock_filter_tbname, $stock_filter_column_name);

/******END STOCK_FILTER******************/















//проверяю на наличие таблицы в базе данных
function check_table_exists($table_name, $sql, $data) {
	global $dbpdo;
	//проверка на таблицу 
	try {	
		$check_db = $dbpdo->prepare('SELECT EXISTS(
	       SELECT * FROM  '.$table_name.') ');
		$check_db->execute();
		//если есть таблица проверить на дату и добавить дату
		check_db_data($table_name, $data);
	} 
	catch(PDOException $e) {
		//если таблицы нет
		creat_table($table_name, $sql, $data);
	}
}

//создаю новую табицу в азе данных
function creat_table($table_name, $sql, $data) {
	global $dbpdo;
	try { 
	    $dbpdo->exec($sql);
	    check_db_data($table_name, $data);
	} 
	catch(PDOException $e) {
	    header('Location: /');
	}
}

//если таблица была в базе проверяю ее на пустоту
function check_db_data($table_name, $array) {
	global $dbpdo;
	global $filter_tbname;
	$data_arr = array();

	//START таблица filter
	if($table_name == $filter_tbname) {
		foreach ($array as $row => $value) {
			$filter_type = $value[0];
			$filter_value = $value[1];
			try {
				$check_exist_data = $dbpdo->prepare('SELECT * FROM filter
				WHERE filter_type = :type 
				AND filter_value = :value 
				GROUP BY filter_id DESC');
				$check_exist_data->bindParam('type', $filter_type);	
				$check_exist_data->bindParam('value', $filter_value);
				$check_exist_data->execute();

				if($check_exist_data->rowCount()>0) {
					echo " ";
				} else {
					$data_arr = array(
						'filter_type' => $filter_type,
						'filter_value' => $filter_value
					);

					install_data( $table_name, $data_arr );
				} 

			} catch(PDOException $e) {
				echo "таблицы не существует";
			}
		}	
	}
	//END таблица filter

}


//заполняю таблицу данными
function install_data($table_name, $data_arr) {
	global $dbpdo;
	/******filter data******/
	if($table_name === 'filter') {
		$filter_type = $data_arr['filter_type'];
		$filter_value = $data_arr['filter_value'];

		$add_fiter = $dbpdo->prepare('INSERT INTO filter (filter_type, filter_value)  VALUES (?, ?) ');
		$add_fiter->execute([$filter_type, $filter_value]);
	}	
	/******filter data******/
}

//проверить на наличие столбца в таблице
function check_table_column_exists($table_name, $column_arr) {
	global $dbpdo;

	foreach ($column_arr as $row => $value) {
		$col_name = $value[0];
		$col_param = $value[1];

		try {
			//тут проверяем на наличие столбца
			$col_check = $dbpdo->prepare('SELECT '.$col_name.' FROM  '.$table_name.'  ');
			$col_check->execute();				
		} catch (Exception $e) {
			$data = array(
				'col_name' => $col_name,
				'col_param' => $col_param 
			);
			//если нет вызываем функци и добавляем
			alert_table_column($table_name, $data);
		}
		
	}


}

//добавить новый столбец к таблице 
function alert_table_column($table_name, $data) {
	global $dbpdo;
	$col_name = $data['col_name'];
	$col_param = $data['col_param'];

	$insert_col_sql = 'ALTER TABLE `'.$table_name.'` ADD `'.$col_name .'` '.$col_param.' ';
	$dbpdo->exec($insert_col_sql);
}