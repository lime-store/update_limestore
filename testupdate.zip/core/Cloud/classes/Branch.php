<?php 
namespace core\Cloud\classes;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\Services\BaseService;

class Branch 
{
    public static function getBranches(): array
    {
        $result = qb::select('*')
                    ->from('branches')
                    ->where('visible', BaseService::VISIBLE_STATE['visible'])
                    ->get();

        return $result ?? [];
    }

    /**
     * 
     */
    public static function getBranchByToken(string $token): array
    {
        $result = qb::select('*')
                    ->from('branches')
                    ->where('token', $token)
                    ->first()
                    ->get();

        return $result ?? [];
    }
}