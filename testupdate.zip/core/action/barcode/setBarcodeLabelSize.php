<?php
use Core\Classes\System\Settings;
use Core\Classes\Utils\Utils;

if(!empty($_POST['width'])) {
    Settings::saveSettingsJSON([
        'stickerWidth' => $_POST['width']
    ]);
}

if(!empty($_POST['height'])) {
    Settings::saveSettingsJSON([
        'stickerHeight' => $_POST['height']
    ]);
}