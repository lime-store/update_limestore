<?php 
namespace Core\Classes;

use Core\Classes\Cart\Checkout;
use core\classes\dbWrapper\db;
use Core\Classes\Traits\ReportStatsCard;
use Core\Classes\System\Main;
use Core\Classes\Utils\Utils;
use core\classes\dbWrapper\queryBilder as QB;
use Core\Classes\System\Init;

class Report {
    use ReportStatsCard;

    public $main;
    public static $index = 'report'; 
    
    public function __construct()
    {
        $this->main = new Main;
    }

    /**
     * @param int $id  id отчета
     * @return array
     *  Получить отчет по id
     */
    public static function getReportById(int $id)
    {
        return db::select([
            'table_name' => 'stock_order_report',
            'col_list' => '*',
            'query' => [
                'base_query' => ' LEFT JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id  
                                    WHERE stock_order_report.order_stock_id = :id ',
                'sort_by' => ' GROUP BY stock_order_report.order_stock_id DESC ORDER BY stock_order_report.order_stock_id DESC  '
            ],            
            'bindList' => [
                ':id' => $id
            ]
            
        ])->first()->get();
    }

    /**
     *  Получить отчет по id
     */
    public static function getReportByColumn(string $columnName, $value, array $visible = [0])
    {
        $visiblePos = implode(',', array_fill(0, count($visible), '?'));

        $myBinds = array_merge([$value], array_values($visible));

        return db::select([
            'table_name' => 'stock_order_report',
            'col_list' => '*',
            'query' => [
                'base_query' => " LEFT JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id  
                                    WHERE $columnName = ? AND stock_order_report.stock_order_visible  IN ($visiblePos) ",
                'sort_by' => ' GROUP BY stock_order_report.order_stock_id DESC ORDER BY stock_order_report.order_stock_id DESC  '
            ],            
            'bindList' => $myBinds
        ], ['placeholders' => 'positional'])->get();
    }


    /**
     * Получить отчет за месяц
     */
    public function getMonthlyReport(string $month = null)
    {

        $controllerData = $this->main->getControllerData('report');

        $data_page = $controllerData->allData;

        $data_page['sql']['query']['body'] = $data_page['sql']['query']['body']  . "  AND stock_order_report.order_my_date = :mydateyear";
        $data_page['sql']['bindList']['mydateyear'] = !empty($month) ? $month : date('m.Y');
        

        return $this->main->prepareData($data_page['sql'], $data_page['page_data_list']);
    }

    /**
     *  Поулчить отчет за день
     */
    public function getDailyReport(string $day = null)
    {
        $controllerData = $this->main->getControllerData('report');

        $data_page = $controllerData->allData;
                
        $data_page['sql']['query']['body'] = $data_page['sql']['query']['body'] . "  AND stock_order_report.order_date = :mayday ";
        $data_page['sql']['bindList']['mayday'] = !empty($day) ? $day : date('d.m.Y');
        
        return $this->main->prepareData($data_page['sql'], $data_page['page_data_list']);
    }    


    /**
     * 
     */
    public function getTopSellingProductsOfMonth($date) 
    {
        return db::select([
            'table_name' => 'stock_order_report',
            'col_list' => "  order_my_date as smonth, order_stock_name,  SUM(order_total_profit) AS total_profit ",
            'query' => [
                'base_query' => '',
                'body' => " WHERE stock_order_report.order_my_date = :mydate
                            AND stock_order_visible = 0 ",
                'sort_by' => ' GROUP BY stock_order_report.stock_id ASC ORDER BY total_profit DESC ',
                'limit' => ' limit 10 '
            ],
            'bindList' => [
                ':mydate' => $date
            ],
        ])->get();
    } 

    /**
     * 
     */
    public function getLastReport()
    {
       $init = new Init();
       $report = $init->getControllerData(self::$index)->allData;
       $report['sql']['query']['limit'] = 'limit 1';
       return db::select($report['sql'])->get();
    }



    /**
     * Редактировать отчет продажи 
     * @param array $data
     * @return json
     */
    public function editReport($data) 
    {
        $option = [
            'before' => ' UPDATE stock_order_report JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id SET ',
            'after' => ' WHERE order_stock_id = :report_id  ',
            'post_list' => [
                'report_order_id' => [
                    'query' => false,
                    'bind' => 'report_id',
                    'require' => true
                ],
                'edit_report_order_tags' => [
                    'query' => ' stock_order_report.payment_method = :payment_tags_id ',
                    'bind' => 'payment_tags_id',
                    'require' => false
                ],
                'edit_report_order_note' => [
                    'query' => ' stock_order_report.order_who_buy = :order_note ',
                    'bind' => 'order_note',
                    'require' => false
                ],

                'report_edit_order_count' => [
                    'query' => '  stock_list.stock_count =  stock_list.stock_count + stock_order_report.order_stock_count ',
                    'bind' => false,
                    'require' => false                    
                ],
            ]
        ];

        $required = [
            'edit_report_order_tags',
            'edit_report_order_note',
        ];

        if (count(array_intersect_key(array_flip($required), $data)) === count($required)) {
            db::update($option, $data);
        }
        
        if(array_key_exists('report_edit_order_count', $data)) {
            $this->changeOrderCount($data);
        }

        if(array_key_exists('report_edit_price', $data)) {
            $this->changeOrderPrice($data);
        }
    }



    /**
     * Возврат товара, по количеству
     * 
     * @param array $data = Array (
     *      [report_order_id]           => int 1234
     *      [report_edit_order_count]   => int 123
     *      [report_edit_price]         => int 12
     *   )
     */
    public function changeOrderCount($data)
    {
        // products count refaund
        $option2 = [
            'before' => ' UPDATE stock_order_report JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id SET ',
            'after' => ' WHERE order_stock_id = :report_id  ',
            'post_list' => [
                'report_order_id' => [
                    'query' => false,
                    'bind' => 'report_id',
                    'require' => true
                ],                
                'report_edit_order_count' => [
                    'query' => ' 
                        stock_list.stock_count = stock_list.stock_count - :changeCount1,
                        stock_order_report.order_stock_count = :changeCount2,
                        stock_order_report.max_refaund_quantity = :changeCount3
                    ',
                    'bind' => [
                        'changeCount1',
                        'changeCount2',
                        'changeCount3',
                    ],
                    'require' => false
                ],
            ]
        ];

        return db::update($option2, $data);        
    }


    /**
     * Изменяем цену в отчете 
     * 
     * @param array @data
     */
    public function changeOrderPrice($data) 
    {
        // products price change
        $option3 = [
            'before' => ' UPDATE stock_order_report JOIN stock_list ON stock_list.stock_id = stock_order_report.stock_id SET ',
            'after' => ' WHERE order_stock_id = :report_id  ',
            'post_list' => [
                'report_order_id' => [
                    'query' => false,
                    'bind' => 'report_id',
                    'require' => true
                ],                
                'report_edit_price' => [
                    'query' => ' stock_order_report.order_stock_sprice = :new_price, 
                                 stock_order_report.order_stock_total_price = :new_price2 * stock_order_report.order_stock_count,
                                 stock_order_report.order_total_profit = stock_order_report.order_stock_total_price - (stock_list.stock_first_price * stock_order_report.order_stock_count) 
                                 
                    
                    ',
                    'bind' => [
                        'new_price',
                        'new_price2'
                    ],
                    'require' => false                    
                ]
            ]
        ];

        return db::update($option3, $data);        
    }




    /**
     * Возврат товара (продажи)
     * @param array $data
     * @return json 
     */
    public function deleteReport($data) 
    {
        $option = [
            'before' => " UPDATE stock_list
                          JOIN stock_order_report ON stock_order_report.order_stock_id = :delete_id
                          SET stock_list.stock_count = 
                            CASE 
                                WHEN stock_order_report.stock_order_visible = 3
                                THEN stock_list.stock_count - stock_order_report.order_stock_count
                                ELSE stock_list.stock_count + stock_order_report.order_stock_count
                            END,    
                          stock_order_report.stock_order_visible = 2,
                          stock_list.stock_return_status = 1 ",
            'after' => "  WHERE stock_list.stock_id = stock_order_report.stock_id ",    
            'post_list' => [
                'report_id' => [
                    'query' => false,
                    'bind' => 'delete_id'
                ]
            ]
        ];   

        db::update($option, $data);
    }


    public static function addReport($res)
    {
        return db::insert('stock_order_report', $res);
    }   

    /**
     * 
     */
    public static function setReportEditableState($reportId, bool $hasEditable)
    {

        $option = [
            'before' => " UPDATE stock_order_report
                          SET stock_order_report.has_editable = :val ",
            'after' => "  WHERE stock_order_report.order_stock_id = :report_id ",    
            'post_list' => [
                'report_id' => [
                    'query' => false,
                    'bind' => 'report_id'
                ],
                'val' => [
                    'query' => false,
                    'bind' => 'val'
                ]
            ]
        ];   
        
        db::update($option, [
            'report_id' => $reportId,
            'val' => $hasEditable,
        ]);
    }

    /**
     * Добавляет возврат в бд
     */
    public static function refaundOrder($orderId, $refaundQuantity)
    {
        $getOrder = self::getReportById($orderId);

        if($getOrder['stock_order_visible'] == 3) {
            return false;
        }

        $prepare = Checkout::prepareOrderData([
            'ProductsData'    => $getOrder,
            'id'              => $getOrder['stock_id'],
            'order_price'     => $getOrder['order_stock_sprice'],
            'order_count'     => $refaundQuantity,
            'description'     => $getOrder['order_who_buy'],
            'payment_method'  => $getOrder['payment_method'],
            'sales_man'       => $getOrder['sales_man'],
            'transaction_id'  => $getOrder['transaction_id'],
        ]);
        
        $prepare[$getOrder['stock_id']]['stock_order_visible'] = '3';
        
        self::addReport($prepare);

        Products::increaseProductCount([
            'stock_id'       => $getOrder['stock_id'],
            'product_count'  => $refaundQuantity
        ]);

        return true;
    }

    /**
     * 
     */
    public static function getMaxRefaundQuantity($reportId)
    {
        $report = self::getReportById($reportId);
        return $report['max_refaund_quantity'];
    }


    /**
     * @return bool если количество равно или меньше чем можно сделать возврат
     *              то выводим true иначе false
     */
    public static function canRefaundQuantity($reportId, int $count)
    {
        $maxCount = self::getMaxRefaundQuantity($reportId);
    
        if(!empty($count) && $count <= $maxCount && $count > 0) {
            return true;
        }

        return false;
    }


    public function getDifferenceOrderCount(int $orderCount, int $changeCount) {

    }

    /**
     * 
     */
    public static function increaseRefaundQuantity(array $data) 
    {
        $option = [
            'before' => " UPDATE stock_order_report SET ",
            'after' => " WHERE stock_order_report.order_stock_id = :report_id ",
            'post_list' => [
                'report_id' => [
                    'query' => false,
                    'bind' => 'report_id'
                ],
                'refaund_quantity' => [
                    'query' => "stock_order_report.max_refaund_quantity = stock_order_report.max_refaund_quantity + :refaund_quantity",
                    'bind' => 'refaund_quantity'
                ]
            ]
        ];

        db::update($option, $data);
    }

    /**
     * 
     */
    public static function decreaseRefaundQuantity(array $data)
    {
        $option = [
            'before' => " UPDATE stock_order_report SET ",
            'after' => " WHERE stock_order_report.order_stock_id = :report_id ",
            'post_list' => [
                'report_id' => [
                    'query' => false,
                    'bind' => 'report_id'
                ],
                'refaund_quantity' => [
                    'query' => "stock_order_report.max_refaund_quantity = stock_order_report.max_refaund_quantity - :refaund_quantity",
                    'bind' => 'refaund_quantity'
                ]
            ]
        ];

        db::update($option, $data);
    }




} 
