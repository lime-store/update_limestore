<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/function.php';

header('Content-type: Application/json');

$stock_id = $_POST['data'];

ls_db_delete(array(
    [
        'table_name' => 'stock_barcode_list',
        'joins' => '',
        'where' => ' br_stock_id = :id ',
        'bindList' => [
            ':id' => $stock_id,
        ]			
    ]
));

if($_POST['update_barcodle_list']) {
    $list = [];
    foreach($_POST['update_barcodle_list'] as $key => $value) {
        $list[] = [
            'barcode_value' => $value,
            'br_stock_id' => $stock_id
        ];
    }

    ls_db_insert('stock_barcode_list', $list);

}

