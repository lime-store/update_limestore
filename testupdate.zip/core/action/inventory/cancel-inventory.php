<?php
header('Content-type: Application/json');

use core\classes\Inventory\Inventory;
use core\classes\Utils\Utils;

$inventoryId = (int) ($_POST['id'] ?? 0);

try {
    Inventory::cancel($inventoryId, $user->getCurrentUser('get_id'));

    Utils::successAbort('Sayim ləğv edildi');
} catch (\Throwable $e) {
    Utils::errorAbort(inventoryErrorMessage($e));
}