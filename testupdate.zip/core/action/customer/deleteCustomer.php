<?php

use core\classes\Services\Customer\Customer;
use core\classes\Utils\Utils;

$id = $_POST['id'];

if (Customer::delete($id)) {
    Utils::successAbort('ok');
}
