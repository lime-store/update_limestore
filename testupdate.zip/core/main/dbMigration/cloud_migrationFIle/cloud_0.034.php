<?php 
use core\classes\System\Migration;

Migration::hasTableExist('sync_queue', function($noExist) {
    if($noExist) {
        Migration::createTable(
            "CREATE TABLE sync_queue (
            id INT PRIMARY KEY AUTO_INCREMENT,
            branch_id INT NOT NULL,
            product_id INT NOT NULL,
            action varchar(70),
            payload JSON NOT NULL,
            status ENUM('pending','done','error') DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            synced_at DATETIME NULL,
            error_message TEXT NULL,
            INDEX idx_branch_status (branch_id, status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
        );
    }
});

$warehouse_token_query_001 = [
    'token' => 'VARCHAR(64) UNIQUE NULL DEFAULT NULL'
];

Migration::hasTableColumnExist('warehouse_list', $warehouse_token_query_001, function($r) {
    if($r) {
        Migration::alertTableColumn('warehouse_list', $r);
    }
});

Migration::createTableIfNotExist('branches', 
    "CREATE TABLE branches (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name varchar(70),
        description varchar(255),
        token VARCHAR(64) UNIQUE NULL DEFAULT NULL,
        visible ENUM('visible','invisible') DEFAULT 'visible',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_branch_id (id, token)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
);