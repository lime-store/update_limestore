<?php
use Core\Classes\System\Migration;
use Core\Classes\System\Settings;


if(!Settings::hasSettingsJSON('config', 'mysqlPort')) {
    Settings::appendSettingsJSON([
        'config' => [
            "mysqlPort" => 3306
        ]
    ]);
}