<?php

use core\classes\Utils\Utils;
use core\Cloud\classes\Branch;

$data_page = $init->initController($page);

$page_config = $data_page['page_data_list'];

$data_page['sql']['query']['body'] = $data_page['sql']['query']['body'] . ' AND branch_id IS NULL ';

$table_result = $main->prepareData($data_page['sql'], $data_page['page_data_list']);

echo $Render->view('/component/inner_container.twig', [
	'renderComponent' => [
		'/component/related_component/include_widget.twig' => [
			'/component/buttons/select/select-button.twig' => [
				'main' => [
					'class_list' => [
						'init_element' => ' widget-fields',
						'container' => ' widget-fields-container',
						'input_parent' => 'width-100 input-dropdown-parent'
					]
				],
				'input' => [
					'label' => 'Axtar',
					'icon' => 'las la-calendar-alt',
					'class_list' => 'form-input input-select area-button input-dropdown branch-button',
					'attribute' => [
						'type' => 'button',
						'value' => 'Filial',
						'placeholder' => 'Some'
					]
				],
				'list' => [
					'class_list' => [
						'container' => 'form-fields-autocomplete ',
						'ul_list' => 'width-100 select-list unset-min-width',
						'list_item_container' => '',
						'list_item_link' => 'select-branch-users selectable-search-item area-closeable select-hidden-fields-input input-dropdown-auto-list-li'
					],
					'default_first' => false,
					'list_data' => Utils::toDropdownItems(Branch::getBranches(), 'id', 'name'),
				],
				'hidden_input' => [
					'class_list' => 'admin-select-user-branch'
				]
			],

			'/component/parts/input.twig' => [
				'inputClassList' => 'input btn-input width-auto load-user-add-modal',
				'inputIcon' => [
					'icon' => 'las la-user-plus'
				],
				'attr' => [
					'type' => 'button',
					'value' => 'Cloud atıcı əlavə edin'
				]
			],
		],
		'/component/table/table_wrapper.twig' => [
			'table' => $table_result['result'],
			'table_tab' => $page,
			'table_type' => $type,
		],
	]
]);
