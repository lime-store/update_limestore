<?php
use Core\Classes\Report;
use core\classes\Services\tableFooter;
use Core\Classes\System\Init;
use Core\Classes\Utils\Utils;

header('Content-Type: application/json');

$Report = new Report;
$orderBy = 'total_count';
$date = 3;

$get_page = $init->initController('analytics');

$page_config = $get_page['page_data_list'];

if(!empty($_POST['date'])) {
    $date = $_POST['date'];
}

if(!empty($_POST['customData'])) {
    if(!empty($_POST['customData']['orderBy'])) {
        $orderBy = $_POST['customData']['orderBy'];
    }
}

$data = Report::getTopSellingProductsOfInterval($date, $orderBy);

$table = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_row.twig' => [
            'table' => $main->compareData($data, $page_config),
            'table_tab' => 'analytics',
            'table_type' => ''       
        ]
    ]
]);


$total = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_footer_row.twig' => [		
            'table_total' => tableFooter::getData(['total_count', 'total_amount', 'total_profit'], $data)  
        ]  
    ]
]);

return $utils::abort([
    'table' => $table,
    'total' => $total
]);