<?php
header('Content-type: Application/json');

use core\classes\Inventory\Inventory;
use core\classes\Utils\Utils;

require __DIR__.'/_helpers.php';

$inventoryId = (int) ($_POST['inventory_id'] ?? 0);

if($inventoryId <= 0) {
    Utils::errorAbort('Sayim seçilməyib');
    return;
}

try {
    $inventory = Inventory::find($inventoryId);

    if(empty($inventory)) {
        Utils::errorAbort('Sayim tapılmadı');
        return;
    }

    $missingItems = Inventory::pendingMissingItems($inventoryId);

    if(!empty($missingItems)) {
        Utils::abort([
            'type'          => 'success',
            'action'        => 'missing_items',
            'missing_count' => count($missingItems),
            'modal'         => renderInventoryMissingModal($inventoryId, $missingItems, $inventory),
        ]);
        return;
    }

    $report = Inventory::close($inventoryId, $user->getCurrentUser('get_id'));
} catch (\Throwable $e) {
    Utils::errorAbort(inventoryErrorMessage($e));
    return;
}

Utils::abort([
    'type'         => 'success',
    'text'         => 'Sayim tamamlandı',
    'report_modal' => renderInventoryReportModal($report),
]);