<?php 

$accessManager = new \core\classes\Privates\AccessManager;

return [
    'tab' => [
        'is_main' => false,
        'title' 			=> 'Customer',
        'icon'				=> [
            'img_big'		 	=> 'assets/img/svg/sidebar/1.svg',
            'img_small'			=> 'assets/img/svg-icon/sidebar/1.svg',
            'modify_class' 		=> 'las la-cart-arrow-down'
        ],
        'link'  			=> '/page/base.php',
        'template_src'      => 'page/base_tpl.twig',
        'background_color'  => 'rgba(0, 150, 136, 0.1)',
        'tab' => array(
            'list' => [
            ],
            'active' => ''
        )
    ],			
    'sql' => [
        'table_name' => ' customer ',
        'col_list'	=> ' * ',
        'query' => array(
            'base_query' =>  "  ",     
            'body' =>  " ",
            "joins" => "",									  
            'sort_by' => " 	GROUP BY customer.id DESC  
                            ORDER BY customer.id DESC ",
            'limit' => ""
        ),	
        'bindList' => array(
        )        
    ],
    'page_data_list' => [
        'sort_key' => 'id',
        'get_data' => [
            'id' 				=> 'id',
            'name'			 	=> 'name',
            'description' 		=> 'description',
            'user_cashback_card_code' => 'cashback_card_code'
          ],
        'autocomplete' => [
            [
                'display' => 'name',
                'search' => [
                    'id' 				=> 'id',
                    'name'			 	=> 'name',
                    'description' 		=> 'description',
                    'user_cashback_card_code' => 'cashback_card_code',
                    'customer_contact_number' => 'contact_number'
                ]
            ]
        ],
        'table_total_list' => [
            'stock_count',
            'search_count',
        ],
        'modal' => [
            'template_block' => 'info_product',
            'modal_fields' => array(
                'info_product_name' => [
                    'db' => 'stock_name',
                    'custom_data' => false,
                    'premission' => true
                ],
                'info_product_description' => [
                    'db' => 'stock_phone_imei',
                    'custom_data' => false,
                    'premission' => true
                ],
                'info_product_count' => [
                    'db' => 'stock_count',
                    'custom_data' => false,
                    'premission' => true
                ],
                'info_product_category' => [
                    'db' => 'category_name',
                    'custom_data' => false,
                    'premission' => true
                ],						
                'info_product_provider' => [
                    'db' => 'provider_name',
                    'custom_data' => false,
                    'premission' => true
                ],						
                'info_product_first_price' => [
                    'db' => 'stock_first_price',
                    'custom_data' => false,
                    'premission' => $accessManager->isDataAvailable('th_buy_price')
                ],
                'info_product_second_price' => [
                    'db' => 'stock_second_price',
                    'custom_data' => false,
                    'premission' => true
                ],
                'info_product_count' => [
                    'db' => 'stock_count',
                    'custom_data' => false,
                    'premission' => true
                ],
                'info_product_min_quantity' => [
                    'db' => 'min_quantity_stock',
                    'custom_data' => false,
                    'premission' => true
                ],
                'info_product_filter_list' => [
                    'db' => 'stock_id',
                    'custom_data' => false,
                    'premission' => true
                ],
                'info_product_add_date' => [
                    'db' => 'stock_get_fdate',
                    'custom_data' => false,
                    'premission' => true
                ]
            )
        ],
        'filter_fields' => [
            // 'color',
            // 'used',
            // 'storage',
            // 'ram',
            // 'brand'
        ]					
    ],

];