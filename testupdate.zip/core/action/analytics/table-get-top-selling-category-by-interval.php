<?php
use core\classes\Report;
use core\classes\Services\tableFooter;
use core\classes\System\Init;
use core\classes\Utils\Utils;

header('Content-Type: application/json');

$Report = new Report;
$orderBy = 'total_profit';
$date = 3;

$get_page = $init->initController('analytics');

$page_config = $get_page['page_data_list'];

if(!empty($_POST['date'])) {
    $date = $_POST['date'];
}

if(!empty($_POST['customData'])) {
    if(!empty($_POST['customData']['orderBy'])) {
        $orderBy = $_POST['customData']['orderBy'];
    }
}

$data = Report::getTopSellingCategoryByInterval($date);

$table = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_row.twig' => [
            'table' => $main->compareData($data, [
                'get_data' => [
                    'id'            => 'category_id',
                    'category'      => 'category_name',
                    'report_period_amount' => 'total_amount',
                    'report_period_profit' => 'total_profit'
                ]                
            ]),
            'table_tab' => 'analytics',
            'table_type' => ''       
        ]
    ]
]);


$total = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_footer_row.twig' => [		
            'table_total' => tableFooter::getData(['total_amount', 'total_profit'], $data)  
        ]  
    ]
]);

return $utils::abort([
    'table' => $table,
    'total' => $total
]);