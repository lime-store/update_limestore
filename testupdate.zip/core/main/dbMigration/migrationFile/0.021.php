<?php

use Core\Classes\System\Migration;
use Core\Classes\System\Settings;

$productsAppendWholesalePrice = [
    'wholesalePrice' => 'float NOT NULL DEFAULT 0'
];

Migration::hasTableColumnExist('stock_list', $productsAppendWholesalePrice, function($notExistColumnName) {
    if($notExistColumnName) {
        Migration::alertTableColumn('stock_list', $notExistColumnName);
    }
});


Migration::hasTableExist('customer', function($noExist) {
    if($noExist) {
        Migration::createTable(
            'CREATE TABLE `customer` (
                `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `name` varchar(255) NOT NULL,
                `contact_number` varchar(128) NOT NULL,
                `description` varchar(64) NOT NULL,
                `visible` int(11) NOT NULL
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;'
        );
    }
});


$reportTypeColumn = [
    'reportType' => "varchar(128) NOT NULL DEFAULT 'RETAIL' "
];

Migration::hasTableColumnExist('stock_order_report', $reportTypeColumn, function($notExistColumnName) {
    if($notExistColumnName) {
        Migration::alertTableColumn('stock_order_report', $notExistColumnName);
    }
});


Migration::hasTableExist('wholesale_transaction', function($noExist) {
    if($noExist) {
        Migration::createTable(
            'CREATE TABLE `wholesale_transaction` (
                `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `customer_id` int(11) NOT NULL,
                `transaction_id` bigint(20) NOT NULL,
                `visible` int(11) NOT NULL
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;'
        );
    }
});


$add_function_settings_token_v0021 = [
    array(':sett_name' => 'printA4Barcode', 'sett_on' => '0')
];

$settings_token_sql_v0021 = [
    'table_name' => 'function_settting',
    'col_list' => '*',
    'query' => [
        'base_query' => ' WHERE sett_name = :sett_name GROUP BY sett_id DESC'
    ],
    'bindList' => []
];

Migration::hasDataExist($settings_token_sql_v0021, $add_function_settings_token_v0021, function($notExistData) {
    if($notExistData) {
        Migration::insertMigrationData('function_settting', $notExistData);
    }
});

