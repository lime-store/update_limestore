<?php 
require_once $_SERVER['DOCUMENT_ROOT'].'/db/config.php';

/******CHECK FILTER TABLE NAME******/
$filter_tbname = 'filter';

$filter_tb_sql = 'CREATE TABLE `filter` (
				  `filter_id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
				  `filter_type` varchar(255) NOT NULL,
				  `filter_value` varchar(255) NOT NULL,
				  `filter_visible` int(11) NOT NULL DEFAULT 0
				) ENGINE=InnoDB DEFAULT CHARSET=utf8;';

$filter_insert_sql = '';
$filter_data = array(
					array("color", "Black"),
					array("color", "Red"),
					array("color", "Gold"),
					array("color", "Rose Gold"),
					array("color", "Rose"),
					array("color", "Yellow"),
					array("color", "Pink"),
					array("color", "Gray"),
					array("color", "Blue"),

					array("storage", "2"),
					array("storage", "4"),
					array("storage", "8"),
					array("storage", "16"),
					array("storage", "32"),
					array("storage", "64"),
					array("storage", "128"),
					array("storage", "512"),
					
					array("ram", "1"),
					array("ram", "2"),
					array("ram", "3"),
					array("ram", "4"),
					array("ram", "8"),
					array("ram", "16"),
					array("ram", "32"),
					array("ram", "64"),

					array("used", "işlənmiş"),
					array("used", "Yeni")
				);
//создаем таблицу и заполняем ее 30.08
check_table_exists($filter_tbname, $filter_tb_sql, $filter_data);


//добавляю к таблице новые столбцы
// $filter_column_name = array(
// 	array("col_name",	 "int(11) NOT NULL"),
// );
//дополнить таблицу столбцами
// check_table_column_exists($filter_tbname, $filter_column_name);		
/******END FILTER******************/




/******CHECK STOCK_FILTER TABLE NAME******/
$stock_filter_tbname = 'stock_filter';
$stock_filter_sql = "CREATE TABLE `".$stock_filter_tbname."` (
					  `stock_filter_id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
					  `stock_id` int(11) NOT NULL,
					  `filter_color_id` int(11) NOT NULL,
					  `filter_storage_id` int(11) NOT NULL,
					  `filter_ram_id` int(11) NOT NULL,
					  `filter_used_id` int(11) NOT NULL
					) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
$filter_data = '';
//создаем таблицу и заполняем ее 30.08
check_table_exists($stock_filter_tbname, $stock_filter_sql, $filter_data);

//добавляю к таблице новые столбцы
 // $stock_filter_column_name = array(
 // 	array("column name", "column param"),
 // );

//дополнить таблицу столбцами
//check_table_column_exists($stock_filter_tbname, $stock_filter_column_name);

/******END STOCK_FILTER******************/


$quiz_sett_name = 'function_settting';
$quiz_sett_db = '';
$quiz_sett_data = array(
					array("2", "get_quiz_theme"),
				);
//создаем таблицу и заполняем ее 15.09
check_db_data($quiz_sett_name, $quiz_sett_data);



/**добавляю к таблице товаров новую сроку**/
$stock_list_barcode_db_name = 'stock_list';
$stock_list_barcode_colum_arr = array(
	array("stock_type", "varchar(255) NOT NULL DEFAULT 'phone'"),
	array("barcode_article", "VARCHAR(255) NOT NULL"),
	array("product_added", " INT NOT NULL DEFAULT 1")
);
check_table_column_exists($stock_list_barcode_db_name, $stock_list_barcode_colum_arr);
/**конец*/

// user_control
$user_control_db_nme = 'user_control';
$user_control_admin_column_arr = array(
	array("user_role", "VARCHAR(255) NOT NULL DEFAULT 'admin' "),
	array("user_visible", "int(11) NOT NULL DEFAULT 0"),
	array("alert_date", "VARCHAR(255) NOT NULL")
);
check_table_column_exists($user_control_db_nme, $user_control_admin_column_arr);
//end

//stock_order_report add seller column
$stock_order_report_db_name = 'stock_order_report';
$stock_order_rep_column_name = array(
	array('stock_type', "varchar(255) NOT NULL DEFAULT 'phone'"),
	array('order_seller_name', ' VARCHAR(255) NOT NULL') 
);
check_table_column_exists($stock_order_report_db_name, $stock_order_rep_column_name);
//end


//start th_list шаблоны названий таблиц
$th_list = 'th_list';
$th_list_sql = "CREATE TABLE `th_list` (
				 `th_id` int(11) NOT NULL AUTO_INCREMENT,
				 `th_description` varchar(255) COLLATE utf8_bin NOT NULL,
				 `th_name` varchar(255) COLLATE utf8_bin NOT NULL,
				 PRIMARY KEY (`th_id`)
				) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin";

$th_list_data = array(
					array("th_serial",		 	"№"),
					array("th_prod_name", 		"Malın adı"),
					array("th_imei", 			"IMEI"),
					array("th_buy_price", 		"Alış qiyməti"),
					array("th_sale_price", 		"Qiymət"),
					array("th_provider", 		"Təchizatçı"),
					array("th_return", 			"Vazvrat"),
					array("th_count", 			"Sayı"),
					array("th_category", 		"Kategoriya"),
					array("th_buy_day", 		"Alış günü"),
					array("th_day_sale", 		"Satış günü"),
					array("th_report_note", 	"Qeyd"),
					array("th_profit", "Xeyir"),
					array("th_serial", "№"),
					array("th_serial", "№"),
					array("th_serial", "№"),
					array("th_serial", "№"),
					array("th_serial", "№")
				);
//создаем таблицу и заполняем ее 30.08
check_table_exists($th_list, $th_list_sql, $th_list_data);
//end th_list 

$data_td_accsess = 'data_td_accsess';
$data_td_accesss_sql = 'CREATE TABLE `data_td_accsess` (
						 `td_id` int(11) NOT NULL AUTO_INCREMENT,
						 `user_id` int(11) NOT NULL,
						 `td_tags_id` int(11) NOT NULL,
						 `accsess_status` tinyint(4) NOT NULL DEFAULT 0,
						 PRIMARY KEY (`td_id`)
						) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8 COLLATE=utf8_bin';
$data_td_acess_list_data = '';
//создаем таблицу и заполняем ее 30.08
check_table_exists($data_td_accsess, $data_td_accesss_sql, $data_td_acess_list_data);						


$user_accesss_page = 'user_access_pages';
$user_accesss_page_sql = 'CREATE TABLE `user_access_pages` (
							 `access_id` int(11) NOT NULL AUTO_INCREMENT,
							 `user_id` int(11) NOT NULL,
							 `access_page_name` varchar(255) COLLATE utf8_bin NOT NULL,
							 `access_page_base_link` varchar(255) COLLATE utf8_bin NOT NULL,
							 PRIMARY KEY (`access_id`)
							) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8 COLLATE=utf8_bin';
$user_accesss_page_data_list = '';
check_table_exists($user_accesss_page, $user_accesss_page_sql, $user_accesss_page_data_list);							

//проверяю на наличие таблицы в базе данных
function check_table_exists($table_name, $sql, $data) {
	global $dbpdo;
	//проверка на таблицу 
	try {	
		$check_db = $dbpdo->prepare('SELECT EXISTS(
	       SELECT * FROM  '.$table_name.') ');
		$check_db->execute();
		//если есть таблица проверить на дату и добавить дату
		check_db_data($table_name, $data);
	} 
	catch(PDOException $e) {
		//если таблицы нет
		creat_table($table_name, $sql, $data);
	}
}

//создаю новую табицу в азе данных
function creat_table($table_name, $sql, $data) {
	global $dbpdo;
	try { 
	    $dbpdo->exec($sql);
	    check_db_data($table_name, $data);
	} 
	catch(PDOException $e) {
	    header('Location: /');
	}
}

//если таблица была в базе проверяю ее на пустоту
function check_db_data($table_name, $array) {
	global $dbpdo,
		   $filter_tbname,
		   $quiz_sett_name,
		   $user_control_db_nme,
		   $th_list;

	$data_arr = array();

	//START таблица filter
	if($table_name == $filter_tbname) {
		foreach ($array as $row => $value) {
			$filter_type = $value[0];
			$filter_value = $value[1];
			try {
				$check_exist_data = $dbpdo->prepare('SELECT * FROM filter
				WHERE filter_type = :type 
				AND filter_value = :value 
				GROUP BY filter_id DESC');
				$check_exist_data->bindParam('type', $filter_type);	
				$check_exist_data->bindParam('value', $filter_value);
				$check_exist_data->execute();

				if($check_exist_data->rowCount()>0) {
					echo " ";
				} else {
					$data_arr = array(
						'filter_type' => $filter_type,
						'filter_value' => $filter_value
					);

					install_data( $table_name, $data_arr );
				} 

			} catch(PDOException $e) {
				echo  " таблицы не существует";
			}
		}	
	}

	if($table_name === $quiz_sett_name) {
		foreach ($array as $row => $value) {
			$sett_id = $value[0];
			$sett_name = $value[1];
			try {
				$check_exist_data = $dbpdo->prepare('SELECT * FROM function_settting
				WHERE sett_name = :sett_name 
				GROUP BY sett_id DESC');
				$check_exist_data->bindParam('sett_name', $sett_name);
				$check_exist_data->execute();

				if($check_exist_data->rowCount()>0) {
					echo " ";
				} else {
					$data_arr = array(
						'sett_id' => $sett_id,
						'sett_name' => $sett_name
					);

					install_data( $table_name, $data_arr );
				} 

			} catch(PDOException $e) {
				echo " таблицы не существует";
			}
		}		
	}
	//END таблица filter


	//start th_list
	if($table_name === $th_list) {
		foreach ($array as $row => $value) {
			$th_description = $value[0];
			$th_name = $value[1];
			try {
				$check_exist_data = $dbpdo->prepare('SELECT * FROM th_list
				WHERE th_description = :th_description 
				GROUP BY th_id DESC');
				$check_exist_data->bindParam('th_description', $th_description);
				$check_exist_data->execute();

				if($check_exist_data->rowCount()>0) {
					echo " ";
				} else {
					$data_arr = array(
						'th_description' => $th_description,
						'th_name' => $th_name
					);

					install_data( $table_name, $data_arr );
				} 

			} catch(PDOException $e) {
				echo " таблицы не существует 3222 </pre>";
			}
		}
	}

	//end th_list
}


//заполняю таблицу данными
function install_data($table_name, $data_arr) {
	global $dbpdo;
	/******filter data******/
	if($table_name === 'filter') {
		$filter_type = $data_arr['filter_type'];
		$filter_value = $data_arr['filter_value'];

		$add_fiter = $dbpdo->prepare('INSERT INTO filter (filter_type, filter_value)  VALUES (?, ?) ');
		$add_fiter->execute([$filter_type, $filter_value]);
	}	
	/******filter data******/

	if($table_name == 'function_settting') {
		$sett_id = $data_arr['sett_id'];
		$sett_name = $data_arr['sett_name'];

		$add_sett = $dbpdo->prepare('INSERT INTO function_settting (sett_custom_id, sett_name) VALUES (?, ?)');
		$add_sett->execute([$sett_id, $sett_name]);
	}

	if($table_name == 'th_list') {
		$th_description = $data_arr['th_description'];
		$th_name = $data_arr['th_name'];

		$add_th = $dbpdo->prepare('INSERT INTO th_list (th_description, th_name) VALUES (?, ?)');
		$add_th->execute([$th_description, $th_name]);
	}	
}

//проверить на наличие столбца в таблице
function check_table_column_exists($table_name, $column_arr) {
	global $dbpdo;

	foreach ($column_arr as $row => $value) {
		$col_name = $value[0];
		$col_param = $value[1];

		try {
			//тут проверяем на наличие столбца
			$col_check = $dbpdo->prepare('SELECT '.$col_name.' FROM  '.$table_name.'  ');
			$col_check->execute();				
		} catch (Exception $e) {
			$data = array(
				'col_name' => $col_name,
				'col_param' => $col_param 
			);
			//если нет вызываем функци и добавляем
			alert_table_column($table_name, $data);
		}
		
	}


}

//добавить новый столбец к таблице 
function alert_table_column($table_name, $data) {
	global $dbpdo;
	$col_name = $data['col_name'];
	$col_param = $data['col_param'];

	$insert_col_sql = 'ALTER TABLE `'.$table_name.'` ADD `'.$col_name .'` '.$col_param.' ';
	$dbpdo->exec($insert_col_sql);
}