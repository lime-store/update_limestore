<?php

use core\classes\Utils\Charts;
use core\classes\Report;

header('Content-Type: application/json');

$Charts = new Charts;
$Report = new Report;

$date = $_POST['date'];

$data = $Report->getTopSellingProductsOfMonth($date);


$res = $Charts->getPieChartsData($data, 'order_stock_name', 'total_profit');

echo json_encode($res);