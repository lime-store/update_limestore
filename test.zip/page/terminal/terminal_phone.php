<?php 
	require_once '../../function.php';
	// //Показывать товары которые находться в базе больше 15 дней 
	// settShowOldProduct();

	// //кнопка компактного меню на странице
	// modalNavigationBtn();

	// //выводим компакнтное меню на странице 
	// getModalSideBarNav();

	// //блок для принта чека
	// printModal();

	// //выводим перекючения вкладок 
	// getCurrentTab(); 


	//получаем тип таблицы
	get_table_svervice_type();

	//получем категорию товара
	get_product_category();

	//заголовок таблицы
	get_table_header();	

	ls_include_tpl();
?>

<div class="view_stock_wrapper">
	<div class="view_stock_box_wrp">
		<!-- начало тут выводим поиск -->
		<div class="search_filter_wrapper">
			<div class="search_filter_block">
				<?php 
				/*фильтр*/ get_filter_root();
				/*Поиск*/  search_input($arr = array(
								'product_type' => $terminal,
								'product_category' => $product_phone,
								'product_class' => 'auto-cmplt-input stock_auto_compelete',
								'parent_class' => 'auto-cmplt-parent search_filter',
								'auto_complete' => 'show',
								'label' => 'hide',
								'label_title' => '',
								'clear_button' => 'show'
							)); 
				?>
			</div>
		</div>
		<!-- конец поиска -->
<div class="stock_view_wrapper">
	<div class="stock_view_list ls-custom-scrollbar">
		<table class="stock_table">
			<thead>
				<tr>
					<?php 
						check_th_access_tpl(array(
							'th_serial' 	=> true,
							'th_prod_name' 	=> true,
							'th_imei' 		=> true,
							'th_buy_price'	=> true,
							'th_sale_price' => true,
							'th_provider' 	=> true,
							'th_return' 	=> true 
						));
					?>					
				 </tr>
			</thead>
			<tbody class="stock_list_tbody" data-stock-src="<?php echo  $terminal; ?>" data-category="<?php echo $product_phone; ?>">		<?php

						$product_category = $product_phone;

						$stock_list = [];
						$stock_view = $dbpdo->prepare("SELECT * FROM stock_list 
													   WHERE stock_count > 0 
													   AND stock_visible = 0 
													   AND stock_type = ?
													   GROUP BY stock_id DESC");
						$stock_view->execute([$product_category]);
						if($stock_view->rowCount()>0) {
							while ($stock_row = $stock_view->fetch(PDO::FETCH_BOTH))
								$stock_list[] = $stock_row;

							foreach ($stock_list as $stock_row)
							{
								$stock_id 				= $stock_row['stock_id'];
								$stock_name 			= $stock_row['stock_name'];
								$stock_imei 			= $stock_row['stock_phone_imei'];
								$stock_first_price 		= $stock_row['stock_first_price'];
								$stock_second_price 	= $stock_row['stock_second_price'];
								$stock_return_status 	= $stock_row['stock_return_status'];
								$stock_provider		 	= $stock_row['stock_provider'];
							 	if($stock_return_status == 1) { $stock_return = $stock_return_image; } else { $stock_return = ''; }
					
								
								
								echo '<tr class="stock-list" id="'.$stock_id.'">';		
									check_td_access_tpl(array(
										'th_serial' 		=> $stock_id,
										'th_prod_name' 	  	=> $stock_name,
										'th_imei'			=> $stock_imei,
										'th_buy_price' 		=> $stock_first_price,
										'th_sale_price' 	=> $stock_second_price,
										'th_provider' 		=> $stock_provider,
										'th_return' 		=> $stock_return 
									));										
								echo '</tr>';							

							}

						}

					?>
						</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

