<?php
use core\Cloud\classes\Sync\CloudSyncQueue;

$categoryId = $_POST['categoryId'] ?? null;

if(!empty($categoryId)) {
    CloudSyncQueue::deleteCategoryTask($categoryId);
}