<?php
require $_SERVER['DOCUMENT_ROOT'].'/start.php';

use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\Utils\Utils;
use core\Cloud\classes\CloudApi;
use core\classes\dbWrapper\db;

$headers = getallheaders();

$branch = CloudApi::authBranch($headers);

if($branch) {
    $method = $_SERVER['REQUEST_METHOD'];
    $path = $_SERVER['PATH_INFO'] ?? ''; 
    
    if ($method === 'GET' && $path === '/pending') {
        $rows = qb::select('*')
                   ->from('sync_queue')
                   ->where('branch_id = :branch_id AND status = "pending" ')
                   ->orderBy('id', 'ASC')
                   ->bindList([
                        ':branch_id' => $branch['id'],                    
                   ])
                   ->execute()
                   ->get();
                   
        
        foreach ($rows as &$r) {
            $r['payload'] = json_decode($r['payload'], true);
        }

        echo json_encode(['tasks' => $rows]);
        exit;
    }    

    if ($method === 'POST' && $path === '/ack') {
        $body = json_decode(file_get_contents('php://input'), true);

        if (!empty($body['data'])) {
            $ids = array_column($body['data'], 'remote_task_id');

            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $d = db::$dbpdo->prepare(
                "UPDATE sync_queue SET status = 'done', synced_at = NOW()
                WHERE id IN ($placeholders)"
            );

            $d->execute($ids);

            echo json_encode(['updated' => $d->rowCount()]);
        }
    }     
}