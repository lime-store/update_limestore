<?php 
namespace core\classes\Services\LocalSync;

use core\classes\dbWrapper\db;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\Products;
use core\classes\Services\Warehouse\Warehouse;
use core\classes\Utils\Utils;
use core\classes\Services\API;
use core\classes\Services\BaseService;
use core\classes\Services\LocalSync\Traits\SyncBarcodes;
use core\classes\Services\LocalSync\Traits\SyncCategories;
use core\classes\Services\LocalSync\Traits\SyncProviders;
use core\classes\Services\LocalSync\Traits\SyncProductInfo;

class SyncQueue
{
    use SyncBarcodes, 
        SyncCategories, 
        SyncProviders,
        SyncProductInfo;

    public static function runTask()
    {
        $result = self::fetchPendingTasks();
        
        if (!$result['ok']) {
            return;
        }

        $tasks = $result['data']['tasks'];

        foreach ($tasks as $task) {
            self::processTask($task);
        }

        self::updateRemoteTaskStatus();        
    }

    /**
     * Запрашивает список задач, ожидающих обработки
     */
    public static function fetchPendingTasks(): array
    {
        return API::send('https://test.lime-store.top/core/Cloud/action/api.php/pending', [
            'token' => self::getToken(),
            'type'  => 'GET',
        ]);
    }

    /**
     * Обрабатывает одну задачу синхронизации: создаёт товар или увеличивает сток,
     * затем привязывает категорию и поставщика
     */
    private static function processTask(array $task): void
    {
        self::addLocalTask($task['id']);
        
        switch ($task['action']) {
            case BaseService::CLOUD_PAYLOAD_ACTION['transferProduct']:
                self::transferProduct($task);
                break;
            case BaseService::CLOUD_PAYLOAD_ACTION['updateProduct']:
                self::updateProduct($task);
                break;
            case BaseService::CLOUD_PAYLOAD_ACTION['deleteProduct']:
                self::deleteProduct($task);
                break;
            case BaseService::CLOUD_PAYLOAD_ACTION['editCategory']:
                self::editCategory($task);
                break;
            case BaseService::CLOUD_PAYLOAD_ACTION['deleteCategory']:
                self::deleteCategory($task);
                break;
            case BaseService::CLOUD_PAYLOAD_ACTION['editProvider']:
                self::editProvider($task);
                break;
            case BaseService::CLOUD_PAYLOAD_ACTION['deleteProvider']:
                self::deleteProvider($task);
                break;
            default:
                Utils::log("Unknown sync action: {$task['action']}, task id: {$task['id']}");
                break;                
        }

        self::updateLocalTaskStatus($task['id'], 'done');
    }    


    private static function addLocalTask(int $taskId)
    {
        db::insert('local_sync_queue', array(
            [
                'remote_task_id' => $taskId,
                'status'         => 'pending'
            ]
        ));
    }



    private static function getToken(): string
    {
        return '2839bbc9-f372-46b3-a8a2-382724390ae1'; // TODO: вынести в конфиг
    }


    /**
     * 
     */
    private static function updateLocalTaskStatus($taskId, $status = 'pending')
    {
        return db::update([
            'before' => 'UPDATE local_sync_queue SET ',
            'after' => " WHERE remote_task_id = :taskId ",
            'post_list' => [
                'taskId' => [
                    'query' => false,
                    'bind' => 'taskId'
                ],
                'status' => [
                    'query' => ' status = :status ',
                    'bind' => 'status'
                ]
            ]
        ], 
        [
            'taskId' => $taskId,
            'status' => $status
        ]);
    }


    /**
     * 
     */
    private static function getLocalTaskList($status = 'pending')
    {
        $result = qb::select('remote_task_id')
                    ->from('local_sync_queue')
                    ->where('status = :status')
                    ->bindList([
                        ':status' => $status
                    ])
                    ->execute()
                    ->get();

        return $result;                    
    }

    /**
     * 
     */
    public static function updateRemoteTaskStatus()
    {
        $token = '2839bbc9-f372-46b3-a8a2-382724390ae1';
        $data = self::getLocalTaskList('done') ?: [];

        $result = API::send('https://test.lime-store.top/core/Cloud/action/api.php/ack', [
            'token'  => $token,
            'type'   => 'POST',
            'body'   => [
                'data' => $data
            ]
        ]);

        return $result;
    }
}