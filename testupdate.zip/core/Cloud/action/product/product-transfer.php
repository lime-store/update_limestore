<?php

use core\Cloud\classes\Sync\CloudSyncQueue;

 header('Content-type: Application/json');

$Warehouse = new core\classes\Services\Warehouse\Warehouse;

if(empty($_POST) || empty($_POST['list'])) {
   return $utils::abort([
        'type' => 'error',
        'text' => 'Корзина пустая' 
    ]);
}

if(empty($_POST['warehouse_id'])) {
   return $utils::abort([
        'type' => 'error',
        'text' => 'Выберите анбар для трансфера' 
    ]); 
}

$warehouse_id = $_POST['warehouse_id'];

$list = $_POST['list'];

if($Warehouse->hasWarehouse($warehouse_id) == false) {
    return $utils::abort([
        'type' => 'error',
        'text' => 'ERROR 820828'
    ]);
}


if(CloudSyncQueue::addTransferTask($list, $warehouse_id)) {
    return $utils::abort([
        'type' => 'success',
        'text' => 'Ok'
    ]);
}





