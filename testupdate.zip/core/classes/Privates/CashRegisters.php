<?php 

namespace core\classes\Privates;

use core\classes\dbWrapper\db;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\dbWrapper\updateBuilder;
use core\classes\Services\BaseService;
use core\classes\System\Init;
use core\classes\Utils\Utils;

class CashRegisters
{
    public static string $controllerIndex = 'cash-registers';

    public static function getCashRegisters(int $paymentMethod = 1)
    {
        $query = Init::getControllerData(self::$controllerIndex)->getQuery();

        $query['query']['joins'] = $query['query']['joins'] . ' WHERE cash_registers.payment_method = :paymentMethod';
        $query['bindList'] = [
            ':paymentMethod' => $paymentMethod
        ];

        return db::select($query)->get();
    }

    /**
     * 
     */
    public static function getLast() :array
    {
        $query = Init::getControllerData(self::$controllerIndex)->getQuery();
        $query['sort_by'] = "GROUP BY id ORDER BY id DESC"; 
        $query['limit'] = 'limit 1';

        $result = db::select($query)->first()->get();

        return $result ?: [];
    }

    /**
     * 
     */
    public static function getCurrentBalance(int $paymentMethod = 1)
    {
        $query = Init::getControllerData(self::$controllerIndex)->getQuery();

        $result = qb::select($query['col_list'])
                    ->from('cash_registers')
                    ->where('payment_method', $paymentMethod)
                    ->leftJoin('payment_method_list as pm', 'pm.id = cash_registers.payment_method')
                    ->leftJoin('user_control c', 'c.user_id = cash_registers.user_id')
                    ->last('cash_registers.id')
                    ->columnName('running_balance')
                    ->get();
        
        if(!empty($result)) {
            return $result;
        }

        return 0;
    }

    /**
     * 
     */
    public static function filter(string $date, string $paymentMethod)
    {
        $query = Init::getControllerData(self::$controllerIndex)->getQuery();

        $qb = qb::select($query['col_list'])
                    ->from('cash_registers')
                    ->leftJoin('payment_method_list as pm', 'pm.id = cash_registers.payment_method')
                    ->leftJoin('user_control c', 'c.user_id = cash_registers.user_id');
        

        if(!empty($date) && $date !== BaseService::UTILS_VALUES['general']) {
            $qb->whereBetween('created_at', $date . ' 00:00:00', $date . ' 23:59:59');
        }

        if(!empty($paymentMethod) && $paymentMethod !== BaseService::UTILS_VALUES['general']) {
            $qb->andWhere('payment_method', $paymentMethod);
        }

        $result = $qb->orderBy('created_at', 'DESC')->get();

        return $result ?? [];
    }    

    /**
     * 
     */
    public static function editPaymentMethod(int $transactionId, int $paymentMethod)
    {
        if($transactionId) {
            updateBuilder::table('cash_registers')
                            ->set('payment_method', $paymentMethod)
                            ->where('transaction_id', $transactionId)
                            ->execute();
        }
    }

    /**
     * 
     */
    public static function getBalanceAtDate(string $date, ?int $paymentMethod = 1)
    {
        $date = $date ?: Utils::getDateDMY();
        
        $dt = \DateTime::createFromFormat('d.m.Y', $date);
        if($dt) {
            $converted = $dt->format('Y-m-d');
        } else {
            $converted = $date;
        }
        $query = Init::getControllerData(self::$controllerIndex)->getQuery();
        $result = qb::select($query['col_list'])
                ->from('cash_registers')
                ->whereBetween('created_at', $converted . ' 00:00:00', $converted . ' 23:59:59')
                ->andWhere('payment_method', $paymentMethod)
                ->leftJoin('payment_method_list as pm', 'pm.id = cash_registers.payment_method')
                ->leftJoin('user_control c', 'c.user_id = cash_registers.user_id')
                ->last('created_at')
                ->columnName('running_balance')
                ->get();

        return $result;
    }


    /**
     * @param float  $balanceBefore   - баланс до изменения
     * @param float  $amountChange    - сумма на которую была изменена
     * @param float  $balanceAfter    - баланс
     * @param float  $type            - тип операции
     * @param int    $userId          - кто сделал операцию
     * @param int    $orderId         - идинтификатор продажи
     * @param string $comment        - описание операции
     * 
     */
    public static function applyToCashRegisters(
        float $balanceBefore,
        float $amountChange,
        float $balanceAfter,
        string $type,
        int $userId,
        ?string $comment,
        ?int $paymentMethod = 1,
        ?int $transactionId = null
    ) {
        
        return db::insert('cash_registers', [
            [
                'amount_before'     => $balanceBefore,
                'amount_change'     => $amountChange,
                'current_balance'   => $balanceAfter,
                'type'              => $type,
                'comment'           => $comment,
                'user_id'           => $userId, 
                'payment_method'    => $paymentMethod,
                'transaction_id'    => $transactionId
            ]
        ]);
    }

    /**
     * 
     */
    public static function deposit(
        float $amount, 
        string $type, 
        int $userId,  
        ?int $paymentMethod,
        int $transactionId = null,
        string $comment = ''
    ) {
        $currentBalance = self::getCurrentBalance();
        $balanceAfter  = $amount + $currentBalance;

        return self::applyToCashRegisters(
            $currentBalance,
            $amount,
            $balanceAfter,
            $type, 
            $userId,
            $comment,
            $paymentMethod,
            $transactionId
        );
    }

    public static function withdraw(
        float $amount, 
        string $type, 
        int $userId,  
        ?int $paymentMethod,
        ?int $transactionId = null,
        string $comment = ''
    ) {
        $currentBalance = self::getCurrentBalance();
        $balanceAfter  = $currentBalance - $amount;

        return self::applyToCashRegisters(
            $currentBalance,
            -$amount,
            $balanceAfter,
            $type, 
            $userId,
            $comment,
            $paymentMethod,
            $transactionId
        );
    }
}