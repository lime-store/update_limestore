<?php

namespace core\classes\Services;

class BaseService
{
    const CLOUD_PAYLOAD_ACTION = [
        'transferProduct' => 'transferProduct',
        'updateProduct'   => 'updateProduct',
        'createProduct'   => 'createProduct',
        'deleteProduct'   => 'deleteProduct',
        
        'editCategory'    => 'editCategory',
        'deleteCategory'  => 'deleteCategory',

        'editProvider'    => 'editProvider',
        'deleteProvider'  => 'deleteProvider',
    ];

    const CLOUD_PAYLOAD_STATUS = [
        'pending' => 'pending',
        'done'    => 'done',
        'error'   => 'error',
    ];

    const VISIBLE_STATE = [
        'visible' => 'visible',
        'invisible' => 'invisible',
    ];

    const UTILS_VALUES = [
        'general' => 'Ümumi',
    ];
}
