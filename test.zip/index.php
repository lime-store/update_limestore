<?php 
	require_once 'include/header.php';
	ls_include_tpl();
?>
<div class="container" id="container">
	<div class="sidebar_menu_wrp">
		<?php require_once 'core/main/menu_sidebar.php'; ?>
	</div>

	<div class="main" id="main">
		<div class="main-wrapper" id="main_wrapper">
			<?php require_once 'core/main/options.php'; ?>
		</div>
	</div>

</div>

<?php 
if($update_check_day == $weak_now) {
	check_connections(require_once GET_ROOT_DIRS.'/core/main/update_check.php');
	//опросник
	check_connections(require_once  GET_ROOT_DIRS.'/core/modal_action/show_quiz.php');
}
?>

<!-- <script defer src="/js/check_update.js?v=<?php echo time(); ?>"></script> -->