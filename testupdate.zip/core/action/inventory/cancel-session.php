<?php
header('Content-type: Application/json');

use core\classes\Inventory\InventorySession;
use core\classes\Utils\Utils;

$sessionId = (int) ($_POST['id'] ?? 0);

try {
    InventorySession::cancel($sessionId, $user->getCurrentUser('get_id'));

    Utils::successAbort('Sessiya ləğv edildi');
} catch (\Throwable $e) {
    Utils::errorAbort($e);
}