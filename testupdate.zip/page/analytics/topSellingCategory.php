<?php
use Core\Classes\Report;
use core\classes\Services\tableFooter;
use Core\Classes\System\Main;
use Core\Classes\Utils\Utils;

$data_page = $init->initController($page);

$page_config = $data_page['page_data_list'];


$report_date_list = $main->getReportDateList([
	'table_name' 	=> 'stock_order_report',
	'col_name' 		=> 'order_my_date',
	'order'			=> 'order_real_time DESC',
	'query'			=> ' WHERE order_stock_count > 0 AND stock_order_visible = 0 ',
	'default'		=> date('m.Y')
]);

$table_result = $main->prepareData($data_page['sql'], $data_page['page_data_list']);

$topSellingProductsOfLastThreeMonth = Report::getTopSellingCategoryByInterval(3);

echo $Render->view('/component/inner_container.twig', [
    'renderComponent' => [
        '/component/include_once_component.twig' => [
            'includs' => [
                [
                    '/component/pulgin/charts/chartsScript.twig' => []
                ],
                [
                    '/component/related_component/include_widget.twig' => [
                        '/component/buttons/select/select-button.twig' => [
                            'main' => [
                                'class_list' => [
                                    'init_element' => ' widget-fields ',
                                    'container' => ' widget-fields-container',
                                    'input_parent' => 'width-100 input-dropdown-parent'
                                ]
                            ],
                            'input' => [
                                'label' => 'Axtar',
                                'icon' => 'las la-calendar-alt',
                                'class_list' => ' scroll-auto form-input area-button input-dropdown',
                                'attribute' => [
                                    'type' => 'button',
                                    'placeholder' => 'Some'
                                ]
                            ],
                            'list' => [
                                'class_list' => [
                                    'container' => 'form-fields-autocomplete ',
                                    'ul_list' => 'width-100 select-list unset-min-width',
                                    'list_item_container' =>'',
                                    'list_item_link' => 'selectable-search-item area-closeable select-category-id select-hidden-fields-input input-dropdown-auto-list-li load-multiple-charts load-analytics-top-selling-category-on-table'
                                ],
                                'default_first' => true,                    
                                'list_data' => [
                                    [
                                        'custom_value' => 'Son 3 ayda olan satışlar',
                                        'custom_data_id' => '3'
                                    ],
                                    [
                                        'custom_value' => 'Son 1 ayda olan satışlar ',
                                        'custom_data_id' => '1'
                                    ],                                    
                                    [
                                        'custom_value' => 'Son 6 ayda olan satışlar',
                                        'custom_data_id' => '6'
                                    ], 
                                    [
                                        'custom_value' => 'Son 12 ayda olan satışlar',
                                        'custom_data_id' => '12'
                                    ],                                                                        
                                ],
                            ]
                        ],
                    ]
                ],                 
                [
                    '/component/pulgin/charts/pieChartsContainer.twig' => [ 
                        'includs' =>[                    
                            [
                                '/component/pulgin/charts/chartsLoader.twig' => [
                                    'classList' => 'reloadTopProducts lineCharts ',
                                    'wrapperClassList' => 'width-100 chartsWrapper',
                                    'chartsType' => 'bar',
                                    'chartsName' => 'reportTopCategoryByInterval',
                                    'scriptUrl' => 'core/action/analytics/charts-get-top-category.php',
                                    'scriptRoute' => 'analyticsChartsTopCategoryByInterval',
                                    'dataValue' => 'total_profit',
                                    'setLabel' => 'Ən çox satılan kateqoriya',
                                    'chartOption' => [
                                        'maintainAspectRatio' => false,
                                    ]
                                ]					
                            ], 
                            [
                                '/component/pulgin/charts/chartsLoader.twig' => [
                                    'classList' => 'reloadTopProducts doughnutCharts',
                                    'wrapperClassList' => 'width-100 chartsWrapper',
                                    'chartsType' => 'doughnut',
                                    'chartsName' => 'reportTopProviderByInterval',
                                    'scriptUrl' => 'core/action/analytics/charts-get-top-provider-by-interval.php',
                                    'scriptRoute' => 'analyticsChartsTopProviderByInterval',
                                    'dataValue' => 'total_profit',
                                    'setLabel' => 'Təchizatçılar üzrə satış',
                                    'chartOption' => [
                                        'plugins' => [
                                            'legend' => [
                                                'display' => false
                                            ]
                                        ]
                                    ]                                               
                                ]					
                            ],                                                           
                        ]
                    ]
                ],
                [
                    '/component/related_component/include_widget.twig' => [
                        '/component/widget/title.twig' => [
                            'title' => 'ən çox satılan məhsullar (mənfəət olaraq)',
                            'classList' => 'margin-0 mrgn-top-100 sub-title',
                        ],
                    ],                    
                    '/component/table/table_wrapper.twig' => [
                        'table' => $main->compareData($topSellingProductsOfLastThreeMonth, [
                            'get_data' => [
                                'id'            => 'category_id',
                                'category'      => 'category_name',
                                'report_period_amount' => 'total_amount',
                                'report_period_profit' => 'total_profit'
                            ]
                        ]),
                        'table_tab' => $page,
                        'table_type' => $type,
                        'attribute' => [
                            'data-route-id' => 'some-route-id'
                        ]
                        // 'classList' => 'stock-list'
                    ],
                    '/component/table/table_footer_wrapper.twig' => [
                        'table_total' => tableFooter::getData(['total_amount', 'total_profit'], $topSellingProductsOfLastThreeMonth)
                    ],                                    
                ],
            ]
        ],
    ]
]);
