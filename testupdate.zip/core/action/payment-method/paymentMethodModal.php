<?php
header('Content-Type: application/json');

use Core\Classes\Utils\Utils;


$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/custom_modal/u_modal.twig' => [
            'containerClassList' => 'small-modal',
            'modalController' => [
                'title' => 'Ödəniş üsulu əlavə edin',
                'closeButtonClassList' => 'removeModal',
            ],
            'modalContent' => [
                'path' => '/component/form/fields/payment-method/create-payment-method.twig',
                'classList' => 'modal-form'
            ],
            'list' => Utils::getTagsList()
		]  
	]
]);


$utils::abort([
	'res' => $total,
]);
