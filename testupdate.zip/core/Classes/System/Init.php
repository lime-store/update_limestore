<?php 
namespace Core\Classes\System;
use core\classes\dbWrapper\db;
use core\Classes\System\Constants;
use Core\Classes\Utils\Utils;

class Init
{
    
    public static $tableName;
    public static $columnList;
    public static $baseQuery;
    public static $body;
    public static $joins;
    public static $sortBy;
    public static $limit;
    public static $allData;
    public static $bindList;

    private static ?Init $instance = null; 
    private static array $initList = [];
    
    private function __construct() {}

    public static function getInstance(): Init
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function initDefaultControllerList(): void
    {
        self::$initList = [
            'cart_terminal'   	=>  Constants::RETAIL_CONTROLLER_DIR.'/cart-terminal/cart-terminal.controller.php',
            'terminal'      	=>  Constants::RETAIL_CONTROLLER_DIR.'/terminal/terminal.controller.php',
            'stock'         	=>  Constants::RETAIL_CONTROLLER_DIR.'/stock/stock.controller.php',
            'productHistory'    =>  Constants::RETAIL_CONTROLLER_DIR.'/productHistory/productHistory.controller.php',
            'report'        	=>  Constants::RETAIL_CONTROLLER_DIR.'/report/report.controller.php',
            'analytics'         =>  Constants::RETAIL_CONTROLLER_DIR.'/analytics/analytics.controller.php',
            'expense'        	=>  Constants::RETAIL_CONTROLLER_DIR.'/expense/expense.controller.php',
            'warehouse-transfer-form'    =>  Constants::RETAIL_CONTROLLER_DIR.'/warehouse-transfer/warehouse-transfer-form/warehouse-transfer-form.controller.php',
            'warehouse-transfer-report'  =>  Constants::RETAIL_CONTROLLER_DIR.'/warehouse-transfer/warehouse-transfer-report/warehouse-transfer-report.controller.php',
            
            'arrival-form' 		=>  Constants::RETAIL_CONTROLLER_DIR.'/arrival-products/arrival-form/arrival-form.controller.php',
            'arrival-report'  	=>  Constants::RETAIL_CONTROLLER_DIR.'/arrival-products/arrival-report/arrival-report.controller.php',
            
            'write-off-form'    =>  Constants::RETAIL_CONTROLLER_DIR.'/write-off-products/write-off-form/write-off-form.controller.php',
                'write-off-report'  =>  Constants::RETAIL_CONTROLLER_DIR.'/write-off-products/write-off-report/write-off-report.controller.php',
            
            'admin'         	=>  Constants::RETAIL_CONTROLLER_DIR.'/admin/admin.controller.php',
                'create_warehouse'      =>  Constants::RETAIL_CONTROLLER_DIR.'/warehouse/create-warehouse.controller.php',
                'category_form' 	    =>  Constants::RETAIL_CONTROLLER_DIR.'/category-form/category-form.controller.php',
                'payment_method_form'   =>  Constants::RETAIL_CONTROLLER_DIR.'/payment-method-form/payment-method-form.controller.php',
                'provider_form' 	    =>  Constants::RETAIL_CONTROLLER_DIR.'/provider-form/provider-form.controller.php',
                'filter_form'   	    =>  Constants::RETAIL_CONTROLLER_DIR.'/filter-form/filter-form.controller.php',
                // 'settings'      	    =>  Constants::RETAIL_CONTROLLER_DIR.'/settings/settings.controller.php',
            
        ];
    }

    public static function initWholesaleController(): void  
    {
        self::$initList = [
            'wholesaleTerminal'      	    =>  Constants::WHOLESALE_CONTROLLER_DIR.'/terminal/terminal.controller.php',
                'wholesaleCart'             =>  Constants::WHOLESALE_CONTROLLER_DIR.'/cart-terminal/cart-terminal.controller.php',
            'wholesaleProducts'         	=>  Constants::WHOLESALE_CONTROLLER_DIR.'/products/products.controller.php',
            'wholesaleCustomer'         	=>  Constants::WHOLESALE_CONTROLLER_DIR.'/customer/customer.controller.php',
            'wholesaleReport'               =>  Constants::WHOLESALE_CONTROLLER_DIR.'/report/report.controller.php',
        ];        
    }


    public static function initController($page = false)
    {    
        if(empty(self::$initList)) {
            self::initDefaultControllerList();

            $itsArray = self::$initList;

            self::initWholesaleController();

            self::$initList = array_merge(self::$initList, $itsArray);            
        }


        $param = [];
        $all_pages = [];

        if($page) {
            $data_param = require self::$initList[$page];
        } else {
            foreach (self::$initList as $key => $val) {
                $all_pages[$key] = require $val; 
            }

            return $all_pages;
        }

        
        if($data_param) {
            $sql_param = $data_param['sql'];
            $table_name = $sql_param['table_name'];
            $base_query = $sql_param['query']['base_query'];
            $col_list = $sql_param['col_list'];
            $get_param = false;
            $get_sort  = false;

            if(!empty($sql_param['query'])) {
                if(array_key_exists('body', $sql_param['query'])) {
                    $get_param = $sql_param['query']['body'];
                }
                if(array_key_exists('sort_by', $sql_param['query'])) {
                    $get_sort = $sql_param['query']['sort_by'];
                }
            }
            // return $param;
            return $data_param;	
        }
    }

    public static function getControllerData($index)
    {
        $data = self::initController($index);

        $sql = $data['sql'];

        self::$tableName    = $sql['table_name'];
        self::$columnList   = $sql['col_list'];
        self::$baseQuery    = $sql['query']['base_query'];
        self::$body         = $sql['query']['body'];
        self::$joins        = $sql['query']['joins'];
        self::$sortBy       = $sql['query']['sort_by'];
        self::$limit        = $sql['query']['limit'] ?? '';
        self::$bindList     = $sql['bindList'] ?? [];
        self::$allData      = $data;
        
        return new static();
    }

    public static function getAllData()
    {
        return self::$allData;
    }

    public static function getTableName()
    {
        return self::$tableName;
    }

    public static function getColumnList()
    {
        return self::$columnList;
    }

    public static function getBaseQuery()
    {
        return self::$baseQuery;
    }

    public static function getBody()
    {
        return self::$body;
    }

    public static function getJoins()
    {
        return self::$joins;
    }

    public static function getSort()
    {
        return self::$sortBy;
    }

    public static function getLimit()
    {
        return self::$limit;
    }

    public static function getBindList()
    {
        return self::$bindList;
    }

}
