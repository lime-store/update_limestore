<?php
header('Content-type: Application/json');

use core\classes\Inventory\Inventory;
use core\classes\System\Constants;
use core\classes\System\Main;
use core\classes\Utils\Utils;

$postData = $_POST['post_data'] ?? [];

$title = trim($postData['title'] ?? '');

if($title === '') {
    Utils::errorAbort('Sayim adını daxil edin');
    return;
}

$inventory = Inventory::create($title, $user->getCurrentUser('get_id'));

$inventory['open']       = ' ';
$inventory['cancel']     = ' ';
$inventory['report']     = '';
$inventory['created_at'] = date('d.m.Y H:i', strtotime($inventory['created_at']));
$inventory['status']     = 'Aktiv';

$controllerData = require Constants::RETAIL_CONTROLLER_DIR.'/inventory/inventory.controller.php';

$table_result = Main::compareData([$inventory], $controllerData['page_data_list']);

$table = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_row.twig' => [
            'table' => $table_result,
            'table_tab' => Utils::getPostPage(),
            'table_type' => Utils::getPostType(),
        ]
    ]
]);

Utils::abort([
    'type'  => 'success',
    'text'  => 'Sayim yaradıldı',
    'table' => $table,
]);