$(document).ready(function() {
    customer = {

    };
 
 
    $(document).on('order_success', function () {
        if(cart.cashback > 0) {
            spendCashback(cart.cashback);
        } else {
            applyCashback();
        }
    });

    $(document).on('display_total', function() {
      displayEarnedCashback();
    });

    $(document).on('click', '.open-cashback-pay-modal', function() {
        const controllerIndex = $(this).attr('data-controller-index');

        $.ajax({
            url: 'ajax_route.php',
            type: 'POST',
            dataType: 'json',
            data: {
                url: '/core/action/customer/cashbackPayModal.php',
                route: 'cashbackPayModal',
                customer_id: customer.id,
                orderSum: cart.orderSum
            },
            success: (data) => {
                if(data.type == 'error') {
                    return pageData.alert_notice(data.type, data.text);
                }
                console.log(data);
				pageData.overlayShow();
				$('.container').append(data.res);
            }
        });
    });

    $(document).on('keyup', '.pay-cashback-sum', function() {
        const value = $(this).val();
        const availableCashback = Number($('.modal-pay-cashback-amount').attr('data-cashback-amount'));

        const sum = availableCashback - value ?? 0;
        $('.modal-cashback-pay-notice').hide();
        
        $('.remaning-sum').html(sum.toFixed(2));
    });

    $(document).on('click', '.modal-apply-cashback-to-pay', function() {
        const cashbackSum = Number($('.pay-cashback-sum').val());
        const orderSum = Number($('.modal-pay-order-sum').attr('data-cart-sum'));
        const availableCashback = Number($('.modal-pay-cashback-amount').attr('data-cashback-amount'));

        // если ничего не ввели
        if(!cashbackSum) {
            $('.modal-cashback-pay-notice')
                .show()
                .text(`Keşbek istifadə məbləğini daxil edin`);
            return; 
        }

        
        // если ввели больше бонусов чем есть
        if(cashbackSum > availableCashback) {
            console.log(cashbackSum);
            $('.modal-cashback-pay-notice')
                .show()
                .text(`Maksimum mövcud məbləğ: ${availableCashback}`);
            return;   
        }

        // если сумма кэшбэка больше суммы заказа
        if(cashbackSum > orderSum) {
            $('.modal-cashback-pay-notice')
                .show()
                .text(`Maksimum mövcud məbləğ: ${orderSum}`);
            return;   
        }

        cart.cashback = cashbackSum;

        cart.display_total();

        closeAndRemoveModal();
    }); 


    $(document).on('click', '.select-customer-item', function() {
        const id = $(this).attr('data-id');

        $.ajax({
            url: 'ajax_route.php',
            type: 'POST',
            dataType: 'json',
            data: {
                url: '/core/action/customer/getCustomerInfo.php',
                route: 'getCustomerInfo',
                id: id
            },
            success: (data) => {
                customer = data;
                displayEarnedCashback();
            }
        });
    });
});

 
  $('body').on('click', '.reset-cart, .reset-customer-choose-input', function(){
    resetCustomerInput();
    cart.display_total();
  });


function spendCashback(amount) {
    $.ajax({
        url: 'ajax_route.php',
        type: 'POST',
        dataType: 'json',
        data: {
            url: '/core/action/customer/spendCashback.php',
            route: 'spendCashback',
            spendAmount: amount         
        },
        beforeSend: function() {

        },
        success: (data) => {
           return resetCustomerInput();
        }
    });
}


function applyCashback(amount) {
    $.ajax({
        url: 'ajax_route.php',
        type: 'POST',
        dataType: 'json',
        data: {
            url: '/core/action/customer/applyCashback.php',
            route: 'applyCashback'               
        },
        success: (data) => {
            return resetCustomerInput();
        }
    });
}

function resetCustomerInput() {
    $('.select-customer').val('Müştəri seçin').attr('data-id', '');
    cart.cashback = 0;
    customer = {};
    displayEarnedCashback();
}

function displayEarnedCashback() {
    const c = cart.orderSum * customer.cashback_percent / 100;
    const container = $('.customer-choose-input-container')
            .find('.fields-label');

    if(customer.id && cart.cashback <= 0) {
        if (container.find('.earned-cashback-info').length === 0) {
            container.append('<span class="earned-cashback-info"></span>');
        }

        // обновляем текст
        container.find('.earned-cashback-info').html(`
            (Qazanılan bonus: ${c})
        `);   
    } else {
        $('.customer-choose-input-container').find('.earned-cashback-info').remove();
    }      
}