<?php

use core\classes\Inventory\Inventory;
use core\classes\Inventory\InventorySession;
use core\classes\System\Constants;
use core\classes\System\Main;

$inventory_id = (int) ($_POST['inventory_id'] ?? ($_GET['inventory_id'] ?? 0));
$session_id   = (int) ($_POST['session_id'] ?? ($_GET['session_id'] ?? 0));

$controllerData = require Constants::RETAIL_CONTROLLER_DIR.'/inventory/inventory.controller.php';

$inventoryStatusText = [
    Inventory::STATUS_ACTIVE    => 'Aktiv',
    Inventory::STATUS_COMPLETED => 'Tamamlanıb',
    Inventory::STATUS_CANCELLED => 'Ləğv edilib',
];

$sessionStatusText = [
    InventorySession::STATUS_OPEN      => 'Açıq',
    InventorySession::STATUS_CLOSED    => 'Bağlanıb',
    InventorySession::STATUS_CANCELLED => 'Ləğv edilib',
];


/**
 * Экран сканирования сессии
 */
if($session_id > 0) {

    $session = InventorySession::find($session_id);

    if(empty($session)) {
        echo $Render->view('/component/inner_container.twig', [
            'renderComponent' => [
                '/component/parts/alert.twig' => [
                    'value' => 'Sessiya tapılmadı',
                    'classList' => 'mark-danger width-100'
                ],
            ]
        ]);
        return;
    }

    $inventory = Inventory::find((int) $session['inventory_id']);
    $review    = !empty($session['review_started_at']) && $session['status'] === InventorySession::STATUS_OPEN;
    $items     = $review
        ? InventorySession::items($session_id, 'name_asc')
        : InventorySession::items($session_id, 'updated_desc', 50);

    echo $Render->view('/component/inner_container.twig', [
        'renderComponent' => [
            '/component/inventory/session_scan.twig' => [
                'inventory'            => $inventory,
                'session'              => $session,
                'items'                => $items,
                'review'               => $review,
                'session_status_text'  => $sessionStatusText[$session['status']] ?? $session['status'],
                'session_id'           => $session_id,
            ]
        ]
    ]);

    return;
}


/**
 * Список сессий инвентаризации
 */
if($inventory_id > 0) {

    $inventory = Inventory::find($inventory_id);
    $sessions  = Inventory::sessions($inventory_id);

    $list = [];

    foreach ($sessions as $row) {
        $isOpen = $row['status'] === InventorySession::STATUS_OPEN;

        $row['open']       = $isOpen ? ' ' : '';
        $row['cancel']     = $isOpen ? ' ' : '';
        $row['created_at'] = date('d.m.Y H:i', strtotime($row['created_at']));
        $row['status']     = $sessionStatusText[$row['status']] ?? $row['status'];

        $list[] = $row;
    }

    $table_result = Main::compareData($list, $controllerData['page_data_list']['session_list']);

    $widgets = [
        'back' => [
            '/component/parts/input.twig' => [
                'containerClassList' => 'height-auto',
                'inputClassList' => 'input btn-input btn-secondary width-auto inventory-back',
                'attr' => [
                    'type' => 'button',
                    'value' => '← Geri'
                ]
            ]
        ],
    ];

    if(!empty($inventory) && $inventory['status'] === Inventory::STATUS_ACTIVE) {
        $widgets['create'] = [
            '/component/parts/input.twig' => [
                'containerClassList' => 'height-auto',
                'inputClassList' => 'input btn-input btn-success width-auto load-session-add-modal',
                'inputIcon' => [
                    'icon' => 'las la-plus-circle'
                ],
                'attr' => [
                    'type' => 'button',
                    'value' => 'Yeni sessiya',
                    'data-inventory-id' => $inventory_id
                ]
            ]
        ];

        $widgets['close'] = [
            '/component/parts/input.twig' => [
                'containerClassList' => 'height-auto',
                'inputClassList' => 'input btn-input btn-warning width-auto close-inventory',
                'inputIcon' => [
                    'icon' => 'las la-check-circle'
                ],
                'attr' => [
                    'type' => 'button',
                    'value' => 'Sayımı bitir',
                    'data-inventory-id' => $inventory_id
                ]
            ]
        ];
    }

    echo $Render->view('/component/inner_container.twig', [
        'renderComponent' => [
            '/component/related_component/include_widget.twig' => [
                '/component/include_once_component.twig' => [
                    'includs' => $widgets
                ],
            ],
            '/component/table/table_wrapper.twig' => [
                'table' => $table_result,
                'table_tab' => $page,
                'table_type' => $type,
            ],            
        ]
    ]);

    return;
}


/**
 * Список инвентаризаций
 */
$inventories = Inventory::all();

$list = [];

foreach ($inventories as $row) {
    $isActive    = $row['status'] === Inventory::STATUS_ACTIVE;
    $isCompleted = $row['status'] === Inventory::STATUS_COMPLETED;

    $row['open']       = $isActive ? ' ' : '';
    $row['cancel']     = $isActive ? ' ' : '';
    $row['report']     = $isCompleted ? ' ' : '';
    $row['created_at'] = date('d.m.Y H:i', strtotime($row['created_at']));
    $row['status']     = $inventoryStatusText[$row['status']] ?? $row['status'];

    $list[] = $row;
}

$table_result = Main::compareData($list, $controllerData['page_data_list']);

echo $Render->view('/component/inner_container.twig', [
    'renderComponent' => [
        '/component/related_component/include_widget.twig' => [
            '/component/include_once_component.twig' => [
                'includs' => [
                    'create' => [
                        '/component/parts/input.twig' => [
                            'containerClassList' => 'height-auto',
                            'inputClassList' => 'input btn-input btn-success width-auto load-inventory-add-modal',
                            'inputIcon' => [
                                'icon' => 'las la-plus-circle'
                            ],
                            'attr' => [
                                'type' => 'button',
                                'value' => 'Yeni sayim'
                            ]
                        ]
                    ],
                ],
            ],
        ],
        '/component/table/table_wrapper.twig' => [
            'table' => $table_result,
            'table_tab' => $page,
            'table_type' => $type,
        ],        
    ]
]);