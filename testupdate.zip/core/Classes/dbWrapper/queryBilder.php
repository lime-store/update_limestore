<?php
namespace core\classes\dbWrapper;

use \core\classes\dbWrapper\traits\select;
use Core\Classes\Utils\Utils;

class queryBilder
{
    use select;

    /**
     * @param string $select
     * @return mixed
     */
    public static function select($select)
    {
        self::$query .= " SELECT $select ";
        return new static;
    }

    /**
     * 
     */
    public static function from($tableName)
    {
        self::$query .= " FROM $tableName ";
        return new static;
    }

    /**
     * 
     */
    public static function where($where)
    {
        self::$query .= " WHERE $where ";
        return new static;
    }


    /**
     * 
     */
    public static function join()
    {

    }


    /**
     * @param string $colName названиле колонки 
     * @param string $desc    сортировка ASC/DESC (default = ASC)
     */
    public static function orderBy($colName, $desc = 'ASC')
    {
        self::$query .= " ORDER BY $colName $desc ";
        return new static;
    }

    /**
     * @param string $colName названиле колонки 
     * @param string $desc    сортировка ASC/DESC (default = ASC)
     */
    public static function groupBy($colName, $desc = 'ASC')
    {
        self::$query .= " GROUP BY $colName $desc ";
        return new static;
    }
    
    /**
     * 
     */
    public static function limit($limit)
    {
        self::$query .= " LIMIT $limit ";
        return new static;
    }

    /**
     * 
     */
    public static function all()
    {
        return self::$result;
    }

    /**
     * 
     */
    public static function first()
    {
        self::$result = self::$result[0];
        return new static;
    }


    /**
     * 
     */
    public static function columnName(string $columnName)
    {
        self::$result = self::$result[$columnName];
        return new static;
    }

    /**
     * 
     */
    public static function bindList(array $bindList)
    {
        self::$bindList = $bindList;
        return new static;
    }    


    /**
     * @return mixed
     */
     public static function execute()
     {
        self::queryExecute();
        return new static;
     }

     /**
      * 
      */
     public static function get()
     {
        return self::$result;
     }


}