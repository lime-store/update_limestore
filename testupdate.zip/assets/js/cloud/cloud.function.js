$(document).ready(function() {
   $(document).on('click', '.send-cloud-transfer', function() {
        const warehouse_id = $('.cart-warehouse-id').val();
        if(cart.is_cart_prepared() !== false) {
            $.ajax({
                url: 'ajax_route.php',
                type: 'POST',
                data: {
                    route: 'cloudProductTransfer',
                    url: '/core/cloud/action/product-transfer.php',
                    warehouse_id: warehouse_id,
                    list: cart.get_cart_list()
                },
                success: (data) => {

                    if(data.type == 'success') {
                        cart.order_success();
                    }

                    createBackup();

                    pageData.alert_notice(data.type, data.text);
                }
            });
        }
    });

    /**
     * editedProduct - это триггер который вызывается в stock.function.js
     * в блоке success если товар был успешно изменен
     */
    $(document).on('editedProduct', function() {
        const productId = Utils.itemId;
        const editedProduct = Utils.lastEditedProduct;

        if(productId) {
            $.ajax({
                url: 'ajax_route.php',
                type: 'POST',
                data: {
                    route: 'cloudEditProduct',
                    url: '/core/cloud/action/product-edit.php',
                    productId: productId,
                    lastEditedProduct: editedProduct,
                },
                success: (data) => {
                }
            });
        }
    });

    $(document).on('deleteProduct', function() {
        const productId = Utils.itemId;

        if(productId) {
            $.ajax({
                url: 'ajax_route.php',
                type: 'POST',
                data: {
                    route: 'cloudDeleteProduct',
                    url: '/core/cloud/action/product-delete.php',
                    productId: productId
                }
            });
        }
    });


    $(document).on('editCategory', function(event, category) {
        $.ajax({
            url: 'ajax_route.php',
            type: 'POST',
            data: {
                route: 'cloudEditCategory',
                url: '/core/cloud/action/edit-category.php',
                categoryId: category.id
            }
        });
    });

    $(document).on('deleteCategory', function(event, category) {
        $.ajax({
            url: 'ajax_route.php',
            type: 'POST',
            data: {
                route: 'cloudDeleteCategory',
                url: '/core/cloud/action/delete-category.php',
                categoryId: category.id
            }
        });
    });


    $(document).on('editProvider', function(event, provider) {
        $.ajax({
            url: 'ajax_route.php',
            type: 'POST',
            data: {
                route: 'cloudEditProvider',
                url: '/core/cloud/action/edit-provider.php',
                providerId: provider.id
            }
        });
    });

    $(document).on('deleteProvider', function(event, provider) {
        $.ajax({
            url: 'ajax_route.php',
            type: 'POST',
            data: {
                route: 'cloudDeleteProvider',
                url: '/core/cloud/action/delete-provider.php',
                providerId: provider.id
            }
        });
    });    


    $(document).on('click', '.select-branch-users', function() {
        const branchId = $(this).attr('data-id');

        $.ajax({
            url: 'ajax_route.php',
            type: 'POST',
            dataType: 'json',
            data: {
                page: pageData.page(),
                branchId: branchId,
                route: 'cloudGetBranchUsers',
            },
            success: (data) => {
                if(data.table) {
                    pageData.innerTable(data.table);
                }                
            }
        });
    });

    $(document).on('addSeller', function() {
        const getBranchId = $('.admin-select-user-branch').val();

        $.ajax({
            url: 'ajax_route.php',
            type: 'POST',
            dataType: 'json',
            data: {
                route: 'setUserBranch',
                branchId: getBranchId
            }
        });
    });
    
});