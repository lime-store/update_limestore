﻿<?php 
/**
 * LIME SKLAD 2020
 * ©EMIL GASANOV
 * Версия для сотовых магазинов
 */

header("Cache-Control: no-cache, must-revalidate");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Content-Type: application/xml; charset=utf-8");
header("Pragma: no-cache");


require_once 'function.php';
root_dir();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Lime Store</title>
	<link rel="icon" type="image/x-icon" href="img/favicon.ico">	
	<link rel="stylesheet" type="text/css" href="css/new_style.css?v=1.0.1">
	<link rel="stylesheet" type="text/css" href="css/print.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

<div class="header-top-site flex-cntr">
	<div class="header-logo-wrp">
		<div class="header-logo-center">
			<a href="javascript:void(0);" class="header-logo-link">
				<span class="header-logo-bold-style flex-cntr">L</span>ime Store</a>
				<span class="sd">last upd: 03.06.2020</span>
		</div>
	</div>
	<div class="author_info">
		<div class="link_to_site_info"><a href="http://lime-sklad.github.io/" target="_blank" class="link">lime-sklad.github.io</a></div>
		<span>©Emil (tel: 0504213635) <?php echo date("Y"); ?></span>
	</div>

	<div class="preloader">
		<?php echo get_preloader(); ?>
	</div>
</div>



<?php include 'lib_include.php'; ?>
<?php require_once  (GET_ROOT_DIRS.'/core/main/update_check.php'); ?>