<?php

$this_data = $init->initController($page);

$page_config = $this_data['page_data_list'];

$table_result = $main->prepareData($this_data['sql'], $page_config);

echo $Render->view('/component/inner_container.twig', [
    'renderComponent' => [
        '/component/related_component/include_widget.twig' => [
			'/component/parts/input.twig' => [
				'inputClassList' => 'input btn-input width-auto load-category-add-modal',
				'inputIcon' => [
					'icon' => 'las la-plus-circle'
				],
				'attr' => [
					'type' => 'button',
					'value' => 'Kateqoriya əlavə et'
				]
			],
		],
        '/component/table/table_wrapper.twig' => [
            'table' => $table_result['result'],
            'table_tab' => $page,
            'table_type' => $type,				
        ],
    ]
]);