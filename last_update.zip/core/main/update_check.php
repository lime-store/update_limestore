<?php
	
	define('root_dir', $_SERVER['DOCUMENT_ROOT']);

	$root_dir = root_dir;

	$current_version = file_get_contents($root_dir.'/version.txt');

	// Создаем поток
	$opts = array(
	  'http'=>array(
	    'method'=>"GET",
	    'header'=>"Accept-language: en\r\n" .
	              "Cookie: foo=bar\r\n"
	  )
	);

	$context = stream_context_create($opts);
	//получем версию с репозитория
	$get_verison = file_get_contents('https://raw.githubusercontent.com/lime-sklad/update_limestore/master/version.txt', false, $context);

	//чистим от пробелов
	$get_verison = trim($get_verison);

	//версия пользователя
	$current_version = trim($current_version);



	if($current_version !== $get_verison) {
	   if(!isset($_POST['download_upd'])) {
	   		show_upd_notify();
	   }

		if(isset($_POST['download_upd'])) {
		    exec('curl https://github.com/lime-sklad/update_limestore/raw/master/last_update.zip -L -o update.zip');
			//запускаем установку обнов.
			ls_install_update($root_dir);
		}
	} 



	function ls_install_update($root_dir) {	 
		$zip = new ZipArchive;
		if($zip->open('update.zip') === TRUE) {
			$zip->extractTo($root_dir.'/sys');
		    $zip->close();
		    echo "Удачно";
		}
	}


	function show_upd_notify() {
	?>
		<div class="update_block">
			<div class="upd_wrapper">
				<div class="upd_preloader">Yuklenir</div>
				<div class="upd_header">
					<span class="">Yeniləmə mövcuddur</span>
				</div>
				<div class="upd_dwnld">
					<button class="btn download_btn_s download_btn">Yükləyin</button>
				</div>
			</div>
		</div>
	<?php
	}

?> 

<script type="text/javascript">
	$('body').on('click', '.download_btn', function(){	
		var $get_preloader = $('.upd_preloader');
		$get_preloader.fadeIn().css('display', 'flex');
		alert('Yeniləmələr yüklənir, zəhmət olmasa yükləmənin sonuna qədər gözləyin. \n Davam etmək üçün "OK" düyməsini basın');

		setTimeout(function(){
			get_request_upd();
		}, 3000);

		function get_request_upd() {
			var download_upd = 'dsfds';
			var link_path = 'core/main/update_check';
			$.ajax({
				type: 'POST',
				url: link_path,
				data: {
					download_upd: download_upd
				},
				cache: false,
				async: false,
				success: (data) => {
					document.location.href = "./";
				}			

			});
		}

	});
</script>

<style type="text/css">
	.update_block {
	    position: absolute;
	    right: 0;
	    top: 60px;
	}

	.update_block div {
	    box-sizing: border-box;
	}
	.upd_preloader {
	    width: 100%;
	    height: 100%;
	    display: none;
	    position: absolute;
	    justify-content: center;
	    align-items: center;
	    z-index: 40;
	    background: #ddd;
	    left: 0;
	    top: 0;
	    border-radius: 22px;
	}
	.upd_wrapper {
	    width: 350px;
	    height: 63px;
	    margin: 21px;
	    display: flex;
	    justify-content: unset;
	    align-items: center;
	    padding: 18px;
	    /* background: red; */
	    box-sizing: border-box;
	    z-index: 20;
	    background: #f2f2f2f2;
	    box-shadow: 0 0 20px 0px rgba(197, 197, 197, 0.6);
	    border-radius: 10px;
	    position: relative;
	    transition: .5s;
	}

	.upd_wrapper:hover {
	    box-shadow: 0 0 20px 0px rgb(34, 111, 181, 0.5);
	}

	.upd_header {
	    /* padding: 0 10px; */
	    width: 50%;
	    height: 100%;
	    display: flex;
	    align-items: center;
	}

	.upd_header>span {
	    font-size: 16px;
	    color: #333;
	}

	.upd_dwnld {
	    position: absolute;
	    right: 10px;
	    transition: .5s;
	}

	.upd_dwnld:hover {
	    right: 15px;
	}

	.download_btn_s {
	    border-radius: 22px;
	    border: 0;
	    background: #226fb5;
	    color: #fff;
	    width: 113px;
	    height: 38px;
	    font-size: 16px;
	    text-transform: uppercase;
	    cursor: pointer;
	    outline: 0;
	    opacity: 0.8;
	    transition: .5s;
	}

	.download_btn_s:hover {
	    opacity: 1;
	} 
</style><?php
	
	define('root_dir', $_SERVER['DOCUMENT_ROOT']);

	$root_dir = root_dir;

	$current_version = file_get_contents($root_dir.'/version.txt');

	// Создаем поток
	$opts = array(
	  'http'=>array(
	    'method'=>"GET",
	    'header'=>"Accept-language: en\r\n" .
	              "Cookie: foo=bar\r\n"
	  )
	);

	$context = stream_context_create($opts);
	//получем версию с репозитория
	$get_verison = file_get_contents('https://raw.githubusercontent.com/lime-sklad/update_limestore/master/version.txt', false, $context);

	//чистим от пробелов
	$get_verison = trim($get_verison);

	//версия пользователя
	$current_version = trim($current_version);



	if($current_version !== $get_verison) {
	   if(!isset($_POST['download_upd'])) {
	   		show_upd_notify();
	   }

		if(isset($_POST['download_upd'])) {
		    exec('curl https://github.com/lime-sklad/update_limestore/raw/master/last_update.zip -L -o update.zip');
			//запускаем установку обнов.
			ls_install_update($root_dir);
		}
	} 



	function ls_install_update($root_dir) {	 
		$zip = new ZipArchive;
		if($zip->open('update.zip') === TRUE) {
			$zip->extractTo($root_dir);
		    $zip->close();
		    echo "Удачно";
		}
	}


	function show_upd_notify() {
	?>
		<div class="update_block">
			<div class="upd_wrapper">
				<div class="upd_preloader">Yuklenir</div>
				<div class="upd_header">
					<span class="">Yeniləmə mövcuddur</span>
				</div>
				<div class="upd_dwnld">
					<button class="btn download_btn_s download_btn">Yükləyin</button>
				</div>
			</div>
		</div>
	<?php
	}

?> 

<script type="text/javascript">
	$('body').on('click', '.download_btn', function(){	
		var $get_preloader = $('.upd_preloader');
		$get_preloader.fadeIn().css('display', 'flex');
		alert('Yeniləmələr yüklənir, zəhmət olmasa yükləmənin sonuna qədər gözləyin. \n Davam etmək üçün "OK" düyməsini basın');

		setTimeout(function(){
			get_request_upd();
		}, 3000);

		function get_request_upd() {
			var download_upd = 'dsfds';
			var link_path = 'core/main/update_check';
			$.ajax({
				type: 'POST',
				url: link_path,
				data: {
					download_upd: download_upd
				},
				cache: false,
				async: false,
				success: (data) => {
					document.location.href = "./";
				}			

			});
		}

	});
</script>

<style type="text/css">
	.update_block {
	    position: absolute;
	    right: 0;
	    top: 60px;
	}

	.update_block div {
	    box-sizing: border-box;
	}
	.upd_preloader {
	    width: 100%;
	    height: 100%;
	    display: none;
	    position: absolute;
	    justify-content: center;
	    align-items: center;
	    z-index: 40;
	    background: #ddd;
	    left: 0;
	    top: 0;
	    border-radius: 22px;
	}
	.upd_wrapper {
	    width: 350px;
	    height: 63px;
	    margin: 21px;
	    display: flex;
	    justify-content: unset;
	    align-items: center;
	    padding: 18px;
	    /* background: red; */
	    box-sizing: border-box;
	    z-index: 20;
	    background: #f2f2f2f2;
	    box-shadow: 0 0 20px 0px rgba(197, 197, 197, 0.6);
	    border-radius: 10px;
	    position: relative;
	    transition: .5s;
	}

	.upd_wrapper:hover {
	    box-shadow: 0 0 20px 0px rgb(34, 111, 181, 0.5);
	}

	.upd_header {
	    /* padding: 0 10px; */
	    width: 50%;
	    height: 100%;
	    display: flex;
	    align-items: center;
	}

	.upd_header>span {
	    font-size: 16px;
	    color: #333;
	}

	.upd_dwnld {
	    position: absolute;
	    right: 10px;
	    transition: .5s;
	}

	.upd_dwnld:hover {
	    right: 15px;
	}

	.download_btn_s {
	    border-radius: 22px;
	    border: 0;
	    background: #226fb5;
	    color: #fff;
	    width: 113px;
	    height: 38px;
	    font-size: 16px;
	    text-transform: uppercase;
	    cursor: pointer;
	    outline: 0;
	    opacity: 0.8;
	    transition: .5s;
	}

	.download_btn_s:hover {
	    opacity: 1;
	} 
</style>