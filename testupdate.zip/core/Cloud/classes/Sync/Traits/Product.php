<?php

namespace core\Cloud\classes\Sync\Traits;

use core\classes\Products;
use core\classes\Services\BaseService;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\dbWrapper\db;
use core\classes\Services\Warehouse\Warehouse;
use core\classes\Utils\Utils;

trait Product
{
    /**
     * 
     */
    public static function addTransferTask(array $data, int $branchId)
    {
        $Products = new Products;

        try {
            Warehouse::addTransfer($data, $branchId);

            db::beginTransaction();

            foreach ($data as $row) {
                $productId = $row['id'];

                $product        = $Products::getProductById($productId);
                $categoryList   = $Products->getProductCategory($productId);
                $prodviderList  = $Products->getProductProvider($productId);
                $barcodeList    = $Products->getProductBarcodeList($productId);

                db::insert('sync_queue', [
                    [
                        'branch_id'     => $branchId,
                        'product_id'    => $productId,
                        'action'        => BaseService::CLOUD_PAYLOAD_ACTION['transferProduct'],
                        'status'        => 'pending',
                        'payload'       => json_encode([
                            'productInfo'   => $product,
                            'transferInfo'  => $row,
                            'categoryInfo'  => $categoryList,
                            'providerInfo'  => $prodviderList,
                            'barcodeInfo'   => $barcodeList,
                        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                    ]
                ]);
            }

            db::commit();
            return true;
        } catch (\Throwable $e) {
            db::rollBack();
            throw $e;
        }
    }



    public static function editProductTask($productId, $productInfo)
    {
        $Products = new Products;
        $product        = $Products::getProductById($productId);
        $categoryList   = $Products->getProductCategory($productId);
        $prodviderList  = $Products->getProductProvider($productId);
        $barcodeList    = $Products->getProductBarcodeList($productId);
        $branchList     = self::getBranchOnTaskListByProductId($productId);
        unset($productInfo['plus_minus_product_count']);
        unset($productInfo['append_stock_count']);
        unset($productInfo['change_product_count']);

        if (empty($branchList)) {
            return;
        }

        try {
            db::beginTransaction();
            foreach ($branchList as $branch) {
                db::insert('sync_queue', [
                    [
                        'branch_id'     => $branch['id'],
                        'product_id'    => $productId,
                        'action'        => BaseService::CLOUD_PAYLOAD_ACTION['updateProduct'],
                        'status'        => 'pending',
                        'payload'       => json_encode([
                            'productInfo'   => $productInfo,
                            'categoryInfo'  => $categoryList,
                            'providerInfo'  => $prodviderList,
                            'barcodeInfo'   => $barcodeList,
                        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)

                    ]
                ]);
            }

            db::commit();
            return true;
        } catch (\Throwable $e) {
            db::rollBack();
            throw $e;
        }
    }

    public static function deleteProduct(int $productId)
    {
        $branchList     = self::getBranchOnTaskListByProductId($productId);

        if (empty($branchList)) {
            return;
        }

        foreach ($branchList as $branch) {
            db::insert('sync_queue', [
                [
                    'branch_id'     => $branch['id'],
                    'product_id'    => $productId,
                    'action'        => BaseService::CLOUD_PAYLOAD_ACTION['deleteProduct'],
                    'status'        => 'pending',
                    'payload'       => json_encode([
                        'delete'   => true,
                    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                ]
            ]);
        }
    }

    /**
     * 
     */
    public static function getBranchOnTaskListByProductId(int $productId, $status = 'done'): array
    {
        $result = qb::select('DISTINCT branch_id as id')
            ->from('sync_queue')
            ->where('product_id=:product_id AND action=:action AND status=:status')
            ->bindList([
                'product_id' => $productId,
                'action'     => BaseService::CLOUD_PAYLOAD_ACTION['transferProduct'],
                'status'     => $status
            ])
            ->execute()
            ->get();

        return $result ?? [];
    }
}
