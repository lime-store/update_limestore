<?php 
	require_once '../../function.php';

	ls_include_tpl();
	//получаем тип таблицы
	get_table_svervice_type();

	//получем категорию товара
	get_product_category();
	
	//получаем заголовки таблицы
	get_table_header();

?>



<div class="terminal_main">
	<div class="view_stock_wrapper">
		<div class="view_stock_box_wrp">
			<section class="note_wrapper_section">
				<div class="note_wrapper">
					<div class="note_add_wrp">
						<div class="note_add_form">

							<ul class="add_stock_box_form">
								<li class="add_stock_form_list">
									<span class="add_stock_description">Xərc:</span>
									<input type="text" class="add_stock_input add_rasxod_style add_rasxod_value_a">
								</li>
								<li class="add_stock_form_list note_custom_list">
									<span class="add_stock_description">Təsvir:</span>
									<textarea class="add_stock_input add_rasxod_descript_a add_note_descript"></textarea>
								</li>
								<li class="add_stock_form_list submit_list">
									<input type="hidden" class="note_action_type" data-type="<?php echo $note; ?>">
									<a href="javascript:void(0)" class="btn add_rasxod_submit flex-cntr">Saxla</a>
								</li>
							</ul>

						</div>
					</div>
				<div class="search_filter_wrapper">
					<div class="flex f-jc-end f-ai-cntr width-100">
						<?php 
						filt_report_date($rasxod_category, $dbpdo, $order_myear, $rasxod); 
						search_input($arr = array(
							'product_type' => $rasxod,
							'product_category' => $rasxod_category,
							'product_class' => '',
							'parent_class' => '',
							'auto_complete' => 'hide',
							'label' => 'hide',
							'label_title' => '',
							'clear_button' => 'show'

						)); 
						?>	
					</div>
				</div>

					<div class="note_table_list ls-custom-scrollbar">
						<table class="display stock_table" style="width:100%">
							<thead>
								<tr>
									<?php 
									echo $table_header['th_date'];
									echo $table_header['th_total_rasxod'];
									echo $table_header['th_rasxod_decsription'];
									?>
								</tr>
							</thead>
							<tbody class="rasxod_order_list stock_list_tbody" data-stock-src="<?php echo  $rasxod; ?>" data-category="<?php echo $rasxod_category; ?>">
							<?php 

								$rasxod_list = [];

								$rasxod_query = $dbpdo->prepare("SELECT * FROM rasxod 
									WHERE rasxod_visible = 0
									AND rasxod_year_date = :mydate  
									GROUP BY rasxod_id DESC");
								$rasxod_query->bindParam('mydate', $order_myear);
								$rasxod_query->execute();

								if($rasxod_query->rowCount()>0) {
									while ($rasxod_row = $rasxod_query->fetch(PDO::FETCH_BOTH))
										$rasxod_list[] = $rasxod_row;
									foreach ($rasxod_list as $rasxod_row) 
									{
										$rasxod_id 				= $rasxod_row['rasxod_id'];
										$rasxod_day_date 		= $rasxod_row['rasxod_day_date'];
										$rasxod_price 			= $rasxod_row['rasxod_money'];
										$rasxod_descriptuon 	= $rasxod_row['rasxod_description'];								
										
										$get_rasxod = array(
											'rasxod_id'				=> $rasxod_id, 			   			
											'rasxod_day_date'		=> $rasxod_day_date, 	   	
											'rasxod_price'			=> $rasxod_price, 		   		
											'rasxod_descriptuon' 	=> $rasxod_descriptuon,
											'manat_image'			=> $manat_image 
										);
										echo get_rasxod_tr_tamplate($get_rasxod);
									}	
								   get_total_rasxod_value($order_myear);
								}

						 ?>												
							</tbody>
						</table>					
					</div>

				</div>
			</section>
		</div>
	</div>
