<?php

namespace core\Cloud\classes\Sync\Traits;

use core\classes\Products;
use core\classes\Services\BaseService;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\dbWrapper\db;
use core\classes\Services\Warehouse\Warehouse;

trait Provider
{
    /**
     * 
     */
    public static function getSyncedBranchesForProvider(int $providerId)
    {
        return qb::select('branch_id')
            ->from('products_provider_list')
            ->where('id_from_provider', $providerId)
            ->where('status', BaseService::CLOUD_PAYLOAD_STATUS['done'])
            ->innerJoin('sync_queue', 'sync_queue.product_id = products_provider_list.id_from_stock')
            ->groupBy('sync_queue.branch_id')
            ->get();        
    }

    /**
     * 
     */
    public static function editProviderTask(int $providerId)
    {
        $branches = self::getSyncedBranchesForProvider($providerId);
        
        $provider = qb::select('*')
                    ->from('stock_provider')
                    ->where('provider_id', $providerId)
                    ->first()
                    ->get();

        if(empty($branches) && empty($provider)) {
            return;
        }

        foreach($branches as $branch) {
            db::insert('sync_queue', [
                [
                    'branch_id'     => $branch['id'],
                    'product_id'    => 0,
                    'action'        => BaseService::CLOUD_PAYLOAD_ACTION['editProvider'],
                    'status'        => BaseService::CLOUD_PAYLOAD_STATUS['pending'],
                    'payload'       => json_encode([
                        'providerInfo'  => $provider,
                    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                ]
            ]);
        }
    }

   /**
     * 
     */
    public static function deleteProviderTask(int $providerId)
    {
        $branches = self::getSyncedBranchesForProvider($providerId);
        
        $provider = qb::select('*')
                    ->from('stock_provider')
                    ->where('provider_id', $providerId)
                    ->first()
                    ->get();

        if(empty($branches) && empty($provider)) {
            return;
        }

        foreach($branches as $branch) {
            db::insert('sync_queue', [
                [
                    'branch_id'     => $branch['id'],
                    'product_id'    => 0,
                    'action'        => BaseService::CLOUD_PAYLOAD_ACTION['deleteProvider'],
                    'status'        => BaseService::CLOUD_PAYLOAD_STATUS['pending'],
                    'payload'       => json_encode([
                        'providerInfo'  => $provider,
                    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                ]
            ]);
        }        
    }    
}
