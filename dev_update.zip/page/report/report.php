<?php
	require_once '../../function.php';
	//Показывать товары которые находться в базе больше 15 дней 
	// settShowOldProduct();

	//выводим заголовок страницы
	tab_page_header('Hesabat');

	//блок для принта чека
	printModal();

	//пути к категориям
	get_product_root_dir();	

	//выводим перекючения вкладок 
	getCurrentTab($report_phone_link, $report_akss_link); 

	//абсолютный пусть к файлам
	root_dir();
?>

<div class="terminal_main">
	<?php require_once GET_ROOT_DIRS. $report_phone_link;	?>
</div>