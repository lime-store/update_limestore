<?php
header('Content-type: Application/json');

use core\classes\Inventory\InventorySession;
use core\classes\Utils\Utils;

require __DIR__.'/_helpers.php';

$sessionId = (int) ($_POST['session_id'] ?? 0);
$stockId   = (int) ($_POST['stock_id'] ?? 0);
$counted   = (float) ($_POST['counted_quantity'] ?? 0);

if($sessionId <= 0 || $stockId <= 0) {
    Utils::errorAbort('Məlumat tapılmadı');
    return;
}

try {
    InventorySession::updateCountedQuantity($sessionId, $stockId, $counted, $user->getCurrentUser('get_id'));
} catch (\Throwable $e) {
    Utils::errorAbort(inventoryErrorMessage($e));
    return;
}

$result = renderInventorySessionItems($sessionId);

Utils::abort([
    'type'        => 'success',
    'items_table' => $result['items_table'],
    'review'      => $result['review'],
]);