<?php 

include $_SERVER['DOCUMENT_ROOT'].'/core/main/auto_install_dbsql.php';

header('Location: /');

