<?php
exit;

require_once $_SERVER['DOCUMENT_ROOT'].'/vendor/autoload.php';

use Spatie\Dropbox\Client as DropboxClient;
use Spatie\Dropbox\RefreshableTokenProvider;
use Spatie\Dropbox\TokenProvider;
use GuzzleHttp\Client;  


$appKey = '0cno2oumcf4kt5g';
$appSecret =  'tek71f5tf84ri9n';





// $refressh_token = 'RucxgS1pHDAAAAAAAAAAKaqaCr4DLLwHmKsVowXQ6qQ';
// $token = 'sl.BlTXV5NA8u0KnEvmktBB3aXiE59M1Z2cYBM4wPB5N7j4Ra7f7lXyRp83R_gqr0VlTKNUKvw_vM86bkevNS8nmiFqgb9dTt_EOgrTPPkQMMxsTE1_kWmZQ2VN8gdCMmoXsWV2_BLZMT0Yqb6L6Z_wsAk';
// // sl.BlQAjITCyJ2PICbzBHVXOGNJvv9k4v8i1RZyw64PgejO_RMHXshPdURj9Ayz8pSg0A-vxh8cHOS_OGj87fWtLvcWjKHKbsURVIC9HearJkKnLydHNtxsbcIIWgTs8I_ZpzXLriXVzP62C2IlTK6xlxg

$client = new DropboxClient([$appKey, $appSecret]);


// $tokenProvider =  new RefreshableTokenProvider('sl.BlR-OixW-oOm3wx4WzytkdYR2c2y_cD703gIkqCnUpSBey7eUfAVz5sr9JyroRJEO9xnQAE-7c410c6-qeNgqJts74Iea06A8P9kviOAyNVoq67XoPOjhj6Lf4JRFnjXDk9JjffVBEoX-FrflQ7VrBM');


$tokenProvider = $client->createConfiguredMock(RefreshableTokenProvider::class, [
    'getToken' => 'test_token',
]);


var_dump($tokenProvider);

exit;

// этот код работает он реворкает токен, но после того как он изменил токен мы не можеи если увидить и использовать сука
$response = $client->post('https://api.dropboxapi.com/2/auth/token/revoke', [
    'headers' => [
        'Authorization' => 'Bearer ' . 'sl.BlR-OixW-oOm3wx4WzytkdYR2c2y_cD703gIkqCnUpSBey7eUfAVz5sr9JyroRJEO9xnQAE-7c410c6-qeNgqJts74Iea06A8P9kviOAyNVoq67XoPOjhj6Lf4JRFnjXDk9JjffVBEoX-FrflQ7VrBM',
    ],
]);

// Проверьте ответ на ошибки
if ($response->getStatusCode() !== 200) {
    $error = json_decode($response->getBody(), true);
    echo 'Error: ' . $error['error_summary'];
} else {

    echo '<pre>';
        var_dump($response);
    echo '</pre>';

    echo 'Token revoked successfully.';
}







// use Spatie\Dropbox\Client as DropboxClient;
// use Spatie\Dropbox\TokenProvider;
// use GuzzleHttp\Client;


// // $token = 'sl.BktV5UaHcj26Bw7oTfKTI-lUcGHeyqpOHkx7LH6zm7hfUImY4A2bNu4RTGK9Oh5nmy6J2qfO8EQ2J63MSZ-1EmIUtR0MQvfJrSXU4AKY9i4U_8sTb1WNatpbB8ezi-iT4rhKVLAgKMNvfmY';
// $token = '0cno2oumcf4kt5g';

// // $client = new DropboxClient($token);
// $client = new DropboxClient($token);

// $date = date('d.Y');


// $client = new Client();

// $response = $client->post('https://api.dropboxapi.com/oauth2/token', [
//     'form_params' => [
//         'grant_type' => 'refresh_token',
//         'refresh_token' => 'YOUR_REFRESH_TOKEN',
//         'client_id' => 'YOUR_CLIENT_ID',
//         'client_secret' => 'YOUR_CLIENT_SECRET',
//     ],
// ]);

// $data = json_decode($response->getBody(), true);

// // Extract the new access token from the response
// $newAccessToken = $data['access_token'];


// var_dump($newAccessToken);
// // $client->upload("/filename_$date.txt", file_get_contents('file.txt'), $mode='add');