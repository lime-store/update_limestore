<?php

namespace core\classes\Utils;

use core\classes\Privates\AccessManager;
use core\classes\System\Init;
use GuzzleHttp\Client;


class Utils
{
    /**
     * 
     * @param int $price
     * @return int
     * old function name decorate_num
     */
    public static function prettyPrintNumber($price)
    {
        // Проверяем, является ли число дробным
        if (strpos($price, '.') !== false) {
            // Преобразуем число в дробное с двумя знаками после запятой
            $formatted_number = number_format((float)$price, 2, '.', ' ');
        } else {
            // Преобразуем число в целое
            $formatted_number = number_format((float)$price, 0, '.', ' ');
        }

        return $formatted_number;
    }

    /**
     * 
     */
    public static function toIntVal($number) {
        if ($number == intval($number)) {
            return intval($number);
        } 
        
        return $number;
    }
    
    /**
     * выводит месяц и год
     * @return date|year month and year
     * 
     * old function name get_my_dateyear
     */
    public static function getDateMY()
    {
        return date("m.Y");
    }

    /**
     * выводит день месяц и год
     * @return day|month|year
     * 
     * old function get_my_datetoday()
     */
    public static function getDateDMY()
    {
        return  date("d.m.Y");
    }


    /**
     * 
     */
    public static function log($var)
    {
        echo "<pre>";
        echo '=== '.date('Y-m-d H:i:s')." === \n";
        print_r($var);
        echo "</pre>";
    }

    /**
     * 
     */
    public static function dlog($var)
    {
        self::log($var);
        die;
    }    

    /**
     * Выводить json
     * @param array $arr 
     * @return json|null
     */
    public static function abort(array $arr)
    {
        echo json_encode($arr);
    }


    /**
     * 
     */
    public static function errorAbort(string $errText)
    {
        return self::abort([
            'type' => 'error',
            'text' => $errText
        ]);
    }

    /**
     * 
     */
    public static function successAbort(string $text)
    {
        return self::abort([
            'type' => 'success',
            'text' => $text
        ]);
    }


    /**
     * 
     */
    public static function getPostPage()
    {
        return $_POST['page'] ?? false;
    }


    /**
     * 
     */
    public static function getPostType()
    {
        return $_POST['type'] ?? false;
    }


    /**
     * 
     */
    public static function stringToInt($val)
    {
        return (int) str_replace(' ', '', $val);
    }

    /**
     * 
     */
    public static function stringToFloat($val)
    {
        return (float) str_replace(' ', '', $val);
    }


    /**
     * 
     */
    public static function generateTransactionId()
    {
        $new_sault = rand(000000, 999999);
        $new_sault2 = rand(000000, 555555);

        $transaction_id = $new_sault * $new_sault2 / 2;

        return (int) $transaction_id;
    }



    /**
     * проверяем есть интернет у пользоваетля
     * 
     * @return boolean true/false
     */
    public static function hasConnetion()
    {
        $client = new Client();

        $response = $client->request('GET', 'https://www.google.com/', [
            'headers' => [
                'Accept' => 'application/json', // Пример добавления заголовков, если это необходимо
            ]
        ]);

        $statusCode = $response->getStatusCode();
        if ($statusCode == 200) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * получаем сегодняшний день недели 
     */
    public static function getCurrentWeek()
    {
        $today_list = getdate();
        return $today_list['wday'];
    }


    /**
     * Проверяем наличие папки если нет, то создаем папку
     * @param string $dir path
     */
    public static function checkAndCreateDir($dir)
    {
        if (!file_exists($dir)) {
            mkdir($dir, 0700);
        }

        return true;
    }



    /**
     * time.windows.com - 180-200ms
     * time.google.com - 80-90ms
     * time.cloudflare.com - 8-25ms
     */
    public static function ntp($server = 'time.cloudflare.com', $port = 123)
    {
        $socket = @fsockopen("udp://$server", $port, $err_no, $err_str, 1);
        if (!$socket) return;

        fwrite($socket, chr(0x1b) . str_repeat("\0", 47));

        $packetReceived = fread($socket, 48);

        $unixTimestamp = unpack('N', $packetReceived, 40)[1] - 2208988800;

        $utcDate = date("d.m.Y", $unixTimestamp);

        return $utcDate;
    }

    /**
     * извлекаем архив и устанавливем обновление 
     * 
     * old function name unpack_update
     */
    public static function unpackZip($pathToZip, $pathToExtract, callable $callback)
    {
        $zip = new \ZipArchive;

        if ($zip->open($pathToZip) === TRUE) {
            $zip->extractTo($pathToExtract);
            $zip->close();

            return $callback(true);
        }

        return $callback(false);
    }


    /**
     * @return boolean
     */
    public static function createZip($option)
    {
        $zip = new \ZipArchive();

        if (!$zip->open($option['path_to_file'] . $option['file_name'] . '.zip', \ZIPARCHIVE::CREATE)) {
            return false;
        }

        $zip->addFile($option['path_to_file'] . $option['file_name'], $option['file_name']);
        $zip->close();
    }


    /**
     * 
     * 
     * 
     */
    public static function getTagsList()
    {
        $default_data = [
            [
                'tags_id' => 'success',
                'class_list' => 'mark mark-tags mark-success-fill width-100 height-100',
            ],
            [
                'tags_id' => 'success-light',
                'class_list' => 'mark mark-tags mark-success width-100 height-100',
            ],
            [
                'tags_id' => 'danger',
                'class_list' => 'mark mark-tags mark-danger-fill width-100 height-100'
            ],
            [
                'tags_id' => 'danger-light',
                'class_list' => 'mark mark-tags mark-danger width-100 height-100'
            ],
            [
                'tags_id' => 'rose',
                'class_list' => 'mark mark mark-tags mark-rose width-100 height-100'
            ],
            [
                'tags_id' => 'warning',
                'class_list' => 'mark mark-tags mark-warning width-100 height-100'
            ],
            [
                'tags_id' => 'primary',
                'class_list' => 'mark mark-tags mark-primary width-100 height-100'
            ],
            [
                'tags_id' => 'black',
                'class_list' => 'mark mark-tags mark-black-fill width-100 height-100'
            ],
            [
                'tags_id' => 'blue',
                'class_list' => 'mark mark-tags mark-blue-fill width-100 height-100'
            ],
            [
                'tags_id' => 'gray',
                'class_list' => 'mark mark-tags mark-gray width-100 height-100'
            ]
        ];

        // если нужно вывести только теги 
        return $default_data;
    }


    /**
     * 
     */
    public static function isCorrectLocalDate()
    {
        $d = new \core\classes\dbWrapper\db;

        $data = $d::select([
            'table_name' => 'stock_order_report',
            'col_list' => '*',
            'query' => [
                'base_query' => '',
            ],
            'sort_by' => ' GROUP BY order_stock_id DESC ORDER BY order_stock_id DESC ',
            'limit' => 'limit 1'
        ]);

        $last_sale_date = $data[0]['order_date'];

        $local_date = (string) self::getDateDMY();

        if (strtotime($last_sale_date) > strtotime($local_date)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * GPT GENERATED CODE :/
     */
    public static function mergeArraysRecursively(array $array1, array $array2): array
    {
        foreach ($array2 as $key => $value) {
            if (is_array($value) && isset($array1[$key]) && is_array($array1[$key])) {
                $array1[$key] = self::mergeArraysRecursively($array1[$key], $value);
            } else {
                $array1[$key] = $value;
            }
        }
        return $array1;
    }

    public static function getOperationClass($value) {
        switch(true) {
            case (stripos($value, '-') !== false): 
                return 'mark-danger';
                break;
            case (stripos($value, '+') !== false):
                return 'mark-success';
                break;
            case (stripos($value, '%') !== false):
                return 'mark-warning';
                break;
            default:
                return 'mark-success';
                break;
        }
    }

    /**
     * Возвращает описание для значения reference_type
     */
    public static function getReferenceTypeDescription(string $type): string
    {
        $list = self::getReferenceTypeDescriptions();

        return $list[$type] ?? $type;
    }

    /**
     * Список всех описаний reference_type
     */
    public static function getReferenceTypeDescriptions(): array
    {
        return [
            'delete_refaund' => 'Geri qaytarma silindi',
            'delete_sale'    => 'Satış silindi',
            'refaund'        => 'Geri qaytarma',
            'sales'          => 'Satış',
            'manual_edit'    => 'Manual düzəliş',
            'transferIn'     => 'Transfer (giriş)',
            'transferOut'    => 'Transfer (çıxış)',
            'arivval'        => 'Alış fakturası',
            'writeOff'       => 'Silinmə fakturası',

            'deposit'        => 'Kassa medaxil',
            'withdraw'       => 'Kassa məxaric',
            'expense'        => 'Xərc',

            'cloudTransfer' => 'Mərkəzdən transfer (giriş)',
        ];
    }

    /**
     * Форматирует изменение количества (+/-)
     */
    public static function formatValueChange($value): string
    {
        return $value > 0 ? "+{$value}" : (string)$value;
    }

    /**
     * Подготавливает список для отображения
     */
    public static function formatReferenceList(
        array $list,
        string $valueColumnName,
        string $typeColumnName
    ): array {
        foreach ($list as &$item) {
            $item[$valueColumnName] = self::formatValueChange($item[$valueColumnName]);

            $item[$typeColumnName] = self::getReferenceTypeDescription(
                $item[$typeColumnName]
            );
        }

        unset($item);

        return $list;
    }

    /**
     * 
     */
    public static function toDropdownItems(array $items, string $id, string $value)
    {
        $result = [];

        foreach($items as $item) {
            $result[] = [
                'custom_data_id' => $item[$id] ?? '',
                'custom_value'   => $item[$value] ?? ''
            ];
        }

       return $result;
    }
}
