<?php

use core\classes\Services\Customer\Customer;

use core\classes\Utils\Utils;

$id = $_POST['id'];
Utils::abort(Customer::getCustomerInfo($id));