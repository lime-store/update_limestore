<?php

namespace core\classes\dbWrapper\traits;
use core\classes\Utils\Utils;
use core\classes\dbWrapper\db;
trait select
{
    protected static $defaultSettings = [
        'fetch_type'    => \PDO::FETCH_ASSOC,
        'placeholders'  => 'named',
        'bindType'      => 'bindParam'
    ];

    protected static $result;
    
    protected static $conditions = [];

    protected static $query;
    
    protected static $bindList = [];

    /**
     * Делает запрос в базу данных
     * 
     * @param array $query - массив с данными таблицы
     *  $pdo_fetch_type = \PDO::FETCH_ASSOC, string $placeholders = 'named'
     */
    public static function select(array $query, array $settings = []) {

        /**
        *    $res = $db::select([
        *        'table_name' => 'stock_list',
        *        'col_list' => '*',
        *        'query' => [
        *            'base_query' => '',
        *            'body' => '',
        *            'joins' => '',
        *            'sort_by' => '',
        *            'limit' => ''
        *        ],
        *        'bindList' => [
        *             'param' => $param
        *        ]        
        *    ])->get(); 
        **/

        self::setSettings($settings);
    
        // Utils::log($defaultSettings);   

        $query_row = $query['query'];

        self::$conditions 		= [];
        $table_name 		= $query['table_name'] 				?? '';
        $col_list 			= $query['col_list'] 				?? '';
        $base_query 		= $query_row['base_query'] 			?? '';
        $body				= $query_row['body'] 		        ?? '';
        $joins				= $query_row['joins'] 		        ?? '';
        $sort_by			= $query_row['sort_by'] 			?? '';
        $limit				= $query_row['limit'] 				?? '';
        $bind_list			= $query['bindList'] 	            ?? array();
    //  Utils::log($query);
    
        $query  = "SELECT $col_list FROM $table_name ";
        $query .= $base_query;
        $query .= $body;
        $query .= $joins;
        $query .= $sort_by;
        $query .= $limit;

        self::$query = $query;
        self::$bindList = $bind_list;

        self::queryExecute();

        return new static;
    }

    /**
     * 
     */
    public static function setSettings(array $settings)
    {
        self::$defaultSettings = array_merge(self::$defaultSettings, $settings);
        return new static;
    }

    /**
     * 
     */
    public static function queryExecute()
    {
        $placeholders   = self::$defaultSettings['placeholders'];
        $pdo_fetch_type = self::$defaultSettings['fetch_type'];
        $bindType       = self::$defaultSettings['bindType'];

        self::$conditions = array_merge(self::$conditions, self::$bindList);
    
        $stock_view = db::$dbpdo->prepare(self::$query, array(\PDO::ATTR_CURSOR => \PDO::CURSOR_SCROLL));
    
        if($placeholders == 'named') {
            foreach(self::$conditions as $bind_key => $bindValue) {
                if($bindType == 'bindParam') {
                    $stock_view->bindParam($bind_key, $bindValue);
                } 
                
                if($bindType == 'bindValue') {
                    $stock_view->bindValue($bind_key, $bindValue);
                }

            }
        
            $stock_view->execute();
        }
    
        if($placeholders == 'positional') {
            $stock_view->execute(self::$conditions);
        }
    
        self::$result = $stock_view->fetchAll($pdo_fetch_type);
    
        $stock_view->closeCursor();
        self::$query = null;
    }

    /**
     * 
     */
    public static function first()
    {
        if(count(self::$result) > 0) {
            self::$result = self::$result[0];
        }
        
        return new static;
    }

    /**
     * 
     */
    public static function columnName(string $columnName)
    {
        self::$result = self::$result[$columnName];

        return new static;
    }



    /**
     * @return array
     */
    public static function get():array
    {  
        return (array) self::$result;
    }
}
