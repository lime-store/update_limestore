// ctrl = false;

// $(document).key(function(){

//     console.log('ds');
// });

// $(document).keydown(function(event){
//     if(event.which=="17") {
//         ctrl = true;
//         ctrl_hotkey_init(ctrl);
//     }
// });

// $(document).keyup(function(event) {
//     if(event.which == '17') {
//         ctrl = false;
//         ctrl_hotkey_init(ctrl);
//     }
// });

// function ctrl_hotkey_init(ctrl) {
//     if(ctrl) {
//         $('.filter-hotkey-sort').addClass([
//             'stock-link-text-filter',
//             'get_item_by_filter'
//         ]);

        
//     } else {
//         $('.filter-hotkey-sort').removeClass([
//             'stock-link-text-filter',
//             'get_item_by_filter'
//         ]);        
//     }
// }