<?php

use core\classes\Cart\Payment;

header('Content-type: Application/json');


$total = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/modal/custom_modal/u_modal.twig' => [
            'modalController' => [
                'title' => "Kassa mədaxil", // Kassa məxaric
                'closeButtonClassList' => 'removeModal',
            ],
            'modalContent' => [
                'path' => '/component/cash-register/deposit-form.twig',
            ],
            'containerClassList' => 'small-modal',
            'paymentSelect' => [
                'main' => [
                    'class_list' => [
                        'init_element' => 'width-100 widget-fields',
                        'container' => ' widget-fields-container',
                        'input_parent' => 'width-100 input-dropdown-parent'
                    ]
                ],
                'input' => [
                    'label' => 'Ödəniş üsulu',
                    'labelClassList' => 'pos-relative transform-none',
                    'icon' => 'las la-wallet',
                    'class_list' => 'flex-auto form-input input-select area-button input-dropdown min-width-200',
                    'attribute' => [
                        'type' => 'button',
                    ]
                ],
                'list' => [
                    'class_list' => [
                        'container' => 'form-fields-autocomplete ',
                        'ul_list' => 'width-100 select-list unset-min-width',
                        'list_item_container' => '',
                        'list_item_link' => 'selectable-search-item area-closeable select-hidden-fields-input input-dropdown-auto-list-li'
                    ],
                    'default_first' => true,
                    'list_data' => Payment::getPaymentMethodList(),
                ],
                'hidden_input' => [
                    'class_list' => 'form-payment-method-id'
                ]
            ]
        ]
    ]
]);


$utils::abort([
    'res' => $total,
]);
