<?php

namespace core\classes\Inventory;

use core\classes\dbWrapper\db;
use core\classes\dbWrapper\queryBuilder;
use core\classes\dbWrapper\updateBuilder;

/**
 * Инвентаризация (sayim). Состоит из сессий (InventorySession) — каждая
 * закрывается отдельно и сразу же корректирует сток тех товаров, которые
 * в ней посчитали (через stock_adjustment_document / stock_adjustment_item).
 * Поэтому продажи между сессиями/днями не портят уже применённые корректировки.
 *
 * Инвентаризацию нельзя завершить, пока остаются товары со стоком > 0,
 * которые не посчитали ни в одной сессии (pendingMissingItems): пользователю
 * предлагается открыть новую сессию с такими товарами (counted = 0),
 * просканировать их, и только потом закрыть инвентаризацию.
 *
 * Товары с отрицательным стоком, которые не посчитали (и не исключили),
 * при закрытии доводятся до 0 автоматически (closeNegativeMissingItems):
 * они не блокируют закрытие, но сток корректируется и попадает в отчёт.
 *
 * Товар можно исключить из этой проверки через inventory_excluded_item
 * (excludeStock()) — предполагаю, что это для позиций, которые заведомо
 * не должны считаться недостачей (например, физически в пути). Если у вас
 * другое назначение этой таблицы — скажите, поправлю.
 */
class Inventory
{
    const STATUS_ACTIVE    = 'active';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';

    public static function create(string $title, int $userId, ?string $comment = null): array
    {
        db::insert('inventory', [
            [
                'title'      => $title,
                'status'     => self::STATUS_ACTIVE,
                'created_by' => $userId,
                'created_at' => date('Y-m-d H:i:s'),
                   'comment'    => $comment,
            ]
        ]);

        return self::find((int) db::$dbpdo->lastInsertId());
    }

    public static function all(): array
    {
        return queryBuilder::select('*')
        ->from('inventory')
        ->orderBy('created_at', 'DESC')
        ->execute()
        ->all();
    }

    public static function find(int $inventoryId): array
    {
        return queryBuilder::select('*')
        ->from('inventory')
        ->where('id', $inventoryId)
        ->execute()
        ->first()
        ->get();
    }

    public static function sessions(int $inventoryId): array
    {
        return queryBuilder::select('*')
        ->from('inventory_session')
        ->where('inventory_id', $inventoryId)
        ->orderBy('session_number', 'ASC')
        ->execute()
        ->all();
    }

    public static function cancel(int $inventoryId, int $userId, ?string $comment = null): bool
    {
        $inventory = self::find($inventoryId);

        if (empty($inventory)) {
            throw new \RuntimeException('Инвентаризация не найдена');
        }

        if ($inventory['status'] !== self::STATUS_ACTIVE) {
            throw new \RuntimeException('Отменить можно только активную инвентаризацию');
        }

        if (self::hasOpenSession($inventoryId)) {
            throw new \RuntimeException('Сначала закройте или отмените открытую сессию');
        }

        $update = updateBuilder::table('inventory')
        ->set('status', self::STATUS_CANCELLED)
        ->set('cancelled_by', $userId)
        ->set('cancelled_at', date('Y-m-d H:i:s'));

        if ($comment !== null) {
            $update->set('comment', $comment);
        }

        $update->where('id', $inventoryId)->execute();

        return true;
    }

    /**
     * Исключить товар из проверки "не сканировался" при закрытии инвентаризации
     */
    public static function excludeStock(int $inventoryId, int $stockId, int $userId): void
    {
        $exists = queryBuilder::select('id')
        ->from('inventory_excluded_item')
        ->where('inventory_id', $inventoryId)
        ->where('stock_id', $stockId)
        ->execute()
        ->first()
        ->get();

        if (!empty($exists)) {
            return;
        }

        db::insert('inventory_excluded_item', [
            [
                'inventory_id' => $inventoryId,
                'stock_id'     => $stockId,
                'created_by'   => $userId,
                'created_at'   => date('Y-m-d H:i:s'),
            ]
        ]);
    }

    public static function excludedStockIds(int $inventoryId): array
    {
        return queryBuilder::select('stock_id')
        ->from('inventory_excluded_item')
        ->where('inventory_id', $inventoryId)
        ->execute()
        ->pluck('stock_id');
    }

    /**
     * Товары, которые ещё не посчитаны ни в одной сессии этой инвентаризации
     * (и не исключены): stock_count > 0. Пока они есть — инвентаризацию
     * нельзя завершить: пользователю предлагается открыть новую сессию,
     * в которой эти товары уже лежат со значением counted = 0.
     */
    public static function pendingMissingItems(int $inventoryId): array
    {
        $countedStockIds = queryBuilder::select('DISTINCT isi.stock_id')
        ->from('inventory_session_item isi')
        ->innerJoin('inventory_session iss', 'isi.session_id = iss.id')
        ->where('iss.inventory_id', $inventoryId)
        ->execute()
        ->pluck('stock_id');

        $excludedStockIds = self::excludedStockIds($inventoryId);

        $skipStockIds = array_flip(array_map('intval', array_merge($countedStockIds, $excludedStockIds)));

        $allStockWithBalance = queryBuilder::select('stock_id, stock_name, stock_count, stock_first_price')
        ->from('stock_list')
        ->where('stock_count > 0')
        ->where('stock_visible = 0')
        ->execute()
        ->all();

        return array_values(array_filter($allStockWithBalance, function ($row) use ($skipStockIds) {
            return !isset($skipStockIds[(int) $row['stock_id']]);
        }));
    }

    public static function hasPendingMissingItems(int $inventoryId): bool
    {
        return !empty(self::pendingMissingItems($inventoryId));
    }

    /**
     * Закрыть инвентаризацию и вернуть итоговый отчёт.
     * Закрытие возможно только когда все товары со стоком > 0 посчитаны
     * (нет pendingMissingItems) и нет открытой сессии.
     */
    public static function close(int $inventoryId, int $userId): array
    {
        $inventory = self::find($inventoryId);

        if (empty($inventory)) {
            throw new \RuntimeException('Инвентаризация не найдена');
        }

        if ($inventory['status'] !== self::STATUS_ACTIVE) {
            throw new \RuntimeException('Инвентаризация уже закрыта или отменена');
        }

        if (self::hasOpenSession($inventoryId)) {
            throw new \RuntimeException('Сначала закройте открытую сессию, прежде чем завершать инвентаризацию');
        }

        if (self::hasPendingMissingItems($inventoryId)) {
            throw new \RuntimeException('Остались не посчитанные товары');
        }

        // товары с отрицательным стоком, которые не посчитали ни в одной
        // сессии (и не исключены), в pendingMissingItems не попадают
        // (stock_count > 0) — их сток доводим до 0 закрытой авто-сессией,
        // чтобы он не остался отрицательным и попал в итоговый отчёт
        self::closeNegativeMissingItems($inventoryId, $userId);

        updateBuilder::table('inventory')
        ->set('status', self::STATUS_COMPLETED)
        ->set('completed_by', $userId)
        ->set('completed_at', date('Y-m-d H:i:s'))
        ->where('id', $inventoryId)
        ->execute();

        return self::report($inventoryId);
    }

    /**
     * Авто-коррекция товаров с отрицательным стоком, которые не посчитали
     * ни в одной сессии и не исключили: сток доводится до 0 (тип surplus),
     * оформляется закрытой авто-сессией с stock_adjustment_document/items,
     * чтобы корректировка попала в отчёт и историю стока.
     */
    private static function closeNegativeMissingItems(int $inventoryId, int $userId): void
    {
        $countedStockIds = queryBuilder::select('DISTINCT isi.stock_id')
        ->from('inventory_session_item isi')
        ->innerJoin('inventory_session iss', 'isi.session_id = iss.id')
        ->where('iss.inventory_id', $inventoryId)
        ->execute()
        ->pluck('stock_id');

        $skipStockIds = array_flip(array_map('intval', array_merge($countedStockIds, self::excludedStockIds($inventoryId))));

        $negative = array_values(array_filter(
            queryBuilder::select('stock_id, stock_name, stock_count, stock_first_price')
            ->from('stock_list')
            ->where('stock_count < 0')
            ->where('stock_visible = 0')
            ->execute()
            ->all(),
            function ($row) use ($skipStockIds) {
                return !isset($skipStockIds[(int) $row['stock_id']]);
            }
        ));

        if (empty($negative)) {
            return;
        }

        db::beginTransaction();

        try {
            db::insert('inventory_session', [
                [
                    'inventory_id'   => $inventoryId,
                    'session_number' => InventorySession::nextSessionNumber($inventoryId),
                    'status'         => InventorySession::STATUS_CLOSED,
                    'created_by'     => $userId,
                    'created_at'     => date('Y-m-d H:i:s'),
                    'closed_by'      => $userId,
                    'closed_at'      => date('Y-m-d H:i:s'),
                    'comment'        => 'Avto-korreksiya: mənfi stok 0-a çatdırıldı',
                ]
            ]);
            $sessionId = (int) db::$dbpdo->lastInsertId();

            db::insert('stock_adjustment_document', [
                [
                    'inventory_id' => $inventoryId,
                    'session_id'   => $sessionId,
                    'status'       => 'applied',
                    'created_by'   => $userId,
                    'created_at'   => date('Y-m-d H:i:s'),
                    'applied_at'   => date('Y-m-d H:i:s'),
                ]
            ]);
            $adjustmentId = (int) db::$dbpdo->lastInsertId();

            $surplusQty = 0.0;
            $surplusAmt = 0.0;

            foreach ($negative as $row) {
                $before = (float) $row['stock_count'];
                $after  = 0.0;
                $diff   = $after - $before;
                $price  = (float) $row['stock_first_price'];
                $amount = round($diff * $price, 2);

                db::insert('stock_adjustment_item', [
                    [
                        'adjustment_id'       => $adjustmentId,
                        'stock_id'            => $row['stock_id'],
                        'quantity_before'     => $before,
                        'counted_quantity'    => $after,
                        'difference_quantity' => $diff,
                        'quantity_after'      => $after,
                        'price'               => $price,
                        'difference_amount'   => $amount,
                        'difference_type'     => 'surplus',
                    ]
                ]);

                updateBuilder::table('stock_list')
                ->set('stock_count', $after)
                ->where('stock_id', $row['stock_id'])
                ->execute();

                db::insert('log_product_stock_history', [
                    [
                        'product_id'      => $row['stock_id'],
                        'quantity_before' => $before,
                        'quantity_change' => $diff,
                        'quantity_after'  => $after,
                        'reference_type'  => 'inventory_session',
                        'reference_id'    => $sessionId,
                        'comment'         => 'Avto-korreksiya (mənfi stok)',
                        'user_id'         => $userId,
                        'created_at'      => date('Y-m-d H:i:s'),
                    ]
                ]);

                $surplusQty += $diff;
                $surplusAmt += $amount;
            }

            updateBuilder::table('stock_adjustment_document')
            ->set('total_surplus_quantity', $surplusQty)
            ->set('total_surplus_amount', round($surplusAmt, 2))
            ->set('final_difference_amount', round($surplusAmt, 2))
            ->where('id', $adjustmentId)
            ->execute();

            updateBuilder::table('inventory_session')
            ->set('adjustment_document_id', $adjustmentId)
            ->where('id', $sessionId)
            ->execute();

            db::commit();
        } catch (\Throwable $e) {
            db::rollBack();
            throw $e;
        }
    }

    /**
     * Итоговый отчёт: все позиции из stock_adjustment_item по всем сессиям
     * этой инвентаризации (включая авто-сессию недостачи/пересдачи), плюс
     * суммы по закупочной (stock_first_price, зафиксирована на момент
     * коррекции) и розничной (stock_second_price, берётся из текущего
     * stock_list — не хранится в adjustment-таблицах) цене.
     */
    public static function report(int $inventoryId): array
    {
        $inventory = self::find($inventoryId);

        if (empty($inventory)) {
            throw new \RuntimeException('Инвентаризация не найдена');
        }

        $rows = queryBuilder::select('
        ai.stock_id,
        ai.quantity_before,
        ai.counted_quantity,
        ai.difference_quantity,
        ai.price AS first_price,
        ai.difference_amount AS first_price_amount,
        ai.difference_type,
        ad.session_id,
        sl.stock_name,
        sl.barcode_article,
        sl.stock_second_price
        ')
        ->from('stock_adjustment_item ai')
        ->innerJoin('stock_adjustment_document ad', 'ai.adjustment_id = ad.id')
        ->innerJoin('stock_list sl', 'ai.stock_id = sl.stock_id AND sl.stock_visible = 0')
        ->where('ad.inventory_id', $inventoryId)
        ->orderBy('sl.stock_name', 'ASC')
        ->execute()
        ->all();

        $items = [];
        $totals = [
            'recounted'                 => 0,
            'shortage_count'            => 0,
            'surplus_count'             => 0,
            'shortage_sum_first_price'  => 0.0,
            'shortage_sum_second_price' => 0.0,
            'surplus_sum_first_price'   => 0.0,
            'surplus_sum_second_price'  => 0.0,
        ];

        foreach ($rows as $row) {
            $diffQty           = (float) $row['difference_quantity'];
            $secondPriceAmount = round($diffQty * (float) $row['stock_second_price'], 2);

            $items[] = [
                'stock_id'            => (int) $row['stock_id'],
                'stock_name'          => $row['stock_name'],
                'barcode'             => $row['barcode_article'],
                'session_id'          => (int) $row['session_id'],
                'system_count'        => (float) $row['quantity_before'],
                'counted_count'       => (float) $row['counted_quantity'],
                'diff'                => $diffQty,
                'difference_type'     => $row['difference_type'],
                'first_price_amount'  => (float) $row['first_price_amount'],
                'second_price_amount' => $secondPriceAmount,
            ];

            $totals['recounted']++;

            if ($row['difference_type'] === 'shortage') {
                $totals['shortage_count']++;
                $totals['shortage_sum_first_price']  += abs((float) $row['first_price_amount']);
                $totals['shortage_sum_second_price'] += abs($secondPriceAmount);
            } elseif ($row['difference_type'] === 'surplus') {
                $totals['surplus_count']++;
                $totals['surplus_sum_first_price']  += (float) $row['first_price_amount'];
                $totals['surplus_sum_second_price'] += $secondPriceAmount;
            }
        }

        $totals['shortage_sum_first_price']  = round($totals['shortage_sum_first_price'], 2);
        $totals['shortage_sum_second_price'] = round($totals['shortage_sum_second_price'], 2);
        $totals['surplus_sum_first_price']   = round($totals['surplus_sum_first_price'], 2);
        $totals['surplus_sum_second_price']  = round($totals['surplus_sum_second_price'], 2);

        // итоговый (финальный) результат инвентаризации: излишки минус недостача
        $totals['net_first_price']  = round($totals['surplus_sum_first_price'] - $totals['shortage_sum_first_price'], 2);
        $totals['net_second_price'] = round($totals['surplus_sum_second_price'] - $totals['shortage_sum_second_price'], 2);

        return [
            'inventory' => $inventory,
            'items'     => $items,
            'totals'    => $totals,
        ];
    }

    private static function hasOpenSession(int $inventoryId): bool
    {
        $open = queryBuilder::select('id')
        ->from('inventory_session')
        ->where('inventory_id', $inventoryId)
        ->where('status', InventorySession::STATUS_OPEN)
        ->execute()
        ->first()
        ->get();

        return !empty($open);
    }
}
