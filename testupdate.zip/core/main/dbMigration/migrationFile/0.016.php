<?php 
use Core\Classes\System\Migration;
use core\classes\dbWrapper\db;

$append_license_column_v0016 = [
    'token' => ' varchar(255) NOT NULL ',
];

Migration::hasTableColumnExist('licence', $append_license_column_v0016, function($notExistData) {
    if($notExistData) {
        Migration::alertTableColumn('licence', $notExistData);
    }
});


$add_function_settings_token_v0016 = [
    array(':sett_name' => 'appSync', 'sett_on' => '1'),
    array(':sett_name' => 'showPriceOnBarcodeLabel', 'sett_on' => '1')  
];

$settings_token_sql_v0016 = [
    'table_name' => 'function_settting',
    'col_list' => '*',
    'query' => [
        'base_query' => ' WHERE sett_name = :sett_name GROUP BY sett_id DESC'
    ],
    'bindList' => []
];

Migration::hasDataExist($settings_token_sql_v0016, $add_function_settings_token_v0016, function($notExistData) {
    if($notExistData) {
        Migration::insertMigrationData('function_settting', $notExistData);
    }
});

$setting_append_column_v0016 = [
    'title' => 'varchar(128) NOT NULL',
    'group' => 'varchar(64) NOT NULL',
];

// Migration::hasTableColumnExist('function_settting', $setting_append_column_v0016, function($notExistColumn) {
//     if($notExistColumn) {
//         Migration::alertTableColumn('function_settting', $notExistColumn);
//     }
// });