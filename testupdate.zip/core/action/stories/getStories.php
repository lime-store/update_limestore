<?php

use Core\Classes\Utils\Stories;
use Core\Classes\Utils\Utils;
$contentData = Stories::getStories();

// test
// $contentData = [
//     [
//         'message' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Consectetur dolores rerum tenetur delectus laboriosam error natus adipisci reprehenderit labore voluptatibus? Tempore quos voluptate numquam perferendis corrupti molestiae eos laborum sed.',
//         'type' => 'image',
//         'url' => 'http://localhost/assets/img/pattern/mountains-02.jpeg'
//     ]
// ];

$tpl = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/stories/stories-row.twig' => [
            'contentData' => $contentData
        ]
    ]
]);

Utils::abort([
    'res' => $tpl
]);
