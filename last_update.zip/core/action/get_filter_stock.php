<?php
require_once  $_SERVER['DOCUMENT_ROOT'].'/function.php';
//тип таблицы (terminal, stock, report и тд)
get_table_svervice_type();
//получем категорию товара
get_product_category();

$color_id 	  		= [];
$storage_id 	    = [];
$ram_id				= [];
$used_id 			= [];

if(isset($_GET['color_id'])) {
	$get_color_id		= $_GET['color_id'];
	$color_id  	= $get_color_id; 
	$c_id = implode("','", $color_id);
}

if(isset($_GET['storage_id'])) {
	$get_storage_id	    = $_GET['storage_id'];
	$storage_id = $get_storage_id;
	$s_id = implode(' AND ', $storage_id);
}

if(isset($_GET['ram_id'])) {
	$get_ram_id	    = $_GET['ram_id'];
	$ram_id = $get_ram_id;
	$r_id = implode("','", $ram_id);	
}
 
if(isset($_GET['used_id'])) {
	$get_used_id = $_GET['used_id'];
	$used_id = $get_used_id;
	$u_id =  implode("','", $used_id);
} 

$cur_tab = $_GET['tab_action'];
$prod_cat = $_GET['tab_category'];

//$type  	= $get_type;



// $c_id = implode(',', array_fill(0, count($color_id), '?'));
// $s_id = implode(', ', array_fill(0, count($storage_id), ' ? '));

$filter_prod = [];
$query = "SELECT * FROM user_control 
 		  LEFT JOIN stock_filter ON stock_filter.stock_filter_id != 0";
if(isset($get_color_id)) {
	$query .= " AND stock_filter.filter_color_id IN('".$c_id."')";
}	
if(isset($get_storage_id)) {
	$query .= " AND stock_filter.filter_storage_id = ".$s_id."  ";
}
if(isset($get_ram_id)) {
	$query .= " AND stock_filter.filter_ram_id IN('".$r_id."')";
}
if(isset($get_used_id)) {
	$query .= " AND stock_filter.filter_used_id IN('".$u_id."')";
}


$query .= " INNER JOIN stock_list 
			ON stock_list.stock_id = stock_filter.stock_id
			AND stock_list.stock_type = ?
			AND stock_list.stock_visible = 0
			AND stock_list.stock_count > 0 
		    GROUP BY stock_filter.stock_id DESC";
$get_product = $dbpdo->prepare($query);

$get_product->execute([$prod_cat]);
							
if($get_product->rowCount()>0) {	
	while($row = $get_product->fetch(PDO::FETCH_ASSOC))
		$filter_prod [] = $row;
		
	foreach ($filter_prod as $row) {
		$stock_id 				= $row['stock_id'];
		$stock_name 			= $row['stock_name'];
		$stock_imei 			= $row['stock_phone_imei'];
		$stock_first_price 		= $row['stock_first_price'];
		$stock_second_price 	= $row['stock_second_price'];
		$stock_return_status 	= $row['stock_return_status'];
		$stock_provider		 	= $row['stock_provider'];
		$stock_count		 	= $row['stock_count'];
		$stock_get_date 		 = $row['stock_get_fdate'];
		
		if($cur_tab == $terminal) {
			if($prod_cat == $product_phone) {
				$get_product_table = array( 'stock_id' 				=> 	$stock_id,
											'stock_name' 			=> 	$stock_name,
											'stock_phone_imei' 		=> 	$stock_imei,
											'stock_first_price' 	=> 	$stock_first_price, 
											'stock_second_price' 	=> 	$stock_second_price,
											'stock_return_status' 	=> 	$stock_return_status,
											'stock_provider'		=> 	$stock_provider, 
											'manat_image' 			=>  $manat_image,
											'stock_return_image' 	=>  $stock_return_image
										);

				get_terminal_phone_table_row($get_product_table);	

			}
			//проверяем товар на категорию акссесуар
			if($prod_cat == $product_akss) {
				$get_product_table = array( 'stock_id'  			=> 	$stock_id,
										    'stock_name' 			=> 	$stock_name,
										    'stock_first_price' 	=> 	$stock_first_price, 
										    'stock_second_price' 	=> 	$stock_second_price,
										    'stock_count'			=>  $stock_count,
										    'stock_provider'		=> 	$stock_provider, 
										    'manat_image' 			=>  $manat_image
										);
				get_terminal_akss_table_row($get_product_table);
			}
		}	

	}
}	
