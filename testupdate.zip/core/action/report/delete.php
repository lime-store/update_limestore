<?php

use core\classes\Privates\CashRegisters;
use core\classes\Privates\User;
use core\classes\Products;
use core\classes\Report;
use core\classes\Utils\Utils;

header('Content-type', 'Application/json');

$report = new \core\classes\Report;

if(!empty($_POST['report_id'])) {
	$reportId = $_POST['report_id'];
	
	$curReport 			= $report->getReportById($_POST['report_id']);
	$getProduct 		= Products::getProductById($curReport['stock_id']);
	$salesReport 		= $report->getReportByColumn('stock_order_report.transaction_id', $curReport['transaction_id']);
	$salesReport 		= $salesReport[0];
	$increasesQuantity 	= $curReport['order_stock_count'];	
	$transaction 		= $curReport['transaction_id'];

	if($curReport['has_editable'] == 0) {
		return Utils::errorAbort('Məhsul əvvəl geri qaytarıldığı üçün redaktə etmək mümkün deyil');
	}

	$report->deleteReport($_POST);

	if($curReport['stock_order_visible'] == 0) {
        Products::logProductStockChange(
            $getProduct['stock_id'],
            $getProduct['stock_count'],
            ($getProduct['stock_count'] + $increasesQuantity),
            'delete_sale',
			$transaction
        );

		CashRegisters::withdraw(
			($increasesQuantity * $curReport['order_stock_sprice']),
			'delete_sale',
			User::getCurrentUser('get_id'),
			$curReport['payment_method'],
			$transaction
		);
	}
	
	if($curReport['stock_order_visible'] == 3) {
        Products::logProductStockChange(
            $getProduct['stock_id'],
            $getProduct['stock_count'],
            ($getProduct['stock_count'] - $increasesQuantity),
            'delete_refaund',
			$transaction
        );
		CashRegisters::deposit(
			($increasesQuantity * $curReport['order_stock_sprice']),
			'delete_refaund',
			User::getCurrentUser('get_id'),
			$curReport['payment_method'],
			$transaction
		);


		Report::increaseRefaundQuantity([
			'report_id' => $salesReport['order_stock_id'],
			'refaund_quantity' => $increasesQuantity
		]);

		$refaundReport = $report->getReportByColumn('stock_order_report.transaction_id', $transaction, [3]);

		if($refaundReport == false) {
			$report->setReportEditableState($salesReport['order_stock_id'], true);
		}
	}

	echo $utils::successAbort('Ok');
} else {
	return Utils::errorAbort('Empty result');
}


