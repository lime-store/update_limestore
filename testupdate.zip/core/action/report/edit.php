<?php

use core\classes\Utils\Utils;

 header('Content-type', 'Application/json');

$report = new \core\classes\Report;

if(!empty($_POST['prepare'])) {
    $data = $_POST['prepare'];

    $getLastEditedOrder = $report::getReportById($_POST['oderId']);

    if($getLastEditedOrder['has_editable'] == 1) {
        $report->editReport($data, $getLastEditedOrder['transaction_id']);

        $getLastEditedOrder = $report::getReportById($_POST['oderId']);

        echo Utils::abort([
            'type' => 'success',
            'text' => 'Ok',
            'res' => [
                'edit-report-order-note' => $getLastEditedOrder['order_who_buy'],
                'product_second_price' => $getLastEditedOrder['order_stock_sprice'],
                'change_product_count' => $getLastEditedOrder['order_stock_count'],
                'edit-report-order-total' => $getLastEditedOrder['order_stock_total_price'],
                'res-report-order-profit' => $getLastEditedOrder['order_total_profit']
            ]
        ]);
    } else {
        echo Utils::abort([
            'type' => 'error',
            'text' => 'Məhsul əvvəl geri qaytarıldığı üçün redaktə etmək mümkün deyil',
        ]);
    }   

} else {
    $utils::errorAbort('Emprty');
}



