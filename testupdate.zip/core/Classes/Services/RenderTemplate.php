<?php 
namespace Core\Classes\Services;

use core\Classes\System\Constants;
use Core\Classes\Utils\Utils;
use Twig\Loader\FilesystemLoader;
use Twig\Environment;

class RenderTemplate
{
    public static $twig;

    /**
     * загружает новый шаблон
     */
    public function load($tpl)
    {
      return $this->initTwig()->load($tpl);
    }
    
    /**
     * Иницилизирует твиг
     */
    public static function initTwig()
    {
      $loader = new FilesystemLoader(Constants::ROOT_DIR.'/core/template/');
      $twig = new Environment($loader);  

      return $twig;
    } 

    /**
     * Иницилизирует твиг и выводит шаблон
     */
    public static function view(string $template, array $content = [])
    {
      
      //load lang pack
      $content['lang'] = [
        'buttons' => 'sadjas'
      ];

        return self::initTwig()->render($template, $content);
    }

}