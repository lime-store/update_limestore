<?php
use Core\Classes\Utils\Charts;
use Core\Classes\Report;
use Core\Classes\Utils\Utils;

header('Content-Type: application/json');

$Charts = new Charts;
$Report = new Report;
$orderBy = 'total_sales';
$interval = 5;
$interval = Utils::getDateMY();

if(!empty($_POST['date'])) {
    $interval = $_POST['date'];
}


$data = Report::getReportBySeller($interval);

$res = $Charts->getPieChartsData($data, 'user_name', $orderBy);

echo json_encode($res);