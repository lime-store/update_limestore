<?php 

	require_once 'include/header.php';

?>

<div class="main">
	<div class="main-wrapper" id="main_wrapper">
		<?php require_once 'core/main/options.php'; ?>
	</div>
</div>

