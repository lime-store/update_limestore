<?php

namespace core\classes\System;

use \core\classes\Privates\AccessManager;
use \core\classes\Utils\Utils;
use \core\classes\dbWrapper\db;
use \core\classes\Services\RenderTemplate;
use core\classes\Cart\Payment;
use core\classes\Products;

class Main
{
	use \core\classes\Traits\TabList,
	    \core\classes\Traits\TableHeaderList;

    private $utils;
    private $accessManager;

    public function __construct()
    {
        $this->utils = new utils;
        $this->accessManager = new AccessManager;
    }


        /** 
     * @param array $arr
     * $arr = [
     * 	'table_name' => 'stock_list',
     * 	'col_name'	 => 'stock_name',
     * 	'order'		 => ' date desc ',
     *  'query' 	 => 'WHERE date_query = 0'
     * ];
     * 
     * @return array|null
     * 
     * old function name get_report_date_list
     */
    public static function getReportDateList($data) 
    {
        $table_name 	= $data['table_name'];
        $col_name 		= $data['col_name'];
        $order 			= $data['order'];
        $query 			= $data['query'];
        $default 		= $data['default'];

        $res = db::select([
            'table_name' => $table_name,
            'col_list' => " DISTINCT $col_name",
            'query' => [
                'base_query' => $query,
                'body' => "",
                'joins' => "",
                'sort_by' => " ORDER BY $order "
            ],
            'bindList' => array()
            
        ])->get();
        
        
        $dd = array_column($res, $col_name);

        $dd['default'] = $default;

        return $dd;
    }

    /**
     * reference:  https://codepen.io/Markshall/pen/ExPxpYX
     */
    public static function getDatesGroupedByMonth(array $dateList = [])
    {
        $months = [
            '01' => 'Январь',
            '02' => 'Февраль',
            '03' => 'Март',
            '04' => 'Апрель',
            '05' => 'Май',
            '06' => 'Июнь',
            '07' => 'Июль',
            '08' => 'Август',
            '09' => 'Сентябрь',
            '10' => 'Октябрь',
            '11' => 'Ноябрь',
            '12' => 'Декабрь',
        ];

        $newDates = [];

        foreach ($dateList as $key => $dates) {
            $parts = explode('.', $dates);
            
            //its full date
            if(count($parts) === 3) {
                $monthName = $months[$parts[1]] ?? null;
                $years = $parts[2] ?? null;

                if($monthName && $years) {
                    if(!isset($newDates[$years])) {
                        $newDates[$years] = [];
                    }
    
                    if(!isset($newDates[$years][$monthName])) {
                        $newDates[$years][$monthName] = [];
                    }
    
                    if(isset($newDates[$years][$monthName])) {
                        $newDates[$years][$monthName][] = $dates;
                    }
                }                 
            }

            //its short dates
            if(count($parts) == 2) {
                $monthName = $months[$parts[0]] ?? null;
                $years = $parts[1] ?? null;


                if($monthName && $years) {
                    if(!isset($newDates[$years])) {
                        $newDates[$years] = [];
                    }
    
                    if(isset($newDates[$years])) {
                        $newDates[$years][$monthName] = $dates;
                    }
                }                  
            }           
        }
        
        // Utils::log($newDates);
        return $newDates;
    }

    /**
     * old function name page_tab_list
     * 
     * получаем массив для меню на главной странице и сайдбаре
     * 
     * @return array|null
     */
    public function getMenuList($page = null) 
    {
        // для версия выше 7.4+ return array_map(fn($post) => $post['tab'], page_data(false));
        
        //для версий ниже 7.4
        // return array_map(function($post) { return $post['tab']; }, page_data(false));
        Init::getInstance();

        $page_data = Init::initController();

        $result = [];

        foreach ($page_data as $key => $value) {
            if($value['tab']['is_main']) {
                AccessManager::hasAccessToPage($key, function($noAccess) use ($value, $key, &$result) {
                    if($noAccess == false) {
                        $result[$key] = $value['tab'];
                    }
                });
            }
        }

        return $result;
    }



    /**
     * в этой функцие описываем какие данные таблицы нужны для определённой категории
     *
     * пример вызова функции 
     * 	@param array $arr = array(
     * 	 'type' => 'phone/akss/..'         - обьязательное поле 
     * 	 'page => 'terminal || stock || report'  - обьязательное поле
     * 	'search' => array(                 - не обьязательное поле
     * 	 'param' =>  " AND stock_type = :stock_type AND stock_count > 0 " ,
     *		'bindList' => array(
     *			':stock_type' => $type
     *		)
     *	)
     * 	);
     * 
     * old function name render_data_template
    **/
    public static function prepareData(array $sql_data, array $config,  $settings = []) 
    {
        //страница
        $stock_list = db::select($sql_data, $settings)->get();

        return [
            'result'        => self::compareData($stock_list, $config),
            'base_result'   => AccessManager::cleanseInaccessibleData([ 'query' => $stock_list, 'access' => $config ], self::getTableHeaderList())
        ];
    }


    /**
     * 
     */
    public static function prepareCustomData($data_list, $config)
    {
        return [
            'result'        => self::compareData($data_list, $config),
            'base_result'   => AccessManager::cleanseInaccessibleData([ 'query' => $data_list, 'access' => $config ], self::getTableHeaderList())
        ];        
    }


    /**
     * 
     */
    public function getPrepareData($controllerIndex)
    {
        $data_page = Init::initController($controllerIndex);
        $page_config = $data_page['page_data_list'];

        return self::prepareData($data_page['sql'], $data_page['page_data_list']);
    }



    /**
     * тут адов говно код, который тем не менее работает. Переделать!
     */
    public static function compareData($stock_list, $page_data_list) 
    {
        $result 	= [];
        $th_list 	= [];
        $complete 	= [];
        $sort_key = false;
        $tr_class_list = '';
        $compare_data = [];

        $required = array_flip([
            'count',
            'remaining_quantity',
            'report_period_count',
            'change',
            'final_count',
            'before',
        ]);        

        $matches = [
            'refaund',
            'writeOff',
        ];

        if(array_key_exists('get_data', $page_data_list)) {
            $data_name = $page_data_list['get_data'];
        }



        if (array_key_exists('get_data@template', $page_data_list)) {
            $th = $page_data_list['get_data@template'];
        } else {

            $th = self::getTableHeaderList();
        }

  
        if(array_key_exists('sort_key', $page_data_list)) {
            $sort_key = $page_data_list['sort_key'];
        }


        foreach ($data_name as $td_list => $td_row) {
            $th_this		 	= $th[$td_list];

            $th_title 			    = $th_this['is_title'];
            $th_modify_class 	    = $th_this['modify_class'];
            $td_class 			    = $th_this['td_class']      ?: '';
            $default_link_class 	= $th_this['link_class']    ?: '';
            $data_sort 			    = $th_this['data_sort']     ?: '';
            $mark 				    = $th_this['mark']          ?: array();
            $hideIfNotValue 	    = isset($th_this['hideIfNotValue']) ?: false;


            if($th_title) {

                $th_list[] = [
                    'title' => $th_title,
                    'modify_class' => $th_modify_class
                ];

                $mass = [];
                foreach ($stock_list as $key => $row) {
                    $link_class = $default_link_class;

                    $operationClass = '';

                    if(array_key_exists('payment_method', $row)) {
                        $mark_text = '';
                        $mark_modify_class = '';
                        // ($row['payment_method'] == 1) ? $row['payment_method'] = ' ' : $row['payment_method'] = false;

                        if($td_row == 'payment_method') {
                            $tags_id = $row['tags_id'];

                            $mark_text = $row['title'];
                            $mark_modify_class = Payment::getPaymentMethodTags($base = false, $tags_id); 
                        
                            $row['payment_method'] = ' ';

                            $mark['mark_text'] = $mark_text;

                            $mark['mark_modify_class'] = $mark_modify_class['class_list'];
                        }
                    }


                    if(array_key_exists('discount', $row)) {
                        if($td_row == 'discount') {
                            if(empty($row['discount'])) {
                                $row['discount'] = '';
                            } else {
                                $mark['mark_text'] = $row['discount'].'%';
                                $mark['mark_modify_class'] = 'mark-tags mark-success width-100 height-100';
                                $row['discount'] = ' ';
                            }
                        }
                    }


                    if (array_key_exists('stock_order_visible', $row)) {
                        if ($row['stock_order_visible'] == 3) {
                            $tr_class_list = ' mark-danger ';
                        }
                    }

                    if(array_intersect($matches, $row)) {
                        $tr_class_list = ' mark-danger ';                        
                    }
                    
                    if(isset($required[$td_list])) {
                        if(array_key_exists('product_unit', $row)) {
                            $getUnit = Products::getUnit($row['product_unit'], 'id');
                            $mark['mark_text'] = $getUnit['name'];
                        }   
                    }

                    if(isset($mark['mark_operation_class']) && $mark['mark_operation_class'] == true) {
                        $operationClass = Utils::getOperationClass($row[$td_row]);
                    }
                 
                    if(array_key_exists($td_row, $row)) {
                        $data = $row[$td_row];                      
                    } else {
                        $data = null;
                    }                   

                    if(array_key_exists('mark_is_title', $th_this)) {
                        $data = ' ';
                        $mark['mark_text'] = $row[$td_row];
                    }


                    if($hideIfNotValue) {
                        if(is_null($row[$td_row]) || empty($row[$td_row])) {
                            $link_class = 'hide';
                        } else {
                            // $data = '';
                        }
                    }                         


                    // если в массиве есть id товара то добавляем его, если нет, то берем просто ключ 
                    // array_key_exists('stock_id', $row) ? $id = $row['stock_id'] : $id = $key;            
                    $sort_key ? $id = $row[$sort_key] : $id = $key;

                    $result[$key][$id]['data'][] = [
                        'data' 			=> $data,
                        'td_class' 		=> $td_class,
                        'link_class' 	=> "$link_class $operationClass",
                        'data_sort' 	=> $data_sort,
                        'mark'			=> $mark,
                    ];

                    $result[$key][$id]['tr'] = [
                        'class_list' => $tr_class_list
                    ];

                    $tr_class_list = '';
                }
            }

        }

        $complete = [
            'th' => $th_list,
            'td' => $result,
        ];

        return $complete;	
    }    


    /**
     * 
     */
    public function autocomplete($search_value, $controller_index, $optionClassList, $distinct = 'DISTINCT')
    {
		$th_list = self::getTableHeaderList();
		$controllerData = Init::getControllerData($controller_index);
		$allData = $controllerData->getAllData();
        $displayValue = '';

		$td_data = $allData['page_data_list'];
		
		$page_data_row =  $td_data['autocomplete'] ?? $td_data['get_data'];


        if(!empty($page_data_row[0])) {
            $displayValue = $page_data_row[0]['display'];
            $page_data_row = $page_data_row[0]['search'];
        }
		
		$sort_column = $td_data['sort_key'];

		$col_list 		= $controllerData->getColumnList();
		$table_name 	= $controllerData->getTableName();
		$base_query 	= $controllerData->getBaseQuery();
		$joins 			= $controllerData->getJoins();
		$sort_by 		= $controllerData->getSort();
		$bind_list 		= $controllerData->getBindList();


        foreach($page_data_row as $key => $col_name_prefix) {
            $th_this = $th_list[$key];
        
            $display = $displayValue ?: $col_name_prefix;
            $data_sort = $th_this['data_sort'];
        
            if($data_sort) {
                $bind_list['search'] = "%{$search_value}%";
        
                $search_array = [
                    'table_name' => $table_name,
                    'col_list'   => " $distinct $display, $sort_column ",			
                    'query' => [
                        'base_query' 	=> $base_query,			
                        'body' 			=> $controllerData->getBody(),
                        'joins' 		=> $joins . " WHERE $col_name_prefix LIKE :search ",
                        'sort_by' 	 	=> " GROUP BY $col_name_prefix, $sort_column ",
                    ],
                    'bindList' => $bind_list
                ];


                $d = db::select($search_array)->get();		

                
                foreach($d as $key) {
                    if(array_key_exists($display, $key)) {
                        echo RenderTemplate::view('/component/search/search_list.twig', [
                            'data' 				=>  $key[$display],
                            // 'link_modify_class' => 'get_item_by_filter search-item area-closeable selectable-search-item',
                            // 'link_modify_class' => !empty($allData['component_config']['search']['autocomplete']['autocomlete_class_list']) 
                            //                     ? $allData['component_config']['search']['autocomplete']['autocomlete_class_list'] 
                            //                     : $optionClassList,
                            'link_modify_class' => $optionClassList,
                            'data_sort_value' 	=> true,
                            'data_sort' 		=> $data_sort,
                            'data_id'			=> $key[$sort_column],
                            'mark'				=> ''
                        ]);		
                    }
                }
            }
        }        
    }

    /**
     * 
     */
    public static function hasRequiredUpdateFields(array $option, array $data, callable $onError)
    {
        foreach ($option as $optionName => $optionValue) {
            if (array_key_exists('require', $optionValue) && isset($data[$optionName]) && empty($data[$optionName])) {
                return $onError(true);
            }
        }

        return $onError(false);   
    }

    /**
     * 
     */
 	public static function hasRequiredInsertFields()
    {

    }
}