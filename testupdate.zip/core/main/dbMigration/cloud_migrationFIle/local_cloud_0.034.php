<?php 
use core\classes\System\Migration;

Migration::hasTableExist('local_sync_queue', function($noExist) {
    if($noExist) {
        Migration::createTable(
            "CREATE TABLE local_sync_queue (
            id INT PRIMARY KEY AUTO_INCREMENT,
            remote_task_id INT NOT NULL,
            status ENUM('pending','done','error') DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            synced_at DATETIME NULL,
            error_message TEXT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
        );
    }
});

$remote_id_column_033 = [
    'remote_id' => "int(11) DEFAULT NULL",
];

Migration::hasTableColumnExist('stock_list', $remote_id_column_033, function($notExistColumnName) {
    if($notExistColumnName) {
        Migration::alertTableColumn('stock_list', $notExistColumnName);
    }
});

Migration::hasTableColumnExist('stock_category', $remote_id_column_033, function($notExistColumnName) {
    if($notExistColumnName) {
        Migration::alertTableColumn('stock_category', $notExistColumnName);
    }
});

Migration::hasTableColumnExist('stock_provider', $remote_id_column_033, function($notExistColumnName) {
    if($notExistColumnName) {
        Migration::alertTableColumn('stock_provider', $notExistColumnName);
    }
});

Migration::hasTableColumnExist('stock_order_report', $remote_id_column_033, function($notExistColumnName) {
    if($notExistColumnName) {
        Migration::alertTableColumn('stock_order_report', $notExistColumnName);
    }
});

Migration::hasTableColumnExist('stock_barcode_list', $remote_id_column_033, function($notExistColumnName) {
    if($notExistColumnName) {
        Migration::alertTableColumn('stock_barcode_list', $notExistColumnName);
    }
});

Migration::hasTableColumnExist('user_control', ['remote_id' => "int(11) DEFAULT NULL", 'branch_id' => 'int(11) DEFAULT NULL'], function($notExistColumnName) {
    if($notExistColumnName) {
        Migration::alertTableColumn('user_control', $notExistColumnName);
    }
});
