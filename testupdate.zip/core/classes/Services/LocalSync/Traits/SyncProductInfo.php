<?php 
namespace core\classes\Services\LocalSync\Traits;
use core\classes\Services\Warehouse\Warehouse;
use core\classes\Products;
use core\classes\Utils\Utils;

trait SyncProductInfo
{
    private static function transferProduct($task)
    {
        $payload      = $task['payload'];
        $productInfo  = $payload['productInfo'];
        $transferInfo = $payload['transferInfo'];
        $categoryInfo = $payload['categoryInfo'] ?? [];
        $providerInfo = $payload['providerInfo'] ?? [];
        $barcodeInfo  = $payload['barcodeInfo']  ?? [];

        $remoteId     = $task['product_id'];

        $existingProduct = Products::getProductByRemoteId($remoteId);

        // товар уже добавлен в базу
        if (!empty($existingProduct)) {
            $localStockId = $existingProduct['stock_id'];;
            self::increaseStock($existingProduct, $transferInfo);
        } else {
            $localStockId = self::createProductFromTask($productInfo, $transferInfo, $remoteId)->stock_id;
            Products::logProductStockChange(
                $localStockId,
                0,
                (0 + $transferInfo['count']),
                'cloudTransfer'
            );
        }

        self::syncProductCategories($categoryInfo, $localStockId);

        self::syncProductProviders($providerInfo, $localStockId);

        self::syncProductBarcodes($barcodeInfo, $localStockId);
    } 

    /**
     * 
     */
    private static function updateProduct($task)
    {
        $product      = new Products;

        $payload      = $task['payload'];
        $productInfo  = $payload['productInfo'];
        $categoryInfo = $payload['categoryInfo'] ?? [];
        $providerInfo = $payload['providerInfo'] ?? [];
        $barcodeInfo  = $payload['barcodeInfo']  ?? [];

        $remoteId     = $task['product_id'];

        $existingProduct = Products::getProductByRemoteId($remoteId);
        $localStockId = $existingProduct['stock_id'];

        if(!empty($productInfo)) {
            $productInfo['upd_product_id'] = $localStockId;

            $product->editProduct($productInfo);

            self::syncProductCategories($categoryInfo, $localStockId);
            self::syncProductProviders($providerInfo, $localStockId);
            self::syncProductBarcodes($barcodeInfo, $localStockId);        
        }
    }

    /**
     * Увеличивает количество товара на складе
     */
    private static function increaseStock(array $existingProduct, array $transferInfo)
    {
        $warehouse = new Warehouse;

        $warehouse->handleProductArrival([
            [
                'id'          => $existingProduct['stock_id'],
                'count'       => $transferInfo['count'],
                'description' => $transferInfo['description'] ?? '',
            ]
        ], 'cloudTransfer');
    }   

    /**
     * Создаёт новый товар на основе данных из задачи. Возвращает локальный stock_id.
     */
    private static function createProductFromTask(array $productInfo, array $transferInfo, $remoteId)
    {
        $product = new Products;

        $preparedData = self::mapProductPayload($productInfo);

        $preparedData['add_stock_count'] = $transferInfo['count'];
        $preparedData['remote_id']       = $remoteId;

        $product->addProduct($preparedData);

        return (object) $product->getLastAddedProduct();
    }

    /**
     * 
     */
    private static function deleteProduct(array $data) 
    {
        $Product = new Products;

        $localId = $Product::getProductByRemoteId($data['product_id']);
        
        return $Product->deleteProduct($localId['stock_id']);
    }


    /**
     * Сопоставляет payload товара с локальными колонками БД
     */
    private static function mapProductPayload(array $productInfo): array
    {
        $productColList = Products::getCreateProductFillList();
        $mapped = [];

        foreach ($productColList as $colKey => $col) {
            if (array_key_exists($col['col_name'], $productInfo)) {
                $mapped[$colKey] = $productInfo[$col['col_name']];
            }
        }

        return $mapped;
    }    
}
