<?php
namespace core\classes\System;
use core\classes\Utils\Utils;
use core\classes\dbWrapper\db;

class dump
{
    //общяя папка с бэкапами
    public static $PATH_TO_BACKUP_DIR;

    // папка для бэкапа базы данных
    public static $PATH_TO_BACKUP_DATABASE_DIR;

    // автоматическое название бэкапа
    public static $BACKUP_DATABASE_NAME;

    public static $PATH_TO_MYSQL_FILE;

    public function __construct()
    {
        self::$PATH_TO_BACKUP_DIR = $_SERVER['DOCUMENT_ROOT'] . '/backup/';
        
        self::$PATH_TO_BACKUP_DATABASE_DIR = $_SERVER['DOCUMENT_ROOT'] . '/backup/db/';
        
        self::$BACKUP_DATABASE_NAME = 'db'.date('-(d.m.Y)');
        
        self::$PATH_TO_MYSQL_FILE = dirname($_SERVER['DOCUMENT_ROOT']) . '/mysql/bin/mysqldump';       
    }


    /**
     * old function ls_db_dump 
     */
    public static function dumpDatabase() 
    {
        Utils::checkAndCreateDir(self::$PATH_TO_BACKUP_DIR);
        Utils::checkAndCreateDir(self::$PATH_TO_BACKUP_DATABASE_DIR);
               
        $save_to = self::$PATH_TO_BACKUP_DATABASE_DIR . self::$BACKUP_DATABASE_NAME . '.sql';
        
        if(exec(self::$PATH_TO_MYSQL_FILE." --user=".DBUSER." --password=".DBPASS." --host=127.0.0.1 --port=3310 ".DBNAME." --result-file={$save_to} 2>&1", $output)) {
            return true;
        }
    }
    
    /**
     * Удаляет старые бэкапы (.sql и .zip), оставляя только $keep последних.
     * Файлы с одинаковым именем без расширения (db-(05.08.2026).sql и
     * db-(05.08.2026).zip) считаются одним "комплектом" и удаляются/остаются
     * ВМЕСТЕ — пара никогда не разрывается.
     *
     * @param string $dir        Папка с бэкапами
     * @param int    $keep       Сколько последних комплектов оставить
     * @param array  $extensions Какие расширения учитывать
     * @return array ['deleted' => [...], 'kept' => [...], 'error' => string|null]
     */
    public static function cleanupOldBackups(string $dir, int $keep = 5, array $extensions = ['sql', 'zip']): array
    {
        $dir = rtrim($dir, '/\\') . '/';

        if (!is_dir($dir)) {
            return ['deleted' => [], 'kept' => [], 'error' => "dir not found: {$dir}"];
        }

        $files = [];
        foreach ($extensions as $ext) {
            $found = glob($dir . '*.' . $ext);
            if ($found) {
                $files = array_merge($files, $found);
            }
        }
        $files = array_filter($files, 'is_file');

        if (empty($files)) {
            return ['deleted' => [], 'kept' => [], 'error' => null];
        }

        // Группируем по имени без расширения: .sql и .zip с одинаковым
        // базовым именем — это один комплект
        $groups = [];
        foreach ($files as $file) {
            $base = pathinfo($file, PATHINFO_FILENAME);
            $groups[$base][] = $file;
        }

        // Время комплекта = самое свежее mtime среди его файлов
        $groupTimes = [];
        foreach ($groups as $base => $groupFiles) {
            $groupTimes[$base] = max(array_map('filemtime', $groupFiles));
        }

        arsort($groupTimes); // от новых к старым
        $keepBases = array_slice(array_keys($groupTimes), 0, $keep);

        $deleted = [];
        $kept = [];
        foreach ($groups as $base => $groupFiles) {
            if (in_array($base, $keepBases, true)) {
                $kept = array_merge($kept, $groupFiles);
                continue;
            }
            foreach ($groupFiles as $file) {
                if (@unlink($file)) {
                    $deleted[] = $file;
                }
            }
        }

        return ['deleted' => $deleted, 'kept' => $kept, 'error' => null];
    }

/**
 * @deprecated
 */
 function is_db_backup_exists($db_dump_name, $db_dump_file_path) {
    $dump_name = $db_dump_file_path . $db_dump_name . '.sql';

    if(file_exists($dump_name)) {
        return true;
    } else {
        return false;
    }
 }   


}