<?php 
require_once  $_SERVER['DOCUMENT_ROOT'].'/function.php';



//верстка
?>
<div class="flilter_wrapper">
	<div class="filter-custom-section-block ls-custom-scrollbar">
		<div class="filter_wrapper_title">Filter</div> 
		<div class="filter-custom-list-wrp">
			<ul class="filter-custom-section-list">
				<li class="filter-check-header">
					<span class="filter-title">Reng</span>
				</li>

				<ul class="filter-check-list ls-custom-scrollbar" type="color">
					<?php ger_filter_param('color', ''); ?>
				</ul>							
			</ul>
			<ul class="filter-custom-section-list">
				<li class="filter-check-header">
					<span class="filter-title">Yaddas</span>
				</li>

				<ul class="filter-check-list ls-custom-scrollbar" type="storage">
					<?php ger_filter_param('storage', 'gb'); ?>
				</ul>							
			</ul>
			<ul class="filter-custom-section-list">
				<li class="filter-check-header">
					<span class="filter-title">Ram</span>
				</li>

				<ul class="filter-check-list ls-custom-scrollbar" type="ram">
					<?php ger_filter_param('ram', 'gb'); ?>
				</ul>							
			</ul>

			<ul class="filter-custom-section-list">
				<li class="filter-check-header">
					<span class="filter-title">Yeni/İslenmis</span>
				</li>

				<ul class="filter-check-list ls-custom-scrollbar" type="used">
					<?php ger_filter_param('used', ''); ?>
				</ul>							
			</ul>
												
		</div>
	</div>
</div>