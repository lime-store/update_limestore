<?php
use core\classes\System\Migration;
use core\classes\System\Settings;


if(!Settings::hasSettingsJSON('config', 'mysqlPort')) {
    Settings::appendSettingsJSON([
        'config' => [
            "mysqlPort" => 3306
        ]
    ]);
}