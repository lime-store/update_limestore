<?php

use core\classes\Privates\User;

if(!empty($_POST['branchId'])) {
    $branchId = $_POST['branchId'];

    return User::setUserBranch($branchId);
}