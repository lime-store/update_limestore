<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/function.js?v=<?php echo time(); ?>"></script>
<script src="js/print.min.js"></script>
<script src="js/ajax.js?v=<?php echo time(); ?>"></script>