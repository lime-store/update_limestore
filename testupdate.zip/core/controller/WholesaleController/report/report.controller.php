<?php

use Core\Classes\Cart\Payment;

$user = new \core\classes\privates\user;
$Payment = new Payment;

return [
    'tab' => [
        'is_main' => true,
        'title'		 		=> 'Topdan Hesabat',
        'icon'				=> [
            'img_big'		 	=> 'assets/img/svg/070-file hosting.svg',
            'img_small'			=> '',
            'modify_class' 		=> 'las las la-donate'
        ],
        'link'  			=> '/page/base.php',		
        'template_src'      => '/page/base_tpl.twig',
        'background_color'  => 'rgba(72, 61, 139, 0.1)',
        'tab' => array(
            'list' => [
                'tab_report_day_wholesale',
                'tab_report_phone_wholesale',
            ],
            'active' => 'tab_report_day_wholesale'			
        )
    ],			
    'sql' => [
        'table_name' => ' user_control ',
        'col_list'	=> '*, ROUND(sum(stock_order_report.order_stock_total_price), 3) as wholesale_order, 
                           ROUND(sum(stock_order_report.order_total_profit), 3) as wholesale_profit',

        'query' => array(
            'base_query' =>  " 
                    INNER JOIN stock_order_report ON stock_order_report.stock_order_visible IN (0, 3)

                    LEFT JOIN customer ON customer.id != 0

                    INNER JOIN wholesale_transaction ON wholesale_transaction.transaction_id = stock_order_report.transaction_id
                        AND wholesale_transaction.customer_id = customer.id
            ",
            'body' =>  "  AND stock_order_report.order_stock_count > 0
                          AND user_control.user_id = stock_order_report.sales_man
                          AND stock_order_report.reportType = 'WHOLESALE'
                            ",
            "joins" => " ",		
            'sort_by' => " GROUP BY stock_order_report.transaction_id DESC
                           ORDER BY stock_order_report.order_stock_id DESC",
        ),
        'bindList' => array(
        )        
            
    ],
    'page_data_list' => [
        'sort_key' => 'order_stock_id',
        'get_data' => [
            'report_order_id'	    => 'order_stock_id',
            // 'sales_time'        => 'sales_time',
            'sales_date'  		    => 'order_date',
            'report_order_date'		=> 'order_my_date',            
            'wholesale_customer_name' => 'name',
            'wholesale_total_order' => 'wholesale_order',
            'report_profit'         => 'wholesale_profit',
            'wholesale_show_order'	=> null,
            'wholesale_transaction_id'  => 'transaction_id'

        ],
        'table_total_list'	=> [
            'wholesale_order',
            'wholesale_refaund',
            'wholesale_final_order',
            'wholesale_profit'

        ],
        'stats_card' => [
            'order_turnover_wholesale',
            'order_profit_wholesale',
            'order_expense_wholesale',
            'order_margin_wholesale',
            // 'order_count',
        ],
        'modal' => [
            'template_block' => 'report_return',
            'modal_fields' => array(
                'user' => [
                    'db' 			=> false, 
                    'custom_data' 	=> $user->getCurrentUser('get_id'), 
                    'premission' 	=> true
                ],
                'report_order_id' => [
                    'db' => 'order_stock_id',
                    'custom_data' => false,
                    'premission' => true
                ],
                'info_product_name' => [
                    'db' => 'stock_name',
                    'custom_data' => false,
                    'premission' => true
                ],
                'info_product_description' => [
                    'db' => 'stock_phone_imei',
                    'custom_data' => false,
                    'premission' => true
                ],
                'report_change_tags' => [
                    'db' => 'id',
                    'custom_data' => $Payment->getPaymentMethodTags(true),
                    'premission' => true
                ],
                'report_order_note' => [
                    'db' => 'order_who_buy',
                    'custom_data' => false,
                    'premission' => true
                ],

                'report_edit_order_count' => [
                    'db' => 'order_stock_count',
                    'custom_data' => false,
                    'premission' => true
                ],
                'report_edit_price' => [
                    'db' => 'order_stock_sprice',
                    'custom_data' => false,
                    'premission' => true
                ],
                'search_by_transaction_id' => [
                    'db' => 'transaction_id',
                    'custom_data' => false,
                    'premission' => true
                ],
                'save_report_change' => [
                    'db' => false,
                    'custom_data' => false,
                    'premission' => true
                ],

                'report_refaund_btn' => [
                    'db' => false,
                    'custom_data' => false,
                    'premission' => true
                ],
                'report_delete_btn' => [
                    'db' => false,
                    'custom_data' => false,
                    'premission' => true
                ]                
            )
        ],
        'filter_fields' => [
        ],
    ]
];