<?php 
require_once  $_SERVER['DOCUMENT_ROOT'].'/function.php';
require_once  $_SERVER['DOCUMENT_ROOT'].'/vendor/autoload.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/core/function/update.function.php';

is_check_new_version();