<?php
namespace Core\Classes\Services;

use core\classes\dbWrapper\db;

class Notify 
{
    /**
     * 
     */
    public static function getNotifyList()
    {
        return db::select([
            'table_name' => 'ls_notify',
            'col_list' => '*',
            'query' => [
                'sort_by' => 'ORDER BY notify_id DESC',
                'limit' => ' LIMIT 10 '
            ]
        ])->get();
    }


    /**
     * 
     */
    public static function getNotifyListByType()
    {

    }

    /**
     * @param array $data = [
     *  text,
     *  type,
     *  id
     * ]
     */
    public static function addNotify(array $data = [])
    {
        db::insert('ls_notify', [
            [
                'notify_text' => $data['text'],
                'notify_type' => $data['type'],
                'notify_date' => date('d.m.Y'),
                'custom_id' => $data['id'] ?? null
            ]
        ]);
    }


    /**
     * 
     */
    public static function getLastAddedNotify()
    {
       return db::select([
            'table_name' => 'ls_notify',
            'col_list' => '*',
            'query' => [
                'sort_by' => ' GROUP BY notify_id DESC ORDER BY notify_id DESC ',
                'limit' => ' LIMIT 1 '
            ]
        ])->first()->get();
    }


    /**
     * 
     */
    public static function hasUnreadableNotification()
    {
        $data = db::select([
            'table_name' => 'ls_notify',
            'col_list' => '*',
            'query' => [
                'body' => ' WHERE notify_state = 1 ',
                'sort_by' => ' ORDER BY notify_id DESC '
            ]
        ])->get();

        return $data ? true : false; 
    }

    /**
     * 
     */
    public static function resetNotifyState()
    {
        $option = [
            'before' => ' UPDATE ls_notify SET ',
            'after' => ' notify_state = 0 ',
            'bind_list' => []
        ];
        db::update($option, []);
    }

    /**
     * 
     */
    public static function getNotifyById(int $id)
    {
        return db::select([
            'table_name' => 'ls_notify',
            'col_list' => '*',
            'query' => [
                'body' => ' WHERE notify_id = :id '
            ],
            'bindList' => [
                'id' => $id
            ]
        ])->first()->get();
    }   
}