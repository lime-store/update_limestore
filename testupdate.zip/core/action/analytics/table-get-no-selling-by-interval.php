<?php
use Core\Classes\Report;
use Core\Classes\System\Init;
use Core\Classes\Utils\Utils;

header('Content-Type: application/json');

$Report = new Report;

$date = 3;

$get_page = $init->initController('analytics');

$page_config = $get_page['page_data_list'];

if(!empty($_POST['date'])) {
    $date = $_POST['date'];
}

$data = Report::getNoSalesProductsOfInterval($date);



$table = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_row.twig' => [
            'table' => $main->compareData($data, [
                'get_data' => [
                    'id' 				=> 'stock_id',
                    'name'			 	=> 'stock_name',
                    'description' 		=> 'stock_phone_imei',
                    'first_price'		=> 'stock_first_price',
                    'second_price' 		=> 'stock_second_price',
                    'count'				=> 'stock_count',
                    'stock_barcode'		=> 'barcode_value',
                ]                
            ]),
            'table_tab' => 'analytics',
            'table_type' => ''       
        ]
    ]
]);

return $utils::abort([
    'table' => $table
]);