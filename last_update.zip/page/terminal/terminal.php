<?php
	require_once '../../function.php';
	//Показывать товары которые находться в базе больше 15 дней 
	// settShowOldProduct();

	//выводим заголовок страницы
	tab_page_header('satış');

	//блок для принта чека
	printModal();
	//пути к категориям
	get_product_root_dir();	

	//выводим перекючения вкладок 
	getCurrentTab($terminal_phone_link, $terminal_akss_link); 

	//абсолютный пусть к файлам
	root_dir();


	//модальное окно успешно выполнено функция
	success_done();
	//модальное коно не выполнено функция
	fail_notify();

?>


<div class="terminal_main">
	<?php 
		require_once GET_ROOT_DIRS. $terminal_phone_link;	
	?>
</div>