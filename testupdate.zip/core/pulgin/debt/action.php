<?php 
require_once $_SERVER['DOCMNET_ROOT'].'/function.php';

//шаблоны
ls_include_tpl();


if(isset($_POST['customer_id'])) {
//here satr action 
	//customer_id
	$cust_id = trim($_POST['customer_id']);

	if(isset($_POST['get_customer_table'])) { 


	}
}








