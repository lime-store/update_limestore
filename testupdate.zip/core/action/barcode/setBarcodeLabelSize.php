<?php
use core\classes\System\Settings;
use core\classes\Utils\Utils;

if(!empty($_POST['width'])) {
    Settings::saveSettingsJSON([
        'stickerWidth' => $_POST['width']
    ]);
}

if(!empty($_POST['height'])) {
    Settings::saveSettingsJSON([
        'stickerHeight' => $_POST['height']
    ]);
}