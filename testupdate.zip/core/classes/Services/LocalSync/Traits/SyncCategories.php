<?php

namespace core\classes\Services\LocalSync\Traits;
use core\classes\Services\Category;
use core\classes\dbWrapper\db;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\dbWrapper\updateBuilder as ub;
use core\classes\Products;
use core\classes\Utils\Utils;
use core\classes\Services\BaseService;

trait SyncCategories
{
    /**
     * Синхронизирует категории товара: добавляет новые связи, убирает лишние,
     * не трогает те, что совпадают.
     */
    private static function syncProductCategories(array $categories, int $localStockId): void
    {
        $currentRemoteIds = self::getCurrentCategoryRemoteIds($localStockId);
        $newRemoteIds = array_column($categories, 'category_id');

        $toAddIds = array_diff($newRemoteIds, $currentRemoteIds);
        $toRemoveIds = array_diff($currentRemoteIds, $newRemoteIds);

        // Добавляем новые
        foreach ($categories as $category) {
            if (in_array($category['category_id'], $toAddIds)) {
                $localCategoryId = self::findOrCreateCategory($category);
                self::linkProductToCategory($localCategoryId, $localStockId);
            }
        }

        // Убираем лишние
        foreach ($toRemoveIds as $remoteId) {
            self::unlinkCategoryByRemoteId($remoteId, $localStockId);
        }
    }

    /**
     * Текущие remote_id категорий, привязанных к товару
     */
    private static function getCurrentCategoryRemoteIds(int $localStockId): array
    {
        $rows = qb::select('sc.remote_id')
            ->from('products_category_list pcl')
            ->join('stock_category sc ON sc.category_id = pcl.id_from_category')
            ->where('pcl.id_from_stock = :stock_id')
            ->bindList([':stock_id' => $localStockId])
            ->execute()
            ->get();

        return array_column($rows ?: [], 'remote_id');
    }

    /**
     * Удаляет связь товара с категорией по remote_id категории
     */
    private static function unlinkCategoryByRemoteId(int $remoteCategoryId, int $localStockId): void
    {
        $category = qb::select('category_id')
            ->from('stock_category')
            ->where('remote_id = :remote_id')
            ->bindList([':remote_id' => $remoteCategoryId])
            ->execute()
            ->first()
            ->get();

        if (empty($category)) {
            return; // такой категории и так нет локально — нечего убирать
        }

        db::delete([
            [
                'table_name' => 'products_category_list',
                'where' => ' id_from_category = :cat_id AND id_from_stock = :stock_id ',
                'bindList' => [
                    'cat_id'   => $category['category_id'],
                    'stock_id' => $localStockId,
                ]
            ]
        ]);
    }

    /**
     * Привязывает категорию к товару (если связки ещё нет)
     */
    private static function linkProductToCategory(int $localCategoryId, int $localStockId): void
    {
        $exists = qb::select('id')
            ->from('products_category_list')
            ->where('id_from_category = :cat_id AND id_from_stock = :stock_id')
            ->bindList([
                ':cat_id'   => $localCategoryId,
                ':stock_id' => $localStockId,
            ])
            ->execute()
            ->first()
            ->get();

        if (!empty($exists)) {
            return;
        }

        db::insert('products_category_list', [
            [
                'id_from_category' => $localCategoryId,
                'id_from_stock'    => $localStockId,
            ]
        ]);
    }

    /**
     * Находит локальную категорию по remote_id, либо создаёт новую
     */
    private static function findOrCreateCategory(array $categoryInfo)
    {
        $category = new Category;
        $remoteCategoryId = $categoryInfo['category_id'];

        $existing = qb::select('category_id')
            ->from('stock_category')
            ->where('remote_id = :remote_id')
            ->bindList([':remote_id' => $remoteCategoryId])
            ->execute()
            ->first()
            ->get();

        if (!empty($existing)) {
            return $existing['category_id'];
        }

        db::insert('stock_category', [
            [
                'category_name' => $categoryInfo['category_name'],
                'visible'       => $categoryInfo['visible'] ?? 'visible',
                'remote_id'     => $remoteCategoryId,
            ]
        ]);

        return $category->getLastAddedCategory()['category_id'];
    }


    /**
     * 
     */
    public static function editCategory(array $task)
    {
        $categoryInfo = $task['payload']['categoryInfo'];

        if (!empty($categoryInfo)) {
            ub::table('stock_category')
                ->set('category_name', $categoryInfo['category_name'])
                ->set('visible', $categoryInfo['visible'])
                ->where('remote_id', $categoryInfo['category_id'])
                ->execute();
        }
    }

    /**
     * 
     */
    public static function deleteCategory(array $task)
    {
        $categoryInfo = $task['payload']['categoryInfo'];

        if (!empty($categoryInfo)) {
            $localCategoryId = qb::select('*')
                                    ->from('stock_category')
                                    ->where('remote_id', $categoryInfo['category_id'])
                                    ->first()
                                    ->columnName('category_id')
                                    ->get();
                                    
            if(!empty($localCategoryId)) {
                $category = new Category;
                $category->deleteCategory($localCategoryId);
            }
        }       
    }
}
