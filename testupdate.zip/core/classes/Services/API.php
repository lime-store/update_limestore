<?php

namespace core\classes\Services;

use GuzzleHttp\Client;

class API
{
    /**
     * @param string $uri
     * @param array $params [
     *     'token'   => string,
     *     'type'    => 'GET'|'POST'|'PUT'|'DELETE',
     *     'headers' => array,
     *     'body'    => array,
     *     'timeout' => int (seconds, optional)
     * ]
     * @return array ['ok' => bool, 'status' => int, 'data' => array|null, 'error' => string|null]
     */
    public static function send(string $uri, array $params = []): array
    {
        $client = new Client();

        $headers = array_merge(
            ['Accept' => 'application/json'],
            $params['headers'] ?? []
        );

        if (isset($params['token'])) {
            $headers['Authorization'] = 'Bearer ' . $params['token'];
        }

        $options = [
            'headers' => $headers,
            'timeout' => $params['timeout'] ?? 10,
        ];

        if (isset($params['body'])) {
            $headers['Content-Type'] = 'application/json';
            $options['headers'] = $headers;
            $options['body'] = json_encode($params['body']);
        }

        $method = strtoupper($params['type'] ?? 'GET');

        try {
            $response = $client->request($method, $uri, $options);

            return [
                'ok'     => true,
                'status' => $response->getStatusCode(),
                'data'   => json_decode($response->getBody()->getContents(), true),
                'error'  => null,
            ];
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            $status = $e->getResponse()->getStatusCode() ?? 0;
            $body   = $e->getResponse()
                ? json_decode($e->getResponse()->getBody()->getContents(), true)
                : null;

            return [
                'ok'     => false,
                'status' => $status,
                'data'   => $body,
                'error'  => $body['error'] ?? $e->getMessage(),
            ];
        }
    }
}
