<div class="report_stast_card_block ls-custom-scrollbar">
	<div class="report_stats_header h1">Статистика за <span class="mark stats-date" data-cur-date="<?php echo date("m.Y"); ?>"></span></div>
	<div class="stas_wrapper">
		<ul class="stas_crad_list">									
		</ul>	
	</div>
</div>	