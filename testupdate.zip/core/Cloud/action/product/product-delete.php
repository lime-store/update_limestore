<?php

use core\Cloud\classes\Sync\CloudSyncQueue;

if(!empty($_POST['productId'])) {
    $productId = $_POST['productId'];

    CloudSyncQueue::deleteProduct($productId);
}