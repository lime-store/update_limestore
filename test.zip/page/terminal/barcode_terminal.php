

<div class="list" style="display: none;">
	<div class="wrapper">
		<div class="barcode_wrapper_table-list">
			<div class="barcode_product_list">
				<table>
					<thead>
						<tr>
							<th class="th_w60">ID</th>
							<th class="th_w250">Malın adı</th>
							<th class="th_w120">Qiymət</th>
							<th class="th_w120">Sayı</th>
					    </tr>
					</thead>
					<tbody class="bc_product_table">
						
					</tbody>
				</table>
				<button class="send_arry">Send</button>
			</div>
		</div>
	</div>
</div>