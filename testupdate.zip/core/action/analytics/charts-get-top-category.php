<?php
use core\classes\Utils\Charts;
use core\classes\Report;
use core\classes\Utils\Utils;

header('Content-Type: application/json');

$Charts = new Charts;
$Report = new Report;
$orderBy = 'total_profit';
$interval = 3;

if(!empty($_POST['date'])) {
    $interval = $_POST['date'];
}


$data = Report::getTopSellingCategoryByInterval($interval);

$res = $Charts->getPieChartsData($data, 'category_name', $orderBy);

echo json_encode($res);