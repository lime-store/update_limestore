<?php

use core\classes\Privates\AccessManager;

header('Content-Type: application/json');

$Charts = new \core\classes\Utils\Charts;

$data = AccessManager::isDataAvailable('th_total_circ_money') == false ?: $Charts->getReportChartList();
$profit = AccessManager::isDataAvailable('th_profit') == false ?: $Charts->getReportChartListProfit();

echo json_encode(['turnover' => $data, 'profit' => $profit]);