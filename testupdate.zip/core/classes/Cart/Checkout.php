<?php 

namespace core\classes\Cart;


use \core\classes\dbWrapper\db;
use \core\classes\Products;
use \core\classes\Report;
use \core\classes\Utils\Utils;

class Checkout 
{


    /**
     * @param array $orderData
     * 
     * $orderData = [
     *  'ProductsData' => $stock_row, - данные товара
     *  'id'           => $id,        - id товара
     *  'order_price'  => $order_price, - цена заказа
     *  'order_count'  => $order_count, - количество
     *  'description'  => $description - описание
     *  'payment_method' => $payment_method
     * ];
     */
    public static function checkoutOrder(array $orderData) 
    {
        $res = self::prepareOrderData($orderData);

        self::addOrder($res);

        Products::updateStockAfterSale(array(
            [
                'stock_id' => $orderData['id'],
                'product_count' => $orderData['order_count']
            ]
        ));
    }

    public static function addWholesaleTransaction($data)
    {
        return db::insert('wholesale_transaction', [
            $data
        ]);
    }


    public static function addOrder($res)
    {
        return Report::addReport($res);
    }


    public static function sumCost($price, $count) 
    {
        return $price * $count;
    }

    public static function sumOrder($orderPrice, $orderSum)
    {
        $res = $orderPrice * $orderSum;

        // if($discount) {
        //     $discountSum = $res * $discount / 100;

        //     $res = $res - $discountSum;
        // }

        
        return $res;
    }

    public static function sumProfit($orderSum, $costSum) 
    {
        return $orderSum - $costSum;
    }


    public static function prepareOrderData($orderData)
    {
        $ProductsData           = $orderData['ProductsData'];
        $order_count            = $orderData['order_count'];
        $order_price            = $orderData['order_price'];
        $description            = $orderData['description'];
        $payment_method         = $orderData['payment_method'];
        $sales_man              = $orderData['sales_man'];
        $transaction_id         = $orderData['transaction_id'];
        $id                     = $orderData['id'];
        $reportType             = $orderData['reportType'];
        $discount               = $orderData['discount'];
        $first_price            = $ProductsData['stock_first_price']; // себестоимость товара
        $customer_id            = $orderData['customer_id'];
        $cashbackAmount         = $orderData['cashback_amount'];

        if($discount) {
            $discountSum = $order_price * $discount / 100;

            $order_price = $order_price - $discountSum;
        }

        if($cashbackAmount) {
            $order_price = $order_price - $cashbackAmount;
        }

        // в переменную заносим значение себестоимость товара умноженное на количество в заказе
        $total_profit   = self::sumCost($first_price, $order_count);

        // в переменную заносим значение цена указанная в заказе на количество
        $order_sum      = self::sumOrder($order_price, $order_count);
        
        // высчитываем прыбыль
        $profit         = self::sumProfit($order_sum, $total_profit);

        
        // готовим данные для добавления в таблицу бд
        $stock_data[$id] = [
            'stock_id'                  => $id,
            'order_stock_name'          => $ProductsData['stock_name'],
            'order_stock_imei'          => $ProductsData['stock_phone_imei'],
            'order_who_buy'             => $description,
            'order_stock_count'         => $order_count,
            'order_stock_sprice'        => $order_price,
            'order_stock_total_price'   => $order_sum,
            'order_total_profit'        => $profit,
            'order_date'                => Utils::getDateDMY(),
            'order_my_date'             => Utils::getDateMY(),
            'order_real_time'           => date('Y-m-d'),
            'payment_method'            => $payment_method,
            'sales_man'                 => $sales_man,
            'transaction_id'            => $transaction_id,
            'max_refaund_quantity'      => $order_count,
            'reportType'                => $reportType,
            'discount'                  => $discount,
            'customer_id'               => $customer_id,
        ];        


        return $stock_data;
    }

    public static function validateOrder($row)
    {
        if(empty($row['id']) || !isset($row['id'])) throw new \Exception('ID not found');
        
        if(empty($row['count']) || !isset($row['count']) || $row['count'] <= 0)   throw new \Exception('Заполните количество товара');

        if(empty($row['price']) || !isset($row['price']))   throw new \Exception('Заполните цену товара');
    }

}