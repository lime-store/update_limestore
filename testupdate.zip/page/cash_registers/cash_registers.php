<?php
$data_page = $init->initController($page);

$page_config = $data_page['page_data_list'];

// $table_result = $main->prepareData($data_page['sql'], $data_page['page_data_list']);	

use core\classes\Cart\Payment;
use core\classes\Privates\CashRegisters;
use core\classes\System\Main;
use core\classes\Utils\Utils;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\Services\BaseService;

$list = CashRegisters::getCashRegisters();
$list = Utils::formatReferenceList($list, 'amount_change', 'type');

$table_result = Main::compareData($list, $page_config);


$report_date_list = qb::select('DISTINCT DATE(created_at) AS date_only')
	->from('cash_registers')
	->orderBy('date_only', 'DESC')
	->get();

$paymentMethodList = Payment::getPaymentMethodList();



array_unshift($report_date_list, [
	'date_only' => BaseService::UTILS_VALUES['general'],
]);

array_unshift($paymentMethodList, [
	'custom_value' => BaseService::UTILS_VALUES['general'],
	'custom_data_id' => 0,
]);

echo $Render->view('/component/inner_container.twig', [
	'renderComponent' => [
		'/component/pulgin/stats_card/stats_card_container.twig' => [
			'date_type' => 'cash-register-day',
		],
		'/component/related_component/include_widget.twig' => [
			'/component/include_once_component.twig' => [
				'includs' => [
					'date-picker' => [
						'/component/buttons/select/select-button.twig' => [
							'main' => [
								'class_list' => [
									'init_element' => ' widget-fields',
									'container' => ' widget-fields-container',
									'input_parent' => 'width-100 input-dropdown-parent'
								]
							],
							'input' => [
								'label' => 'Tarix',
								'icon' => 'las la-calendar-alt',
								'class_list' => 'form-input input-select area-button input-dropdown min-width-200 filter-cash-register-date',
								'attribute' => [
									'type' => 'button',
									// 'value' => 'Filial',
									// 'placeholder' => 'Some'
								]
							],
							'list' => [
								'class_list' => [
									'container' => 'form-fields-autocomplete ',
									'ul_list' => 'width-100 select-list unset-min-width',
									'list_item_container' => '',
									'list_item_link' => 'filter-cash-regiser selectable-search-item area-closeable select-hidden-fields-input input-dropdown-auto-list-li'
								],
								'default_first' => true,
								'list_data' => Utils::toDropdownItems($report_date_list, false, 'date_only'),
							],
							'hidden_input' => [
								'class_list' => ''
							]
						],
					],
					'payment-method' => [
						'/component/buttons/select/select-button.twig' => [
							'main' => [
								'class_list' => [
									'init_element' => ' widget-fields',
									'container' => ' widget-fields-container',
									'input_parent' => 'width-100 input-dropdown-parent'
								]
							],
							'input' => [
								'label' => 'Ödəniş üsulu',
								'icon' => 'las la-wallet',
								'class_list' => 'form-input input-select area-button input-dropdown min-width-200',
								'attribute' => [
									'type' => 'button',
									// 'value' => 'Filial',
									// 'placeholder' => 'Some'
								]
							],
							'list' => [
								'class_list' => [
									'container' => 'form-fields-autocomplete ',
									'ul_list' => 'width-100 select-list unset-min-width',
									'list_item_container' => '',
									'list_item_link' => 'filter-cash-regiser selectable-search-item area-closeable select-hidden-fields-input input-dropdown-auto-list-li'
								],
								'default_first' => true,
								'list_data' => $paymentMethodList,
							],
							'hidden_input' => [
								'class_list' => 'filter-cash-register-payment-method'
							]
						],
					],
					'deposit' => [
						'/component/parts/input.twig' => [
							'containerClassList' => 'height-auto',
							'inputClassList' => 'input btn-input btn-success width-auto load-cash-register-transaction-modal',
							'inputIcon' => [
								'icon' => 'las la-plus-circle'
							],
							'attr' => [
								'type' => 'button',
								'value' => 'Kassa mədaxil',
								'data-route' => 'loadDepositModal'
							]
						],
					],
					'withdraw' => [
						'/component/parts/input.twig' => [
							'containerClassList' => 'height-auto',
							'inputClassList' => 'input btn-input btn-warning width-auto load-cash-register-transaction-modal',
							'inputIcon' => [
								'icon' => 'las la-minus-circle'
							],
							'attr' => [
								'type' => 'button',
								'value' => 'Kassa məxaric',
								'data-route' => 'loadWithdrawModal'
							]
						],
					]
				]
			],
		],
		'/component/table/table_wrapper.twig' => [
			'table' => $table_result,
			'table_tab' => $page,
			'table_type' => $type,
		],
	]
]);
