<?php
header('Content-type: Application/json');

use core\classes\Utils\Utils;

$html = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/modal/custom_modal/u_modal.twig' => [
            'containerClassList' => 'small-modal',
            'modalController' => [
                'title' => 'Yeni sayim',
                'closeButtonClassList' => 'removeModal',
            ],
            'modalContent' => [
                'classList' => 'modal-form',
                'path' => '/component/form/fields/inventory/create-inventory.twig',
            ],
        ]
    ]
]);

Utils::abort([
    'res' => $html,
]);