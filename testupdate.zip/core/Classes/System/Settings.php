<?php 
namespace Core\Classes\System;
use core\classes\dbWrapper\queryBilder as QB;
use core\classes\dbWrapper\db;
use Core\Classes\Utils\Utils;

class Settings 
{
    public static $dirJSON = ROOT.'/core/settings.json';
    /**
     * Получить список 
     */
    public static function getSettingsList() 
    {

    }

    /**
     * Получить конкретную настройку 
     */
    public static function getSetting(string $settingName, $returnType = 'array')
    {
        $data =  QB::select('sett_id as id, sett_name as name, sett_on as state')
                    ->from('function_settting')
                    ->where('sett_name = :settingName')
                    ->bindList([
                        ':settingName' => $settingName
                    ])
                    ->execute()
                    ->first()
                    ->get();

        if($returnType == 'array') {
            return (array) $data;
        }

        if($returnType == 'object') {
            return (object) $data;
        }
    }


    /**
     * @return boolean
     */
    public static function getSettingState(string $settingName)
    {
        return self::getSetting($settingName, 'object')->state;
    }

    /**
     * Добавляем новую настройку
     */
    public static function addSetting()
    {

    }

    /**
     * Редактируем настройку
     */
    public static function editSetting(string $settingName, int $state)
    {
        return db::update([
            'before' => 'UPDATE function_settting SET ',
            'after' => " WHERE sett_name = :sett_name ",
            'post_list' => [
                'name' => [
                    'query' => false,
                    'bind' => 'sett_name'
                ],
                'state' => [
                    'query' => ' sett_on = :state ',
                    'bind' => 'state'
                ]
            ]
        ], 
        [
            'name' => $settingName,
            'state' => $state
        ]);
    }

    /**
     * Активируем настройку
     */
    public static function activeSetting(string $settingName)
    {

    }

    /**
     * Деактивируем настройку
     */
    public static function deactiveSetting(string $settingName)
    {

    }

    /**
     * 
     */
    public static function getSettingsJSON()
    {
        return (object) json_decode(file_get_contents(self::$dirJSON), true);
    }

    /**
     * 
     */
    public static function saveSettingsJSON(array $arr)
    {
        $oldSettings = (array) self::getSettingsJSON();
        $newSettings = array_merge($oldSettings, $arr);
        file_put_contents(self::$dirJSON, json_encode($newSettings));
    }

    /**
     * 
     */
    public static function hasSettingsJSON($settingsKeyName, $settingValName = false)
    {
        $oldSettings = (array) self::getSettingsJSON();
        
        foreach($oldSettings as $key => $val) {
            if($key == $settingsKeyName) {
                if($settingValName !== false && !empty($oldSettings[$settingsKeyName][$settingValName])) {
                    return true;
                }
                
                if($settingValName == false) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * 
     */
    public static function appendSettingsJSON($arr)
    {
        $oldSettings = (array) self::getSettingsJSON();
        $result = Utils::mergeArraysRecursively($oldSettings, $arr);
        file_put_contents(self::$dirJSON, json_encode($result));
    }


    

}