<?php

namespace core\classes\Inventory;

use core\classes\dbWrapper\db;
use core\classes\dbWrapper\queryBuilder;
use core\classes\dbWrapper\updateBuilder;

/**
 * Сессия внутри инвентаризации (gun#1, gun#2 ...). На инвентаризацию
 * одновременно может быть открыта только одна сессия.
 *
 * Жизненный цикл: create() -> scan() (много раз, можно в разные дни, пока
 * сессия open и review ещё не начат) -> startReview() (открывает окно
 * ручной проверки, дальше сканировать нельзя) -> при необходимости
 * updateCountedQuantity() чтобы вручную поправить посчитанное количество ->
 * close() — применяет корректировку стока и создаёт
 * stock_adjustment_document/stock_adjustment_item как постоянную запись.
 */
class InventorySession
{
    const STATUS_OPEN      = 'open';
    const STATUS_CLOSED    = 'closed';
    const STATUS_CANCELLED = 'cancelled';

    public static function create(int $inventoryId, int $userId, ?string $comment = null): array
    {
        $inventory = queryBuilder::select('status')
        ->from('inventory')
        ->where('id', $inventoryId)
        ->execute()
        ->first()
        ->get();

        if (empty($inventory)) {
            throw new \RuntimeException('Инвентаризация не найдена');
        }

        if ($inventory['status'] !== Inventory::STATUS_ACTIVE) {
            throw new \RuntimeException('Инвентаризация не активна, нельзя открыть сессию');
        }

        $alreadyOpen = queryBuilder::select('id')
        ->from('inventory_session')
        ->where('inventory_id', $inventoryId)
        ->where('status', self::STATUS_OPEN)
        ->execute()
        ->first()
        ->get();

        if (!empty($alreadyOpen)) {
            throw new \RuntimeException('Уже есть открытая сессия — сначала закройте её');
        }

        db::insert('inventory_session', [
            [
                'inventory_id'   => $inventoryId,
                'session_number' => self::nextSessionNumber($inventoryId),
                   'status'         => self::STATUS_OPEN,
                   'created_by'     => $userId,
                   'created_at'     => date('Y-m-d H:i:s'),
                   'comment'        => $comment,
            ]
        ]);

        return self::find((int) db::$dbpdo->lastInsertId());
    }

    /**
     * Создать открытую сессию и сразу добавить в неё товары, которые ещё
     * не посчитаны ни в одной сессии (pendingMissingItems), со значением
     * counted = 0. Пользователь сканирует их — counted увеличивается.
     */
    public static function createWithPendingItems(int $inventoryId, array $items, int $userId): array
    {
        $inventory = queryBuilder::select('status')
        ->from('inventory')
        ->where('id', $inventoryId)
        ->execute()
        ->first()
        ->get();

        if (empty($inventory)) {
            throw new \RuntimeException('Инвентаризация не найдена');
        }

        if ($inventory['status'] !== Inventory::STATUS_ACTIVE) {
            throw new \RuntimeException('Инвентаризация не активна, нельзя открыть сессию');
        }

        $alreadyOpen = queryBuilder::select('id')
        ->from('inventory_session')
        ->where('inventory_id', $inventoryId)
        ->where('status', self::STATUS_OPEN)
        ->execute()
        ->first()
        ->get();

        if (!empty($alreadyOpen)) {
            throw new \RuntimeException('Уже есть открытая сессия — сначала закройте её');
        }

        db::beginTransaction();

        try {
            db::insert('inventory_session', [
                [
                    'inventory_id'   => $inventoryId,
                    'session_number' => self::nextSessionNumber($inventoryId),
                       'status'         => self::STATUS_OPEN,
                       'created_by'     => $userId,
                       'created_at'     => date('Y-m-d H:i:s'),
                ]
            ]);
            $sessionId = (int) db::$dbpdo->lastInsertId();

            $itemsList = [];

            foreach ($items as $item) {
                $systemQty = (float) $item['stock_count'];

                $itemsList[] = [
                    'session_id'          => $sessionId,
                    'stock_id'            => (int) $item['stock_id'],
                    'system_quantity'     => $systemQty,
                    'scanned_quantity'    => 0,
                    'counted_quantity'    => 0,
                    'difference_quantity' => -$systemQty,
                    'price'               => (float) ($item['stock_first_price'] ?? 0),
                    'difference_amount'   => round(-$systemQty * (float) ($item['stock_first_price'] ?? 0), 2),
                       'created_by'          => $userId,
                       'created_at'          => date('Y-m-d H:i:s'),
                ];
            }

            if (!empty($itemsList)) {
                db::insert('inventory_session_item', $itemsList);
            }

            db::commit();
        } catch (\Throwable $e) {
            db::rollBack();
            throw $e;
        }

        return self::find($sessionId);
    }

    public static function find(int $sessionId): array
    {
        return queryBuilder::select('*')
        ->from('inventory_session')
        ->where('id', $sessionId)
        ->execute()
        ->first()
        ->get();
    }

    /**
     * Скан штрихкода — ищем товар по баркоду (stock_barcode_list),
     * артикулу или названию (stock_list). Если товар уже есть в сессии —
     * увеличиваем counted_quantity, иначе создаём позицию с counted = 1.
     */
    public static function scan(int $sessionId, string $barcode, int $userId): array
    {
        $session = self::find($sessionId);

        if (empty($session)) {
            throw new \RuntimeException('Сессия не найдена');
        }

        if ($session['status'] !== self::STATUS_OPEN) {
            throw new \RuntimeException('Сессия закрыта, сканирование недоступно');
        }

        if (!empty($session['review_started_at'])) {
            throw new \RuntimeException('Идёт ручная проверка — сканирование временно недоступно');
        }

        $stockId = self::findStockIdByInput($barcode);

        if ($stockId === null) {
            throw new \RuntimeException('Товар не найден');
        }

        $stock = queryBuilder::select('stock_id, stock_name, stock_count, stock_first_price')
        ->from('stock_list')
        ->where('stock_id', $stockId)
        ->where('stock_visible = 0')
        ->execute()
        ->first()
        ->get();

        if (empty($stock)) {
            throw new \RuntimeException('Товар не найден в stock_list');
        }

        $existingRow = queryBuilder::select('*')
        ->from('inventory_session_item')
        ->where('session_id', $sessionId)
        ->where('stock_id', $stockId)
        ->execute()
        ->first()
        ->get();

        if (!empty($existingRow)) {
            $newScanned = (int) $existingRow['scanned_quantity'] + 1;
            $newCounted = $newScanned; // авто-синхронизация до начала review
            $diff       = $newCounted - (float) $existingRow['system_quantity'];

            updateBuilder::table('inventory_session_item')
            ->set('scanned_quantity', $newScanned)
            ->set('counted_quantity', $newCounted)
            ->set('difference_quantity', $diff)
            ->set('difference_amount', round($diff * (float) $existingRow['price'], 2))
            ->set('updated_by', $userId)
            ->set('updated_at', date('Y-m-d H:i:s'))
            ->where('id', $existingRow['id'])
            ->execute();
        } else {
            $newScanned = 1;
            $newCounted = 1;
            $systemQty  = (float) $stock['stock_count'];
            $price      = (float) $stock['stock_first_price'];
            $diff       = $newCounted - $systemQty;

            db::insert('inventory_session_item', [
                [
                    'session_id'          => $sessionId,
                    'stock_id'            => $stockId,
                    'system_quantity'     => $systemQty,
                    'scanned_quantity'    => $newScanned,
                    'counted_quantity'    => $newCounted,
                    'difference_quantity' => $diff,
                    'price'               => $price,
                    'difference_amount'   => round($diff * $price, 2),
                       'created_by'          => $userId,
                       'created_at'          => date('Y-m-d H:i:s'),
                ]
            ]);
        }

        return [
            'stock_id'      => $stockId,
            'stock_name'    => $stock['stock_name'],
            'system_count'  => (float) $stock['stock_count'],
            'scanned_count' => $newScanned,
        ];
    }

    /**
     * Список позиций сессии.
     *
     * $sort:
     *  - 'name_asc'    — по названию товара (экран ручной проверки)
     *  - 'updated_desc'— сначала недавно сканированные (экран сканирования)
     * $limit — сколько позиций вернуть максимум (на экране сканирования
     * показываем только последние 50 отсканированных, см. renderInventorySessionItems).
     */
    public static function items(int $sessionId, string $sort = 'name_asc', ?int $limit = null): array
    {
        $query = queryBuilder::select('
        si.*,
        sl.stock_name,
        sl.barcode_article,
        sl.stock_count AS current_system_count
        ')
        ->from('inventory_session_item si')
        ->innerJoin('stock_list sl', 'si.stock_id = sl.stock_id AND sl.stock_visible = 0')
        ->where('si.session_id', $sessionId);

        if ($sort === 'updated_desc') {
            $query->orderBy('COALESCE(si.updated_at, si.created_at)', 'DESC');
        } else {
            $query->orderBy('sl.stock_name', 'ASC');
        }

        if ($limit !== null) {
            $query->limit($limit);
        }

        return $query->execute()->all();
    }

    /**
     * Одна позиция сессии (для точечного рендера строки после скана,
     * чтобы не перерисовывать всю таблицу).
     */
    public static function item(int $sessionId, int $stockId): array
    {
        return queryBuilder::select('
        si.*,
        sl.stock_name,
        sl.barcode_article,
        sl.stock_count AS current_system_count
        ')
        ->from('inventory_session_item si')
        ->innerJoin('stock_list sl', 'si.stock_id = sl.stock_id AND sl.stock_visible = 0')
        ->where('si.session_id', $sessionId)
        ->where('si.stock_id', $stockId)
        ->execute()
        ->first()
        ->get();
    }

    /**
     * Открыть окно ручной проверки — после этого сканирование блокируется,
     * позиции можно поправить только вручную через updateCountedQuantity().
     */
    public static function startReview(int $sessionId): array
    {
        $session = self::find($sessionId);

        if (empty($session)) {
            throw new \RuntimeException('Сессия не найдена');
        }

        if ($session['status'] !== self::STATUS_OPEN) {
            throw new \RuntimeException('Сессия закрыта');
        }

        if (empty($session['review_started_at'])) {
            updateBuilder::table('inventory_session')
            ->set('review_started_at', date('Y-m-d H:i:s'))
            ->where('id', $sessionId)
            ->execute();
        }

        return self::find($sessionId);
    }

    /**
     * Ручная правка посчитанного количества на экране проверки.
     */
    public static function updateCountedQuantity(int $sessionId, int $stockId, float $countedQuantity, int $userId): array
    {
        $session = self::find($sessionId);

        if (empty($session) || $session['status'] !== self::STATUS_OPEN) {
            throw new \RuntimeException('Сессия недоступна для правки');
        }

        $item = queryBuilder::select('*')
        ->from('inventory_session_item')
        ->where('session_id', $sessionId)
        ->where('stock_id', $stockId)
        ->execute()
        ->first()
        ->get();

        if (empty($item)) {
            throw new \RuntimeException('Позиция не найдена в этой сессии');
        }

        $diff = $countedQuantity - (float) $item['system_quantity'];

        updateBuilder::table('inventory_session_item')
        ->set('counted_quantity', $countedQuantity)
        ->set('difference_quantity', $diff)
        ->set('difference_amount', round($diff * (float) $item['price'], 2))
        ->set('updated_by', $userId)
        ->set('updated_at', date('Y-m-d H:i:s'))
        ->where('id', $item['id'])
        ->execute();

        return queryBuilder::select('*')
        ->from('inventory_session_item')
        ->where('id', $item['id'])
        ->execute()
        ->first()
        ->get();
    }

    /**
     * Закрытие сессии: применяет корректировку стока по всем позициям
     * сессии (counted_quantity после ручной проверки) и создаёт
     * stock_adjustment_document/stock_adjustment_item как постоянную запись.
     */
    public static function close(int $sessionId, int $userId): array
    {
        $session = self::find($sessionId);

        if (empty($session)) {
            throw new \RuntimeException('Сессия не найдена');
        }

        if ($session['status'] !== self::STATUS_OPEN) {
            throw new \RuntimeException('Сессия уже закрыта или отменена');
        }

        $items = self::items($sessionId);

        db::beginTransaction();

        try {
            db::insert('stock_adjustment_document', [
                [
                    'inventory_id' => $session['inventory_id'],
                    'session_id'   => $sessionId,
                    'status'       => 'applied',
                    'created_by'   => $userId,
                    'created_at'   => date('Y-m-d H:i:s'),
                       'applied_at'   => date('Y-m-d H:i:s'),
                ]
            ]);
            $adjustmentId = (int) db::$dbpdo->lastInsertId();

            $shortageQty = 0.0;
            $surplusQty  = 0.0;
            $shortageAmt = 0.0;
            $surplusAmt  = 0.0;

            foreach ($items as $item) {
                // берём актуальный сток прямо перед корректировкой — если между
                // сканированием и закрытием были продажи, база сравнения свежая
                $before = (float) $item['current_system_count'];
                $after  = (float) $item['counted_quantity'];
                $diff   = $after - $before;
                $price  = (float) $item['price'];
                $amount = round($diff * $price, 2);
                $type   = $diff < 0 ? 'shortage' : ($diff > 0 ? 'surplus' : 'match');

                db::insert('stock_adjustment_item', [
                    [
                        'adjustment_id'       => $adjustmentId,
                        'stock_id'            => $item['stock_id'],
                        'quantity_before'     => $before,
                        'counted_quantity'    => $after,
                        'difference_quantity' => $diff,
                        'quantity_after'      => $after,
                        'price'               => $price,
                        'difference_amount'   => $amount,
                        'difference_type'     => $type,
                    ]
                ]);

                updateBuilder::table('stock_list')
                ->set('stock_count', $after)
                ->where('stock_id', $item['stock_id'])
                ->execute();

                db::insert('log_product_stock_history', [
                    [
                        'product_id'      => $item['stock_id'],
                        'quantity_before' => $before,
                        'quantity_change' => $diff,
                        'quantity_after'  => $after,
                        'reference_type'  => 'inventory_session',
                        'reference_id'    => $sessionId,
                        'comment'         => null,
                        'user_id'         => $userId,
                        'created_at'      => date('Y-m-d H:i:s'),
                    ]
                ]);

                if ($diff < 0) {
                    $shortageQty += abs($diff);
                    $shortageAmt += abs($amount);
                } elseif ($diff > 0) {
                    $surplusQty += $diff;
                    $surplusAmt += $amount;
                }
            }

            updateBuilder::table('stock_adjustment_document')
            ->set('total_shortage_quantity', $shortageQty)
            ->set('total_surplus_quantity', $surplusQty)
            ->set('total_shortage_amount', round($shortageAmt, 2))
            ->set('total_surplus_amount', round($surplusAmt, 2))
            ->set('final_difference_amount', round($surplusAmt - $shortageAmt, 2))
            ->where('id', $adjustmentId)
            ->execute();

            updateBuilder::table('inventory_session')
            ->set('status', self::STATUS_CLOSED)
            ->set('closed_by', $userId)
            ->set('closed_at', date('Y-m-d H:i:s'))
            ->set('adjustment_document_id', $adjustmentId)
            ->where('id', $sessionId)
            ->execute();

            db::commit();
        } catch (\Throwable $e) {
            db::rollBack();
            throw $e;
        }

        return self::find($sessionId);
    }

    /**
     * Отменить сессию без применения корректировок (пока она открыта).
     */
    public static function cancel(int $sessionId, int $userId): bool
    {
        $session = self::find($sessionId);

        if (empty($session)) {
            throw new \RuntimeException('Сессия не найдена');
        }

        if ($session['status'] !== self::STATUS_OPEN) {
            throw new \RuntimeException('Отменить можно только открытую сессию');
        }

        updateBuilder::table('inventory_session')
        ->set('status', self::STATUS_CANCELLED)
        ->set('cancelled_by', $userId)
        ->set('cancelled_at', date('Y-m-d H:i:s'))
        ->where('id', $sessionId)
        ->execute();

        return true;
    }

    /**
     * Поиск товара по произвольному вводу (скан или ручной ввод):
     *  1. точный баркод в stock_barcode_list
     *  2. точный артикул (barcode_article) в stock_list
     *  3. точное название (без учёта регистра)
     *
     * Частичное совпадение по названию намеренно не используется — иначе
     * одиночная буква (например «b») при ручном вводе находит случайный товар.
     */
    private static function findStockIdByInput(string $input): ?int
    {
        $input = trim($input);

        if ($input === '') {
            return null;
        }

        $row = queryBuilder::select('br_stock_id')
        ->from('stock_barcode_list')
        ->where('barcode_value', $input)
        ->execute()
        ->first()
        ->get();

        if (!empty($row)) {
            return (int) $row['br_stock_id'];
        }

        $row = queryBuilder::select('stock_id')
        ->from('stock_list')
        ->where('barcode_article', $input)
        ->where('stock_visible = 0')
        ->execute()
        ->first()
        ->get();

        if (!empty($row)) {
            return (int) $row['stock_id'];
        }

        $row = queryBuilder::select('stock_id')
        ->from('stock_list')
        ->where('LOWER(stock_name)', mb_strtolower($input))
        ->where('stock_visible = 0')
        ->execute()
        ->first()
        ->get();

        return !empty($row) ? (int) $row['stock_id'] : null;
    }

    public static function nextSessionNumber(int $inventoryId): int
    {
        $max = queryBuilder::select('MAX(session_number) AS max_number')
        ->from('inventory_session')
        ->where('inventory_id', $inventoryId)
        ->execute()
        ->first()
        ->get();

        return (int) ($max['max_number'] ?? 0) + 1;
    }
}
