<?php 
header('Content-type: Application/json');

$controllerIndex = $_POST['controllerIndex'] ?: '';


$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/custom_modal/u_modal.twig' => [
			'containerClassList' => 'small-modal',
			'modalController' => [
				'title' => 'Müştəri seçin',
				'closeButtonClassList' => 'removeModal',
			],
			'modalContent' => [
				'classList' => 'modal-form',
				'path' => '/component/form/fields/customer/choose-customer.twig',
			],
			'controllerIndex' => $controllerIndex
		]
	]
]);


$utils::abort([
	'res' => $total,
]);
