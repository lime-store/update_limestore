<?php
use core\classes\Services\Customer\Customer;
use core\classes\Report;
use core\classes\Utils\Utils;



$reportInfo = Report::getLastReport()[0];

$transactionId      = $reportInfo['transaction_id'];
$orderInfo = Report::getOrderByTransactionId($transactionId)[0];
$customer_id        = $reportInfo['customer_id'];
$orderSum           = $orderInfo['transaction_order_total'];

if(!empty($customer_id)) {
    Customer::applyCashback($customer_id, $orderSum, $transactionId);
    $utils::successAbort('ok');
}

