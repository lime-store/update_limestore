<?php 
header('Content-type: application/json');

use Core\Classes\Products;
use Core\Classes\Services\Notify;
use Core\Classes\Utils\Utils;

if(!empty($_POST['changeNotifyState'])) {
    Notify::resetNotifyState();

    Utils::abort([
        'success'
    ]);
}

if(!empty($_POST['getNotifyModal'])) {
    $id = !empty($_POST['customId']) ? $_POST['customId'] : exit;;
    $notifyId = !empty($_POST['notifyId']) ? $_POST['notifyId'] : exit;
    $notifyTitle = !empty($_POST['notifyTitle']) ? $_POST['notifyTitle'] : exit;
    
    $getProduct = Products::getProductById($id);

    $stockInit = $init->initController('stock');

    unset($stockInit['page_data_list']['get_data']['edit_stock_btn']);

    // Utils::log($stockInit);

    $table_result = $main->compareData([$getProduct], $stockInit['page_data_list']);

    $modal = $Render->view('/component/include_component.twig', [
        'renderComponent' => [
            '/component/modal/custom_modal/u_modal.twig' => [
                'modalController' => [
                    'title' => $notifyTitle,
                    'closeButtonClassList' => 'removeModal'
                ],
                'modalContent' => [
                    'path' => '/component/table/table_wrapper.twig',
                ],
                'class_list' => '',
                'table' => $table_result, 
            ]  
        ]
    ]);

    Utils::abort([
        'res' => $modal
    ]);
}