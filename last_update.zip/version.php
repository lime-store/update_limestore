Version: 1.0.1;

<?php 
	function sotre_version() {
		$ver = '1.0.1';
	}
