<?php 

namespace core\classes\Traits;

use core\classes\Privates\CashRegisters;
use core\classes\Utils\Utils;

trait ReportStatsCard
{  
    public static $res = [];

    public function getStatsList($data, $card_list, $expense, $date = null) 
    {
        $order_count 		= 0;
        $order_turnover 	= 0;
        $order_profit 		= 0;
        $refaund            = 0;
        $wholesale_turnover = 0;
        $wholesale_refaund  = 0;
        $wholesale_profit   = 0;

        foreach($data as $stock) {
            if(array_key_exists('stock_order_visible', $stock)) {                
                if($stock['stock_order_visible'] == 0) {
                    $order_profit 		+= $stock['order_total_profit'];
                    $order_count 		+= $stock['order_stock_count']; 
                    $order_turnover 	+= $stock['order_stock_total_price'];

                    if(!empty($stock['wholesale_order'])) {
                        $wholesale_turnover += $stock['wholesale_order'];
                    }


                    if(!empty($stock['wholesale_profit'])) {
                        $wholesale_profit += $stock['wholesale_profit'];
                    }                    
                }

                if($stock['stock_order_visible'] == 3) {
                    $refaund += $stock['order_stock_total_price'];
                    $order_profit = $order_profit - $stock['order_total_profit'];

                    if(!empty($stock['total_refaund'])) {
                        $wholesale_refaund += $stock['total_refaund'];

                        $wholesale_profit = $wholesale_profit - $stock['total_profit'];
                    }                         
                }
            }
        }

        $order_turnover = $order_turnover - $refaund;
        $wholesale_turnover = $wholesale_turnover - $wholesale_refaund;
    
        foreach($card_list as $type) {
            //количество товара
            switch ($type) {
                case 'order_turnover':
                    self::getOrderTurnOverCard($type, $order_turnover);
                    break;
                
                case 'order_margin':
                    self::getOrderMarginCard($type, ($order_profit - $expense));
                    break;		

                case 'order_profit':
                    self::getOrderProfitCard($type, $order_profit);
                    break;

                case 'rasxod':
                    self::getOrderExpenseCard($type, $expense);
                    break;							
                
                case 'order_count':
                    self::getOrderCountCard($type, $order_count);
                    break;
                
                case 'order_turnover_wholesale':
                    self::getOrderTurnOverCard($type, $wholesale_turnover);
                    break;                

                case 'order_margin_wholesale':
                    self::getOrderMarginCard($type, ($wholesale_profit - $expense));
                    break;

                case 'order_profit_wholesale':
                    self::getOrderProfitCard($type, $wholesale_profit);
                    break;
                    
                case 'order_expense_wholesale':
                    self::getOrderExpenseCard($type, $expense);
                    break;   

                case 'daily_cash':
                    self::displayCashAmountForDay($type, $date);
                    break;  
                case 'daily_card':
                    self::displayCardAmountForDay($type, $date);
                    break;
                case 'total_cash':
                    self::displayTotalCashAmount($type);
                    break;
                case 'total_card': 
                    self::displayTotalCardAmount($type);
                    break;                                

            }
        }
    
        return self::$res;
    }

public static function getOrderTurnOverCard($type, $value)
{
   return array_push(self::$res, [
        'title' => 'Satış',
        'fields' => $type,
        'value' => Utils::prettyPrintNumber($value),
        'mark' 	=> [
            'mark_text' => '',
            'mark_modify_class' => 'mark-large-icon-manat button-icon-right manat-icon--black '
        ],
        'icon' => [
            'parentClassList' => 'mark mark-tags mark-success',
            'icon' => 'la-chart-line'
        ]
    ]);
}

public static function displayCashAmountForDay($type, $date)
{ 
   $result = CashRegisters::getBalanceAtDate($date, 1);
   $value = !empty($result) ? $result : 0;

   return array_push(self::$res, [
        'title' => 'Gündəlik kassa qalığı (nağd)',
        'fields' => $type,
        'value' => Utils::prettyPrintNumber($value),
        'mark' 	=> [
            'mark_text' => '',
            'mark_modify_class' => 'mark-large-icon-manat button-icon-right manat-icon--black '
        ],
        'icon' => [
            'parentClassList' => 'mark mark-tags mark-primary',
            'icon' => 'la-money-bill-wave'
        ]
    ]);        
}

public static function displayCardAmountForDay($type, $date) 
{
   $result = CashRegisters::getBalanceAtDate($date, 2);
   $value = !empty($result) ? $result : 0;

   return array_push(self::$res, [
        'title' => 'Gündəlik kart qalığı',
        'fields' => $type,
        'value' => Utils::prettyPrintNumber($value),
        'mark' 	=> [
            'mark_text' => '',
            'mark_modify_class' => 'mark-large-icon-manat button-icon-right manat-icon--black '
        ],
        'icon' => [
            'parentClassList' => 'mark mark-tags mark-default',
            'icon' => 'la-credit-card'
        ]
    ]);          
}

public static function displayTotalCashAmount($type) 
{
   $result = CashRegisters::getCurrentBalance(1);
   $value = !empty($result) ? $result : 0;

   return array_push(self::$res, [
        'title' => 'Ümumi kassa qalığı (nağd)',
        'fields' => $type,
        'value' => Utils::prettyPrintNumber($value),
        'mark' 	=> [
            'mark_text' => '',
            'mark_modify_class' => 'mark-large-icon-manat button-icon-right manat-icon--black '
        ],
        'icon' => [
            'parentClassList' => 'mark mark-tags mark-success',
            'icon' => 'la-money-bill-wave'
        ]
    ]);          
}

public static function displayTotalCardAmount($type) 
{
   $result = CashRegisters::getCurrentBalance(2);
   $value = !empty($result) ? $result : 0;

   return array_push(self::$res, [
        'title' => 'Ümumi kart qalığı',
        'fields' => $type,
        'value' => Utils::prettyPrintNumber($value),
        'mark' 	=> [
            'mark_text' => '',
            'mark_modify_class' => 'mark-large-icon-manat button-icon-right manat-icon--black '
        ],
        'icon' => [
            'parentClassList' => 'mark mark-tags mark-danger',
            'icon' => 'la-credit-card'
        ]
    ]);          
}

public static function getOrderMarginCard($type, $value)
{
    return array_push(self::$res, [
        'title' => 'Xalis mənfəət',
        'fields' => $type,
        'value' => Utils::prettyPrintNumber($value),
        'mark' 	=> [
            'mark_text' => '',
            'mark_modify_class' => 'mark-large-icon-manat button-icon-right manat-icon--black'
        ],
        'icon' => [
            'parentClassList' => 'mark mark-tags mark-success',
            'icon' => 'la-piggy-bank'
        ]
        
    ]);        
}

public static function getOrderProfitCard($type, $value)
{
    return array_push(self::$res, [
        'title' => 'Mənfəət',
        'fields' => $type,
        'value' => Utils::prettyPrintNumber($value),
        'mark' 	=> [
            'mark_text' => '',
            'mark_modify_class' => 'mark-large-icon-manat button-icon-right manat-icon--black'
        ],
        'icon' => [
            'parentClassList' => 'mark mark-tags mark-warning',
            'icon' => 'la-coins'
        ]
        
    ]);        
}

public static function getOrderExpenseCard($type, $value)
{
    return array_push(self::$res, [
        'title' => 'Xərclər',
        'fields' => $type,
        'value' => Utils::prettyPrintNumber($value),
        'mark' 	=> [
            'mark_text' => '',
            'mark_modify_class' => 'mark-large-icon-manat button-icon-right manat-icon--black'
        ],
        'icon' => [
            'parentClassList' => 'mark mark-tags mark-danger',
            'icon' => 'la-file-invoice-dollar'
        ]
    ]);        
}

public static function getOrderCountCard($type, $value)
{
    return array_push(self::$res, [
        'title' => 'Cəmi satış (sayı)',
        'fields' => $type,
        'value' => Utils::prettyPrintNumber($value),
        'mark' 	=> [
            'mark_text' => 'ədəd',
            'mark_modify_class' => 'mark-right'
        ],
        'icon' => [
            'parentClassList' => 'mark mark-tags mark-primary',
            'icon' => 'la-shopping-basket'
        ]
    ]);        
}
}