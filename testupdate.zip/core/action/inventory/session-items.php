<?php
header('Content-type: Application/json');

use core\classes\Utils\Utils;

require __DIR__.'/_helpers.php';

$sessionId = (int) ($_POST['session_id'] ?? 0);

if($sessionId <= 0) {
    Utils::errorAbort('Sessiya seçilməyib');
    return;
}

$result = renderInventorySessionItems($sessionId);

Utils::abort([
    'type'        => 'success',
    'items_table' => $result['items_table'],
    'review'      => $result['review'],
]);