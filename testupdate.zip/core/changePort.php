<?php
include $_SERVER['DOCUMENT_ROOT'].'/autoload.php';

use Core\Classes\System\Settings;

Settings::appendSettingsJSON([
    'config' => [
        'mysqlPort' => 3310
    ]
]);

header('Location: /');
exit;