<?php

use Core\Classes\Utils\Utils;

$count = 0;

if(empty($_POST['all'])) {
	$count = $_POST['count'];
	$barcode = $_POST['barcode'];

	$content = $Render->view('/component/include_component.twig', [
		'renderComponent' => [
			'/component/multipleBarcode/multipleBarcode.twig' => [
				'count' => $count,
                'barcode' => $barcode
			]
		]
	]);	
}

if($count > 56) {
    $count = 56;
}

if($count <= 0) {
    $count = 1;
}


$content = '';
	
	if($_POST['all']) {
		foreach($_POST['all'] as $key => $val) {
			$content .= $Render->view('/component/include_component.twig', [
				'renderComponent' => [
					'/component/multipleBarcode/multipleBarcode.twig' => [
						'count' => $val['count'],
						'barcode' => $val['barcode']
					]
				]
			]);	
		}
	}


    Utils::abort([
        'content' => $content
    ]);