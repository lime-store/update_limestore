<?php 
	require_once '../../function.php';

	//шаблоны
	ls_include_tpl();

	//получаем тип таблицы
	get_table_svervice_type();

	//получем категорию товара
	get_product_category();

	//заголовок таблицы
	get_table_header();	

?>
<div class="view_stock_wrapper">
	<div class="view_stock_box_wrp">

		<!-- начало формы добавления товара в базу -->
		<div class="add_stock_sell_wrp flex-cntr">
			<div class="new_stock_box">

				<ul class="add_stock_box_form">

					<li class="add_stock_form_list new_stock_box_header_description">
						<span>DIGƏR məhsul əlavə edin</span>
					</li>
					<div class="row">
						<div class="col-w50">
							<li class="add_stock_form_list auto-cmplt-parent">
								<span class="add_stock_description">Malın adı</span>
								<input type="text" autocomplete="off" class="add_stock_input add_stock_name_action auto-cmplt-input stock_auto_compelete" data-name="name">
								<?php auto_complete_select_wrapper_tpl(); ?>
							</li>

							<input type="hidden" autocomplete="off" class="add_stock_input  add_stock_imei_action">
						
						<div class="row">
							<li class="add_stock_form_list row-list">
								<span class="add_stock_description">Mayası</span>
								<input type="text" autocomplete="off" class="add_stock_input add_stock_first_price_action add_stock_fpice_style input_preg_action" placeholder="0">
							</li>
							<li class="add_stock_form_list row-list">
								<span class="add_stock_description">MALIN SAYI</span>
								<input type="text" class="add_stock_input add_stock_count input_preg_action add_stock_count_style" autocomplete="off" placeholder="0">						
							</li>	

							<li class="add_stock_form_list row-list">
								<span class="add_stock_description">Satış qiyməti</span>
								<input type="text" autocomplete="off" class="add_stock_input add_stock_second_price_action add_stock_spice_style input_preg_action" placeholder="0">
							</li>

						</div>		
				    </div>		
						<div class="col-w50">
							<li class="add_stock_form_list auto-cmplt-parent">
								<span class="add_stock_description">KATEGORIYA</span>
								<input type="text" autocomplete="off" class="add_stock_input add_stock_provider_action auto-cmplt-input stock_auto_compelete" data-name="category">
								<?php auto_complete_select_wrapper_tpl(); ?>
							</li>	

							<div class="row">
								<?php add_filter_list_tpl(); ?>
							</div>
						</div>
						<li class="add_stock_form_list submit_list">
							<a href="javascript:void(0)" class="add_stock_submit btn add_stock_style click">Yüklə</a>
						</li>
					</div>
				</ul>

			</div>
		</div>		
		<!-- конец формы добавления товара в базу -->
		<div class="search_filter_wrapper flex f-jc-end f-ai-cntr">
			<!-- начало формы поиска -->
		<?php 
		search_input($arr = array(
			'product_type' => $stock,
			'product_category' => $product_akss,
			'auto_complete' => 'show',
			'product_class' => 'auto-cmplt-input stock_auto_compelete',
			'parent_class' => 'auto-cmplt-parent search_filter',
			'label' => 'hide',
			'label_title' => '',
			'clear_button' => 'show'
		)); 
		?>	
			<!-- конец формы поиска -->
		</div>
		<!-- начало таблицы товаров -->
		<div class="stock_view_wrapper">
			<div class="stock_view_list ls-custom-scrollbar">
				<table class="stock_table">
					<thead>
						<tr>
							<?php 
								check_th_access_tpl(array(
									'th_serial' 	=> true,
									'th_buy_day'	=> true,
									'th_prod_name' 	=> true,
									'th_buy_price'	=> true,
									'th_sale_price' => true,
									'th_count' 		=> true,
									'th_category'	=> true
								));									
							?>							
						</tr>
					</thead>
					<tbody class="stock_list_tbody" data-stock-src="<?php echo $stock; ?>" data-category="<?php echo $product_akss; ?>">
						<?php 
							$product_category = $product_akss;

							$stock_list = [];
							$stock_view = $dbpdo->prepare("SELECT * FROM stock_list
							 WHERE stock_visible = 0
							 AND stock_type = ?
							 ORDER BY stock_id DESC");
							$stock_view->execute([$product_category]);
							if($stock_view->rowCount()>0) {
								while ($stock_row = $stock_view->fetch(PDO::FETCH_BOTH))
									$stock_list[] = $stock_row;

								foreach ($stock_list as $stock_row)
								{
									$stock_id 				= $stock_row['stock_id'];			
									$stock_name 			= $stock_row['stock_name'];				
									$stock_first_price 		= $stock_row['stock_first_price'];	
									$stock_second_price		= $stock_row['stock_second_price'];
									$stock_count			= $stock_row['stock_count'];
									$stock_provider			= $stock_row['stock_provider'];	
									$stock_date 			= $stock_row['stock_get_fdate'];	
									echo '<tr class="stock-list" id="'.$stock_id.'">';
										check_td_access_tpl(array(
											'th_serial' 	=> $stock_id,
											'th_buy_day'	=> $stock_date,
											'th_prod_name' 	=> $stock_name,  
											'th_buy_price'	=> $stock_first_price,  
											'th_sale_price' => $stock_second_price,  
											'th_count' 		=> $stock_count,  
											'th_category'	=> $stock_provider  
										));
									echo '<tr>';																	
								}						
								get_product_count_price('', $product_category, $manat_image);	
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
		<!-- конец табицы товаров -->

	</div>
</div>


