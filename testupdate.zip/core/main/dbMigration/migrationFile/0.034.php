<?php
use core\classes\dbWrapper\updateBuilder;
use core\classes\System\Migration;

$customerType_034 = [
    'type'              => "varchar(128) NOT NULL DEFAULT 'RETAIL' ",
    'cashback_percent'  => "decimal(10,2) NOT NULL DEFAULT 1",
    'cashback_card_code' => 'VARCHAR(20)'
];

Migration::hasTableColumnExist('customer', $customerType_034, function($notExistColumnName) {
    if($notExistColumnName) {
        Migration::alertTableColumn('customer', $notExistColumnName);
    }
});

Migration::hasTableExist('customer_balance', function($noExist) {
    if($noExist) {
        Migration::createTable(
            "CREATE TABLE `customer_balance` (
                `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `customer_id`       varchar(255)  NOT NULL,
                `transaction_id`    varchar(128)  NOT NULL,
                `balance_amount`    decimal(10,2) NOT NULL DEFAULT 0,
                `balance_before`    decimal(10,2) NOT NULL DEFAULT 0,
                `earned_amount`     decimal(10,2) NOT NULL DEFAULT 0,
                `spend_amount`      decimal(10,2) NOT NULL DEFAULT 0,
                `date`              DATE DEFAULT (CURRENT_DATE),
                `date_short`        varchar(255) NOT NULL,
                `date_full`         varchar(255) NOT NULL,
                `visible`           int(11) NOT NULL
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
        );
    }
});



$stock_order_report_customer_id_034 = [
    'customer_id' => "int(11) NULL",
    'used_cashback_amount' => 'decimal(10, 2)'
];

Migration::hasTableColumnExist('stock_order_report', $stock_order_report_customer_id_034, function($notExistColumnName) {
    if($notExistColumnName) {
        Migration::alertTableColumn('stock_order_report', $notExistColumnName);
    }
});


$add_function_settings_customer_cashback_v0034 = [
    array(':sett_name' => 'customerCashback', 'sett_on' => '0')
];

$settings_customer_cashback_sql_v0034 = [
    'table_name' => 'function_settting',
    'col_list' => '*',
    'query' => [
        'base_query' => ' WHERE sett_name = :sett_name ORDER BY sett_id DESC'
    ],
    'bindList' => []
];

Migration::hasDataExist($settings_customer_cashback_sql_v0034, $add_function_settings_customer_cashback_v0034, function($notExistData) {
    if($notExistData) {
        Migration::insertMigrationData('function_settting', $notExistData);
    }
});

updateBuilder::table('cash_registers')
              ->set('payment_method', 1)
              ->whereNull('payment_method')
              ->execute();