<?php 
header('Content-type: Application/json');

use Core\Classes\Report;
use core\classes\Services\tableFooter;
use Core\Classes\System\Init;
use Core\Classes\Utils\Utils;

$report_id = $_POST['report_id'];
$transaction_id = $_POST['transaction_id'];

if($transaction_id == false) {
    return Utils::errorAbort('Cant find transaction id');
}

$controllerData = Init::getControllerData('report');

$data_page = $controllerData->getAllData();
        
$data_page['sql']['query']['base_query'] = $data_page['sql']['query']['base_query'] . "  AND stock_order_report.transaction_id = :transaction_id ";
$data_page['sql']['bindList']['transaction_id'] = $transaction_id;

$result = $main->prepareData($data_page['sql'], $data_page['page_data_list']);



$table = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_row.twig' => [
            'table' => $result['result'],
            'table_tab' => 'report',
            'table_type' => 'some'       
        ]
    ]
]);


$total = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_footer_row.twig' => [		
            'table_total' => tableFooter::getData($data_page['page_data_list']['table_total_list'], $result['base_result'])  
        ]  
    ]
]);

return $utils::abort([
    'type' => 'success',
    'text' => 'Ok',
    'table' => $table,
    'total' => $total
]);