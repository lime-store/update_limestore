<?php header('Content-type: Application/json');

use core\classes\Privates\CashRegisters;
use core\classes\Privates\User;
use core\classes\Services\Expenses;
use core\classes\Utils\Utils;

$expense = new Expenses;

if(!empty($_POST) && count($_POST['post_data']) > 0) {
	try {
		$expense->addExpense($_POST['post_data']);
		
		if(isset($_POST['post_data']['add_rasxod_cash_register'])) {
			if($_POST['post_data']['add_rasxod_cash_register']) {
				CashRegisters::withdraw(
					$_POST['post_data']['add_rasxod_sum'],
					'expense',
					User::getCurrentUser('get_id'),
					1,
					null,
					$_POST['post_data']['add_rasxod_description']
				);
			}
		}

		echo json_encode([
			'type'	 => 'success',
			'text' => 'ok',
		]);	



	} catch (Exception $e) {
		echo json_encode([
			'text' => "Ошибка",
			'type' 	=> 'error'
		]);
	}
}