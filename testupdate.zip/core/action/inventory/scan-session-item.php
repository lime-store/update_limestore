<?php
header('Content-type: Application/json');

use core\classes\Inventory\InventorySession;
use core\classes\Utils\Utils;

require __DIR__.'/_helpers.php';

$sessionId = (int) ($_POST['session_id'] ?? 0);
$barcode   = trim($_POST['barcode'] ?? '');

if($sessionId <= 0) {
    Utils::errorAbort('Sessiya seçilməyib');
    return;
}

if($barcode === '') {
    Utils::errorAbort('Barkod daxil edin');
    return;
}

try {
    $scanResult = InventorySession::scan($sessionId, $barcode, $user->getCurrentUser('get_id'));
} catch (\Throwable $e) {
    Utils::errorAbort(inventoryErrorMessage($e));
    return;
}

// первый скан сессии — таблицы ещё нет, отдаём её целиком (одна строка);
// дальше отдаём только строку сканированного товара, JS добавляет её в начало
$isEmpty = empty(InventorySession::items($sessionId, 'updated_desc', 1));

$result = $isEmpty ? renderInventorySessionItems($sessionId, true) : [];

Utils::abort([
    'type'        => 'success',
    'text'        => $scanResult['stock_name'].' — sayılmış: '.$scanResult['scanned_count'],
    'stock_id'    => $scanResult['stock_id'],
    'items_table' => $result['items_table'] ?? null,
    'row_html'    => $isEmpty ? null : renderInventorySessionRow($sessionId, $scanResult['stock_id']),
    'review'      => false,
]);