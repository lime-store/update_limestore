<?php
header('Content-type: Application/json');

use core\classes\Inventory\InventorySession;
use core\classes\Utils\Utils;

require __DIR__.'/_helpers.php';

$sessionId = (int) ($_POST['id'] ?? 0);

try {
    $session = InventorySession::close($sessionId, $user->getCurrentUser('get_id'));

    Utils::abort([
        'type'         => 'success',
        'text'         => 'Sessiya bağlandı',
        'inventory_id' => (int) $session['inventory_id'],
    ]);
} catch (\Throwable $e) {
    Utils::errorAbort(inventoryErrorMessage($e));
}