<?php 
namespace core\classes\dbWrapper\traits;

use core\classes\dbWrapper\updateBuilder as ub;

trait softDelete
{
}