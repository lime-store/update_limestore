<?php 
header('Content-type: Application/json');

$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/custom_modal/u_modal.twig' => [
			'containerClassList' => 'small-modal',
			'modalController' => [
				'title' => 'Satıcı əlavə edin',
				'closeButtonClassList' => 'removeModal',
			],
			'modalContent' => [
				'classList' => 'modal-form',
				'path' => '/component/form/fields/admin/add_seller.twig',
			]
		]
	]
]);


$utils::abort([
	'res' => $total,
]);
