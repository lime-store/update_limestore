<?php 
//шаблон для оформения заказа на странице терминала - лист
function terminal_order_list_tpl($filter_title, $filter_name, $give_product_id, $custom_class_filter_input, $mark) {
?>	
	<li class="order_modal_list">
		<span class="module_order_desrioption"><?php echo $filter_title; ?></span>
		<?php get_filter_selected_input_value($filter_name, $give_product_id, $custom_class_filter_input, 'disabled', 'terminal', $mark); ?>
	</li>
<?php
}

//шаблон для редакрирования товара на стрнаице амбар - лист
function stock_edit_order_list_tpl($filter_title, $filter_name, $edit_stock_id, $custom_class_filter_input, $mark) {
?>
		<li class="order_modal_list">
			<span class="module_order_desrioption"><?php echo $filter_title; ?></span>
			<div class="add_stock_filter_redit">
				<div class="ls-custom-select-wrapper">
					<ul class="ls-select-list">
						<div class="select-drop-down">

						<?php get_filter_selected_input_value($filter_name, $edit_stock_id, $custom_class_filter_input, '', 'stock', $mark); ?>

							<div class="reset_option">
								<input type="button" class="ls-reset-option ls-reset-option-style">
							</div>
						</div>
						<div class="ls-select-option-list">
							<ul class="ls-select-list-option ls-custom-scrollbar">
								<?php get_filter_li_list($filter_name, '', ''); ?>		
							</ul>
						</div>
					</ul>
				</div>				
			</div>
		</li>
<?php			
}

//вывод списка филтров для страницы терминал
function terminal_filter_return_tpl($filter_title, $filter_name, $class, $text) {
?>
	<li class="filter_return_list ls-select-list">
		<div class="select-drop-down">
			<input type="button"  class="<?php echo $class; ?> drop_down_btn filter_input_height_modify" value="<?php echo $filter_title; ?>" default-value="<?php echo $filter_title; ?>">
			<div class="reset_option">
				<input type="button" class="ls-reset-option ls-reset-option-style">
			</div>
		</div>
		<div class="ls-select-option-list">
			<ul class="ls-select-list-option ls-custom-scrollbar">
				<?php ger_filter_param($filter_name, $text); ?>		
			</ul>
		</div>

	</li>
<?php		
}

function auto_complete_select_wrapper_tpl() {
?>
	<div class="auto-cmplt-select auto-compelete-list-style">
		<ul class="ls-select-list-option ls-custom-scrollbar auto-cmplt-result">
			<?php get_autocomplete_list_tpl('', ''); ?>
		</ul>
	</div>
<?php
}


function get_autocomplete_list_tpl($list_value, $text) {
	if(empty($list_value)) { echo '<span class="">Начните вводить название</span>'; }
	else {
?>	


	<li class="ls-select-li">
		<a href="javascript:void(0)" class="choice-style auto-cmplt-list" id="" value="<?php echo $list_value; ?>">
			<span class="mark filter-name"><?php echo $list_value; ?></span>
			<span class="mark filter-mark-text"><?php echo $text; ?></span>
		</a>
	</li>
<?php
	}
}
