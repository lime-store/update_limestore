<?php
header('Content-type: Application/json');

use core\classes\Inventory\Inventory;
use core\classes\Inventory\InventorySession;
use core\classes\Utils\Utils;

require __DIR__.'/_helpers.php';

$inventoryId = (int) ($_POST['inventory_id'] ?? 0);

if($inventoryId <= 0) {
    Utils::errorAbort('Sayim seçilməyib');
    return;
}

try {
    $missingItems = Inventory::pendingMissingItems($inventoryId);

    if(empty($missingItems)) {
        Utils::errorAbort('Sayılmamış mal yoxdur');
        return;
    }

    $session = InventorySession::createWithPendingItems($inventoryId, $missingItems, $user->getCurrentUser('get_id'));
} catch (\Throwable $e) {
    Utils::errorAbort(inventoryErrorMessage($e));
    return;
}

Utils::abort([
    'type'         => 'success',
    'text'         => 'Sessiya yaradıldı və açıldı',
    'inventory_id' => $inventoryId,
    'session_id'   => (int) $session['id'],
]);
