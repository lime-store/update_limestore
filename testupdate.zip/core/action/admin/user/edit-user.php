<?php
    use core\classes\Privates\AccessManager;
use core\classes\Utils\Utils;

    header('Content-type: application/json');

    $prepare_data = $_POST['prepare_data'];

    if(array_key_exists('edit_seller_name', $prepare_data)) {
        if(!$user->isUsernameAvailable($prepare_data['edit_seller_name'])) {
            return $utils::abort([
                'type' => 'error',
                'text'	=> 'İstifadəçi artıq əlavə edilib'
            ]);

            exit();
            die();
        } 
    }


    if(!empty($_POST['newAccessData'])) {
        $addedList = $_POST['newAccessData'];

        foreach($addedList as $rulesId) {
            AccessManager::setUserDataAccess($prepare_data['seller_id'], $rulesId, function($hasAdmin) {
                if($hasAdmin) {
                    echo Utils::abort($hasAdmin);
                    die;
                }
            });
        }
    }

    if(!empty($_POST['delAccessData'])) {
        $removedAccess = $_POST['delAccessData'];

        foreach($removedAccess as $rulesId) {
            AccessManager::unsetUserDataAccess($prepare_data['seller_id'], $rulesId, function($hasAdmin) {
                if($hasAdmin) {
                    echo Utils::abort($hasAdmin);
                    die;
                }
            });
        }
    }


    if(!empty($_POST['newAccessAction'])) {
        $addActionList = $_POST['newAccessAction'];

        foreach($addActionList as $actionId) {
            AccessManager::setUserActionAccess(['userId' => $prepare_data['seller_id'], 'rulesId' => $actionId], function($hasAdmin) {
                if($hasAdmin) {
                    echo Utils::abort($hasAdmin);
                    die;
                }
            });
        }
    }

    if(!empty($_POST['userDiscountLimit'])) {
        $discountLimit = $_POST['userDiscountLimit'];
        AccessManager::unsetUserActionAccess($prepare_data['seller_id'], 'discountLimit', function($hasAdmin) {
            if($hasAdmin) {
                echo Utils::abort($hasAdmin);
                die;
            }
        });
        
        AccessManager::setUserActionAccess(['userId' => $prepare_data['seller_id'], 'rulesId' => 'discountLimit', 'description' => $discountLimit], function($hasAdmin) {
            echo Utils::abort($hasAdmin);
            die;
        });
    }


    if(!empty($_POST['delAccessAction'])) {
        $removedAccessAction = $_POST['delAccessAction'];

        foreach($removedAccessAction as $actionId) {
            AccessManager::unsetUserActionAccess($prepare_data['seller_id'], $actionId, function($hasAdmin) {
                if($hasAdmin) {
                    echo Utils::abort($hasAdmin);
                    die;
                }
            });
        }
    }    


    if(!empty($_POST['newAccessPage'])) {
        $addedList = $_POST['newAccessPage'];

        foreach($addedList as $rulesId) {
            AccessManager::setUserPageAccess($prepare_data['seller_id'], $rulesId, function($hasAdmin) {
                if($hasAdmin) {
                    echo Utils::abort($hasAdmin);
                    die;
                }
            });
        }
    }

    if(!empty($_POST['deleteAccesspage'])) {
        $removedAccess = $_POST['deleteAccesspage'];

        foreach($removedAccess as $rulesId) {
            AccessManager::unsetUserPageAccess($prepare_data['seller_id'], $rulesId, function($hasAdmin) {
                if($hasAdmin) {
                    echo Utils::abort($hasAdmin);
                    die;
                }
            });
        }
    }    


    if(count($prepare_data) > 1) {
        $user->editUser($prepare_data);
    }

    return $utils::abort([
        'type' => 'success',
        'text' => 'Ok'
    ]);