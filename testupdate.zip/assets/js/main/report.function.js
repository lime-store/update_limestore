$(document).ready(function() {

		$(document).on('click', '.stats-value', function() {
			
		});


/** 
 * START report 
 * удаление отчёта
 */
$(document).on('click', '.report-delete-btn', function() {
    //id - отячёта
    var report_order_id = $('.report_order_id').data('id');
  
    $.ajax({
        url: 'ajax_route.php',
        type: 'POST',
        data: {
			route: 'deleteReport',
			url: 'core/action/report/delete.php',
            report_id: report_order_id
        },
        dataType: 'json',
        success: (data)=> {
            if(data.type == 'success') {
				sendAjaxHistory();

				pageData.rightSideModalHide();
				pageData.overlayHide();

				var $stock = $(`#${report_order_id}.stock-list`); 

				$stock.hide(1000, function() {
					$stock.remove();
				});				
            }
			
            pageData.alert_notice(data.type, data.text);

			createBackup();
        }
    });
});
/** END report */

$(document).on('click', '.report-refaund-btn', function() {
    //id - отячёта
    var report_order_id = $('.report_order_id').data('id');
  
    $.ajax({
        url: 'ajax_route.php',
        type: 'POST',
        data: {
			route: 'refaundReport',
			url: 'core/action/report/refaund.php',
            report_id: report_order_id
        },
        dataType: 'json',
        success: (data)=> {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success') {
				sendAjaxHistory();
				pageData.rightSideModalHide();
				pageData.overlayHide();
				pageData.prependTable(data.table);
				
				createBackup();
			}
        }
    });
});

// тут нужно сделать поиск по транзакции
$(document).on('click', '.report-search-transaction-id', function() {
	//id - отячёта
	var report_order_id = $('.report_order_id').data('id');
	var transaction_id = $(this).attr('data-transaction-id');
  
	$.ajax({
		url: 'ajax_route.php',
		type: 'POST',
		data: {
			route: 'searchTransactionId',
			url: 'core/action/report/search.php',
			report_id: report_order_id,
			transaction_id: transaction_id
		},
		dataType: 'json',
		success: (data)=> {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success') {
				pageData.rightSideModalHide();
				pageData.overlayHide();
				pageData.innerTable(data.table);

				setAjaxHistory({
					url: 'ajax_route.php',
					type: 'POST',
					data: {
						route: 'searchTransactionId',
						url: 'core/action/report/search.php',
						report_id: report_order_id,
						transaction_id: transaction_id
					},
					dataType: 'json'					
				});
			}
		}
	});
});

$(document).on('click', '.open-refaund-modal', function() {
    //id - отячёта
    var report_order_id = $('.report_order_id').data('id');
  
	remove_modal();

    $.ajax({
        url: 'ajax_route.php',
        type: 'POST',
        data: {
			route: 'refaundReport',
			url: 'core/action/report/refaund.php',
            report_id: report_order_id,
			getModal: true,
        },
        dataType: 'json',
        success: (data)=> {
			if(data.type == 'error') {
				pageData.alert_notice(data.type, data.text);
				// pageData.overlayHide();
				// pageData.rightSideModalHide();
				return;
			}
			$('.container').append(data.res);
			pageData.rightSideModalHide();

			createBackup();
        }
    });
});


$(document).on('click', '.send-report-refaund', function() {
    //id - отячёта
    var report_order_id = $(this).data('id');
	var refaund_quantity = $('.modal-refaund-quantity').val();
  
    $.ajax({
        url: 'ajax_route.php',
        type: 'POST',
        data: {
			route: 'refaundReport',
			url: 'core/action/report/refaund.php',
            report_id: report_order_id,
			refaundQuantity: refaund_quantity,
			sendData: true,
        },
        dataType: 'json',
        success: (data)=> {
			pageData.alert_notice(data.type, data.text);
			$('.container').append(data.res);
			pageData.rightSideModalHide();

			if(data.type == 'success') {
				remove_modal();
				pageData.overlayHide();

				sendAjaxHistory();
			}
        }
    });
});
/** END report */


$(document).on('click', '.edit-report-order', function() {
	const prepare = prepare_form_data(
		$(this).closest('.modal_order_form'),
		'.edit-report-order-input.edited',
		'fields-name'
	);

	console.log(prepare);
		
	const id = $(this).closest('.modal_order_form').find('.report_order_id').attr('data-id');

	$.ajax({
		url: 'ajax_route.php',
		type: 'POST',
		dataType: 'json',
		data: {
			oderId: id,
			route: 'editReport',
			url: 'core/action/report/edit.php',
			prepare: prepare,

		},
		success: (data) => {
			if(data.type == 'success') {
				for (key in data.res) {
					pageData.update_table_row(key, data.res[key], id);
				}
			}

			let $item = $(this).closest('.modal_order_form').find('.button-tags');
			let class_list = $item.attr('data-old-class');
			
			$(`#${id}.stock-list`).find('.res-payment-tags').find('.mark').attr('class', '').addClass(class_list).html($item.text());
			console.log(prepare);
			pageData.alert_notice(data.type, data.text);	
			
			sendAjaxHistory();

			createBackup();
		}
	});
});

});