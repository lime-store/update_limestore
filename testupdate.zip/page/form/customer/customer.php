<?php
use core\classes\Utils\Utils;

$data_page = $init->initController($page);

$page_config = $data_page['page_data_list'];

$table_result = $main->prepareData($data_page['sql'], $data_page['page_data_list']);	

echo $Render->view('/component/inner_container.twig', [
	'renderComponent' => [
		'/component/related_component/include_widget.twig' => [
			'/component/parts/input.twig' => [
				'inputClassList' => 'input btn-input width-auto create-new-customer-modal-form',
				'inputIcon' => [
					'icon' => 'las la-plus-circle'
				],
				'attr' => [
					'type' => 'button',
					'value' => 'Müştəri əlavə edin'
				]
			],
		],
		'/component/table/table_wrapper.twig' => [
			'table' => $table_result['result'],
			'table_tab' => $page,
			'table_type' => $type,
		],
	]
]);