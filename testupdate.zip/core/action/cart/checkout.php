<?php
use core\classes\Cart\Checkout;
use core\classes\dbWrapper\db;
use core\classes\Privates\AccessManager;
use core\classes\Privates\CashRegisters;
use core\classes\Privates\User;
use core\classes\Products;
use core\classes\Report;
use core\classes\Services\Notify;
use core\classes\Services\RenderTemplate;
use core\classes\Utils\Utils;

header('Content-Type: application/json');

$products = new Products;
$Checkout = new Checkout;

$postData = $_POST['data'] ?? [];

// если корзина пустая, то выводим сообщение
if(!isset($postData['cart'])) {
    return Utils::errorAbort('Səbət boşdur');
}

if(!isset($_POST['dataMode']) || Report::isValidReportType($_POST['dataMode']) == false) {
    return Utils::errorAbort('System Error');
}

$reportType            = $_POST['dataMode'];
$payment_method        = $postData['payment_method'] ?? 0;
$sales_man             = $postData['sales_man'] ?? 0;
$cart_list             = $postData['cart'];
$full_date             = $utils->getDateDMY();
$short_date            = $utils->getDateMY();
$transaction_id        = $utils::generateTransactionId();
$notify_list           = [];
$discount              = $postData['discount'] ?? 0;
$canChangePrice        = AccessManager::hasUserAccessAction('changeSalePriceOnCart', $sales_man) ?? false;
$customer_id           = $postData['customer_id'] ?? null;
$usedCashback          = $postData['used_cashback'] ?? null;
$reportCashback        = null;

if($discount) {
    $hasDiscount = AccessManager::hasUserAccessAction('canDiscount', $sales_man);
    $discountLimit = AccessManager::hasUserAccessAction('discountLimit', $sales_man);

    $getUserInfo = User::getUserInfo($sales_man);
    $getUserName = $getUserInfo['user_name'];

    if(!$hasDiscount) {
        Utils::errorAbort("Istifadəçinin ($getUserName) endirim tətbiq etmək icazəsi yoxdur");
        exit;
    }

    if($discountLimit && $discount > $discountLimit['description']) {
        $maxDiscountLimit = $discountLimit['description'];

        Utils::errorAbort("Zəhmət olmasa düzgün endirim məbləği daxil edin. max - $maxDiscountLimit%");
        exit;
    }
}


db::$dbpdo->beginTransaction();

try {
    if($reportType == 'WHOLESALE') {
        if(!isset($postData['customer_id']) || empty($postData['customer_id'])) {
            return $utils::errorAbort('Choose customer');

            exit;
        }

        $customer_id = $postData['customer_id'];

        Checkout::addWholesaleTransaction([
            'customer_id' => $customer_id,
            'transaction_id' => $transaction_id
        ]);
    }


    if($usedCashback) {
        $reportCashback = $usedCashback / count($cart_list);
    }

    foreach($cart_list as $row) {
        Checkout::validateOrder($row);

        $id = (int) $row['id'];
        // цена товара
        $order_price = $row['price'];
        // количество товара
        $order_count = $row['count'];  
        // заметка продажи
        $description = $row['description'];
        
        $stock_row = $products->getProductById($id);
        $initialStockCount = $stock_row['stock_count'];

        if($canChangePrice) {
            $order_price = $stock_row['stock_second_price'];
        }
        
        $Checkout->checkoutOrder([
            'ProductsData'      => $stock_row,
            'id'                => $id,
            'order_price'       => $order_price,
            'order_count'       => $order_count,
            'description'       => $description,
            'payment_method'    => $payment_method,
            'sales_man'         => $sales_man,
            'transaction_id'    => $transaction_id,
            'reportType'        => $reportType,
            'discount'          => $discount,
            'customer_id'       => $customer_id,
            'cashback_amount'    => $reportCashback,
        ]);

        Products::logProductStockChange(
            $id,
            $stock_row['stock_count'],
            ($initialStockCount - $order_count),
            'sales',
            $transaction_id
        );        


        $notify_count = $stock_row['stock_count'] - $order_count;

        if($notify_count < 3) {
            $text = $stock_row['stock_name'];
            $NotifyType = 'almostOutOfStock'; 

            if($notify_count <= 0) {
                $NotifyType = 'outOfStock'; 
                $text = $stock_row['stock_name'] . ' ' .$stock_row['stock_phone_imei'];
            } 
        
            Notify::addNotify([
                'type' => $NotifyType,
                'text' => $text,
                'id' => $id
            ]);

            array_push($notify_list, Notify::getLastAddedNotify());
        }
    }

    CashRegisters::deposit(
        Report::getOrderTotalByTransactionId($transaction_id),
        'sales',
        User::getCurrentUser('get_id'),
        $payment_method,
        $transaction_id
    );

    db::$dbpdo->commit();
}
catch(\Exception $e) {  
    db::$dbpdo->rollBack();

    return Utils::errorAbort($e->getMessage());
}



$notify_tmp = '';

if($notify_list) {
    foreach($notify_list as $key => $row) {
        $notify_tmp.= RenderTemplate::view('/component/notify/notify-items.twig', [
            'data' => $row
        ]);
    }    
}

return $utils::abort([
    'type' => 'success',
    'text' => 'Ok!',
    'notifyList' => $notify_tmp
]);
