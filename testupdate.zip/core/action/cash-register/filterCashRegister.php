<?php

use core\classes\Privates\CashRegisters;
use core\classes\System\Init;
use core\classes\System\Main;
use core\classes\Utils\Utils;

$controllerData = Init::getControllerData(CashRegisters::$controllerIndex);

$data_page = $controllerData->getAllData();


$paymentMethod = $_POST['paymentMethod'] ?? null;
$date = $_POST['date'] ?? false;

$result = CashRegisters::filter($date, $paymentMethod);
$result = Utils::formatReferenceList($result, 'amount_change', 'type');

$data = Main::prepareCustomData($result, $data_page['page_data_list']);



$table = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_row.twig' => [
            'table' => $data['result'],
            'table_tab' => '',
            'table_type' => '',       
        ]
    ]
]);

echo json_encode([
    'table' => $table,
]);