<?php

use core\classes\Services\Customer\Customer;
use core\classes\Utils\Utils;

if(empty($_POST['prepare_data']['id'])) {
    Utils::errorAbort('Такого пользователя нет');
}

return Customer::edit($_POST['prepare_data']);
