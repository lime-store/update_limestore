<?php
header('Content-type: Application/json');

use core\classes\Utils\Utils;

$html = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/modal/custom_modal/u_modal.twig' => [
            'containerClassList' => 'small-modal',
            'modalController' => [
                'title' => 'Yeni sessiya',
                'closeButtonClassList' => 'removeModal',
            ],
            'modalContent' => [
                'classList' => 'modal-form',
                'path' => '/component/form/fields/inventory/create-session.twig',
            ],
        ]
    ]
]);

Utils::abort([
    'res' => $html,
]);