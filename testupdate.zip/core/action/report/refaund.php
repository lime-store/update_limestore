<?php

use Core\Classes\System\Init;
use Core\Classes\Utils\Utils;
header('Content-type', 'Application/json');
$report = new \Core\Classes\Report;

if(empty($_POST['report_id'])) {
	return Utils::errorAbort('Emty result');
}

$reportId = $_POST['report_id'];
$getReport = $report::getReportById($reportId);

if(!empty($_POST['sendData'])) {	
	if(empty($_POST['refaundQuantity'])) {
		return Utils::errorAbort('Xəta: malın qaytarma miqdarı qeyd edin');
	}
		
	if($getReport['max_refaund_quantity'] <= 0) {
		return Utils::errorAbort("Xəta: bu mal artıq qaytarılıb");	
	}
	
	if($_POST['refaundQuantity'] <= 0) {
		return Utils::errorAbort('Xəta: minimum qaytarma miqdarı 1');
	}

	if($report::canRefaundQuantity($reportId, $_POST['refaundQuantity']) == false) {
		return Utils::errorAbort("Xəta: maksimum qaytarma miqdarı - " . $getReport['max_refaund_quantity']);	
	}
	
	
	$refaundQuantity = $_POST['refaundQuantity'];
	if($report->refaundOrder($reportId, $refaundQuantity)) {
		$report->setReportEditableState($reportId, false);

		$report::decreaseRefaundQuantity([
			'report_id' => $reportId,
			'refaund_quantity' => $refaundQuantity
		]);
	
		$table_result = $main->prepareCustomData($report->getLastReport(), Init::getControllerData('report')->getAllData()['page_data_list']);

		$table = $Render->view('/component/include_component.twig', [
			'renderComponent' => [
				'/component/table/table_row.twig' => [		
					'table' => $table_result['result'],
					'table_tab' => 'report',
					'table_type' => 'phone'
				]
			]
		]);	
	
		return $utils::abort([
			'type' => 'success',
			'text' => 'Ok',
			'table' => $table,
		]);	
	} 	

}

	if(!empty($_POST['getModal'])) {
		$total = $Render->view('/component/include_component.twig', [
			'renderComponent' => [
				'/component/modal/custom_modal/u_modal.twig' => [
					'containerClassList' => 'small-modal',
					'modalController' => [
						'title' => 'Malı geri qaytarmaq',
						'closeButtonClassList' => 'removeModal',
					],
					'modalContent' => [
						'path' => '/component/modal/fields/report/refaund_modal_fields.twig',
					],
					'reportData' => $getReport
				]  
			]
		]);

		return Utils::abort([
			'res' => $total
		]);
	}

	


	


