<?php

use core\classes\System\Constants;

include $_SERVER['DOCUMENT_ROOT'].'/start.php';

/**
 * 
 * В этом файле будем икнлюжить файлы для миграции базы данных 
 * 
 */

//0.014.php
require 'migrationFile/0.014.php';

//  0.015
// require 'migrationFile/0.015.php';

// 0.016
require 'migrationFile/0.016.php';

// 0.017
require 'migrationFile/0.017.php';

// 0.019
require 'migrationFile/0.019.php';

//0.020

//0.021
require 'migrationFile/0.021.php';

//0.025
require 'migrationFile/0.025.php';

//0.032
require 'migrationFile/0.032.php';

// 0.033
require 'migrationFile/0.033.php';

// 0.034
require 'migrationFile/0.034.php';

// 0.034.1.php
require 'migrationFile/0.034.1.php';

// 0.035.php
require 'migrationFile/0.035.php';

// 0.034 CLOUD
// require Constants::CLOUD_MIGRATION_FILE_DIR."cloud_0.034.php";
// require Constants::CLOUD_MIGRATION_FILE_DIR."local_cloud_0.034.php";