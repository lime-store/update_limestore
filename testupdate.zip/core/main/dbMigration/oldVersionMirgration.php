<?php
include $_SERVER['DOCUMENT_ROOT'].'/start.php';

/**
 * 
 * В этом файле будем икнлюжить файлы для миграции базы данных 
 * 
 */

//0.014.php
require 'migrationFile/0.014.php';

//  0.015
// require 'migrationFile/0.015.php';

// 0.016
require 'migrationFile/0.016.php';

// 0.017
require 'migrationFile/0.017.php';

// 0.019
require 'migrationFile/0.019.php';

//0.020

//0.021
require 'migrationFile/0.021.php';


//0.025
require 'migrationFile/0.025.php';
