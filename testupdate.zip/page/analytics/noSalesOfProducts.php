<?php
use Core\Classes\Report;
use Core\Classes\Utils\Utils;

$report_date_list = $main->getReportDateList([
	'table_name' 	=> 'stock_order_report',
	'col_name' 		=> 'order_my_date',
	'order'			=> 'order_real_time DESC',
	'query'			=> ' WHERE order_stock_count > 0 AND stock_order_visible = 0 ',
	'default'		=> date('m.Y')
]);

$topSellingProductsOfLastThreeMonth = Report::getNoSalesProductsOfInterval(3, 'total_count');

echo $Render->view('/component/inner_container.twig', [
    'renderComponent' => [
        '/component/include_once_component.twig' => [
            'includs' => [               
                [
                    '/component/related_component/include_widget.twig' => [
                        '/component/buttons/select/select-button.twig' => [
                            'main' => [
                                'class_list' => [
                                    'init_element' => ' widget-fields ',
                                    'container' => ' widget-fields-container',
                                    'input_parent' => 'width-100 input-dropdown-parent'
                                ]
                            ],
                            'input' => [
                                'label' => 'Axtar',
                                'icon' => 'las la-calendar-alt',
                                'class_list' => ' scroll-auto form-input area-button input-dropdown',
                                'attribute' => [
                                    'type' => 'button',
                                    'placeholder' => 'Some'
                                ]
                            ],
                            'list' => [
                                'class_list' => [
                                    'container' => 'form-fields-autocomplete ',
                                    'ul_list' => 'width-100 select-list unset-min-width',
                                    'list_item_container' =>'',
                                    'list_item_link' => 'selectable-search-item area-closeable select-category-id select-hidden-fields-input input-dropdown-auto-list-li  load-analytics-no-selling-products-on-table'
                                ],
                                'default_first' => true,                    
                                'list_data' => [
                                    [
                                        'custom_value' => 'Son 3 ayda satışı olmayan məhsullar',
                                        'custom_data_id' => '3'
                                    ],
                                    [
                                        'custom_value' => 'Son 1 ayda satışı olmayan məhsullar ',
                                        'custom_data_id' => '1'
                                    ],                                    
                                    [
                                        'custom_value' => 'Son 6 ayda satışı olmayan məhsullar',
                                        'custom_data_id' => '6'
                                    ], 
                                    [
                                        'custom_value' => 'Son 12 ayda satışı olmayan məhsullar',
                                        'custom_data_id' => '12'
                                    ],                                                                        
                                ],
                            ]
                        ],                      
                    ],
                    '/component/table/table_wrapper.twig' => [
                        'table' => $main->compareData($topSellingProductsOfLastThreeMonth, [
                            'get_data' => [
                                'id' 				=> 'stock_id',
                                'name'			 	=> 'stock_name',
                                'description' 		=> 'stock_phone_imei',
                                'first_price'		=> 'stock_first_price',
                                'second_price' 		=> 'stock_second_price',
                                'count'				=> 'stock_count',
                                'stock_barcode'		=> 'barcode_value',
                            ]
                        ]),
                        'table_tab' => $page,
                        'table_type' => $type,
                    ],                                    
                ]
            ]
        ],
    ]
]);
