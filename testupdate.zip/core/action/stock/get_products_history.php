<?php
use core\classes\Products;
use core\classes\Services\Warehouse\Traits\Arrival;
use core\classes\Utils\Utils;
use core\classes\System\Main;
use core\classes\Traits\TableHeaderList as TH;

header('Content-type: Application/json');

if(isset($_POST['v']) && $_POST['v'] == 'new') {
    $stock_id = $_POST['data'];
    
    $products = Products::getProductById($stock_id);
    $list = Products::getProductHistory($stock_id);
    
    usort($list, function($a, $b) {
        return  strtotime($a['created_at']) <=> strtotime($b['created_at']);
    });
    
    $list = Utils::formatReferenceList($list, 'quantity_change', 'reference_type');
    
    
    $data = Main::compareData($list, [
        'sort_key' => 'id',
        'get_data' => [
            'id'               => 'id',
            'date'             => 'created_at',
            'transaction'      => 'reference_id',
            'username'         => 'user_name',
            'reference_type'   => 'reference_type',
            'before'           => 'quantity_before',
            'change'           => 'quantity_change',
            'final_count'      => 'quantity_after',
            'showTransaction'  =>  'reference_id',
        ],
        'get_data@template' => [
            'id'                => TH::getTableHeaderByTemplate('id', 'th_w40', [
                'link_class'    => 'stock-link-text-both'
            ]),
            'date'              => TH::getTableHeaderByTemplate('Tarix', 'width-auto', [
                'link_class'    => 'stock-link-text-both'
            ]),
            'username'          => TH::getTableHeaderByTemplate('Satıcı', 'width-auto', [
                'link_class'    => 'mark mark-tags mark-text mark-primary',
                'hideIfNotValue'    => true,
            ]),
            'transaction'       => TH::getTableHeaderByTemplate('Transaksiya kodu', 'width-atuo hide', [
                'link_class'    => 'stock-link-text-both',
                'td_class' 			=> 'hide',            
            ]),        
            'reference_type'     => TH::getTableHeaderByTemplate('Əməliyyat növü', 'width-auto', [
                'link_class'    => 'stock-link-text-both reference-type'
            ]),
            'before'     => TH::getTableHeaderByTemplate('Əvvəlki miqdar', 'th_w100', [
                'link_class'    => 'stock-link-text-both'
            ]),
            'change'     => TH::getTableHeaderByTemplate('Miqdar dəyişikliyi', 'th_w120', [
                'link_class'    => 'mark mark-tags mark-text',
                'mark'				=> array(
                    'mark_text' 		=> '',
                    'mark_modify_class' => '',
                    'mark_operation_class' => true
                )              
            ]),
            'final_count'           => TH::getTableHeaderByTemplate('Qalıq', 'th_w120', [
                'link_class'    => 'stock-link-text-both'
            ]),
            'showTransaction'     => TH::getTableHeaderByTemplate(false, 'th_w100', [
                'hideIfNotValue'     => true,
                // 'is_title' 			=> 'Redaktə',
                'modify_class' 	    	=> 'th_w60',
                'td_class' 			=> 'table-ui-reset',
                'link_class' 		=> 'las la-eye btn btn-secondary width-100 table-ui-btn tr-hide-value product-history-show-transaction',
                'data_sort' 		=> '',
                'mark'				=> false
            ]),        
        ]
    ]);
    
    $total = $Render->view('/component/include_component.twig', [
        'renderComponent' => [
            '/component/modal/custom_modal/u_modal.twig' => [
                'modalController' => [
                    'title' => "Məhsulun tarixçəsi",
                    'closeButtonClassList' => 'removeModal',
                ],
                'modalContent' => [
                    'path' => '/component/include_once_component.twig',
                ],
                'includs' => [
                    'b' => [
                        '/component/buttons/button.twig' => [
                            'btn_attr_list' => [
                                'v'          => 'archive',
                                'class'      => 'load-product-history input btn-input btn-warning width-auto',
                                'data-value' => $stock_id
                            ],
                            'btn_text' => 'Arxivi yuklə'
                        ]
                    ],
                    'd' => [
                        // '/component/widget/title.twig' => [
                        //     'title' => 'dsd',
                        //     'classList' => 'margin-0 mrgn-top-100 sub-title',
                        // ],
                        '/component/table/table_wrapper.twig' => [
                            'table' => $data
                        ],
                    ]
                ],
                'containerClassList' => 'large-modal',  
            ]  
        ]
    ]);
    
    
    $utils::abort([
        'res' => $total,
    ]);
}

if(isset($_POST['v']) && $_POST['v'] == 'archive') {
    $stock_id = $_POST['data'];
    
    $products = Products::getProductById($stock_id);
    
    $data_page = $init->initController('productHistory');
    
    
    $allData = [
        Arrival::getArrivalByProductId($stock_id),
        Arrival::getWriteOffByProductId($stock_id),
        Arrival::getTransferByProductId($stock_id),
        Arrival::getSalesById($stock_id),
        Arrival::getReturnSalesById($stock_id)
    ];
    
    // Utils::log(Arrival::getArrivalByProductId($stock_id));
    // echo "=============";
    // Utils::log(Arrival::getWriteOffByProductId($stock_id));
    // echo "=============";
    // Utils::log(Arrival::getTransferByProductId($stock_id));
    // echo "=============";
    // Utils::log(Arrival::getSalesById($stock_id));
    // echo "=============";
    // Utils::log(Arrival::getReturnSalesById($stock_id));
    
    // exit;
    
    $result = array_merge(...$allData);
    
    
    // asc
    usort($result, function($a, $b) {
        return  strtotime($a['full_date']) <=> strtotime($b['full_date']);
    });
    
    $stock = 0; 
    
    foreach ($result as &$item) {
        // Нормализуем count
        $cnt = $item['count'];
        $cnt = (float) str_replace('+', '', $cnt);
    
        // Применяем операцию
        $stock += $cnt;
    
        // Записываем остаток после операции
        $item['after_balance']  = Utils::prettyPrintNumber($stock);
        $item['stock_name']     = $products['stock_name'];
        $item['stock_id']       = $products['stock_id'];
        $item['product_unit']   = $products['product_unit'];
    }
    
    
    $table_result = Main::prepareCustomData($result, $data_page['page_data_list']);
    
    $total = $Render->view('/component/include_component.twig', [
        'renderComponent' => [
            '/component/modal/custom_modal/u_modal.twig' => [
                'modalController' => [
                    'title' => 'Məhsulun tarixçəsi',
                    'closeButtonClassList' => 'removeModal',
                ],
                'modalContent' => [
                    'path' => '/component/table/table_wrapper.twig',
                ],
                'containerClassList' => 'large-modal',
                'class_list' => '', 
                'table' => $table_result['result'],   
            ]  
        ]
    ]);
    
    
    $utils::abort([
        'res' => $total,
    ]);
}
