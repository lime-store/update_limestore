<?php 
namespace core\Cloud\classes;

use core\classes\dbWrapper\queryBuilder as qb;

class CloudApi 
{
    public static function authBranch($headers) 
    {
        $auth = $headers['Authorization'] ?? '';

        if (!preg_match('/Bearer\s+(.+)/', $auth, $m)) {
            http_response_code(401);
            exit(json_encode(['error' => 'no token']));
        }

        $token = $m[1];

        $branch = Branch::getBranchByToken($token);
        
        if($branch) {
            return $branch;
        } else {
            http_response_code(403);
            exit(json_encode(['error' => 'invalid token']));            
        }
    }


    public static function updateTask($data, $branchId)
    {          
    }
    
}