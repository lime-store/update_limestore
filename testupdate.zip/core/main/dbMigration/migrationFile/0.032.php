<?php

use Core\Classes\System\Migration;

Migration::modifyColumn('stock_order_report',   'order_stock_count', 'decimal(10, 2)');
Migration::modifyColumn('stock_list',           'stock_count',       'decimal(10, 2)');
Migration::modifyColumn('arrival_products',     'count',             'decimal(10, 2)');
Migration::modifyColumn('write_off_products',   'count',             'decimal(10, 2)');
Migration::modifyColumn('transfer_list',        'count',             'decimal(10, 2)');


$report_add_discount_column = [
    'discount' => 'int(11) NOT NULL'
];

Migration::hasTableColumnExist('stock_order_report', $report_add_discount_column, function($notExistData) {
    if($notExistData) {
        Migration::alertTableColumn('stock_order_report', $notExistData);
    }
});



 $append_products_unit_v032 = [
    'product_unit'         => 'int(11) NOT NULL DEFAULT 1'
];

Migration::hasTableColumnExist('stock_list', $append_products_unit_v032, function($notExistData) {
    if($notExistData) {
        Migration::alertTableColumn('stock_list', $notExistData);
    }
});


Migration::hasTableColumnExist('stock_order_report', array('product_unit' => 'varchar(128) NOT NULL'), function($res) {
    if($res == false) {
        Migration::dropTableColumn('stock_order_report', 'product_unit');
    }
});