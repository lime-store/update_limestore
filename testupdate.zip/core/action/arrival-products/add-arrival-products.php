<?php 

include $_SERVER['DOCUMENT_ROOT'] . '/function.php';

if(empty($_POST['list'])) {
    return alert_error('Səbət boşdur');
    exit;
}



$list = $_POST['list'];

foreach($list as $key => $row) {
    ls_db_upadte([
        'before' => ' UPDATE stock_list SET ',
        'after'  => ' WHERE stock_id = :id ',
        'post_list' => [
            'stock_id' => [
                'query' => false,
                'bind' => 'id'
            ],
            'count' => [
                'query' => ' stock_count = stock_count + :add_count ',
                'bind' => 'add_count'
            ]
        ]
    ], [
        'stock_id' => $row['id'],
        'count' => $row['count']
    ]);
}