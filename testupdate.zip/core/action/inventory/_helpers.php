<?php

use core\classes\Inventory\InventorySession;
use core\classes\Services\RenderTemplate;

/**
 * Перевод сообщений исключений классов Inventory/InventorySession
 * с русского на азербайджанский (язык интерфейса проекта).
 */
function inventoryErrorMessage(\Throwable $e): string
{
    $messages = [
        'Инвентаризация не найдена'                                             => 'Sayim tapılmadı',
        'Отменить можно только активную инвентаризацию'                         => 'Yalnız aktiv sayımı ləğv etmək olar',
        'Сначала закройте или отмените открытую сессию'                          => 'Əvvəlcə açıq sessiyanı bağlayın və ya ləğv edin',
        'Инвентаризация уже закрыта или отменена'                                => 'Sayım artıq bağlanıb və ya ləğv edilib',
        'Сначала закройте открытую сессию, прежде чем завершать инвентаризацию'  => 'Sayımı bitirmək üçün əvvəlcə açıq sessiyanı bağlayın',
        'Сессия не найдена'                                                      => 'Sessiya tapılmadı',
        'Инвентаризация не активна, нельзя открыть сессию'                       => 'Sayım aktiv deyil, sessiya açmaq mümkün deyil',
        'Уже есть открытая сессия — сначала закройте её'                         => 'Artıq açıq sessiya var — əvvəlcə onu bağlayın',
        'Сессия закрыта, сканирование недоступно'                                => 'Sessiya bağlanıb, skan etmək mümkün deyil',
        'Идёт ручная проверка — сканирование временно недоступно'                => 'Əl ilə yoxlama gedir — skan etmək müvəqqəti mümkün deyil',
        'Товар не найден в stock_list'                                           => 'Mal tapılmadı',
        'Сессия закрыта'                                                         => 'Sessiya bağlanıb',
        'Сессия недоступна для правки'                                           => 'Sessiyada düzəliş mümkün deyil',
        'Позиция не найдена в этой сессии'                                       => 'Bu sessiyada mövqe tapılmadı',
        'Сессия уже закрыта или отменена'                                        => 'Sessiya artıq bağlanıb və ya ləğv edilib',
        'Отменить можно только открытую сессию'                                  => 'Yalnız açıq sessiyanı ləğv etmək olar',
        'Остались не посчитанные товары'                                         => 'Bəzi mallar hələ sayılmayıb',
    ];

    $message = $e->getMessage();

    if (isset($messages[$message])) {
        return $messages[$message];
    }

    if (preg_match('/^Товар со штрихкодом .* не найден$/', $message)) {
        return 'Barkod tapılmadı';
    }

    return $message;
}

/**
 * Рендер таблицы позиций сессии (используется на странице, при скане,
 * после ручной правки и при старте проверки).
 *
 * $scanMode — режим экрана сканирования: показываем только последние 50
 * отсканированных товаров (по времени скана, свежие сверху). Без $scanMode
 * список зависит от состояния сессии: во время ручной проверки (review)
 * показываются ВСЕ позиции по названию.
 */
function renderInventorySessionItems(int $sessionId, bool $scanMode = false): array
{
    $session = InventorySession::find($sessionId);
    $review  = !empty($session['review_started_at']) && $session['status'] === InventorySession::STATUS_OPEN;

    if ($scanMode) {
        $items  = InventorySession::items($sessionId, 'updated_desc', 50);
        $review = false;
    } elseif ($review) {
        $items = InventorySession::items($sessionId, 'name_asc');
    } else {
        $items = InventorySession::items($sessionId, 'updated_desc', 50);
    }

    $html = RenderTemplate::view('/component/include_component.twig', [
        'renderComponent' => [
            '/component/inventory/session_items.twig' => [
                'items'      => $items,
                'review'     => $review,
                'session_id' => $sessionId,
            ]
        ]
    ]);

    return ['items_table' => $html, 'review' => $review];
}

/**
 * Рендер одной строки таблицы позиций сессии (режим сканирования) —
 * после скана строка добавляется в начало списка без перерисовки всей таблицы.
 */
function renderInventorySessionRow(int $sessionId, int $stockId): string
{
    $item = InventorySession::item($sessionId, $stockId);

    return RenderTemplate::view('/component/include_component.twig', [
        'renderComponent' => [
            '/component/inventory/session_item_row.twig' => [
                'item'       => $item,
                'session_id' => $sessionId,
            ]
        ]
    ]);
}

/**
 * Рендер модалки итогового отчёта инвентаризации.
 */
function renderInventoryReportModal(array $report): string
{
    $statusText = [
        \core\classes\Inventory\Inventory::STATUS_ACTIVE    => 'Aktiv',
        \core\classes\Inventory\Inventory::STATUS_COMPLETED => 'Tamamlanıb',
        \core\classes\Inventory\Inventory::STATUS_CANCELLED => 'Ləğv edilib',
    ];

    return RenderTemplate::view('/component/include_component.twig', [
        'renderComponent' => [
            '/component/inventory/report_modal.twig' => [
                'report'               => $report,
                'inventory_status_text'=> $statusText[$report['inventory']['status']] ?? $report['inventory']['status'],
            ]
        ]
    ]);
}

/**
 * Рендер модалки-предложения: остались товары, которые не посчитали
 * ни в одной сессии — добавить их в новую сессию (counted = 0).
 */
function renderInventoryMissingModal(int $inventoryId, array $missingItems, array $inventory): string
{
    return RenderTemplate::view('/component/include_component.twig', [
        'renderComponent' => [
            '/component/inventory/missing_modal.twig' => [
                'inventory_id'  => $inventoryId,
                'inventory'     => $inventory,
                'missing_items' => $missingItems,
            ]
        ]
    ]);
}