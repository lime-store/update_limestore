<?php
use Core\Classes\Report;
use core\classes\Services\tableFooter;
use Core\Classes\System\Main;
use Core\Classes\Utils\Utils;

$data_page = $init->initController($page);

$page_config = $data_page['page_data_list'];


$report_date_list = $main->getReportDateList([
	'table_name' 	=> 'stock_order_report',
	'col_name' 		=> 'order_my_date',
	'order'			=> 'order_real_time DESC',
	'query'			=> ' WHERE order_stock_count > 0 AND stock_order_visible = 0 ',
	'default'		=> date('m.Y')
]);

$date_list = array_map(function($key) {
    return [
        'custom_value' => $key,
        'custom_data_id' => $key
    ];
}, $report_date_list);

$table_result = $main->prepareData($data_page['sql'], $data_page['page_data_list']);

$topSellingProductsOfLastThreeMonth = Report::getReportBySeller(Utils::getDateMY());

echo $Render->view('/component/inner_container.twig', [
    'renderComponent' => [
        '/component/include_once_component.twig' => [
            'includs' => [
                [
                    '/component/pulgin/charts/chartsScript.twig' => []
                ],
                [
                    '/component/related_component/include_widget.twig' => [
                        '/component/buttons/select/select-button.twig' => [
                            'main' => [
                                'class_list' => [
                                    'init_element' => ' widget-fields ',
                                    'container' => ' widget-fields-container th_w200',
                                    'input_parent' => 'width-100 input-dropdown-parent'
                                ]
                            ],
                            'input' => [
                                'label' => 'Axtar',
                                'icon' => 'las la-calendar-alt',
                                'class_list' => ' scroll-auto form-input area-button input-dropdown',
                                'attribute' => [
                                    'type' => 'button',
                                    'placeholder' => 'Some'
                                ]
                            ],
                            'list' => [
                                'class_list' => [
                                    'container' => 'form-fields-autocomplete ',
                                    'ul_list' => 'width-100 select-list unset-min-width',
                                    'list_item_container' =>'',
                                    'list_item_link' => 'selectable-search-item area-closeable select-category-id select-hidden-fields-input input-dropdown-auto-list-li load-multiple-charts load-analytics-top-seller-on-table',
                                    'item_icon' => 'las las la-calendar-alt',
                                ],
                                'default_first' => true,                    
                                'list_data' => $date_list
                            ]
                        ],
                    ]
                ],                 
                [
                    '/component/pulgin/charts/pieChartsContainer.twig' => [ 
                        'includs' =>[                    
                            [
                                '/component/pulgin/charts/chartsLoader.twig' => [
                                    'classList' => 'reloadTopProducts lineCharts ',
                                    'wrapperClassList' => 'width-100 chartsWrapper',
                                    'chartsType' => 'bar',
                                    'chartsName' => 'analyticsChartsTopSellerByInterval',
                                    'scriptUrl' => 'core/action/analytics/charts-top-seller-interval.php',
                                    'scriptRoute' => 'analyticsChartsTopSellerByInterval',
                                    'dataValue' => 'total_sales',
                                    'setLabel' => 'Ən çox satan',
                                    'chartOption' => [
                                        'maintainAspectRatio' => false,
                                    ]
                                ]					
                            ], 
                            [
                                '/component/pulgin/charts/chartsLoader.twig' => [
                                    'classList' => 'reloadTopProducts doughnutCharts',
                                    'wrapperClassList' => 'width-100 chartsWrapper',
                                    'chartsType' => 'doughnut',
                                    'chartsName' => 'analyticsChartsTopSellerByInterval2',
                                    'scriptUrl' => 'core/action/analytics/charts-top-seller-interval.php',
                                    'scriptRoute' => 'analyticsChartsTopSellerByInterval',
                                    'dataValue' => 'total_sales',
                                    'setLabel' => 'Ən çox satan',
                                    'chartOption' => [
                                        'plugins' => [
                                            'legend' => [
                                                'display' => false
                                            ]
                                        ]
                                    ]                                               
                                ]					
                            ],                                                           
                        ]
                    ]
                ],
                [
                    '/component/related_component/include_widget.twig' => [
                        // '/component/widget/title.twig' => [
                        //     'title' => 'ən çox satılan məhsullar (mənfəət olaraq)',
                        //     'classList' => 'margin-0 mrgn-top-100 sub-title',
                        // ],
                    ],                    
                    '/component/table/table_wrapper.twig' => [
                        'table' => $main->compareData($topSellingProductsOfLastThreeMonth, [
                            'get_data' => $page_config['custom_get_data']['get_date_seller']
                        ]),
                        'table_tab' => $page,
                        'table_type' => $type,
                        'attribute' => [
                            'data-route-id' => 'some-route-id'
                        ]
                        // 'classList' => 'stock-list'
                    ],
                    // '/component/table/table_footer_wrapper.twig' => [
                    //     'table_total' => tableFooter::getData(['total_amount', 'total_profit'], $topSellingProductsOfLastThreeMonth)
                    // ],                                    
                ],
            ]
        ],
    ]
]);
