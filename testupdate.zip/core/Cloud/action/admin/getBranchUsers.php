<?php

use core\classes\Privates\User;

header('Content-Type: application/json');

$branchId = $_POST['branchId'];
$controllerIndex = $_POST['page'];

$get_page = $init->initController($controllerIndex);

$page_config = $get_page['page_data_list'];

$data = User::getUsersByBranchId($branchId);

$table = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_row.twig' => [
            'table' => $main->compareData($data, $page_config),
            'table_tab' => $controllerIndex,
            'table_type' => ''       
        ]
    ]
]);


return $utils::abort([
    'table' => $table
]);