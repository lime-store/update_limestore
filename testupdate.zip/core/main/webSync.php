<?php 
use core\classes\dbWrapper\db;
use Core\Classes\Privates\User;
use Core\Classes\Utils\Utils;
use Core\Classes\System\System;
header('Content-type: application/json');

// получаем настройку синхронизацию
$settings = db::select([
    'table_name' => 'function_settting',
    'col_list' => '*',
    'query' => [
        'body' => ' WHERE sett_name = :appSync '
    ],
    'bindList' => [
        ':appSync' => 'appSync'
    ]
])->first()->get();

// если синх.. отключена, то останавливаем скрипт
if($settings['sett_on'] == false) {
    exit;
    die;
}

System::hasTokenAvailable(function($res) {
    if($res == false) {
        $generatedToken = System::generateToken();
        System::setToken($generatedToken);

        // отправляем созданный токен в api 
        Utils::apiSend([
            'body' => [
                'id'        => $generatedToken,
            ],
            'type'   => 'POST',
            'uri'    => 'https://lime-server.vercel.app/api/users/add'
        ]);

        // отправляем данные в api
        Utils::apiSend([
            'body' => [
                'id'        => $generatedToken,
                'username'  => User::getCurrentUser('get_name'),
                'password'  => User::getCurrentUser('get_password'), 
                'activated' => true,
            ],
            'type'   => 'PUT',
            'uri'    => 'https://lime-server.vercel.app/api/users/edit'
        ]);
    }
});

$token = System::getToken();

$exp = db::select([
    'table_name' => 'rasxod',
    'col_list'	=> " rasxod_id as expense_id, 
                     rasxod_day_date as expense_full_date,
                     rasxod_year_date as expense_short_date,
                     rasxod_money as expense_sum,
                     rasxod_description as expense_description             
    ",
    'query' => array(
        'base_query' =>  " WHERE  rasxod_visible !=1  ",
        'body' =>  " ",
        "joins" => " ",									  
        'sort_by' => " 	GROUP BY rasxod_id DESC  
                        ORDER BY rasxod_id DESC 
        ",
    'bindList' => array()
    )    
])->get();

$prod = db::select([
    'table_name' => 'stock_list',
    'col_list' => '*',
    'query' => [
        'body' => ' WHERE stock_visible = 0 ',
        'sort_by' => 'GROUP BY stock_id DESC ORDER BY stock_id DESC ',
        // 'limit' => 'limit 50'
    ]
])->get();


$rep = db::select([
    'table_name' => '  stock_order_report ',
    'col_list'	=> 'order_stock_id, 
                    order_stock_name, 
                    stock_phone_imei as product_description,
                    order_stock_count as order_count, 
                    order_stock_sprice as order_price, 
                    order_stock_total_price as order_total_price, 
                    order_total_profit, 
                    order_date as order_full_date, 
                    order_my_date as order_short_date,
                    order_who_buy as order_description,
                    transaction_id,
                    stock_list.stock_id                    
                    ',

    'query' => array(
        'base_query' =>  " INNER JOIN stock_list ON stock_list.stock_id  != 0 
                            AND stock_order_report.stock_order_visible = 0
        ",
        'body' =>  " AND stock_order_report.stock_id = stock_list.stock_id
                      AND stock_order_report.order_stock_count > 0
                        ",
        "joins" => "    LEFT JOIN payment_method_list ON payment_method_list.id = stock_order_report.payment_method                                  
                        ",		
        'sort_by' => " GROUP BY stock_order_report.order_stock_id DESC
                       ORDER BY stock_order_report.order_stock_id DESC LIMIT 3000",
    ),
    'bindList' => []      
])->get();


Utils::apiSend([
    'body'      => [
        'token'     => $token,
        'data'      => $exp,
    ],
    'type'      => 'POST',
    'uri'       => 'https://lime-server.vercel.app/api/expenses' 
]);


Utils::apiSend([
    'body'      => [
        'token'     => $token,
        'data'      => $prod,
    ],
    'type'      => 'POST',
    'uri'       => 'https://lime-server.vercel.app/api/products' 
]);


Utils::apiSend([
    'body'      => [
        'token'     => $token,
        'data'      => $rep,
    ],
    'type'      => 'POST',
    'uri'       => 'https://lime-server.vercel.app/api/reports' 
]);