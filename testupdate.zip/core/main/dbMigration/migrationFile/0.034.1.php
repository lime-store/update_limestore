<?php 
use core\classes\dbWrapper\updateBuilder;

updateBuilder::table('cash_registers')
              ->set('payment_method', 1)
              ->where('payment_method', 0)
              ->execute();              