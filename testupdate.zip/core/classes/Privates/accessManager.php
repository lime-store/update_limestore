<?php 
namespace core\classes\Privates;

use core\classes\Utils\Utils;
use core\classes\dbWrapper\db;
use core\classes\Privates\User;
use core\classes\System\Main;


/**
*	Роли: 
*		У каждого пользователя есть своя роль
*		Первая и основаная роль это - Администаротор (admin)
*		Втораая роль Старший продавец - admin_seller
*		Третья роль младший продавец - seller
*	
*	
*	Привилегии:
*		admin - по дефолту имеет доступ ко всем функциям
*			и страницам, ко всем данным, запретить что ли бо админу НЕ ВОЗМОЖНО.
*			- Админ может назначать роли пользователям
*			- Удалять и добавлять новых пользователей
*			- Редактировать их данные
*			- Ограничть просморт страниц для определенного юзера
*			- Ограничить просмотрт данных для опрделенного юзера
*			- Продавать товар
*			- Добавлять товар в базу/удалять товары из базы
*			- Смотреть отчет о продажах
*			- Делать возварты товаров
*			- Приоритетная роль (роль юзера чии привилегии выше) - нет  
*
*		admin_seller - по дефолту имеет доступ ко всем функциям
*			и страницам, ко всем данным. Admin может настроить права для этой категории пользователя
*			- Может смотерть данные юзеров, пароли и другую информацию
*			- не может редактировать данные пользователей
*			- не может добавлять новых юзеров и удалять юзеров
*			- Не может назначать роли пользователям
*			- может добавлять товар в базу
*			- может редактировать и удалять товары с базы
*			- может делать продажи товара
*			- может смотреть отчет продажи
*			- не может удалять или делать возврат продажи
*			- Приоритетная роль (роль юзера чии привилегии выше) - admin
*
*		seller - по дефолту имеет доступ ко всем страницам и данным таблицы
*			- Не может смотреть данные юзеров, редактировать информацию 
*			  добавлять новых юзеров и удалять
*			- Не может добавлять товар в склад
*			- Не может редактировать и удалять товар
*			- Не может удалить отчет о продажах  и сделать возврат
*			- Может сделать продажу товара
*			- Приоритетная роль (роль юзера чии привилегии выше) - admin, admin_seller
*
*						
*
*/
class AccessManager extends User
{    

    /**
     * @return boolean 
     * true данных нет в базе и они НЕ запрещены
     * false данные есть в базе и они запрещены
     */
    public static function isDataAvailable($dataName) 
    {
        //id пользователя из сессии
        $user_id = User::getCurrentUser('get_id');	

        $res = db::select([
            'table_name' => 'user_control',
            'col_list' => '*',
            'query' => [
                'base_query' => ' 
                    INNER JOIN access_data ON access_data.data_name = :dataName AND access_data.user_id = :user_id                 
                ',

                // 'sort_by' => 'GROUP BY data_td_accsess.td_id DESC '                            
            ],
            'bindList' => [
                ':dataName' => $dataName,
                ':user_id' => $user_id  
            ]
            ], ['bindType' => 'bindValue'])->get();

        return count($res) > 0 ? false : true;
    }

     
    /**
     * проверяем и выводим название таблицы
     * 
     * old function name  check_th_return_name
     */
    public static function checkDataPremission($dataName) 
    {
        $checkedData = self::isDataAvailable($dataName);

        if ($checkedData == false) {
            return false;
        }
        
        $restrictedData = self::getRestrictedDataList();

        foreach ($restrictedData as $key => $row) {
            if ($row['id'] == $dataName) {
                return $row['title'];
                break;       
            } 
        }
    }
    

    
    /**
     * Эта функция выводит список всех данных которые можно запретить
     * так же выставляет флаг "active" к данным которые уже запрещены к просмотру 
     */
    public static function getUserRestrictedDataList($userId)
    {
        $permissioList = self::getRestrictedDataList(false);

        $userAccessList = self::getForbiddenUserData($userId);

        foreach($permissioList as $key => $row) {
            $thId = $row['id'];

            foreach($userAccessList as $uKey => $uRow) {
                if($thId == $uRow['data_name']) {
                    $permissioList[$key]['active'] = true;
                }
            }
        }

        return $permissioList;
    }


    /**
     * 
     */
    public static function getForbiddenUserData($userId)
    {
        return db::select([
            'table_name' => 'access_data',
            'col_list' => '*',
            'query' => [
                'base_query' => ' WHERE user_id = :userId '
            ],
            'bindList' => [
                'userId' => $userId
            ],
        ])->get();        
    }


    /**
     * @return mixed array|boolean
     */
    public static function getRestrictedDataList($dataName = false)
    {
        $getRestrictedDataList = [
            [
                'id' => 'th_buy_price',
                'title' => 'Alış qiyməti',
            ],
            [
                'id' => 'th_admin_password',
                'title' => 'Şifrə'
            ],
            [
                'id' => 'th_count',
                'title' => 'Say',
            ],
            [
                'id' => 'th_profit',
                'title' => 'Mənfəət',
            ],                       
            [
                'id' => 'th_total_circ_money',
                'title' => 'Ümumi dövriyyə',
            ], 
            [
                'id' => 'th_rasxod',
                'title' => 'Xərc',
            ],                    
        ];

        return $getRestrictedDataList;
    }


    /**
     * Эта функция выводит список всех данных которые можно запретить
     * так же выставляет флаг "active" к данным которые уже запрещены к просмотру 
     */
    public static function getUserRestrictedPageList($userId)
    {
        $main = new main();

        $userAccessList = self::getForbiddenPage($userId);
        
        $permissioList = $main->getMenuList();

        $list = [];

        foreach($permissioList as $key => $row) {
            $list[] = [
                'id' => $key,
                'title' => $row['title']
            ];
        }

        foreach($list as $key => $row) {
            $thId = $row['id'];

            foreach($userAccessList as $uKey => $uRow) {
                if($thId == $uRow['page']) {
                    $list[$key]['active'] = true;
                }
            }  
        }
      

        return $list;
    }


    /**
     * 
     */
    public static function getForbiddenPage($userId)
    {
        return db::select([
            'table_name' => 'access_page',
            'col_list' => '*',
            'query' => [
                'base_query' => ' WHERE user_id = :userId '
            ],
            'bindList' => [
                'userId' => $userId
            ],
        ])->get();        
    }


    /**
     * 
     */
    public static function setUserPageAccess($userId, $rulesId, callable $callback) 
    {
        $getUserPriviliges = user::getCurrentUser('get_role');

        if($getUserPriviliges == 'admin') {
            return db::insert('access_page', [
                [
                    'user_id' => $userId,
                    'page' => $rulesId
                ]
            ]);
        }

        return $callback([
            'type' => 'error',
            'text' => 'You dont have priviliges for set access'
        ]);
    }


    /**
     * 
     */
    public static function unsetUserPageAccess($userId, $rulesId, callable $callback) 
    {
        $getUserPriviliges = user::getCurrentUser('get_role');

        if($getUserPriviliges == 'admin') {
            return db::delete([
                [
                    'table_name' => 'access_page',
                    'where' => ' access_page.user_id = :userId AND access_page.page = :rulesId ',
                    'bindList' => [
                        'userId' => $userId,
                        'rulesId' => $rulesId
                    ]
                ]
            ]);
        }

        return $callback([
            'type' => 'error',
            'text' => 'You dont have priviliges for delete access'
        ]);
    }      



    /**
     * 
     */
    public static function setUserDataAccess($userId, $rulesId, callable $callback) 
    {
        $getUserPriviliges = user::getCurrentUser('get_role');

        if($getUserPriviliges == 'admin') {
            return db::insert('access_data', [
                [
                    'user_id' => $userId,
                    'data_name' => $rulesId
                ]
            ]);
        }

        return $callback([
            'type' => 'error',
            'text' => 'You dont have priviliges for set access'
        ]);
    }


    /**
     * 
     */
    public static function unsetUserDataAccess($userId, $rulesId, callable $callback) 
    {
        $getUserPriviliges = user::getCurrentUser('get_role');


        if($getUserPriviliges == 'admin') {
            return db::delete([
                [
                    'table_name' => 'access_data',
                    'where' => ' access_data.user_id = :userId AND access_data.data_name = :rulesId ',
                    'bindList' => [
                        'userId' => $userId,
                        'rulesId' => $rulesId
                    ]
                ]
            ]);
        }

        return $callback([
            'type' => 'error',
            'text' => 'You dont have priviliges for delete access'
        ]);
    }  


    /**
     * @return boolean true/false.
     * @description
     * if true - access denied
     * if false - free access
     */
    public static function accessActionRoute(string $route, callable $callback) 
    {
        $getSessionUserId = User::getCurrentUser('get_id');


        if($getSessionUserId == false && $route != 'activeLicense') {
            return $callback(true);
        }


        $res = db::select([
            'table_name' => 'access_action',
            'col_list' => '*',
            'query' => [
                'base_query' => " WHERE action_name=:routeName AND user_id=:user_id ",
            ],
            'bindList' => [
                'user_id'   => $getSessionUserId,
                'routeName' => $route
            ]
            ], ['bindType' => 'bindValue'])->first()->get();
            
        return $callback($res);
    }


    /**
     * 
     */
    public static function hasUserAccessAction($route, $userId)
    {
        if($userId == false && $route != 'activeLicense') {
            return false;
        }


        $res = db::select([
            'table_name' => 'access_action',
            'col_list' => '*',
            'query' => [
                'base_query' => " WHERE action_name=:routeName AND user_id=:user_id ",
            ],
            'bindList' => [
                'user_id'   => $userId,
                'routeName' => $route
            ]
            ], ['bindType' => 'bindValue'])->first()->get();
            
        return $res;
    }


    /**
     *  @return array
     */
    public static function getRestrictedActionList() 
    {
        $actionRoutList = [
            [
                'id' => 'changeSalePriceOnCart',
                'title' => 'Qiyməti dəyişə bilməsin',
                'group' => 'Satış',
            ],             
            [
                'id' => 'canDiscount',
                'title' => 'Endirim',
                'classList' => 'user-access-action-switcher switcher-new-state ls-switcher-green',
                'group' => 'Satış'
            ],
            [
                'id' => 'discountLimit',
                'title' => 'Maksimum endirim faizi',
                'group' => 'Satış',
                'type' => 'input'
            ],            
            [
                'id' => 'addUser',
                'title' => 'Yeni satıcılar əlavə etmək',
                'group' => 'Admin'
            ],
            [
                'id' => 'editUser',
                'title' => 'Satıcı məlumatlarını redaktə etmək',
                'group' => 'Admin'
            ],
            [
                'id' => 'deleteUser',
                'title' => 'Satıcıları silmək',
                'group' => 'Admin'
            ],
            [
                'id' => 'addProduct',
                'title' => 'Yeni məhsul əlavə etmək',
                'group' => 'Anbar'
            ],
            [
                'id' => 'editProduct',
                'title' => 'Məhsulu redaktə etmək',
                'group' => 'Anbar'
            ],
            [
                'id' => 'deleteProducts',
                'title' => 'Məhsulu silmək',
                'group' => 'Anbar'
            ],
            [
                'id' => 'editReport',
                'title' => 'Hesabatı redaktə etmək',
                'group' => 'Hesabat'
            ],
            [
                'id' => 'deleteReport',
                'title' => 'Hesabatı silmək',
                'group' => 'Hesabat'
            ],
            [
                'id' => 'refaundReport',
                'title' => 'Qeri qaytarma',
                'group' => 'Hesabat'
            ],            
            [
                'id' => 'addExpense',
                'title' => 'Yeni xərclər əlavə etmək',
                'group' => 'Xərclər'
            ],
            [
                'id' => 'editExpense',
                'title' => 'Xərcləri redaktə etmək',
                'group' => 'Xərclər'
            ],   
            [
                'id' => 'deleteExpense',
                'title' => 'Xərcləri silmək',
                'group' => 'Xərclər'
            ], 
            [
                'id' => 'addTransfer',
                'title' => 'Yeni məhsul transferi əlavə etmək',
                'group' => 'Transfer'
            ],  
            [
                'id' => 'addArrivalProducts',
                'title' => 'Malların alınması (Alış fakturası)',
                'group' => 'Alış & silinmə fakturası'
            ],              
            [
                'id' => 'addWriteOff',
                'title' => 'Malların silinməı (Silinmə fakturası)',
                'group' => 'Alış & silinmə fakturası'
            ],  
            [
                'id' => 'addCategory',
                'title' => 'Yeni kateqoriya əlavə etmək',
                'group' => 'Kateqoriya'

            ],  
            [
                'id' => 'editCategory',
                'title' => 'Kateqoriyanı redaktə etmək',
                'group' => 'Kateqoriya'
            ],  
            [
                'id' => 'deleteCategory',
                'title' => 'Kateqoriyanı silmək',
                'group' => 'Kateqoriya'
            ],    
            [
                'id' => 'addProvider',
                'title' => 'Yeni təchizatçı əlavə etmək',
                'group' => 'Təchizatçı'
            ],  
            [
                'id' => 'editProvider',
                'title' => 'Təchizatçını redaktə etmək',
                'group' => 'Təchizatçı'
            ],  
            [
                'id' => 'deleteProvider',
                'title' => 'Təchizatçını silmək',
                'group' => 'Təchizatçı'
            ],                                                  
                                              
        ];

        return $actionRoutList;
    }


    public static function groupedRestrictedActionList($userId) 
    {
        $list = self::getUserRestrictedActionList($userId);
        $result = [];

        foreach($list as $key => $val) {
            if(!empty($val['group'])) {
                $result[$val['group']][] = $list[$key];
            }
        }

        return $result;
    }

    /**
     * Эта функция выводит список всех данных которые можно запретить
     * так же выставляет флаг "active" к данным которые уже запрещены к просмотру 
     */
    public static function getUserRestrictedActionList($userId)
    {
        $permissioList = self::getRestrictedActionList(false);

        $userAccessList = self::getForbiddenUserAction($userId);

        foreach($permissioList as $key => $row) {
            $thId = $row['id'];

            foreach($userAccessList as $uKey => $uRow) {
                if($thId == $uRow['action_name']) {
                    $permissioList[$key]['active'] = true;
                    $permissioList[$key]['description'] = $uRow['description'];
                }
            }
        }

        return $permissioList;
    }


    /**
     * 
     */
    public static function getForbiddenUserAction($userId)
    {
        return db::select([
            'table_name' => 'access_action',
            'col_list' => '*',
            'query' => [
                'base_query' => ' WHERE user_id = :userId '
            ],
            'bindList' => [
                'userId' => $userId
            ],
        ])->get();        
    }


    /**
     * 
     */
    public static function unsetUserActionAccess($userId, $rulesId, callable $callback) 
    {
        $getUserPriviliges = user::getCurrentUser('get_role');

        if($getUserPriviliges == 'admin') {
            return db::delete([
                [
                    'table_name' => 'access_action',
                    'where' => ' access_action.user_id = :userId AND access_action.action_name = :rulesId ',
                    'bindList' => [
                        'userId' => $userId,
                        'rulesId' => $rulesId
                    ]
                ]
            ]);
        }

        return $callback([
            'type' => 'error',
            'text' => 'You dont have priviliges for delete access'
        ]);
    }     

    /**
     * 
     */
    public static function setUserActionAccess(array $row, callable $callback) 
    {
        $getUserPriviliges = user::getCurrentUser('get_role');

        if($getUserPriviliges == 'admin') {
            return db::insert('access_action', [
                [
                    'user_id'       => $row['userId'],
                    'action_name'   => $row['rulesId'],
                    'description'   => $row['description'] ?? ''
                ]
            ]);
        }

        return $callback([
            'type' => 'error',
            'text' => 'You dont have priviliges for set access'
        ]);
    }    


    /**
     * @return boolean true/false.
     * @description
     * if true - access denied
     * if false - free access
     */
    public static function hasAccessToPage(string $page, callable $callback) 
    {
        $getSessionUserId = User::getCurrentUser('get_id');

        if($getSessionUserId == false) {
            return $callback(true);
        }

        $res = db::select([
            'table_name' => 'access_page',
            'col_list' => '*',
            'query' => [
                'base_query' => " WHERE page = :pageName AND user_id = :user_id ",
            ],
            'bindList' => [
                'user_id'   => $getSessionUserId,
                'pageName' => $page
            ]
            ], ['bindType' => 'bindValue'])->first()->get();
            
        return $callback($res);
    }    


    /**
     * данные товаров с учетом правилами 
     *  
     * old function name query_clear_by_user_access
    */
    public static function cleanseInaccessibleData($arr, $th) 
    {
        $query = $arr['query'];
        $access = $arr['access']['get_data'];
        // $th  = get_th_list();
        $res = [];
    
        foreach($access as $key => $val) {
            if(isset($th[$key])) {
                $th_this = $th[$key];
                $check_access = $th_this['is_title'];
        
                if($check_access == false) {
                    foreach($query as $q_key => $q_val) {
                        unset($query[$q_key][$val]);
                    }	
                } 
            }
        }
        return $query;
    }
    
    //проверка достпа запросов
    function access_request_action($uri) {
        //получаем роль юзера сессии
        $user_role = $this->getCurrentUser('get_role');
        //получаем файл к которому был сделан запрос
        $uri = basename($uri);
        $access_list = [];
    
        //зпарещенные страница для seller 
        if($user_role === 'seller') {
            $access_list = array(
                'admin.php', 				//админ панель
                'add_user.php', 			//добавлять сотрудников
                'update_user.php', 			//изменять их ифу
                'add_stock.php', 			//добавлять товары
                'update_product.php', 		//изменять товары **old version
                'edit_product.php', 		//изменять товары
                'delete_products.php',		//удалчть товары 
                'return_report.php', 		//возврат товаров
                'delete_report.php', 		//удлаять отчет,
                'add_seller.php',
                'delete_seller.php',
                'edit_seller.php'	
            );
        }
    
    
    
        //зпарещенные страница для seller или admin_seller
        if($user_role === 'admin_seller') {
            $access_list = array(
                'add_user.php',
                'update_user.php'
            );
        }
    
        if($user_role === 'admin') {
            $access_list = array(
                //all rules available
            );
        }
    
        if(in_array($uri, $access_list)) {
            echo  json_encode(array(
                'error' => "Xəta! <br> Bu əməliyyatı yerinə yetirmək üçün yetərli hüquqlarınız yoxdur.", 
            ));
            exit();
            die();
        }
    }
}