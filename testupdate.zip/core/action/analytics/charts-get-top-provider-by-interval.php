<?php
use Core\Classes\Utils\Charts;
use Core\Classes\Report;
use Core\Classes\Utils\Utils;

header('Content-Type: application/json');

$Charts = new Charts;
$Report = new Report;
$orderBy = 'total_profit';
$interval = 3;

if(!empty($_POST['date'])) {
    $interval = $_POST['date'];
}


$data = Report::getTopSellingProviderByInterval($interval);

$res = $Charts->getPieChartsData($data, 'provider_name', $orderBy);

echo json_encode($res);