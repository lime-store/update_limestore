<?php 

namespace Core\Classes\Services\Warehouse\Traits;

use Core\Classes\Utils\Utils;
use core\classes\dbWrapper\db;
use core\classes\dbWrapper\traits\select;
use Core\Classes\Products;
use Core\Classes\System\Init;
use Core\Classes\System\Main;

trait Arrival
{

    /**
     * 
     */
    public function handleProductArrival($productList)
    {

        foreach($productList as $key => $row) {
            $id = $row['id'];
            $count = $row['count'];
        
            // stock_arrivals_count($id, $count);

            Products::increaseProductCount([
                'stock_id' => $id,
                'product_count' => $count
            ]);

            
            self::logProductArrival([
                'description' => $row['description'],
                'count'       => $count,
                'id'          => $id,
            ]);
        }
    }


    /**
     * 
     */
    public static function logProductArrival($data)
    {
        $transaction_id = Utils::generateTransactionId();

        /**
         * @param array = [
         * 	'stock_id' => $id,
         * 	'description' => $desc,
         *  'count' => $count,
         *  'transaction_id' => $transaction_id
         * ];
         */
        return db::insert('arrival_products', [
            [
                'description' 				=> $data['description'],
                'count' 					=> $data['count'],
                'day_date' 					=> Utils::getDateMY(),
                'full_date'					=> Utils::getDateDMY(),
                'id_from_stock' 			=> $data['id'],
                'transaction_id' 			=> $transaction_id
            ]
        ]);        
    }

    /**
     * 
     */
    public function getArrivalByDate($date, $controllerIndex)
    {
        $data_page = Init::initController($controllerIndex);
        
        $data_page['sql']['query']['body'] = $data_page['sql']['query']['body'] . "  AND arrival_products.day_date = :mydateyear";
        $data_page['sql']['bindList']['mydateyear'] = $date ?? date("m.Y");
        
        return Main::prepareData($data_page['sql'], $data_page['page_data_list']);
    }


    /**
     * 
     */
    public static function getArrivalByProductId(int $id)
    {
        $sql = [
            'table_name' => 'arrival_products',
            'col_list' => "*, 
                           arrival_products.full_date as full_date, 
                           CONCAT(IF(arrival_products.count >= 0, '+', ''), arrival_products.count) AS count,
                           'Alış fakturası' as operation_type ",
            'query' => [
                'body' => " WHERE arrival_products.id_from_stock = :id ",
                'sort_by' => "GROUP BY arrival_products.id DESC ",
                'limit' => 'LIMIT 50'
            ],
            'bindList' => [
                'id' => $id
            ] 
        ];
        
        return db::select($sql)->get();
    }


    /**
     * 
     */
    public static function getWriteOffByProductId(int $id)
    {
        $sql = [
            'table_name' => 'write_off_products',
            'col_list' => '*, 
                           write_off_products.full_date as full_date, 
                           -write_off_products.count AS count,
                           "Silinmə fakturası" as operation_type',
            'query' => [
                'body' => " WHERE write_off_products.id_from_stock = :id ",
                'sort_by' => "GROUP BY write_off_products.id DESC ",
                'limit' => 'LIMIT 50'
            ],
            'bindList' => [
                'id' => $id
            ] 
        ];
        
        return db::select($sql)->get();
    }

    /**
     * 
     */
    public static function getTransferByProductId(int $id)
    {
        $sql = [
            'table_name' => 'transfer_list',
            'col_list' => '*, 
                          transfer_list.transfer_full_date as full_date, 
                          -transfer_list.count AS count,
                          "Transfer" as operation_type',
            'query' => [
                'body' => " WHERE transfer_list.stock_id = :id ",
                'sort_by' => "GROUP BY transfer_list.transfer_id DESC ",
                'limit' => 'LIMIT 50'
            ],
            'bindList' => [
                'id' => $id
            ] 
        ];
        
        return db::select($sql)->get();
    }

    /**
     * 
     */
    public static function getSalesById(int $id)
    {
        $sql = [
            'table_name' => 'stock_order_report',
            'col_list' => '*, 
                          stock_order_report.order_date as full_date, 
                          -stock_order_report.order_stock_count as count, 
                          "Satış" as operation_type',
            'query' => [
                'body' => " WHERE stock_order_report.stock_order_visible = 0 AND stock_order_report.stock_id = :id ",
                'sort_by' => "GROUP BY stock_order_report.order_stock_id DESC ",
                'limit' => 'LIMIT 50'
            ],
            'bindList' => [
                'id' => $id
            ] 
        ];
        
        return db::select($sql)->get();
    }
    
    /**
     * 
     */
    public static function getReturnSalesById(int $id)
    {
        $sql = [
            'table_name' => 'stock_order_report',
            'col_list' => "*, 
                           stock_order_report.order_date as full_date, 
                           CONCAT(IF(stock_order_report.order_stock_count >= 0, '+', ''), stock_order_report.order_stock_count) AS count,
                           'Qeri qaytarma' as operation_type",
            'query' => [
                'body' => " WHERE stock_order_report.stock_order_visible = 3 AND stock_order_report.stock_id = :id ",
                'sort_by' => "GROUP BY stock_order_report.order_stock_id DESC ",
                'limit' => 'LIMIT 50'
            ],
            'bindList' => [
                'id' => $id
            ] 
        ];
        
        return db::select($sql)->get();
    }
}