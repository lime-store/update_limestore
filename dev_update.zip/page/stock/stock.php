<?php
	require_once '../../function.php';
	//Показывать товары которые находться в базе больше 15 дней 
	// settShowOldProduct();

	//выводим заголовок страницы
	tab_page_header('Anbar');

	//блок для принта чека
	printModal();
	//пути к категориям
	get_product_root_dir();

	//выводим перекючения вкладок 
	getCurrentTab($stock_phone_link, $stock_akss_link); 

	//абсолютный пусть к файлам
	root_dir();
?>

<div class="terminal_main">
	<?php require_once GET_ROOT_DIRS. $stock_phone_link; ?>
</div>




<?php 
	//выводим модальное окно для оформления заказа
	get_modal_tamplate_checkout_tem();
?>
