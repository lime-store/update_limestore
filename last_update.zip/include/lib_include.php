<script src="/lib/js_lib/jquery-3.3.1.min.js?v=<?php echo time(); ?>"></script>
<script src="js/function.js?v=<?php echo time(); ?>"></script>
<script src="/lib/js_lib/print.min.js?v=<?php echo time(); ?>"></script>
<script src="js/ajax.js?v=<?php echo time(); ?>"></script>
