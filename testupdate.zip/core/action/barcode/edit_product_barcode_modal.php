<?php

header('Content-type: Application/json');


$stock_id = $_POST['data'];


$res = $products->getProductBarcodeList($stock_id);


$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
	      '/component/modal/custom_modal/u_modal.twig' => [
                  'modalController' => [
                        'title' => 'Redaktə et',
                        'closeButtonClassList' => 'removeModal'
                  ],
                  'modalContent' => [
                        'path' => '/component/modal/barcode/edit_barcode_wrapper.twig',		
                  ],
                  'res' => $res,
                  'class_list' => '',
                  'stock_id' => $stock_id          
		]  
	]
]);


 $utils::abort([
	'res' => $total,
]);
