<?php 

namespace core\classes\System;

use core\classes\Utils\Utils;

class Config 
{
    /**
     * 
     */
    public static function loadAssets(array $assetsList = []) :array
    {
        $assets = [
            'css' => [
                'fonts'             => '/assets/css/fonts.css',
                'interFonts'        => '/assets/fonts/Inter/inter.css',
                'styleVar'          => '/assets/css/style_var.css',
                'template'          => '/assets/css/template.css',
                'animate'           => '/assets/css/animate.min.css',
                'lineAwesome'       => '/assets/lib/css_lib/line-awesome/css/line-awesome.min.css',
                'mainStyle'         => '/assets/css/new.style.css',
                'responsive'        => '/assets/css/responsive.css',
                'darktheme'         => '/assets/css/dark.theme.css',
                // '' => 'assets/css/network-status.css',
             ],
            'script' => [
                'jquery'            => '/assets/lib/js_lib/jquery-3.7.1.min.js',
                'jqueryPos'         => '/assets/lib/js_lib/jquery.pos.js',
                'jsBarcode'         => '/assets/lib/js_lib/JsBarcode.all.min.js',
                'hotkey'            => '/assets/js/utils/hotkey.js',
                'function'          => '/assets/js/upd.function.js',
                'ajax'              => '/assets/js/upd.ajax.js',
                
                
                'stockFunction'     => '/assets/js/main/stock.function.js',
                'reportFunction'    => '/assets/js/main/report.function.js',
                'cart'              => '/assets/js/main/cart.js',
                 
                'customerCashback'  => '/assets/js/main/customer-cashback.function.js',
                
                'arrivalFunction'   => '/assets/js/main/arrival.function.js',
                'writeOffFunction'  => '/assets/js/main/write-off.function.js',
                'transferFunction'  => '/assets/js/main/transfer.function.js',
                'cashRegister'      => '/assets/js/main/cashRegister.function.js',
                'printBarcodeA4'    => '/assets/js/main/printA4Barcode.js',

                'utils'             => '/assets/js/utils/utils.js',
                'stories'           => '/assets/js/utils/stories.js',
                
                'dark'              => '/assets/js/utils/dark-theme.js',
                'xlsConvert'        => '/assets/lib/xlsx-convert/xlsx.full.min.js',
                'chart'             => '/assets/lib/chart/chart.min.js'
                // 'assets/js/utils/network-status.js',
            ]
        ];


        if($assetsList) {  
            foreach($assets as $type => $path) {
                $assets[$type] = array_intersect_key($path, array_flip($assetsList[$type]));
            }
        }

        return $assets;
    }


    /**
     * 
     */
    public static function mergeAssets(array $list)
    {
        $assetsList = self::loadAssets();
        return array_merge_recursive($assetsList, $list);
    }
}