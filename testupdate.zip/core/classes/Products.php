<?php
namespace core\classes;
use core\classes\dbWrapper\db;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\Privates\User;
use core\classes\Services\BaseService;
use core\classes\Utils\Utils;
use core\classes\Traits\Barcode;
use core\classes\Services\Warehouse\Warehouse;

class Products
{
    use Barcode;

    public static $col_post_list = [
            'add_stock_name' => [	
                'col_name' => 'stock_name',
                'required' => true
            ],
            'add_stock_description' => [ 
                'col_name' => 'stock_phone_imei' 
            ],
            // 'add_stock_provider_id' => [
            // 	'col_name' => 'product_provider'
            // ],
            // 'add_stock_category_id' => [
            // 	'col_name' => 'product_category'
            // ],
            'add_stock_count' => [
                'col_name' => 'stock_count'
            ],	
            'add_stock_min_quantity' => [
                'col_name' => 'min_quantity_stock'
            ],
            'add_stock_first_price' => [
                'col_name' => 'stock_first_price',
                'required' => true 
            ],
            'add_stock_second_price' => [
                'col_name' => 'stock_second_price' 
            ],
            'add_stock_wholesale_price' => [
                'col_name' => 'wholesalePrice'
            ],
            'add_product_unit' => [
                'col_name' => 'product_unit'
            ],
            'remote_id'     => [
                'col_name'  => 'remote_id'
            ]
            // 'add_stock_barcode' => [
            // 	'col_name' => 'barcode_article'
            // ]	
        ];

    /**
     * Удалить товар
     * 
     * @param int $product_id
     */
    public function deleteProduct(int $product_id)
    {
        $update_data = [
            'before' => 'UPDATE stock_list SET ',
            'after' => ' WHERE stock_id = :prod_id ',
            'post_list' => [
                'id' => [
                    'query' => ' stock_list.stock_visible = 1 ',
                    'bind' => 'prod_id'
                ]
            ]
        ];
    
        db::update($update_data, [
            'id' => $product_id
        ]);
    }


    /**
     * Добавить товар
     */
    public function addProduct($prepareData)
    {
        $data = [];

        foreach (self::$col_post_list as $key => $value) {
            if(array_key_exists($key, $prepareData)) {
                $data = array_merge($data, [
                    $value['col_name'] => $prepareData[$key]
                ]);
            }
        }
                
        $default_data = [
            'stock_visible' 	=> 0,
            'stock_get_fdate' 	=> date("d.m.Y"),
            'stock_get_year' 	=> date("m.Y"),
            'product_added' 	=> User::getCurrentUser('get_id')
        ];
    
        $data = array_merge($data, $default_data);      
    
		// создаем новый товар
		db::insert('stock_list', [$data]);
    }


    /**
     * редактировать товар
     * @param array $data
    */
    public function editProduct($data, $productInfo = null)
    {
        // в первом массиве мы должны описать и связвать данные $postData с таблицей
        $option = [
            'before' => " UPDATE stock_list, user_control SET ",
            'after' => " WHERE stock_id =:stock_id ",
            'post_list' => [
                //id
                'upd_product_id' => [ 
                    'query' => false,
                    'bind' => 'stock_id',
                    'require' => true
                ],	
                //изменить название товра
                'product_name' => [
                    'query' => "stock_list.stock_name = :prod_name",
                    'bind' => 'prod_name',
                ],
                //изменить описание товара (старое imei)
                'product_description' => [
                    'query' => "stock_list.stock_phone_imei = :prod_imei",
                    'bind' => 'prod_imei'
                ],
                //изменить количество товара
                'plus_minus_product_count' => [
                    'query' => "stock_list.stock_count = :add_count",
                    'bind' => 'add_count',
                ],		
                //прибавить n-количсестов товара 
                'append_stock_count' => [
                    'query' => "stock_list.stock_count = stock_list.stock_count + :append_count",
                    'bind' => 'append_count',
                ],		
                //изменить себе стоимость товара
                'product_first_price' => [
                    'query' => "stock_list.stock_first_price = :f_price",
                    'bind' => 'f_price',
                ],
                //изменить стоимость
                'product_second_price' => [
                    'query' => "stock_list.stock_second_price = :s_price",
                    'bind' => 's_price'
                ],
                //изменить минимальное количество товара
                'change_min_quantity' => [
                    'query' => "stock_list.min_quantity_stock = :min_count",
                    'bind' => 'min_count',	
                ],

                //изменить количество товара
                'change_product_count' => [
                    'query' => "stock_list.stock_count = :change_count",
                    'bind' => 'change_count',
                ],		
                
                //последнее изминение товара
                'last_edited_date' => [
                    'query' => "stock_list.last_edited_date = :last_date",
                    'bind' => 'last_date'
                ],

                'product_wholesale_price' => [
                    'query' => "stock_list.wholesalePrice = :wholesalePrice",
                    'bind' => 'wholesalePrice'                    
                ],
                'edit_product_unit' => [
                    'query' => "stock_list.product_unit = :product_unit",
                    'bind' => 'product_unit'                     
                ]
            ]
        ];


        $default_data = [
            'last_edited_date' => date('Y-m-d h:i:s')
        ];

        $data = array_merge($data, $default_data);

        $initialProductCount = $this->getProductById($data['upd_product_id'])['stock_count'];

        if(!empty($data['plus_minus_product_count'])) {
            if($data['plus_minus_product_count'] > $initialProductCount) {
                Warehouse::logProductArrival([
                    'id' => $data['upd_product_id'],
                    'count' => $data['plus_minus_product_count'] - $initialProductCount,
                    'description' => ''
                ]);
            }

            if($data['plus_minus_product_count'] < $initialProductCount) {
                Warehouse::logProductWriteOff([
                    'id' => $data['upd_product_id'],
                    'count' => $initialProductCount - $data['plus_minus_product_count'],
                    'description' => ''
                ]);
            }
        }

        // --- единая точка определения "что изменилось" ---
        $newCount = null;

        if (isset($data['plus_minus_product_count'])) {
            // абсолютное значение
            $newCount = (float) $data['plus_minus_product_count'];
        } elseif (isset($data['change_product_count'])) {
            // тоже абсолютное значение, другой UI-сценарий
            $newCount = (float) $data['change_product_count'];
        } elseif (isset($data['append_stock_count'])) {
            // явная дельта (прибавка)
            $newCount = $initialProductCount + (float) $data['append_stock_count'];
        }

        if ($newCount !== null && $newCount != $initialProductCount) {
            $this->logProductStockChange(
                $data['upd_product_id'], 
                $initialProductCount,
                $newCount,
                'manual_edit'
            );
        }        

	    db::update($option, $data);
    }


    /**
     * Изменить название твоара
     * @param int $productId - id товара
     * @param string $newName - название товара
     */
    public function editProductName($productId, $newName)
    {
        $this->editProduct([
            'upd_product_id' => $productId,
            'product_name' => $newName
        ]);
    }

    /**
     * Изменить описание твоара
     * @param int $productId - id товара
     * @param string $description - описание товара
     */
    public function editProductDescription($productId, $description)
    {
        $this->editProduct([
            'upd_product_id' => $productId,
            'product_description' => $description
        ]);
    }    


    /**
     * изменить кличнство товара после продажи
     * @param array $data|stock_id|order_stock_id
     */
    public static function updateStockAfterSale($data) 
    {
        // полсе добавления товра в базу, обновляем данные товара, уменьшаем количестов товара
        foreach($data as $index => $row) {
            self::decreaseProductCount($row);
        }
    }


    /**
     * Уменьшить количество товара 
     * @param array stock_id|product_count
     * 
     * @param data array(
     *   'stock_id'      => $id,
     *   'product_count' => $count
     *  )
     */
    public static function decreaseProductCount($data) 
    {
        $option = [
            'before' => " UPDATE stock_list SET ",
            'after' => " WHERE stock_id = :stock_id ",
            'post_list' => [
                'stock_id' => [
                    'query' => false,
                    'bind' => 'stock_id'
                ],
                'product_count' => [
                    'query' => "stock_list.stock_count = stock_list.stock_count - :product_count",
                    'bind' => 'product_count'
                ]
            ]
        ];

        db::update($option, $data);
    }


    /**
     * Увеличить количсество товара
     * @param array stock_id|product_count
     * @param data array(
     *   'stock_id'      => $id,
     *   'product_count' => $count
     *  )     
     */
    public static function increaseProductCount($data) 
    {
        $option = [
            'before' => " UPDATE stock_list SET ",
            'after' => " WHERE stock_id = :stock_id",
            'post_list' => [
                'stock_id' => [
                    'query' => false,
                    'bind' => 'stock_id'
                ],
                'product_count' => [
                    'query' => "stock_list.stock_count = stock_list.stock_count + :product_count",
                    'bind' => 'product_count'
                ]
            ]
        ];

        db::update($option, $data);
    }


    public static function getCreateProductFillList()
    {
        return self::$col_post_list;
    }

    /**
     * получаем список категории id товара
     * @param int $id
     * 
     * old function get_products_categorty_list
     */
    public function getProductCategory($id) 
    {
        // $cat = db::select([
        //     'table_name' => ' user_control ',
        //     'col_list' => ' * ',
        //     'query' => [                
        //         'base_query' => ' INNER JOIN products_category_list ON products_category_list.id_from_stock = :id 
        //                         LEFT JOIN stock_category ON stock_category.category_id = products_category_list.id_from_category AND stock_category.visible = :visible
        //         ',
        //         'sort_by' => ' GROUP BY products_category_list.id ASC ORDER BY products_category_list.id ASC '
        //     ],
        //     'bindList' => array(
        //         ":id" => $id,
        //         ':visible' => BaseService::VISIBLE_STATE['visible']
        //     ),
        
        // ])->get();

    
        $cat = qb::select()
                ->from('products_category_list')
                ->innerJoin('stock_category', 'stock_category.category_id = products_category_list.id_from_category')
                ->where('id_from_stock', $id)
                ->andWhere('stock_category.visible', BaseService::VISIBLE_STATE['visible'])
                ->get();

        return $cat;
    }

    
    /**
     * Изменяем категорию товара
     * @param array $data
     * @param array product_id|old_category_id|edited_category_id
     *
     * function old name edit_product_category
     */
    public function editProductCategory($data) 
    {
        $option = [
            'before' => " UPDATE products_category_list SET ",
            'after' => " WHERE id_from_stock =:stock_id AND id_from_category = :old_id",
            'post_list' => [
                //id
                'product_id' => [ 
                    'query' => false,
                    'bind' => 'stock_id',
                    'require' => true
                ],			
                'old_category_id' => [ 
                    'query' => false,
                    'bind' => 'old_id',
                    'require' => true
                ],
                'edited_category_id' => [
                    'query' => ' id_from_category = :new_id ',
                    'bind' => 'new_id',
                    'require' => true
                ]
            ]
        ];

        foreach ($data as $key => $collect_data) {
            db::update($option, $collect_data);
        }
    }


    /**
     * Добавляем категорию для товара
     * @param int $product_id
     * @param array $data
     * 
     * old function name add_product_category 
     */
    public function setProductCategory($product_id, $data) 
    {
        $collect_data = [];
        
        foreach ($data as $key => $val) {
            if(!empty($val['get_new_id'])) {
                $collect_data[] = [
                    'id_from_category' => $val['get_new_id'],
                    'id_from_stock' => $product_id
                ];
            }
        }

        if(!empty($collect_data)) {
            db::insert('products_category_list', $collect_data);
        }
    }

    /**
     * Удаляем категори для товара
     * @param array $data  
     * 
     * old function name delete_product_category
     */
    public function deleteProductCategory($data) 
    {
        foreach ($data as $key => $val) {
            db::delete([
                [
                    'table_name' => 'products_category_list',
                    'joins'	=> '',
                    'where' => ' id_from_stock = :stock_id AND id_from_category = :cat_id ',
                    'bindList' => [
                        ':stock_id' => $val['product_id'],
                        ':cat_id' => $val['del_id']
                    ],
                ]
            ]);
        }
    }    


    /**
     * Добавляем поставщика для товара
     * @param int $product_id
     * @param array $data 
     * 
     * old function name add_product_provider
     */
    public function setProductProvider($product_id, $data) 
    {
        $collect_data = [];
        
        foreach ($data as $key => $val) {
            if(!empty($val['get_new_id'])) {
                $collect_data[] = [
                    'id_from_provider' => $val['get_new_id'],
                    'id_from_stock' => $product_id
                ];
            }
        }
        
        if(!empty($collect_data)) {
            db::insert('products_provider_list', $collect_data);
        }
    }


    /**
     * Изменяем поставщика товара
     * @param array $data
     * @param array product_id|old_provider_id|edited_provider_id
     * 
     * old function name edit_product_provider
     */
    public function editProductProvider($data) 
    {
        $option = [
            'before' => " UPDATE products_provider_list SET ",
            'after' => " WHERE id_from_stock =:stock_id AND id_from_provider = :old_id",
            'post_list' => [
                //id
                'product_id' => [ 
                    'query' => false,
                    'bind' => 'stock_id',
                    'require' => true
                ],			
                'old_provider_id' => [ 
                    'query' => false,
                    'bind' => 'old_id',
                    'require' => true
                ],
                'edited_provider_id' => [
                    'query' => ' id_from_provider = :new_id ',
                    'bind' => 'new_id',
                    'require' => true
                ]
            ]
        ];

        foreach ($data as $key => $collect_data) {
            db::update($option, $collect_data);
        }
    }



    /**
     * получаем список поставщика id товара
     * @param int $id
     * old function name get_products_provider_list
     */
    public function getProductProvider($id) 
    {
        // $provider = db::select([
        //     'table_name' => ' user_control ',
        //     'col_list' => ' * ',
        //     'query' => [
        //         'base_query' => ' INNER JOIN products_provider_list ON products_provider_list.id_from_stock = :id 
        //                         LEFT JOIN stock_provider ON stock_provider.provider_id = products_provider_list.id_from_provider AND stock_provider.visible = :visible
        //         ',
        //         'sort_by' => ' GROUP BY products_provider_list.id ASC ORDER BY products_provider_list.id ASC '
        //     ],
        //     'bindList' => array(
        //         ":id" => $id,
        //         ':visible' => BaseService::VISIBLE_STATE['visible']
        //     )            
        
        // ])->get();

        $provider = qb::select()
                ->from('products_provider_list')
                ->innerJoin('stock_provider', 'stock_provider.provider_id = products_provider_list.id_from_provider')
                ->where('id_from_stock', $id)
                ->andWhere('stock_provider.visible', BaseService::VISIBLE_STATE['visible'])
                ->get();

        return $provider;
    }

    
    /**
     * Удаляем поставщика для товара
     * @param array $data  
     * 
     * old function name delete_product_provider
     */
    public function deleteProductProvider($data) 
    {
        foreach ($data as $key => $val) {
            db::delete([
                [
                    'table_name' => 'products_provider_list',
                    'joins'	=> '',
                    'where' => ' id_from_stock = :stock_id AND id_from_provider = :cat_id ',
                    'bindList' => [
                        ':stock_id' => $val['product_id'],
                        ':cat_id' => $val['del_id']
                    ],
                ]
            ]);
        }
    }

    

    
    /**
     * Получить товар по id 
     */
    public static function getProductById(int $id) 
    {
        return db::select([
            'table_name' => 'stock_list',
            'col_list' => '*',
            'query' => [
                'base_query' => ' WHERE stock_id = :id ',
            ],
            'bindList' => [
                ':id' => $id
            ]        
        ])->first()->get();
    }


    /**
     * Получить последний добавленный товар
     * 
     * @param string $column какой столбец вывести
     * @return array|string|false
     */
    public function getLastAddedProduct($column = false)
    {
        $data = db::select([
            'table_name' => 'stock_list',
            'col_list' => '*',
            'query' => [
                'base_query' => ' WHERE stock_visible = 0 ',
                'sort_by' => 'ORDER BY stock_id DESC LIMIT 1'
            ]
        ])->first()->get();
        
        return !empty($column) ? $data[$column] : $data;
     }    

     /**
      * 
      */
     public static function getUnitList()
     {
        return [
            [
                'id'   => 1,
                'name' => 'ədəd' 
            ],
            [
                'id'   => 2,
                'name' => 'qram' 
            ],
            [
                'id'   => 3,
                'name' => 'litr' 
            ],
            [
                'id'   => 4,
                'name' => 'qutu' 
            ],
            [
                'id'   => 5,
                'name' => 'paket' 
            ],   
            [
                'id'   => 6,
                'name' => 'metr' 
            ],                            
        ];
     }

     /**
      * 
      */
     public static function getUnit($search, $by = 'name')
     {
       $unitList = self::getUnitList();

       $matching_unit = array_values(array_filter($unitList, function ($row) use ($search, $by) {
            return $row[$by] == $search;
       }));

       $matching_unit = $matching_unit[0] ?? null;

       if(!empty($matching_unit)) {
        return $matching_unit;
       }

       return $unitList[0];
     }


     /**
      * 
      */
     public static function getProductUnit($productId)
     {
        $productUnitId = self::getProductById($productId);

        return self::getUnit($productUnitId['product_unit'], 'id');
     }

     /**
      * 
      */
     public static function getProductByRemoteId(int $remoteId)
     {
        $result = qb::select('*')
                    ->from('stock_list')
                    ->where('remote_id = :remote_id')
                    ->bindList([
                        ':remote_id' => $remoteId
                    ])
                    ->execute()
                    ->first()
                    ->get();
        return $result ?: [];
     }


    /**
     * Логирует изменение количества товара в историю стока.
     * 
     * $referenceType option refaund        - Возврат
     *                       delete_refaund - Удалили возврат
     *                       sales          - Продажа
     *                       delete_sale    - Удалили продажу
     *                       manual_edit    - Редактирование товара
     *                       transferIn     - Полученный трансфер
     *                       transferOut    - Сделанный трансфер
     *                       arivval        - Приход товара
     *                       writeOff       - Списанный товар
     * 
     * @param int            $productId      ID товара
     * @param float          $before         Количество до изменения
     * @param float          $after          Количество после изменения
     * @param string|null    $referenceType  Тип источника изменения
     * @param int|null       $referenceId    ID связанной сущности 
     * @param string|null    $comment        Комментарий/причина
     * @param int|null       $userId         Кто внёс изменение
     * @return void
     */
     public static function logProductStockChange(
        int $productId,
        float $before,
        float $after,
        ?string $referenceType = null,
        ?int $referenceId = null,
        ?string $comment = null,
        ?int $userId = null        
     ): void
     {
        $change = $after - $before;

        if($userId == null) {
            $userId = User::getCurrentUser('get_id');
        }

        // если количество фактически не изменилось — запись не нужна
        if ($change == 0) {
            return;
        }        

        $data = [
            'product_id'      => $productId,
            'quantity_before' => $before,
            'quantity_change' => $change,
            'quantity_after'  => $after,
            'reference_type'  => $referenceType,
            'reference_id'    => $referenceId,
            'comment'         => $comment,
            'user_id'         => $userId,
            'created_at'      => date('Y-m-d H:i:s')
        ];        

        db::insert('log_product_stock_history', [$data]);
    }

    

    /**
     * 
     */
    public static function getProductHistory(int $id): array
    {
        return qb::select('*')
            ->from('log_product_stock_history')
            ->leftJoin('stock_list as p', 'p.stock_id = log_product_stock_history.product_id')
            ->leftJoin('user_control as u', 'u.user_id = log_product_stock_history.user_id')
            ->where('product_id=:id')
            ->orderBy('id', 'DESC')
            ->limit(50)
            ->bindList([
                ':id' => $id
            ])->execute()->get();
    }
}
