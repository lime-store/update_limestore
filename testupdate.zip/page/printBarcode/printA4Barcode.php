<?php
use core\classes\Services\tableFooter;
use core\classes\Utils\Utils;

	$data_page = $init::initController($page);


	echo $Render->view('/component/inner_container.twig', [
		'renderComponent' => [
			'/component/multipleBarcode/multipleBarcodeTable.twig' => [
				
			]
		]
	]);

?>
