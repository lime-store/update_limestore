multipleBarcodeList = [                                                                              
];
maxCount = 52;


$(document).on('keyup', '.multipleBarcodeCount', function() {
  console.log('sda');
	$.ajax({
		type: 'POST',
		data: {
			'route': 'changeA4BarcodeCount',

			'count': $(this).val(),
      'barcode': $(this).closest('.print-barcode-fields').find('.barcode').attr('data-product-value')
		},
		dataType: 'json',
		success: (data) => {
      $(this).closest('.countPrint').find('.multipleBarcodeContainer').html();
      $(this).closest('.countPrint').find('.multipleBarcodeContainer').html(data.content);
		}
	});
});


// function drawMultipleBarcode(content) {

// }

$(document).on('input', '.appendBarcodeToA4List', function() {
  console.log('dsasa');
    let barcode = $(this).closest('.a4barcodetr').find('.a4BarcodeValue').html();
    let name = $(this).closest('.a4barcodetr').find('.a4BarcodeProductName').text();
    let count = parseInt($(this).val()) || 0;

    let existing = multipleBarcodeList.find(item => item.barcode === barcode);
    if (!existing) return;

    existing.count = count;

    let totalCount = multipleBarcodeList.reduce((sum, item) => sum + (parseInt(item.count) || 0), 0);

    if (totalCount > maxCount) {
        let allowed = maxCount - (totalCount - count);
        existing.count = Math.max(allowed, 0);
        $(this).val(existing.count);
        totalCount = maxCount;
    }

    // выводим остаток
    let remaining = maxCount - totalCount;
    $('.letCount').text(`${remaining}/52`);
    $('.multipleBarcodeContainer').html();

	$.ajax({
		type: 'POST',              
		data: {
			'route': 'changeA4BarcodeCount',
      'all': multipleBarcodeList,
      'name': name
		},
		dataType: 'json',
		success: (data) => {
            $('.a4BracodeListWrapper').html(data.content);

            allBarcodes = document.querySelectorAll('.barcodeA4');
            allBarcodes.forEach((svg, i) => {
                JsBarcode(svg, $(svg).attr('data-barcode') , {
                    format: "CODE128",
                    width: 1.4,
                    height: 30,
                    displayValue: true,
                    fontSize: 10,
                    margin: 0
                });
            });             
		}
	});
});




$(document).on('click', '.printMultipleBarcode', function() {
    const barcodeHtml = $(this).closest('.countPrint').find('.multipleBarcodeContainer').html();

    // multipleBarcodeCount

    // .barcode[data-product-value]

    printA4Barcode(barcodeHtml);
});

$(document).on('click', '.printA4Barcode', function() {
    //a4BracodeListWrapper

    const barcodeHtml = $('.a4BracodeListWrapper').html();

    printA4Barcode(barcodeHtml);
});

function printA4Barcode(barcodeHtml) {
    const printWindow = window.open('', '_blank');

      printWindow.document.write(`
        <html>
          <head>
            <title>Печать штрих-кода</title>
            <style>
@page {
  size: A4;
  margin: 0;
}

body {
  margin: 12mm 7mm; /* Поля листа */
  display: grid;
  grid-template-columns: repeat(4, 46.4mm);
  grid-template-rows: repeat(14, 21.2mm);
  column-gap: 2.5mm;
  row-gap: 0;
}

.label {
  width: 46.4mm;
  height: 21.2mm;
  box-sizing: border-box;
  padding-top: 2mm; /* ↓↓↓ Сдвигаем вниз на 2–3 мм ↓↓↓ */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  font-size: 9px;
  text-align: center;
}

.barcode {
  width: 40mm;
  height: 12mm;
}
</style>
         </head>
          <body>
            ${barcodeHtml}
          </body>
        </html>
      `);

      // Ждем, пока окно загрузится, затем вызываем печать
      printWindow.document.close(); // Завершаем генерацию документа
      printWindow.focus();          // Устанавливаем фокус на новое окно
      printWindow.print();          // Открываем диалог печати
      printWindow.onafterprint = function () {
        printWindow.close();        // Закрываем окно после печати
      };  
}


$(document).on('click', '.append-multiple-barcode-list', function() {
    const productId = $('.modal_order_form').attr('data-order-id');
    const barcode = $(this).closest('.print-barcode-fields').find('.barcode').attr('data-product-value');
    const productName = $('.edit-stock-name-input').val();
    const count = $(this).closest('.countPrint').find('.multipleBarcodeCountInput').val() ?? 1;

    if(!multipleBarcodeList.some(item => item.barcode === barcode)) {
        multipleBarcodeList.push({
            'productId': productId,
            'productName': productName,
            'barcode': barcode,
            'count': count,
        }); 
    }   

    $(this).addClass('btn-success');

});

$(document).on('click', '.remove-a4-barcode', function() {
    const barcode = $(this).closest('.a4barcodetr').find('.a4BarcodeValue').html();

    multipleBarcodeList = multipleBarcodeList.filter(item => item.barcode !== barcode);

    $(this).closest('.a4barcodetr').remove();

    $('.appendBarcodeToA4List').trigger('input');
});


function loadMultipleBarcode() {
    Object.keys(multipleBarcodeList).forEach(groupKey => {
      let row = multipleBarcodeList[groupKey];

      $('.multipleBarcodeTable').append(`
        <tr class="a4barcodetr">
            <td>
                <span class="stock-list-title a4BarcodeProductName">${row.productName}</span>
            </td>

            <td>
                <span class="stock-list-title a4BarcodeValue">${row.barcode}</span>
            </td>



            <td>
                <div class="flex flex-ai-cntr cart-input-container">
                    <button class="las la-minus btn btn-default add-basket-btn-icon cart-counter cart-minus-count" tabindex="-1"></button>
                      <div class="counter-input">
                        <input type="text" value="${row.count}" class="cart-order-count appendBarcodeToA4List input cart-input cart-counter-input input-validate-length input-validate-count input-required input-validate-min-max-count">
                      </div>
                    <button class="las la-plus btn btn-default cart-counter cart-plus-count" tabindex="-1"></button>
                </div>                                  
            </td>


            <td>
                <button class="btn btn-danger add-basket-btn-icon las la-trash remove-a4-barcode" tabindex="-1"></button>                                
            </td> 
        </tr>         
        
      `); 
  });

  $('.cart-plus-count').first().trigger('click');
  $('.cart-minus-count').first().trigger('click');
}