<?php

use Core\Classes\Cart\Checkout;
use Core\Classes\Privates\User;
use Core\Classes\Products;
use Core\Classes\System\dump;
use Core\Classes\Utils\Utils;
use core\classes\dbWrapper\db;
use core\classes\dbWrapper\queryBilder as qb;
use Core\Classes\System\Migration;
use Core\Classes\Traits\Barcode;
use Core\Classes\System\Settings;
use Core\Classes\Report;
use Core\Classes\System\Init;

require 'start.php';
    // if(!Settings::hasSettingsJSON('generalInfo', 'someKey')) {
    //     Settings::appendSettingsJSON([
    //         'generalInfo' => [
    //             "someKey" => 'jsfjsdf',
    //             'add' => 'sda',
    //             'rEM' => 'SDD'
    //         ]
    //     ]);
    // }


    Settings::appendSettingsJSON([
        'generalInfo' => [
            'companyName' => 'Lime Store'
        ]
    ]);

exit;
echo $Render::view('/component/inner_container.twig', [
	'renderComponent' => [
        '/component/index/head.twig' => [
			'lib_list' => $System->loadAssets(),
			'v' => time()
		],
        '/component/include_once_component.twig' => [
            'includs' => [
                [
                    '/component/parts/input.twig' => [
                        'containerClassList' => 'height-auto',
                        'inputClassList' => 'input btn-input width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],
                ],
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-primary width-auto load-user-add-modal send-firebase',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],                
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-secondary width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],                
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-success width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],                
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-danger width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],                
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-warning width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],                
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-black width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],                
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-light btn-blue width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-light btn-red width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-light btn-default-blue width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-blue-100 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-blue-200 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-blue-300 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-blue-400 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-blue-500 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-blue-600 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-blue-700 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-blue-800 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-blue-900 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-indigo-blue-100 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-indigo-blue-200 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-indigo-blue-300 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-indigo-blue-400 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-indigo-blue-500 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-indigo-blue-600 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-indigo-blue-700 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-indigo-blue-800 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
                [
                    '/component/parts/input.twig' => [
                        'inputClassList' => 'input btn-indigo-blue-900 width-auto load-user-add-modal',
                        'inputIcon' => [
                            'icon' => 'las la-user-plus'
                        ],
                        'attr' => [
                            'type' => 'button',
                            'value' => 'Satıcı əlavə edin'
                        ]
                    ],                    
                ],             
            ]
        ]
	]
    ]);


exit;

use Core\Classes\Privates\accessManager;

// тут мигрируем payment_method_list
Migration::hasTableExist('access_data', function($noExist) {
    if($noExist) {
        Migration::createTable(
            'CREATE TABLE `access_data` (
                `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `data_name` varchar(255) NOT NULL,
                `user_id` int(11) NOT NULL,
                `description` varchar(64) NOT NULL,
                `visible` int(11) NOT NULL
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;'
        );
    }
});




exit;
// Проверяем и добавляем столбец если его нет

$list = [
    'vaga' => 'varchar(255) NOT NULL',
    'freeze' => 'varchar(255) NOT NULL',
];

Migration::hasTableColumnExist('payment_method_list', $list, function($notExistColumn) {
    if($notExistColumn) {
       Migration::alertTableColumn('payment_method_list', $notExistColumn);
    }
});



exit;
// проверяем есть ли таблица в базе, если нет то добавляем

Migration::hasTableExist('payment_method_list', function($notExistTable) {
    if($notExistTable) {
        Migration::createTable(
            'CREATE TABLE `payment_method_list` (
                `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `title` varchar(255) NOT NULL,
                `freeze` int(11) NOT NULL,
                `tags_id` varchar(64) NOT NULL,
                `visible` int(11) NOT NULL
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;'
        );
    }
});


exit;

// Проверяем есть ли данные и добавляем данные если их нет в базе
$data = array(
	array(':title' => 'Kardfsdt', 'freeze' => 0, 'visible' => 0, 'tags_id' => 'danger'),

	array(':title' => '333333333', 'freeze' => 0, 'visible' => 0, 'tags_id' => 'danger'),
	
    array(':title' => 'Новое значеsadsaние', 'freeze' => 0, 'visible' => 0, 'tags_id' => 'danger'),
);

$sql = [
    'table_name' => 'payment_method_list',
    'col_list' => '*',
    'query' => [
        'base_query' => ' WHERE title = :title GROUP BY id DESC'
    ],
    'bindList' => []
];

Migration::hasDataExist($sql, $data, function($notExistData) {
    if($notExistData) {
        Migration::insertMigrationData('payment_method_list', $notExistData);
    }
});


exit;

echo $twig->display('/component/include_component.twig', [
    'renderComponent' => [
        '/component/widget/title.twig' => [
            'title' => 'sahsdha',
        ],
        'component/widget/notice.twig' => [
            //code
        ],
        '/component/related_component/body_preloader.twig' => [
            //data
        ],
        '/component/related_component/overlay.twig' => [
            //data
        ],
    ]
    ]);


exit;
class test2 
{

    public $data;

    public function __construct()
    {
        return $this->data;
    }

    public function intc($page)
    {
        $controller_list = [
            'cart_terminal'   	=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/cart-terminal/cart-terminal.controller.php',
            'terminal'      	=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/terminal/terminal.controller.php',
            'stock'         	=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/stock/stock.controller.php',
            'report'        	=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/report/report.controller.php',
            // 'rasxod'        	=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/rasxod/rasxod.controller.php',
            // 'category_form' 	=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/category_form/category_form.controller.php',
            // 'provider_form' 	=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/provider_form/provider_form.controller.php',
            // 'filter_form'   	=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/filter_form/filter_form.controller.php',
            // 'settings'      	=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/settings/settings.controller.php',
            // 'warehouse_transfer_form'  =>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/warehouse-transfer/warehouse-transfer-form/warehouse-transfer-form.controller.php',
            // 'warehouse_transfer_report'  =>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/warehouse-transfer/warehouse-transfer-report/warehouse-transfer-report.controller.php',
            // 'arrival_form' 		=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/arrival-products/arrival-form/arrival-form.controller.php',
            // 'arrival_report'  	=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/arrival-products/arrival-report/arrival-report.controller.php',
            // 'write_off_form'    =>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/write-off-products/write-off-form/write-off-form.controller.php',
            // 'write_off_report'  =>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/write-off-products/write-off-report/write-off-report.controller.php',
            // 'admin'         	=>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/admin/admin.controller.php',
            // 'create_warehouse'  =>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/warehouse/create-warehouse.controller.php',
            // 'payment_method_form'  =>  $_SERVER['DOCUMENT_ROOT'].'/core/controller/payment_method_form/payment-method-form.controller.php',
        ];
        
        

        $param = [];
        $all_pages = [];

        if($page) {
            $data_param = require $controller_list[$page];
        } else {
            foreach ($controller_list as $key => $val) {
                $all_pages[$key] = require $val; 
            }

            return $all_pages;
        }

        $this->data = $data_param;
    }


}


$er = new test2;

Utils::lsVarDump($er->data);


$init->initController($index);
$init->initController($index)->tableName;



$select = [
    'table_name' => ' user_control ',
    'col_list' => ' * ',
    'base_query' => ' INNER JOIN products_provider_list ON products_provider_list.id_from_stock = :id 
                    LEFT JOIN stock_provider ON stock_provider.provider_id = products_provider_list.id_from_provider
    ',
    'param' => [
        'query' => [
            'param' => 'sadsadsa',
            'joins' => 'asdsadsa',
            'bindList' => array(
                ":id" => $id
            )
        ],
        'sort_by' => ' GROUP BY products_provider_list.id ASC ORDER BY products_provider_list.id ASC ',
        'limit' => '2'
    ]
];


$select = [
    'table_name' => ' user_control ',
    'col_list' => ' * ',
    'query' => [
        'base_query' => ' INNER JOIN products_provider_list ON products_provider_list.id_from_stock = :id 
                        LEFT JOIN stock_provider ON stock_provider.provider_id = products_provider_list.id_from_provider
        ',
        'body' => 'asjsahdas',
        'joins' => 'sadiasoidsa',
        'sort_by' => 'ashdsahdsiah',
        'limit' => 'sdajjdsajdsa'
    ],
    'bindList' => [
        'id' => $id
    ]
    
];

exit;
$td = [];
for ($i = 0; $i < 300; $i++) 
{

    $td[$i] = [
        'data' => [
            [
                'data' => 'jdfj',
                'td_class' => '',
            ],
            [
                'data' => 'jdfj',
                'td_class' => '',
            ],                    
        ]     
    ];
}


$res = [
    'th' => [
        [
            'title' => 'id',
            'modify_class' => 'th_w120 dom-sort-table'
        ],
        [
            'title' => 'Name',
            'modify_class' => 'th_w120 dom-sort-table'
        ]        
    ],
    'td' => [
       $td
    ]
];

$sysConfig = new \Core\Classes\System\SystemConfig;


echo $twig->render('/component/inner_container.twig', [
    'renderComponent' => [
        '/component/index/head.twig' => [
                    'lib_list' => $sysConfig->loadAssets(),
                    'v' => time() 
        ],        
        '/component/table/table_wrapper.twig' => [
            'table' => $res,
            'table_tab' => '',
            'table_type' => '',
        ],
    ]
]);
