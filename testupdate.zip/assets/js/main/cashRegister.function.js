$(document).ready(function(){

    $('body').on('click', '.load-cash-register-transaction-modal', function() {
        const route = $(this).attr('data-route');

        $.ajax({
            url: 'ajax_route.php',
            type: 'POST',
            dataType: 'json',
            data: {
                route: route
            },
            success: (data) => {
                pageData.overlayShow();
                $('.container').append(data.res);
            }
        }); 
    });

    $(document).on('click', '.apply-cashregister-transaction', function() {
        $this = $(this).closest('.modal-content');

        const amount = $this.find('.cahs-register-transaction-amount').val();
        const comment = $this.find('.cahs-register-transaction-comment').val();
        const paymentMethod = $this.find('.form-payment-method-id').val();

        const route = $(this).attr('data-route');

        $.ajax({
            url: 'ajax_route.php',
            type: 'POST',
            dataType: 'json',
            data: {
                route: route,
                page: pageData.page(),
                type: pageData.type(),
                amount: amount,
                paymentMethod: paymentMethod,
                comment: comment
            },
            success: (data) => {
                pageData.alert_notice(data.type, data.text);

				if(data.type == 'success') {
					$this.find('.form-input').val('');
                    
                    pageData.prependTable(data.table);
					// pageData

					closeAndRemoveModal();
                    load_stats_card(null);
					createBackup();
				}
            }
        });
    });


    $(document).on('click', '.filter-cash-regiser', function() {
        const date = $('.filter-cash-register-date').attr('value');
        const paymentMethod = $('.filter-cash-register-payment-method').attr('value');

        $.ajax({
            url: 'ajax_route.php',
            type: 'POST',
            dataType: 'json',
            data: {
                route: 'filterCashRegister',
                date: date,
                paymentMethod: paymentMethod
            },
            success: (data) => {
                if(data.table) {
                    pageData.innerTable(data.table);
                }

                load_stats_card(date);
            }
        });
    });
});