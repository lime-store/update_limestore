<?php

use core\classes\Services\Customer\Customer;
use core\classes\System\Init;
use core\classes\Utils\Utils;

$prepareData = $_POST['prepare_data'];

if (!empty($prepareData['customer_card_code']) && Customer::hasCardCode($prepareData['customer_card_code'])) {
    return Utils::errorAbort('Этот код уже есть');
}

if (empty($prepareData['customer_name'])) {
    return Utils::errorAbort('Заполните имя клиента');
}

if (empty($prepareData['customer_cashback_percent'])) {
    return Utils::errorAbort('Укажите процент кэшбэка');
}

Customer::add($prepareData);

$page = $_POST['page'];
$type = $_POST['type'];

$this_data = Init::initController($page);

$page_config = $this_data['page_data_list'];

$table_result = $main->prepareCustomData([Customer::getLastAdded()], $page_config);

$table = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_row.twig' => [
            'table' => $table_result['result'],
            'table_tab' => $page,
            'table_type' => $type
        ]
    ]
]);

return $utils::abort([
    'type' => 'success',
    'text' => 'Ok',
    'table' => $table,
]);
