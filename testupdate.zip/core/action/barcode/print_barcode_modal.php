<?php

use Core\Classes\Utils\Utils;
use Core\Classes\Products;
use Core\Classes\System\Settings;

header('Content-type: Application/json');



$stock_id = $_POST['data'];


$res = $products->getProductBarcodeList($stock_id);

$prod = Products::getProductById($stock_id);

$barcodeSetting = (object) Settings::getSettingsJSON();
$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
	      '/component/modal/custom_modal/u_modal.twig' => [
                  'containerClassList' => 'small-modal',
                  'modalController' => [
                        'title' => 'PRINT',
                  ],
                  'modalContent' => [
                        'path' => '/component/modal/barcode/print_barcode_modal.twig',		
                  ],
                  'res'      => $res,
                  'stock_id' => $stock_id,
                  'price'    =>  Settings::getSettingState('showPriceOnBarcodeLabel') ? $prod['stock_second_price'] : '',
                  'width' => $barcodeSetting->stickerWidth,
                  'height' => $barcodeSetting->stickerHeight
		]  
	]
]);


 $utils::abort([
	'res' => $total,
]);
