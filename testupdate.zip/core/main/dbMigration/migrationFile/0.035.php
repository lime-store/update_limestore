<?php

use core\classes\System\Migration;

Migration::createTableIfNotExist('inventory', "
    CREATE TABLE `inventory` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `title` varchar(255) NOT NULL,
    `status` varchar(32) NOT NULL DEFAULT 'active',
    `created_by` int(11) NOT NULL,
    `created_at` datetime NOT NULL,
    `completed_by` int(11) DEFAULT NULL,
    `completed_at` datetime DEFAULT NULL,
    `cancelled_by` int(11) DEFAULT NULL,
    `cancelled_at` datetime DEFAULT NULL,
    `comment` varchar(1000) DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_inventory_status` (`status`),
    KEY `idx_inventory_created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");

Migration::createTableIfNotExist('inventory_excluded_item', "
    CREATE TABLE `inventory_excluded_item` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `inventory_id` int(11) NOT NULL,
    `stock_id` int(11) NOT NULL,
    `created_by` int(11) NOT NULL,
    `created_at` datetime NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_inventory_excluded_item` (`inventory_id`,`stock_id`),
    KEY `idx_inventory_excluded_stock` (`stock_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");

Migration::createTableIfNotExist('inventory_session', "
    CREATE TABLE `inventory_session` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `inventory_id` int(11) NOT NULL,
    `session_number` int(11) NOT NULL,
    `status` varchar(32) NOT NULL DEFAULT 'open',
    `created_by` int(11) NOT NULL,
    `created_at` datetime NOT NULL,
    `review_started_at` datetime DEFAULT NULL,
    `closed_by` int(11) DEFAULT NULL,
    `closed_at` datetime DEFAULT NULL,
    `cancelled_by` int(11) DEFAULT NULL,
    `cancelled_at` datetime DEFAULT NULL,
    `adjustment_document_id` int(11) DEFAULT NULL,
    `comment` varchar(1000) DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_inventory_session_number` (`inventory_id`,`session_number`),
    KEY `idx_inventory_session_status` (`inventory_id`,`status`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");

Migration::createTableIfNotExist('inventory_session_item', "
    CREATE TABLE `inventory_session_item` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `session_id` int(11) NOT NULL,
    `stock_id` int(11) NOT NULL,
    `system_quantity` int(11) NOT NULL,
    `scanned_quantity` int(11) NOT NULL DEFAULT 0,
    `counted_quantity` int(11) NOT NULL DEFAULT 0,
    `difference_quantity` int(11) NOT NULL DEFAULT 0,
    `price` decimal(12,2) NOT NULL DEFAULT 0.00,
    `difference_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
    `created_by` int(11) NOT NULL,
    `created_at` datetime NOT NULL,
    `updated_by` int(11) DEFAULT NULL,
    `updated_at` datetime DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_inventory_session_item_stock` (`session_id`,`stock_id`),
    KEY `idx_inventory_session_item_stock` (`stock_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");

Migration::createTableIfNotExist('stock_adjustment_document', "
    CREATE TABLE `stock_adjustment_document` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `inventory_id` int(11) NOT NULL,
    `session_id` int(11) NOT NULL,
    `status` varchar(32) NOT NULL DEFAULT 'applied',
    `created_by` int(11) NOT NULL,
    `created_at` datetime NOT NULL,
    `applied_at` datetime DEFAULT NULL,
    `total_shortage_quantity` int(11) NOT NULL DEFAULT 0,
    `total_surplus_quantity` int(11) NOT NULL DEFAULT 0,
    `total_shortage_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
    `total_surplus_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
    `final_difference_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
    `comment` varchar(1000) DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_stock_adjustment_session` (`session_id`),
    KEY `idx_stock_adjustment_inventory` (`inventory_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");

Migration::createTableIfNotExist('stock_adjustment_item', "
    CREATE TABLE `stock_adjustment_item` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `adjustment_id` int(11) NOT NULL,
    `stock_id` int(11) NOT NULL,
    `quantity_before` int(11) NOT NULL,
    `counted_quantity` int(11) NOT NULL,
    `difference_quantity` int(11) NOT NULL,
    `quantity_after` int(11) NOT NULL,
    `price` decimal(12,2) NOT NULL DEFAULT 0.00,
    `difference_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
    `difference_type` varchar(16) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_stock_adjustment_item_stock` (`adjustment_id`,`stock_id`),
    KEY `idx_stock_adjustment_item_stock` (`stock_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
");