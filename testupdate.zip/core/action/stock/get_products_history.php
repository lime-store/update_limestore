<?php

use Core\Classes\Products;
use Core\Classes\Services\Warehouse\Traits\Arrival;
use Core\Classes\Utils\Utils;
use Core\Classes\System\Main;

header('Content-type: Application/json');

$stock_id = $_POST['data'];


$products = Products::getProductById($stock_id);

$data_page = $init->initController('productHistory');


$allData = [
    Arrival::getArrivalByProductId($stock_id),
    Arrival::getWriteOffByProductId($stock_id),
    Arrival::getTransferByProductId($stock_id),
    Arrival::getSalesById($stock_id),
    Arrival::getReturnSalesById($stock_id)
];

$result = array_merge(...$allData);


// asc
usort($result, function($a, $b) {
    return  strtotime($a['full_date']) <=> strtotime($b['full_date']);
});

$stock = 0; 

foreach ($result as &$item) {

    // Нормализуем count
    $cnt = $item['count'];
    $cnt = (int)str_replace('+', '', $cnt);

    // Применяем операцию
    $stock += $cnt;

    // Записываем остаток после операции
    $item['after_balance'] = $stock;
    $item['stock_name'] = $products['stock_name'];
    $item['stock_id'] = $products['stock_id'];
}


$table_result = Main::prepareCustomData($result, $data_page['page_data_list']);

$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/custom_modal/u_modal.twig' => [
            'modalController' => [
                'title' => 'Məhsulun tarixçəsi',
                'closeButtonClassList' => 'removeModal',
            ],
            'modalContent' => [
                'path' => '/component/table/table_wrapper.twig',
            ],
            'containerClassList' => 'large-modal',
            'class_list' => '', 
            'table' => $table_result['result'],   
		]  
	]
]);


$utils::abort([
	'res' => $total,
]);
