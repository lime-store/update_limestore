<?php 

namespace Core\Classes\Privates;

use core\classes\dbWrapper\db;

class User
{
    /**
     * получить данные пользователя сесии
     * @param string $get_info
     * @param string get_id      user_id
     * @param string get_name    user_name
     * @param string get_role    user_role
     */
    public static function getCurrentUser($get_info = null) 
    {
        if(isset($_SESSION['user'])) {
            $user_id = $_SESSION['user'];
    
            // $ustmp = $this->dbpdo->prepare('SELECT * FROM user_control WHERE user_id = :id');
            // $ustmp->bindParam(':id', $user_id, \PDO::PARAM_INT);
            // $ustmp->execute();
            // $row = $ustmp->fetch(\PDO::FETCH_ASSOC);

            $row = db::select([
                'table_name' => 'user_control',
                'col_list' => '*',
                'query' => [
                    'base_query' => '   WHERE user_id = :id '
                ],
                'bindList' => [
                    ':id' => $user_id
                ]
            ])->first()->get();
        

            switch ($get_info) {
                case 'get_id':
                    return $user_id = $row['user_id'];
                    break;
                case 'get_name':
                    return $user_name = $row['user_name'];
                    break;
                case 'get_role':
                    return $user_role = $row['user_role'];
                    break;
                case 'get_password':
                    return $user_password = $row['user_password'];
                    break;
                default:
                    return $row;
                    break;	
            }
        } 

        return false;
    }


    /**
     * old function name get_all_user_list
     * 
     * получить список пользователей
     * 
     * @return array|null
     */
    public function getAllUser()
    {
        return db::select([
            'table_name' => 'user_control',
            'col_list' => '*',
            'query' => [
                'base_query' => ' WHERE user_visible = 0',
                'body' => '',
                'joins' => '',
                'sort_by' => ' ORDER BY user_id',
                'limits'
            ],
            'bindList' => [],
        ])->get();
    }    


    /**
     * Добавляем нового пользователя
     * 
     * old function name add_new_user
     */
    public function addUser($arr) 
    {
        return db::insert('user_control', [
            [
                'user_name' => $arr['seller_name'],
                'user_password' => $arr['seller_password'],
                'user_role'	=> $arr['seller_role']
            ]
        ]);
    }


    public static function hasCurrentUserAdmin()
    {
        $userRole = self::getCurrentUser('get_role');

        if($userRole == 'admin') {
            return true;
        } 

        return false;
    }
    


        /**
     * Проверить уникальность логина пользователя
     * @param string $user_name
     * @return boolean  true/false (true - пользователя нет, false - пользователь есть в базе данных) 
     * 
     * old function name is_unique_user
     */
    public function isUsernameAvailable($user_name) 
    {
        $data = db::select([
            'table_name' => 'user_control',
            'col_list'	=> '*',
            'query' => [
                'base_query' => ' WHERE user_name = :user_name ',
            ],
            'bindList' => [
                ':user_name' => $user_name
            ]            
        ])->get();
    

        return empty($data) ? true : false;
    }


    /**
     * 
     * old function name get_last_added_user 
     */
    public function getLastAddedUser() 
    {
        return  db::select([
            'table_name' => 'user_control',
            'col_list' => '*',
            'base_query' => ' WHERE user_visible = 0 ',
            'query' => [
                'sort_by' => ' GROUP BY user_id  DESC ORDER BY user_id DESC ',
                'limit' => 'LIMIT 1'
            ]
        ])->get();
    }    


    /**
     * Удаляем пользователя
     * 
     * old function name delete_user
     */
    public function deleteUser($user_id) 
    {
        $options = [
            'before' => ' UPDATE user_control SET ',
            'after' => ' WHERE user_id = :id ',
            'post_list' => [
                'user_id' => [
                    'query' => ' user_visible = 1  ',
                    'bind' => 'id'  
                ],
            ]
    
        ];
    
        return db::update($options, [
            'user_id' => $user_id
        ]);
    }
        

    /**
     * Редактируем данные пользователя
     * 
     * @param array $arr
     */
    public function editUser($arr) 
    {
        $options = [
            'before' => ' UPDATE user_control SET ',
            'after' => ' WHERE user_id = :id ',
            'post_list' => [
                'seller_id' => [
                    'query' => false,
                    'bind' => 'id'  
                ],
    
                'edit_seller_name' => [
                    'query' => ' user_name = :usr_name  ',
                    'bind' => 'usr_name'
                ],
                'edit_seller_password' => [
                    'query' => ' user_password = :usr_password ',
                    'bind' => 'usr_password'
                ]
            ]
    
        ];
    
        return db::update($options, $arr);
    }
}