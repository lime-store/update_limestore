<?php 
use core\classes\Products;
use core\classes\Report;
use core\classes\System\Init;
use core\classes\System\Main;

$transaction_id     = $_POST['transactionId'];
$transactionType    = $_POST['referenceType'];


$referanceTypeList = Products::getReferenceTypeDescriptions();
$list = [];
$controllerIndex = '';

switch (array_search($transactionType, $referanceTypeList)) {
    case 'sales':
        $list = Report::getReportByColumn('transaction_id', $transaction_id, [0, 2, 3]);
        $controllerIndex = 'report';
        break;
    case 'arivval':
        echo 'ff';
        break;
    default:
        echo 'none';
    break;
}

$controller = Init::initController($controllerIndex);

$data = Main::compareData($list, $controller['page_data_list']);

$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/custom_modal/u_modal.twig' => [
            'modalController' => [
                'title' => "Bonus tarixçəsi",
                'closeButtonClassList' => 'removeModal',
            ],
            'modalContent' => [
                'path' => '/component/include_once_component.twig',
            ],
            'includs' => [
                'd' => [
                    // '/component/widget/title.twig' => [
                    //     'title' => 'dsd',
                    //     'classList' => 'margin-0 mrgn-top-100 sub-title',
                    // ],
                    '/component/table/table_wrapper.twig' => [
                        'table' => $data
                    ],
                ]
            ],
            'containerClassList' => 'large-modal',  
		]  
	]
]);


$utils::abort([
	'res' => $total,
]);