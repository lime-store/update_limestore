<?php

namespace core\Classes\System;

class Constants
{
    public const ROOT_DIR = __DIR__.'/../../../';

    public const RETAIL_CONTROLLER_DIR = self::ROOT_DIR.'/core/controller/RetailController';
    public const WHOLESALE_CONTROLLER_DIR = self::ROOT_DIR.'/core/controller/WholesaleController';
}