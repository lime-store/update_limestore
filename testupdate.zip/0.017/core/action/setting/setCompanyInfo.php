<?php
header('Content-type: application/json');
use Core\Classes\Utils\Utils;
use Core\Classes\System\Settings;
use Core\Classes\System\System;

if(!empty($_POST['companyName']) && !empty($_POST['companyContact'])) {
    Settings::appendSettingsJSON([
        'generalInfo' => [
            'companyName'       => $_POST['companyName'],
            'companyContact'    => $_POST['companyContact'],
            'token'             => System::getToken()
        ]
    ]);

    Settings::appendSettingsJSON([
        'generalInfo' => [
            'companyDescription' => $_POST['companyDescription'],
            'companyAdress'      => $_POST['companyAdress'],
        ]
    ]);

    Settings::editSetting('generalInfoModal', 0);

    Utils::successAbort('Ok');
} else {
    Utils::errorAbort('Заполните данные полностью');
}