<?php 

function terminal_order_list_tpl($filter_title, $filter_name, $give_product_id, $custom_class_filter_input, $mark) {
?>	
	<li class="order_modal_list">
		<span class="module_order_desrioption"><?php echo $filter_title; ?></span>
		<?php get_filter_selected_input_value($filter_name, $give_product_id, $custom_class_filter_input, 'disabled', 'terminal', $mark); ?>
	</li>
<?php
}


function stock_edit_order_list_tpl($filter_title, $filter_name, $edit_stock_id, $custom_class_filter_input, $mark) {
?>
		<li class="order_modal_list">
			<span class="module_order_desrioption"><?php echo $filter_title; ?></span>
			<div class="add_stock_filter_redit">
				<div class="ls-custom-select-wrapper">
					<ul class="ls-select-list">
						<div class="select-drop-down">

						<?php get_filter_selected_input_value($filter_name, $edit_stock_id, $custom_class_filter_input, '', 'stock', $mark); ?>

							<div class="reset_option">
								<input type="button" class="ls-reset-option ls-reset-option-style">
							</div>
						</div>
						<div class="ls-select-option-list">
							<ul class="ls-select-list-option ls-custom-scrollbar">
								<?php get_filter_li_list($filter_name, '', ''); ?>		
							</ul>
						</div>
					</ul>
				</div>				
			</div>
		</li>
<?php			
}