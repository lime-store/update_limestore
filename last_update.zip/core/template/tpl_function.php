<?php 
//шаблон для оформения заказа на странице терминала - лист
function terminal_order_list_tpl($filter_title, $filter_name, $give_product_id, $custom_class_filter_input, $mark) {
?>	
	<li class="order_modal_list">
		<span class="module_order_desrioption"><?php echo $filter_title; ?></span>
		<?php get_filter_selected_input_value($filter_name, $give_product_id, $custom_class_filter_input, 'disabled', 'terminal', $mark); ?>
	</li>
<?php
}

//шаблон для редакрирования товара на стрнаице амбар - лист
function stock_edit_order_list_tpl($filter_title, $filter_name, $edit_stock_id, $custom_class_filter_input, $mark) {
?>
		<li class="order_modal_list">
			<span class="module_order_desrioption"><?php echo $filter_title; ?></span>
			<div class="add_stock_filter_redit">
				<div class="ls-custom-select-wrapper">
					<ul class="ls-select-list">
						<div class="select-drop-down">

						<?php get_filter_selected_input_value($filter_name, $edit_stock_id, $custom_class_filter_input, '', 'stock', $mark); ?>

							<div class="reset_option">
								<input type="button" class="ls-reset-option ls-reset-option-style">
							</div>
						</div>
						<div class="ls-select-option-list">
							<ul class="ls-select-list-option ls-custom-scrollbar">
								<?php get_filter_li_list($filter_name, '', ''); ?>		
							</ul>
						</div>
					</ul>
				</div>				
			</div>
		</li>
<?php			
}

//вывод списка филтров для страницы терминал
function terminal_filter_return_tpl($filter_title, $filter_name, $class, $text) {
?>
	<li class="filter_return_list ls-select-list">
		<div class="filter_check_count"></div>
		<div class="select-drop-down">
			<input type="button"  class="<?php echo $class; ?> drop_down_btn filter_input_height_modify" value="<?php echo $filter_title; ?>" default-value="<?php echo $filter_title; ?>">
			<div class="reset_option">
				<input type="button" class="ls-reset-option ls-reset-option-style">
			</div>
		</div>
		<div class="ls-select-option-list">
			<ul class="ls-select-list-option ls-custom-scrollbar">
				<?php ger_filter_param($filter_name, $text); ?>		
			</ul>
		</div>

	</li>
<?php		
}

function auto_complete_select_wrapper_tpl() {
?>
	<div class="auto-cmplt-select auto-compelete-list-style">
		<ul class="ls-select-list-option ls-custom-scrollbar auto-cmplt-result">
			<?php get_autocomplete_list_tpl('', ''); ?>
		</ul>
	</div>
<?php
}


function get_autocomplete_list_tpl($list_value, $text) {
	if(empty($list_value)) { echo '<span class="">Начните вводить название</span>'; }
	else {
?>	


	<li class="ls-select-li">
		<a href="javascript:void(0)" class="choice-style auto-cmplt-list" id="" value="<?php echo $list_value; ?>">
			<span class="mark filter-name"><?php echo $list_value; ?></span>
			<span class="mark filter-mark-text"><?php echo $text; ?></span>
		</a>
	</li>
<?php
	}
}


//кнопка для доп функциий на вклдаке отчета (report) шаблон
function advanced_option_load_tpl() {
?>
<div class="filter_buttons_wrapper">
	<div class="filter_block_open_wrp">
		<a href="javascript:void(0)" class="filter_wodjet_button_style open_filter_widjet load_advanced_report">
			<span class="mark mark--img"><img src="/img/icon/advanced.png"></span>
			<span class="mark mark--name filter_widjet_btn_title">Digər</span>
			<span class="mark filter-count"></span>
		</a>
	</div>

	<div class="filter_content report_load_advncd_options">
		<div class="advanced_list">
			here load list
		</div>
	</div>
</div>


<?php
}

//ip+
//user name
//window height
//window width
//user message
//опросник который собирает данные и отправляет на сервер
function get_theme_quiz_tpl() {
?>	
	<div class="modal quiz_modal">
		<div class="quiz_modal_wrapper flex-cntr">
			<div class="quiz_modal_content flex-cntr">
				<div class="modal_preloder"></div>
				<div class="quiz_form_wrp flex-cntr">
					<div class="quiz_cont">
						<div class="quiz_header">Proqramın yeni dizayn xoşunuza gəlirmi?</div>
						<div class="quiz_form">
							<div class="quiz_row">
								<div class="quiz_option_list">
									<div class="quiz_rate">
										<a href="javascript:void(0)" class="quiz_btn_style ls_radio quiz_choice">Hə</a>
									</div>
									<div class="quiz_rate">
										<a href="javascript:void(0)" class="quiz_btn_style ls_radio quiz_choice">Yox</a>
									</div>	
								</div>	
								<div class="hidden_info">
									<input type="hidden" class="window_size" data-width="">
									<input type="hidden" class="user_name" data-uname="<?php getUserName(); ?>">
								</div>
							</div>	
							<div class="quiz_rate quiz_area">
								<span class="label quiz_lable">Sizin təklifiniz</span>
								<textarea placeholder="text..." maxlength="200" class="quiz_text_area quiz_text_area_style"></textarea>
							</div>
							<div class="quiz_row quiz_submit_box">
								<a href="javascript:void(0)" class="send_quiz qiuz_submit_btn_style">Göndər</a>
							</div>					
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php 	
}