<?php 
namespace core\classes\Services;

use core\classes\System\Constants;
use core\classes\Utils\Utils;
use Twig\Loader\FilesystemLoader;
use Twig\Environment;

class RenderTemplate
{
    public static $twig;

    /**
     * загружает новый шаблон
     */
    public function load($tpl)
    {
      return $this->initTwig()->load($tpl);
    }
    
    /**
     * Иницилизирует твиг
     */
    public static function initTwig($dir = null)
    {
      $default_dir = $dir ?: Constants::ROOT_DIR.'/core/template/';
      $loader = new FilesystemLoader($default_dir);
      $twig = new Environment($loader);  

      return $twig;
    } 

    /**
     * Иницилизирует твиг и выводит шаблон
     */
    public static function view(string $template, array $content = [], $dir = null)
    {
      
      //load lang pack
      $content['lang'] = [
        'buttons' => 'sadjas'
      ];
      
      return self::initTwig()->render($template, $content, $dir);
    }
}