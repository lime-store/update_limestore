<?php 
use core\classes\Traits\Barcode;
use core\classes\Utils\Utils;

header('Content-Type: application/json');

return Utils::abort([
    'res' => Barcode::generateBarcodeNumber()
]);