<?php 
use Core\Classes\System\Migration;
use core\classes\dbWrapper\db;

/**
 * add column "transaction_id" to stock_order_report
 */
$stock_order_report_v0014_column_list = [
    'transaction_id' => 'BIGINT NOT NULL',
];

Migration::hasTableColumnExist('stock_order_report', $stock_order_report_v0014_column_list, function($notExists) {
    if($notExists) {
        Migration::alertTableColumn('stock_order_report', $notExists);
    }
});



/**
 * add column "transaction_id" to arrival_products
 */
$arrival_products_v0014_column_list = [
    'transaction_id' => 'BIGINT NOT NULL',
];

Migration::hasTableColumnExist('arrival_products', $arrival_products_v0014_column_list, function($notExists) {
    if($notExists) {
        Migration::alertTableColumn('arrival_products', $notExists);
    }
});


/**
 * write_off_products
 */
Migration::hasTableExist('write_off_products', function($noExist) {
    if($noExist) {
        Migration::createTable(
            'CREATE TABLE `write_off_products` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `description` varchar(255) NOT NULL,
                `count` int(11) NOT NULL,
                `day_date` varchar(30) NOT NULL,
                `full_date` varchar(30) NOT NULL,
                `id_from_stock` int(11) NOT NULL,
                `transaction_id` varchar(255) NOT NULL,
                PRIMARY KEY (`id`)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;'
        );
    }
});


/**
 * warehouse_list
 */
Migration::hasTableExist('warehouse_list', function($noExist) {
    if($noExist) {
        Migration::createTable(
            'CREATE TABLE `warehouse_list` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `warehouse_name` varchar(255) NOT NULL,
                `warehouse_contact` varchar(255) NOT NULL,
                `warehouse_address` varchar(255) NOT NULL,
                `warehouse_info` varchar(255) NOT NULL,
                `warehouse_visible` int(11) NOT NULL,
                PRIMARY KEY (`id`)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;'
        );
    }
});


/**
 * transfer_list
 */
Migration::hasTableExist('transfer_list', function($noExist) {
    if($noExist) {
        Migration::createTable(
            'CREATE TABLE `transfer_listt` (
                `transfer_id` int(11) NOT NULL AUTO_INCREMENT,
                `warehouse_id` int(11) NOT NULL,
                `stock_id` int(11) NOT NULL,
                `transfer_date` varchar(60) NOT NULL,
                `transfer_full_date` varchar(60) NOT NULL,
                `count` int(11) NOT NULL,
                `description` varchar(255) NOT NULL,
                `visible` int(11) NOT NULL,
                `transaction_id` varchar(255) NOT NULL,
                PRIMARY KEY (`transfer_id`)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;'
        );
    }
});