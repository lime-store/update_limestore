<?php 

namespace core\classes\Services\Inventory;

use core\classes\System\Constants;

class Inventory 
{
    public static function initInventory()
    {
        return [
            'inventory' => Constants::RETAIL_CONTROLLER_DIR.'/inventory/inventory.controller.php',
        ];
    }
}