<?php
header('Content-type: Applcation/json');

use core\classes\Services\Warehouse\Warehouse;
use core\classes\Utils\Utils;

$warehouse = new Warehouse;

if(!empty($_POST['prepare'])) {
    
    $data = $_POST['prepare'];

    $warehouse->editWarehouse($data);
    echo $utils::successAbort('Ok');
} else {
    echo Utils::abort([
        'type' => 'success',
        'text' => 'Ok'
    ]);   
}