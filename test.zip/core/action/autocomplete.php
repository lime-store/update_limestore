<?php 

require_once $_SERVER['DOCUMENT_ROOT'].'/function.php';

//подключаем шаблоны
ls_include_tpl();

function default_cmplt_option($search) {
	get_autocomplete_list_tpl($sort = array(
		'id' 			 => '',
		'value'			 => $search,
		'attr-data-sort' => '',
		'class'			 => '',
		'mark_class'	 => '',
		'text' 			 => '' 
		)
	);	
}


if(isset($_POST['value'])) {
	if(!empty($_POST['value'])) {
		$search = trim($_POST['value']);
		if(isset($_POST['action'])) {
			$action = $_POST['action'];
			$search_list = [];
			if($action == 'name') {
				$query = 'SELECT DISTINCT stock_name as res 
						  FROM stock_list 
						  WHERE stock_name LIKE :name 
						  GROUP BY stock_name DESC 
						  LIMIT 100';

			}
			if($action == 'category') {
				$query = 'SELECT DISTINCT stock_provider as res 
						  FROM stock_list 
						  WHERE stock_provider LIKE :name 
						  GROUP BY stock_provider DESC 
						  LIMIT 100';
			}

			$search_value_stmt = $dbpdo->prepare($query);
			$search_value_stmt->bindValue('name', "%{$search}%"); 
			$search_value_stmt->execute();


			if($search_value_stmt->rowCount() > 0) {
				while ($search_value_row = $search_value_stmt->fetch(PDO::FETCH_BOTH))
					$search_list[] = $search_value_row;
				foreach ($search_list as $search_value_row) {
						$search_val = $search_value_row['res'];

						get_autocomplete_list_tpl($sort = array(
							'id' 				=> '',
							'value'				=> $search_val,
							'attr-data-sort' 	=> '',
							'class' 			=> '',
							'mark_class'		=> '',
							'text' 				=> '' 
							)
						);						
				}
			} else {

			}

		}
		if(isset($_POST['search_filter'])) {
			//поиск по имени
			$srch_by_name = [];
			$type = $_POST['type'];
			$category = $_POST['category'];


			function return_auto_cmplt_option($query, $col_name, $data_sort_name) {
			    if($query->rowCount() > 0){
					while ($cmplt_row = $query->fetch(PDO::FETCH_BOTH))
						$report_list[] = $cmplt_row;
						foreach ($report_list as $cmplt_row)
						{
							$list_name = $cmplt_row[$col_name];
							get_autocomplete_list_tpl($sort = array(
								'id' 				=> '',
								'value'				=> $list_name,
								'attr-data-sort'	=> $data_sort_name,
								'class' 			=> 'get_item_stock_action',
								'mark_class'		=> 'stock_info_text',
								'text'				=> '' 
								)
							);
						} 
				} 					
			}


			if($type == 'report') {
				//поиск по имени
				$auto_cmplt_name = $dbpdo->prepare("SELECT DISTINCT stock_order_report.order_stock_name
				FROM rasxod

				INNER JOIN stock_order_report
				ON stock_order_report.order_stock_name LIKE :search_name
				AND stock_order_report.stock_order_visible = 0
				AND stock_order_report.stock_type = :prod_category
				AND stock_order_report.order_stock_count > 0

				LEFT JOIN stock_list 
				ON stock_list.stock_id = stock_order_report.stock_id 			
				
		 		GROUP BY stock_order_report.order_stock_id DESC
				ORDER BY stock_order_report.order_stock_id DESC");
				$auto_cmplt_name->bindValue('search_name', "%{$search}%");
				$auto_cmplt_name->bindValue('prod_category', $category);
				$auto_cmplt_name->execute();
				return_auto_cmplt_option($auto_cmplt_name, 'order_stock_name', 'name');

				//поиск по поставщикам
				$auto_cmplt_provider = $dbpdo->prepare("SELECT DISTINCT stock_list.stock_provider
				FROM rasxod

				LEFT JOIN stock_list 
				ON stock_list.stock_provider
				LIKE :search_query 

				INNER JOIN stock_order_report
				ON stock_order_report.stock_id = stock_list.stock_id
				AND stock_order_report.stock_order_visible = 0
				AND stock_order_report.stock_type = :prod_category	
				AND stock_order_report.order_stock_count > 0
			 	GROUP BY stock_order_report.order_stock_id DESC
				ORDER BY stock_order_report.order_stock_id DESC");		
				$auto_cmplt_provider->bindValue('search_query',  "%{$search}%"); 
				$auto_cmplt_provider->bindValue('prod_category',  $category);
				$auto_cmplt_provider->execute();
				return_auto_cmplt_option($auto_cmplt_provider, 'stock_provider', 'provider');


				//поиск по imei
				$auto_cmplt_imei = $dbpdo->prepare("SELECT DISTINCT stock_order_report.order_stock_imei
				FROM rasxod

				INNER JOIN stock_order_report
				ON stock_order_report.order_stock_imei LIKE :search_name
				AND stock_order_report.stock_order_visible = 0
				AND stock_order_report.stock_type = :prod_category
				AND stock_order_report.order_stock_count > 0

				LEFT JOIN stock_list 
				ON stock_list.stock_id = stock_order_report.stock_id 			
				
		 		GROUP BY stock_order_report.order_stock_id DESC
				ORDER BY stock_order_report.order_stock_id DESC");
				$auto_cmplt_imei->bindValue('search_name', "%{$search}%");
				$auto_cmplt_imei->bindValue('prod_category', $category);
				$auto_cmplt_imei->execute();
				return_auto_cmplt_option($auto_cmplt_imei, 'order_stock_imei', 'imei');


			} 

			if($type === 'terminal' || $type === 'stock') {
				//поиск по имени
				$auto_terminal_name = $dbpdo->prepare('SELECT DISTINCT stock_name FROM stock_list 
														WHERE stock_name 
														LIKE :search 
														AND stock_visible = 0
														AND stock_type = :type 
														AND stock_count > 0');
				$auto_terminal_name->bindValue('search',  "%{$search}%"); 
				$auto_terminal_name->bindValue('type',  $category);
				$auto_terminal_name->execute();
				return_auto_cmplt_option($auto_terminal_name, 'stock_name', 'name');

				//поиск по imei
				$auto_terminal_imei = $dbpdo->prepare('SELECT DISTINCT stock_phone_imei FROM stock_list 
														WHERE stock_phone_imei 
														LIKE :search 
														AND stock_visible = 0
														AND stock_type = :type 
														AND stock_count > 0');
				$auto_terminal_imei->bindValue('search',  "%{$search}%"); 
				$auto_terminal_imei->bindValue('type',  $category);
				$auto_terminal_imei->execute();
				return_auto_cmplt_option($auto_terminal_imei, 'stock_phone_imei', 'imei');	

				//поиск по provider
				$auto_terminal_provider = $dbpdo->prepare('SELECT DISTINCT stock_provider FROM stock_list 
														WHERE stock_provider 
														LIKE :search 
														AND stock_visible = 0
														AND stock_type = :type 
														AND stock_count > 0');
				$auto_terminal_provider->bindValue('search',  "%{$search}%"); 
				$auto_terminal_provider->bindValue('type',  $category);
				$auto_terminal_provider->execute();
				return_auto_cmplt_option($auto_terminal_provider, 'stock_provider', 'provider');								

			}
		}
	}
}
