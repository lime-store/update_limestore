<?php

use Core\Classes\Report;
use Core\Classes\Utils\Utils;

header('Content-type', 'Application/json');

$report = new \Core\Classes\Report;

if(!empty($_POST['report_id'])) {
	$reportId = $_POST['report_id'];
	
	$curReport = $report->getReportById($_POST['report_id']);
	
	if($curReport['has_editable'] == 0) {
		return Utils::errorAbort('Məhsul əvvəl geri qaytarıldığı üçün redaktə etmək mümkün deyil');
	}

	$report->deleteReport($_POST);
	
	if($curReport['stock_order_visible'] == 3) {
		$salesReport = $report->getReportByColumn('stock_order_report.transaction_id', $curReport['transaction_id']);
		$salesReport = $salesReport[0];

		$increasesQuantity = $curReport['order_stock_count'];
		
		Report::increaseRefaundQuantity([
			'report_id' => $salesReport['order_stock_id'],
			'refaund_quantity' => $increasesQuantity
		]);

		$refaundReport = $report->getReportByColumn('stock_order_report.transaction_id', $curReport['transaction_id'], [3]);

		if($refaundReport == false) {
			$report->setReportEditableState($salesReport['order_stock_id'], true);
		}
	}

	echo $utils::successAbort('Ok');
} else {
	return Utils::errorAbort('Empty result');
}


