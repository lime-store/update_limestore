<?php

namespace core\classes\dbWrapper\traits;

trait transaction
{
    public static function beginTransaction()
    {
        return parent::$dbpdo->beginTransaction();
    }

    public static function commit()
    {
        return parent::$dbpdo->commit();
    }

    public static function rollBack()
    {
        if (parent::$dbpdo->inTransaction()) {
            return parent::$dbpdo->rollBack();
        }
    }
}