<?php 
namespace Core\Classes\Traits;

use core\classes\dbWrapper\db;
use Core\Classes\Utils\Utils;

trait token 
{
    /**
     * @link https://www.uuidgenerator.net/dev-corner/php
     */
    public static function generateToken($data = null) {
        // Generate 16 bytes (128 bits) of random data or use the data passed into the function.
        $data = $data ?? random_bytes(16);
        assert(strlen($data) == 16);
    
        // Set version to 0100
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        // Set bits 6-7 to 10
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    
        // Output the 36 character UUID.
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    /**
     * 
     */
    public static function setToken(string $token)
    {
        $option = [
            'before' => ' UPDATE licence  SET ',
            'after' => "  ",
            'post_list' => [
                'tokens' => [
                    'query' => ' token = :token ',
                    'bind' => 'token'
                ]
            ]
        ];

        $data = [
            'tokens' => $token
        ];

        db::update($option, $data);
    }

    /**
     * @return boolean
     * @return true      Токен установлен
     * @return false     Токена нет
     */
    public static function hasTokenAvailable(callable $callback)
    {
        $result = db::select([
            'table_name' => 'licence',
            'col_list' => 'token',
            'query' => [],
        ])->first()->get();

        if($result['token']) {
            return $callback(true);
        } 
        
        return $callback(false);
    }


    /**
     * 
     */
    public static function getToken()
    {
        $result = db::select([
            'table_name'    => 'licence',
            'col_list'     => 'token',
            'query'         => []
        ])->first()
           ->get();

        return $result['token'];
    }
}
