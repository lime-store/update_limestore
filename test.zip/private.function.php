<?php 
//проверка доступа страницы
function user_check_access_right() {
	global $dbpdo;
	//получаем роль пользователя
	$user_role = getUser('get_user_role');
	$user_id = getUser('get_id');
	//если не админ
	if($user_role !== 'admin') {
		$get_curr_url = basename($_SERVER['REQUEST_URI']);

		$acces_page_list = $dbpdo->prepare('SELECT * FROM user_access_pages WHERE user_id = :user_id AND access_page_base_link = :base_link');
		$acces_page_list->bindParam('user_id', $user_id);
		$acces_page_list->bindParam('base_link', $get_curr_url);
		$acces_page_list->execute();
		if($acces_page_list->rowCount()>0) {
			echo "Access deneid!!";
			exit();
		}
	}
}

//проверка достпа запросов
function user_check_action_reqst() {
	//получаем роль юзера сессии
	$user_role = getUser('get_user_role');
	//получаем файл к которому был сделан запрос
	$uri = $_SERVER['REQUEST_URI'];
	$uri = basename($uri);
	//зпарещенные страница для seller
	if($user_role === 'seller') {
		$access_seller = array(
			'update_product.php'
		);

		if(in_array($uri, $access_seller)) {
			echo json_encode(array(
				'error' => "Ошибка! \n У Вас не достаточно доступа для выполение данной операции", 
			));
			exit();
		}

	}
}


// проверка на доступ юзера к таблице
function check_access_right($arr) {
	/**example 
	*
	*	check_access_right(array(
	*		'th_var' => 'th_count',
	*		'function' => 'render_td',
	*		'modify_class' => '',
	*		'table_data' => array(
	*			'td_value' 			=> $value,
	*			'td_parent_class'	=> 'table_stock',
	*			'td_link_class' 	=> 'stock_info_link_block',
	*			'td_mark_text'		=> ''
	*		)
	*	));	
	*/



	global $dbpdo;
	//выводим кастомную функцию, которую передаем массивом, пример: $function = $arr->function; потом: return $function($args);
	$function = $arr['function'];
	//класс модификатор
	$modify_class = $arr['modify_class'];
	$th_description = $arr['th_var'];

	//table data
	$td = 'default';
	//данные для генерации табицы
	if(array_key_exists('table_data', $arr)) {
		$td = $arr['table_data'];
	}

	//id пользователя из сессии
	$user_id = getUser('get_id');	



	//находим в базе и выводим всю нужную инфорацию по заголовку
	$get_header_info = $dbpdo->prepare('SELECT * FROM th_list WHERE th_description = :th_value');
	$get_header_info->bindValue('th_value', $th_description);
	$get_header_info->execute();
	$row_th_info = $get_header_info->fetch(PDO::FETCH_LAZY);

	$th_info_id = $row_th_info->th_id;
	$th_info_name = $row_th_info->th_name;
	$th_info_description = $row_th_info->th_description;


	//проверяем в табице запретов на наичие id
	$get_right = $dbpdo->prepare('SELECT * FROM data_td_accsess WHERE td_tags_id = :access_th_id AND user_id = :user_id ');
	$get_right->bindParam('access_th_id', $th_info_id);
	$get_right->bindParam('user_id', $user_id);
	$get_right->execute();

	$row = $get_right->fetch(PDO::FETCH_LAZY);
	//если id имееться в базе то ничего не выводим; иначе вызываем функцию , которую передали (см.выше) 
	if($get_right->rowCount()>0) {
		//nohing to do
	} else {
		//render html
		//если такая функция есть
		if(function_exists($function)) {
			$function(array('modify_class' => $modify_class, 'th_name' => $th_info_name, 'td' => $td));
		}
	}
}



//записуем доступ для пользователя  
function add_user_access_rights($rights) {
	// $action - запрос 
	// $data - массив с правами досиупа к данным таблицы для пользователя 
	// telplate
	/*
		add_user_access_rights(array(
			'action' => 'page_access/data_access',
			'data' => $arr2,
			'user_id' => N
		));		
	*/
	global $dbpdo;

	//запрос для выполнения
	$action = $rights['action'];
	//данные для записи
	$data = $rights['data'];
	//id - пользователя
	$user_id = $rights['user_id'];



	if($action == 'data_access') {
		foreach ($data as $access) {
			$insert_access = $dbpdo->prepare('INSERT INTO data_td_accsess (td_id, user_id, td_tags_id, accsess_status) 
				VALUES (NULL, :user_id, :access_param, 0) ');
			$insert_access->bindParam('user_id', $user_id);
			$insert_access->bindParam('access_param', $access);
			$insert_access->execute();
		}
	}

	if($action == 'page_access') {
		foreach ($data as $paccess) {
			$base_link = basename($paccess);
			$insert_access_page = $dbpdo->prepare('INSERT INTO user_access_pages 
				(access_id, user_id, access_page_name, access_page_base_link) 
				VALUES (NULL, :user_id, :full_page_link, :base_page_link) ');
			$insert_access_page->bindParam('user_id', $user_id);
			$insert_access_page->bindParam('full_page_link', $paccess);
			$insert_access_page->bindParam('base_page_link', $base_link);
			$insert_access_page->execute();			
		}
	}	
}

//Сбрасываем доступы пользователя
function reset_user_all_access($arr) {
	global $dbpdo;
	/**
	*example 
	*	$arr = array(
	*		'id' => user id ,
	*		'action' => data/pageaccess,
	*		'action_state' => true 
	*	);
	*/
	$id = $arr['id'];
	$action = $arr['action'];
	$action_state = $arr['action_state'];

	if($action_state == true) {
		if($action == 'data_access') {
			//DELTE data ACCESS
			$delete_data = $dbpdo->prepare('DELETE FROM data_td_accsess WHERE user_id = :u_id');
			$delete_data->bindParam('u_id', $id, PDO::PARAM_INT);
			$delete_data->execute();
		}

		if($action === 'page_access') {
			//delete page access
			$delete_page = $dbpdo->prepare('DELETE FROM user_access_pages WHERE user_id = :u_id');
			$delete_page->bindParam('u_id', $id, PDO::PARAM_INT);
			$delete_page->execute();	
		}
	}
}

//получаемп список правил пользователя для редкатирования
function get_user_access_list($var) {
	global $dbpdo;
	$var = (object) $var;

	/**example
	*	$var = array(
	*		'action'   => 'action'	 
	*		'data_arr' => $menu_query,
	*		'user_id'  => $user_id,
	*	);
	**/

	$data 		  = [];
	$active_link  = '';
	$user_id 	  = $var->user_id;
	$menu_query   = $var->data_arr;
	$action 	  = $var->action;

	switch ($action) {
		case 'access_page':
			foreach ($menu_query as $row) {
				$title 		= $row['title'];
				$link 		= $row['link'];
				$base_link  = basename($link);

				$access_page_list = $dbpdo->prepare('SELECT * FROM user_access_pages 
													 WHERE user_id = :user_id 
													 AND access_page_base_link = :base_link');
				$access_page_list->bindParam('user_id', $user_id);
				$access_page_list->bindParam('base_link', $base_link);
				$access_page_list->execute();

				if($access_page_list->rowCount()>0) {
					$active_link = 'filter-active';
				} else {
					$active_link = '';
				}

				$menu_compare = array(
					'title' 		=>  $title,
					'value'			=>  $link,
					'icon'			=>  '<img src="/img/icon/lock-white.png">',
					'id'			=>  '',
					'text'			=>  '',
					'modify_class' 	=>  $active_link,
					'parent_class' 	=>  ''
				);

				get_access_page_list_tpl($menu_compare);
			}
		break;

		case 'access_data': 
			$get_all_user_th_access_lsit = $dbpdo->prepare('SELECT * FROM data_td_accsess WHERE user_id = :user_id');
			$get_all_user_th_access_lsit->bindParam('user_id', $user_id);
			$get_all_user_th_access_lsit->execute();
			if($get_all_user_th_access_lsit->rowCount()>0) {
				while ($data_row = $get_all_user_th_access_lsit->fetch(PDO::FETCH_LAZY)) {
					$data[] += $data_row->td_tags_id;
				}
			}



			$get_th = $dbpdo->prepare('SELECT * FROM th_list');
			$get_th->execute();
			while ($th_row = $get_th->fetch(PDO::FETCH_LAZY)) {
				$title = $th_row->th_name;
				$value = $th_row->th_description;
				$id    = $th_row->th_id;

				if(array_keys($data, $id)) {
					$data_active = 'filter-active';
				} else {
					$data_active = '';
				}

				$menu_compare = array(
					'title' 		=>  $title,
					'value'			=>  $id,
					'id'			=> 	$id,
					'icon'			=> '<img src="/img/icon/lock-white.png">',
					'text'			=>	'',
					'modify_class' 	=> $data_active,
					'parent_class' 	=> ''
				);

				get_access_page_list_tpl($menu_compare);
			}
		break;

	}

}
