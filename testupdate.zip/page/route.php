<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/start.php';

    use Core\Classes\Privates\accessManager;
    use Core\Classes\Services\RenderTemplate as Render;
    use Core\Classes\Utils\Utils;
    

    define('root_dir', $_SERVER['DOCUMENT_ROOT']);


    if(isset($_POST['data_page_route'])) {
        $page = $_POST['data_page_route'];
     
        $menu = $main->getMenuList($page);

        accessManager::hasAccessToPage($page, function ($res) {
            if($res) {    
                echo Render::view('/component/inner_container.twig', [
                    'renderComponent' => [
                        '/component/parts/alert.twig' => [
                            'value' => 'Bu səhifəyə baxmağa icazəniz yoxdur',
                            'classList' => 'mark-danger width-100'
                        ],
                    ]
                    ]);
                die;
                exit;
            }
        });

        if(array_key_exists($page, $menu)) {
            $this_menu = $menu[$page];
            include root_dir . '/page/base.php';
        }
    }


    if(isset($_POST['tab'])) {
        
        if(isset($_POST['page'])) {
            $page = $_POST['page'];
        }

        if(isset($_POST['type'])) {
            $type = $_POST['type'];
        }

        $get_tab = $_POST['tab'];
        
        
        $tab = $main->getTabs([$get_tab]);
        
        $tab_this = $tab[$get_tab];

        $type = $tab_this['type'];

        $link = $tab_this['tab_link'];
        
        include root_dir.$link;
    }



 