<?php

namespace core\classes\Services\Customer\Traits;

use core\classes\dbWrapper\db;
use core\classes\Utils\Utils;
use core\classes\dbWrapper\queryBuilder as qb;

trait Cashback
{
    public static function applyCashback(int $customerId, int $updateTo, int $transactionId)
    {
        $customerInfo = self::getCustomerInfo($customerId);

        $cashbackPercent = $customerInfo['cashback_percent'];
        $customerHistoryInfo = self::getCustomerHistoryInfo($customerId);

        $balanceAmount = $customerHistoryInfo['balance_amount'] ?: 0;
        $balanceBefore = $balanceAmount ?: 0;
        $earnedAmount = $updateTo * $cashbackPercent / 100;
        $finalBalance = $balanceAmount + $earnedAmount;


        db::insert('customer_balance', [
            [
                'customer_id' => $customerId,
                'balance_amount' => $finalBalance,
                'balance_before' => $balanceBefore,
                'earned_amount'  => $earnedAmount,
                'transaction_id' => $transactionId,
                'date_short'     => Utils::getDateMY(),
                'date_full'      => Utils::getDateDMY()
            ]
        ]);
    }

    public static function spendCashback(int $customerId, float $spendAmount, int $transactionId)
    {
        $customerHistoryInfo = self::getCustomerHistoryInfo($customerId);

        $balanceAmount = $customerHistoryInfo['balance_amount'] ?? 0;
        $balanceBefore = $balanceAmount ?? 0;
        $finalBalance = $balanceAmount - $spendAmount;

        db::insert('customer_balance', [
            [
                'customer_id' => $customerId,
                'balance_amount' => $finalBalance,
                'balance_before' => $balanceBefore,
                'earned_amount' => 0,
                'spend_amount'  => $spendAmount,
                'transaction_id' => $transactionId,
                'date_short'     => Utils::getDateMY(),
                'date_full'      => Utils::getDateDMY()
            ]
        ]);
    }
    public static function getCustomerBalance(int $customerId)
    {
        return qb::select('*')
            ->from('customer_balance')
            ->where('customer_id = :c_id')
            ->groupBy('id')
            ->orderBy('id', 'DESC')
            ->limit(1)
            ->bindList([':c_id' => $customerId])
            ->execute()
            ->first()
            ->columnName('balance_amount')
            ->get();
    }

    public static function getCustomerHistoryInfo(int $customerId)
    {
        return qb::select('*')
            ->from('customer_balance')
            ->where('customer_id = :c_id')
            ->groupBy('id')
            ->orderBy('id', 'DESC')
            ->limit(1)
            ->bindList([':c_id' => $customerId])
            ->execute()
            ->first()
            ->get();
    }

    /**
     * 
     */
    public static function getCustomerBalanceHistory($id, $limit = 100)
    {
        return qb::select('*')
            ->from('customer as c')
            ->innerJoin('customer_balance', 'customer_balance.customer_id = c.id')
            ->where('c.id = :id')
            ->bindList([
                ':id' => $id
            ])
            ->groupBy('customer_balance.id')
            ->orderBy('customer_balance.id', 'desc')
            ->limit($limit)
            ->execute()
            ->get();
    }
}
