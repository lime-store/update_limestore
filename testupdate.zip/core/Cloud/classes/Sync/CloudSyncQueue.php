<?php
namespace core\Cloud\classes\Sync;

use core\classes\dbWrapper\db;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\Products;
use core\classes\Services\BaseService;
use core\classes\Services\Warehouse\Warehouse;
use core\Cloud\classes\Sync\Traits\Category;
use core\Cloud\classes\Sync\Traits\Product;
use core\Cloud\classes\Sync\Traits\Provider;

class CloudSyncQueue
{
    use Product, Category, Provider;
    
    /**
     * 
     */
    public static function addTask($tasks)
    {
        foreach ($tasks as $task) {
            db::insert('sync_queue', $task);
        }
    }
}
