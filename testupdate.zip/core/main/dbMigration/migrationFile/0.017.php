<?php 
use Core\Classes\System\Migration;
use core\classes\dbWrapper\db;
use Core\Classes\System\Settings;

/**
 * 
 * stock_order_report add column:
 *  
 * @param max_refaund_quantity - Это количество сколько можно сделать возврат товара. 
 *                               Допустим мы продали 5шт товара, потом сделали возврат 1шт
 *                               В будущем если будут возвраты относящиеся именно к этой транзакции
 *                               то максимум количество которое можно вернуть это - 4 и тд.
 *                               type - int
 *                               defaut - Количество продажи 
 *
 * @param has_editable -        После продажи можно редактировать отчет, если есть ошибка
 *                              Но если сделать возврат товара, то уже редактировать товар
 *                              будет не возможно
 *                              type - int
 *                              default - 0 (1 - редактировать можно, 0 - нельзя)
 * 
 * @param product_unit       
 *                             
 */

 $append_report_column_v0017 = [
    'max_refaund_quantity' => 'int(11) NOT NULL DEFAULT 1',
    'has_editable'         => 'int(11) NOT NULL DEFAULT 1',
];

Migration::hasTableColumnExist('stock_order_report', $append_report_column_v0017, function($notExistData) {
    if($notExistData) {
        Migration::alertTableColumn('stock_order_report', $notExistData);
    }
});



$add_function_settings_v0017 = [
    array(':sett_name' => 'generalInfoModal', 'sett_on' => '1'),
    array(':sett_name' => 'showCompanyNameOnBarcode', 'sett_on' => '1'),
];

$settings_sql_v0017 = [
    'table_name' => 'function_settting',
    'col_list' => '*',
    'query' => [
        'base_query' => ' WHERE sett_name = :sett_name GROUP BY sett_id DESC'
    ],
    'bindList' => []
];

Migration::hasDataExist($settings_sql_v0017, $add_function_settings_v0017, function($notExistData) {
    if($notExistData) {
        Migration::insertMigrationData('function_settting', $notExistData);
    }
});


if(!Settings::hasSettingsJSON('generalInfo', 'companyName')) {
    Settings::appendSettingsJSON([
        'generalInfo' => [
            "companyName"           => '',
            'companyContact'        => '',
            'companyDescription'    => '',
            'companyAdress'         => '',
            'token'                 => '',
        ]
    ]);
}