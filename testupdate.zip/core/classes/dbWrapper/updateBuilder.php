<?php 
namespace core\classes\dbWrapper;

use core\classes\dbWrapper\db;

class updateBuilder
{
    private string $table;
    private array $sets = [];
    private array $bindings = [];
    private array $wheres = [];


    public static function table(string $table)
    {
        $instance = new static();
        $instance->table = $table;
        return $instance;
    }

    /**
     * @param string $column
     * @param mixed  $value
     */
    public function set(string $column, $value): self
    {
        $placeholder = ':set_' . $column;
        $this->sets[] = "{$column} = {$placeholder}";
        $this->bindings[$placeholder] = $value;
        return $this;
    }

    /**
     * @param string $column
     * @param mixed  $value
     */
    public function where(string $column, $value): self
    {
        $placeholder = ':where_' . $column;
        $this->wheres[] = "{$column} = {$placeholder}";
        $this->bindings[$placeholder] = $value;
        return $this;
    }

    public function toSql(): string
    {
        if (empty($this->sets)) {
            throw new \RuntimeException('Нечего обновлять: не вызван set()');
        }

        $sql = "UPDATE {$this->table} SET " . implode(', ', $this->sets);

        if (!empty($this->wheres)) {
            $sql .= " WHERE " . implode(' AND ', $this->wheres);
        } else {
            // без where обновится вся таблица - лучше явно это запретить
            throw new \RuntimeException('UPDATE без WHERE запрещён. Используй whereRaw(), если это осознанно.');
        }

        return $sql;
    }

    public function whereNull(string $column): self
    {
        $this->wheres[] = "{$column} IS NULL";
        return $this;
    }

    public function whereNotNull(string $column): self
    {
        $this->wheres[] = "{$column} IS NOT NULL";
        return $this;
    }

    public function execute(): bool
    {
        $stmt = db::$dbpdo->prepare($this->toSql());
        return $stmt->execute($this->bindings);
    }
}