<?php
use core\classes\System\Init;
use core\classes\System\Settings;
use core\classes\Utils\Utils;
header('Content-type: Application/json');


$getBranchSettings = (array) Settings::getSettingsJSON();

$getBranchList = $getBranchSettings['branch']['branchList'] ?? [];


$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/custom_modal/u_modal.twig' => [
            'modalController' => [
                'title' => 'Filial seçin',
                'closeButtonClassList' => 'removeModal',
            ],
            'modalContent' => [
                'path' => '/component/branch/chooseBranchList.twig',
            ],
            'containerClassList' => 'small-modal',
            'class_list' => '', 
            'branchList' => $getBranchList
		]  
	]
]);


$utils::abort([
	'res' => $total,
]);
