<?php 
/**
 * в этом файле описываем логику работы с товарами
 * и отчетами 
 */

function ls_update_product() {
    global $dbpdo;

    
}