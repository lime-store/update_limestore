<?php

namespace core\classes\Services\Customer;

use core\classes\dbWrapper\db;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\dbWrapper\updateBuilder as ub;
use core\classes\Services\Customer\Traits\Cashback;
use core\classes\System\Main;
use core\classes\Utils\Utils;

class Customer
{
    use Cashback;

    public static function getCustomerInfo(int $customerId, ?string $columnName = null)
    {
        $select = $columnName ?? '*';

        $res = qb::select($select)
            ->from('customer')
            ->where('id = :c_id')
            ->groupBy('id')
            ->orderBy('id', 'DESC')
            ->limit(1)
            ->bindList([':c_id' => $customerId])
            ->execute()
            ->first()
            ->get();

        if ($columnName !== null) {
            return $res[$columnName];
        }

        return $res;
    }

    /**
     * 
     */
    public static function getLastAdded()
    {
        $result = qb::select('*')
                ->from('customer')
                ->where('visible = 0')
                ->last('id', 'DESC')
                ->get();

        return $result;
    }


    /**
     * true - card code есть
     * false - card code нету
     */
    public static function hasCardCode(int $cardCode)
    {
        $result = qb::select('cashback_card_code')
            ->from('customer')
            ->where('cashback_card_code=:cardCode AND visible = 0')
            ->bindList([
                'cardCode' => $cardCode
            ])
            ->orderBy('id', 'desc')
            ->execute()
            ->first()
            ->get();

        return $result ? true : false;
    }

    /**
     * 
     */
    public static function edit(array $data)
    {
        $option = [
            'before' => ' UPDATE customer SET ',
            'after' => ' WHERE id=:id ',
            'post_list' => [
                'id' => [
                    'query' => false,
                    'bind' => 'id',
                    'require' => true
                ],
                'edit_name' => [
                    'query' => "name=:name",
                    'bind' => 'name',
                    'require' => true,
                ],
                'edit_contact' => [
                    'query' => "contact_number=:contact",
                    'bind' => 'contact',
                ],
                'edit_card_code' => [
                    'query' => 'cashback_card_code=:card_code',
                    'bind' => 'card_code',
                ],
                'edit_percent' => [
                    'query' => 'cashback_percent=:percent',
                    'bind' => 'percent',
                    'require' => true
                ]
            ]
        ];

        Main::hasRequiredUpdateFields($option['post_list'], $data, function ($onError) use ($option, $data) {
            if ($onError) {
                return Utils::errorAbort('Заполните обьязательные поля');
            } else {
                db::update($option, $data);
                return Utils::successAbort('Ok');
            }
        });
    }


    /**
     * 
     */
    public static function add(array $data)
    {
        db::insert('customer', [
            [
                'name'                  => $data['customer_name'],
                'contact_number'        => $data['customer_contact'],
                'cashback_percent'      => $data['customer_cashback_percent'],
                'cashback_card_code'    => $data['customer_card_code'],
            ]
        ]);
    }

    /**
     * 
     */
    public static function delete($id)
    {
        return ub::table('customer')
            ->set('visible', 1)
            ->where('id', $id)
            ->execute();
    }
}
