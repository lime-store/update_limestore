<?php
	require_once '../../function.php';

	ls_include_tpl();
	//Показывать товары которые находться в базе больше 15 дней 
	// settShowOldProduct();
	//выводим заголовок страницы
	tab_page_header('Anbar');

	//блок для принта чека
	printModal();
	//пути к категориям
	get_product_root_dir();

	//абсолютный пусть к файлам
	root_dir();

	//выводим вкладки 
	$get_return_tab = array(
		'tab_stock_phone',
		'tab_stock_akss'
	);
	//выводим перекючения вкладок 
	get_current_tab($arr = array(
		'link_list' => $get_return_tab,
		'registry_tab_link' => $tab_arr,
		'default_link' => 'tab_stock_phone',
		'modify_class' => '',
		'parent_modify_class' => ''
	));		
?>




<div class="terminal_main">
	<?php require_once GET_ROOT_DIRS. $tab_arr['tab_stock_phone']['tab_link']; ?>
</div>




<?php 
	//выводим модальное окно для оформления заказа
	get_right_modal();
?>
