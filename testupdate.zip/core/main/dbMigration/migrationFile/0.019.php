<?php

use Core\Classes\Privates\User;
use Core\Classes\System\Migration;
use Core\Classes\System\Settings;

$add_function_settings_v0019 = [
    array(':sett_name' => 'showProductNameOnBarcode', 'sett_on' => '1'),
    array(':sett_name' => 'accessPageInit', 'sett_on' => '1')
];

$settings_sql_v0019= [
    'table_name' => 'function_settting',
    'col_list' => '*',
    'query' => [
        'base_query' => ' WHERE sett_name = :sett_name GROUP BY sett_id DESC'
    ],
    'bindList' => []
];

Migration::hasDataExist($settings_sql_v0019, $add_function_settings_v0019, function($notExistData) {
    if($notExistData) {
        Migration::insertMigrationData('function_settting', $notExistData);
    }
});


$notify_v0019_new_column = [
    'notify_state'  => 'int(11) NOT NULL DEFAULT 1',
    'notify_date'   => 'varchar(128) NOT NULL',
    'custom_id'   => 'int(11) NOT NULL',
];

Migration::hasTableColumnExist('ls_notify', $notify_v0019_new_column, function($notExistData) {
    if($notExistData) {
        Migration::alertTableColumn('ls_notify', $notExistData);
    }
});


Migration::hasTableExist('access_page', function($noExist) {
    if($noExist) {
        Migration::createTable(
            'CREATE TABLE `access_page` (
                `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `page` varchar(255) NOT NULL,
                `user_id` int(11) NOT NULL,
                `description` varchar(64) NOT NULL,
                `visible` int(11) NOT NULL
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;'
        );
    }
});







if (Settings::getSettingState('accessPageInit') == true) {
    $add_column_access_page_v0019 = [];


    foreach (User::getAllUser() as $key => $val) {
        if ($val['user_role'] !== 'admin' && $val['user_visible'] == 0) {
            $add_column_access_page_v0019[] = [
                ':user_id' => $val['user_id'],
                'page' => 'analytics'
            ];
        }
    }

    $check_sql_access_page_v0019 = [
        'table_name' => 'access_page',
        'col_list' => '*',
        'query' => [
            'base_query' => ' WHERE user_id = :user_id GROUP BY id DESC'
        ],
        'bindList' => []
    ];

    Migration::hasDataExist($check_sql_access_page_v0019, $add_column_access_page_v0019, function ($notExistData) {
        if ($notExistData) {
            Migration::insertMigrationData('access_page', $notExistData);
            Settings::changeSettingState('accessPageInit', 0);
        }
    });
}