<?php 
use core\classes\System\Settings;
use core\classes\Utils\Utils;

header('Content-type: application/json');

$contentPath =  '';

if(Settings::getSettingState('generalInfoModal')) {
    $contentPath = '/component/modal/generalInfoModal/generalInfoModal.twig';
}


if(!empty($contentPath)) {
   $view = $Render->view('/component/include_component.twig', [
        'renderComponent' => [
            '/component/modal/custom_modal/u_modal.twig' => [
                'containerClassList' => 'small-modal',
                'modalController' => [
                    'title' => 'Mağaza məlumatı',
                    'closeButtonClassList' => 'hide'
                ],
                'modalContent' => [
                    'path' => $contentPath
                ]
            ]
        ]
    ]);


 echo Utils::abort([
        'type' => 'success',
        'view' => $view
    ]);
}
