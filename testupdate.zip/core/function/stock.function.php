<?php 
/**
 * в этом файле описываем логику работы с товарами
 * и отчетами 
 */


 function get_last_added_stock() {
    return ls_db_request([
        'table_name' => 'stock_list',
        'col_list' => '*',
        'base_query' => ' WHERE stock_visible = 0 ',
        'param' => [
            'sort_by' => 'ORDER BY stock_id DESC LIMIT 1'
        ]
    ])[0];
 }

 
/**
 * @param arr =  array(
 *				'id' => $id,
 *				'action' => 'get_name'
 *			);
 * получить информацию товара по id
 */
function get_stock_by_id($arr) {
	$id = $arr['id'];
	$action = $arr['action'];

    $row = ls_db_request([
        'table_name' => 'stock_list as tb',
        'col_list'   => '*',
        'base_query' => 'INNER JOIN stock_list ON stock_list.stock_visible != 3 ',			
        'param' => [
			'query' => array(
				'param' =>  " AND stock_list.stock_count >= stock_list.min_quantity_stock
							  AND stock_list.stock_visible = 0 AND stock_list.stock_id = :id ",
				"joins" => "  LEFT JOIN stock_provider ON stock_provider.provider_id = stock_list.product_provider
							  LEFT JOIN stock_category ON stock_category.category_id = stock_list.product_category ",		
				'bindList' => array(
					'id' => $id
				)
			),
			'sort_by' => " GROUP BY stock_list.stock_id DESC ORDER BY stock_list.stock_id DESC "
        ]
    ]);	

	$row = $row[0];


	switch ($action) {
		case 'name':
			return $row['stock_name'];
			break;
		case 'imei':
			return $row['stock_phone_imei'];
			break;
		case 'provider':
			return $row['stock_provider'];
			break;
		case 'category':
			return $row['stock_provider'];
			break;			
		case 'first_price':
			return $row['stock_first_price'];
			break;
		case 'all':
			return $row;
			break;
		default:
			return $row;
			break;
	}

}