<?php

use core\classes\Services\Customer\Customer;

header('Content-type: Application/json');

$customerId = $_POST['customer_id'] ?? 0;
$orderSum = $_POST['orderSum'] ?? 0;


if(empty($customerId)) {	
	$utils::errorAbort('Musteri secilmeyib');
	return;
}


$customerName = Customer::getCustomerInfo($customerId, 'name');
$customerBalance = Customer::getCustomerBalance($customerId);


$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/custom_modal/u_modal.twig' => [
			'containerClassList' => 'modal-xs',
			'modalController' => [
				'title' => 'Bonusla ödəniş',
				'closeButtonClassList' => 'removeModal',
			],
			'modalContent' => [
				'classList' => 'modal-form',
				'path' => '/component/customer/cashbackPayModal.twig',
			],
			'customerName' => $customerName,
			'customerBalance' => $customerBalance,
			'orderSum' => $orderSum
		]
	]
]);

$utils::abort([
	'res' => $total,
]);
