<?php 
namespace core\classes\dbWrapper;

use core\classes\System\Constants;
use core\classes\System\Settings;
use core\classes\Utils\Utils;
date_default_timezone_set('Asia/Baku');
session_set_cookie_params(31536000 + 500, '/');

$settings = (array) Settings::getSettingsJSON();

session_start();

$dbConfigFile = Constants::ROOT_DIR.'.config.php';

if(file_exists($dbConfigFile)) {
    require $dbConfigFile;
} else {
    $dbName = $settings['branch']['active'] ?? 'lime_sklad';
    define('DBUSER','root');
    define('DBPASS','');
    define('DBNAME', $dbName);
    define('SITEEMAIL','noreply@domain.com');
    define('ROOT', $_SERVER['DOCUMENT_ROOT']);
    $port = 3306;

    if(Settings::hasSettingsJSON('config', 'mysqlPort')) {
        $port = Settings::getSettingsJSON()->config['mysqlPort'];
    }

    define('DBHOST','localhost:'.$port);
}


class dbConfig 
{
    public static $dbpdo;

    public function __construct()
    {        
        // $this->dbpdo = new \PDO("mysql:host=".DBHOST.";charset=utf8mb4;dbname=".DBNAME, DBUSER, DBPASS);
        // $this->dbpdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        // $this->dbpdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);

        // return $this;
        self::dbInitialize();
        return self::$dbpdo;
    }

    public static function dbInitialize()
    {
        if (!isset(self::$dbpdo)) {
            self::$dbpdo = new \PDO("mysql:host=".DBHOST.";charset=utf8mb4;dbname=".DBNAME, DBUSER, DBPASS);
            self::$dbpdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            self::$dbpdo->setAttribute(\PDO::ATTR_EMULATE_PREPARES, false);
        }

        return self::$dbpdo;
    }
}       