<?php
use Core\Classes\Utils\Utils;
use Core\Classes\System\Settings;

// Utils::log(Settings::getSetting('showPriceOnBarcodeLabel'));
// Utils::log(Settings::getSetting('appSync'));

$showPriceOnBarcodeLabel = (object) Settings::getSetting('showPriceOnBarcodeLabel');
$showCompanyNameOnBarcode = (object) Settings::getSetting('showCompanyNameOnBarcode');
$appSync                 = (object) Settings::getSetting('appSync');
$dbBackup                = (object) Settings::getSetting('telegram_backup');
$jsonSettings            = (object) Settings::getSettingsJSON();

echo $Render->view('/component/inner_container.twig', [
    'renderComponent' => [
        '/component/form/fields/settings/settings.twig' => [
            'includs' => [
                'companyInfo' => [
                    //appSync
                    '/component/form/fields/settings/companyInfo.twig' => [
                        'companyInfo' => $jsonSettings->generalInfo,
                    ]                    
                ],                
                'otherSettings' => [
                    //appSync
                    '/component/form/fields/settings/other.twig' => [            
                        [
                            'label' => [
                                'classList' => 'switcher-label',
                                'value' => 'Data backup ',
                            ],
                            'button' => [
                                'classList' => 'switcher-new-state toggleSettingSwitcher',
                                'value' => $dbBackup->state,
                                'attr' => [
                                    'data-radio-state' => $dbBackup->state,
                                    'data-fields-name' => $dbBackup->name,
                                    'data-id'          => $dbBackup->id
                                ]
                            ] 
                        ],                
                        [
                            'label' => [
                                'classList' => 'switcher-label',
                                'value' => 'Web App-ilə sinxronizasiya ',
                            ],
                            'button' => [
                                'classList' => 'switcher-new-state toggleSettingSwitcher',
                                'value' => $appSync->state,
                                'attr' => [
                                    'data-radio-state' => $appSync->state,
                                    'data-fields-name' => $appSync->name,
                                    'data-id'          => $appSync->id
                                ]
                            ] 
                        ],
                    ]                    
                ],
                'barcoeLabelWidth' => [
                    '/component/form/fields/settings/barcode.twig' => [
                        'switcher' => [
                            // barcodeLabel
                            [
                                'label' => [
                                    'classList' => 'switcher-label',
                                    'value' => 'Barkodda qiyməti göstərmək',
                                ],
                                'button' => [
                                    'classList' => ' switcher-new-state  toggleSettingSwitcher',
                                    'value' => $showPriceOnBarcodeLabel->state,
                                    'attr' => [
                                        'data-radio-state' => $showPriceOnBarcodeLabel->state,
                                        'data-fields-name' => $showPriceOnBarcodeLabel->name,
                                        'data-id'          => $showPriceOnBarcodeLabel->id
                                    ]
                                ] 
                            ],
                            [
                                'label' => [
                                    'classList' => 'switcher-label',
                                    'value' => 'Barkodda mağaza adı göstərmək',
                                ],
                                'button' => [
                                    'classList' => ' switcher-new-state  toggleSettingSwitcher',
                                    'value' => $showCompanyNameOnBarcode->state,
                                    'attr' => [
                                        'data-radio-state' => $showCompanyNameOnBarcode->state,
                                        'data-fields-name' => $showCompanyNameOnBarcode->name,
                                        'data-id'          => $showCompanyNameOnBarcode->id
                                    ]
                                ] 
                            ],                                                         
                        ],
                        'barcodeLabelSize' => [
                            'width' => Settings::getSettingsJSON()->stickerWidth,
                            'height' => Settings::getSettingsJSON()->stickerHeight
                        ]          
                    ] 
                ]
            ]
        ]
    ]
]);