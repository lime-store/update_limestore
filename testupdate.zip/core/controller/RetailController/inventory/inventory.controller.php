<?php 

use core\classes\Traits\TableHeaderList as TH;

return [
    'tab' => [
        'is_main' => true,
        'title' 			=> 'Sayim',
        'icon'				=> [
            'img_big'		 	=> '',
            'img_small'			=> '',
            'modify_class' 		=> 'las la-clipboard-list'
        ],
        'link'  			=> '/page/base.php',
        'template_src'      => 'page/base_tpl.twig',
        'background_color'  => '',
        'tab' => array(
            'list' => [
                'tab_inventory_list',
            ],
            'active' => 'tab_inventory_list'
        )
    ],
    'page_data_list' => [
        'sort_key' => 'id',
        'get_data' => [
            'id' 				=> 'id',
            'title'			 	=> 'title',
            'created_at'		=> 'created_at',
            'status'			=> 'status',
            'open'				=> 'open',
            'cancel'			=> 'cancel',
            'report'			=> 'report',
        ],
        'get_data@template' => [
            'id' => TH::getTableHeaderByTemplate('№', 'th_w40', [
                'link_class'    => 'stock-link-text-both'
            ]),
            'title' => TH::getTableHeaderByTemplate('Ad', 'th_w200', [
                'link_class'    => 'stock-link-text-both'
            ]),
            'created_at' => TH::getTableHeaderByTemplate('Tarix', 'th_w140', [
                'link_class'    => 'stock-link-text-both'
            ]),
            'status' => TH::getTableHeaderByTemplate('Status', 'th_w100 text-center', [
                'link_class'    => 'mark mark-tags mark-text',
                'td_class'      => 'text-center',
                'mark_is_title' => true,
                'mark'          => array(
                    'mark_operation_class' => true,
                )
            ]),
            'open' => TH::getTableHeaderByTemplate('Aç', 'th_w60', [
                'td_class'      => 'table-ui-reset',
                'link_class'    => 'las la-folder-open btn btn-primary width-100 table-ui-btn open-inventory',
                'hideIfNotValue'=> true,
                'mark'          => false
            ]),
            'cancel' => TH::getTableHeaderByTemplate('Ləğv et', 'th_w70', [
                'td_class'      => 'table-ui-reset',
                'link_class'    => 'las la-times btn btn-danger width-100 table-ui-btn cancel-inventory',
                'hideIfNotValue'=> true,
                'mark'          => false
            ]),
            'report' => TH::getTableHeaderByTemplate('Hesabat', 'th_w70', [
                'td_class'      => 'table-ui-reset',
                'link_class'    => 'las la-file-alt btn btn-info width-100 table-ui-btn show-report',
                'hideIfNotValue'=> true,
                'mark'          => false
            ]),
        ],
        'session_list' => [
            'sort_key' => 'id',
            'get_data' => [
                'session_number' 	=> 'session_number',
                'created_at'		=> 'created_at',
                'status'			=> 'status',
                'open'				=> 'open',
                'cancel'			=> 'cancel',
            ],
            'get_data@template' => [
                'session_number' => TH::getTableHeaderByTemplate('№', 'th_w40', [
                    'link_class'    => 'stock-link-text-both'
                ]),
                'created_at' => TH::getTableHeaderByTemplate('Tarix', 'th_w140', [
                    'link_class'    => 'stock-link-text-both'
                ]),
                'status' => TH::getTableHeaderByTemplate('Status', 'th_w100 text-center', [
                    'link_class'    => 'mark mark-tags mark-text',
                    'td_class'      => 'text-center',
                    'mark_is_title' => true,
                    'mark'          => array(
                        'mark_operation_class' => true,
                    )
                ]),
                'open' => TH::getTableHeaderByTemplate('Aç', 'th_w60', [
                    'td_class'      => 'table-ui-reset',
                    'link_class'    => 'las la-folder-open btn btn-primary width-100 table-ui-btn open-session',
                    'hideIfNotValue'=> true,
                    'mark'          => false
                ]),
                'cancel' => TH::getTableHeaderByTemplate('Ləğv et', 'th_w70', [
                    'td_class'      => 'table-ui-reset',
                    'link_class'    => 'las la-times btn btn-danger width-100 table-ui-btn cancel-session',
                    'hideIfNotValue'=> true,
                    'mark'          => false
                ]),
            ],
        ],
    ],
];
