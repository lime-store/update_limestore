<?php
header('Content-type: Application/json');
use core\classes\Services\tableFooter;

$postData = $_POST['data'];

//удалить товар
if(!empty($postData['stock_id'])) {
	$products->deleteProduct($postData['stock_id']);


	$total = $Render->view('/component/include_component.twig', [
		'renderComponent' => [
			'/component/table/table_footer_row.twig' => [	
				'table_total' => tableFooter::updateData($_POST['updFooter'])		
			]  
		]
	]);

	return $utils::abort([
		'type'	=> 'success',
		'text'	=> 'Ok',
		'table_footer' => $total
	]);
} else {
	return $utils::abort([
		'type'	=> 'error',
		'text' 	=> 'Cant find id'
	]);
}
