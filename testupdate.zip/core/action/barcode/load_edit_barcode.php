<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/function.php';

header('Content-type: Application/json');


$stock_id = $_POST['data'];


$res = ls_db_request([
        'table_name' => ' stock_barcode_list ',
        'col_list' => ' * ',
        'base_query' => ' WHERE br_stock_id = :id ',
        'param' => [
            'query' => [
                'param' => '',
                'joins' => '',
                'bindList' => array(
                    'id' => $stock_id
                )
            ],
            'sort_by' => 'ORDER BY barcode_id DESC'
        ]            
    ]);


$total = $twig->render('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/barcode/barcode_edit_modal.twig' => [		
            'res' => $res,
            'stock_id' => $stock_id
		]  
	]
]);


echo json_encode([
	'res' => $total,
]);
