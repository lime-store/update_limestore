<?php
use core\Cloud\classes\Sync\CloudSyncQueue;
//test
header('Content-type: Application/json');

$Warehouse = new core\classes\Services\Warehouse\Warehouse;

$productId      = $_POST['productId'];
$productInfo    = $_POST['lastEditedProduct'];

CloudSyncQueue::editProductTask($productId, $productInfo);









