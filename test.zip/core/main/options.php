<?php
	define('GET_ROOT_DIR', $_SERVER['DOCUMENT_ROOT']);

	require_once(GET_ROOT_DIR.'/function.php');

	//ссылки вкладок на главной странице
	get_tab_main_page();

?>

<div class="main-option-service">
	<div class="options-list">


<?php
	$menu_count = count($menu_query);
	for ($row = 0; $row < $menu_count; $row++) {
		$title = $menu_query[$row]['title'];
		$img = $menu_query[$row]['img_big'];
		$link = $menu_query[$row]['link'];
		$background_color = 'background-color:'.$menu_query[$row]['background-color'];
		//some one
		?>
		<div class="option-list-box flex-cntr" style="<?php echo $background_color; ?>">
			<div class="stock-view-link">
				<a href="javascript:void(0)" class="select_page_main select_page_btn_style flex-cntr scroll_top" data-link="<?php echo $link; ?>">
						<span class="stock_view_header"> <?php echo $title; ?> </span>
					<div class="stock_view_icon">
						<img src="<?php echo $img; ?>">
					</div>
				</a>				
			</div>
		</div>
	<?php				
	} ?>




		
	</div>
</div>			