<?php 
use core\classes\System\Settings;
use core\classes\Utils\Utils;

if(!empty($_POST['name'])) {
    $name = $_POST['name'];
    $state = $_POST['state'] ?? 0;
    return Settings::changeSettingState($name, $state);
}