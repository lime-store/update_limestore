<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/function.js?v=1.0.1"></script>
<script src="js/print.min.js"></script>
<script src="js/ajax.js?v=1.0.1"></script>