﻿<?php 
/**
 * LIME SKLAD 2020
 * ©EMIL GASANOV
 * Версия для сотовых магазинов
 */

header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

require_once 'function.php';
root_dir();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Lime Store</title>
	<link rel="icon" type="image/x-icon" href="img/favicon.ico">	
	<link rel="stylesheet" type="text/css" href="css/style.css?v=<?php echo time(); ?>">
	<link rel="stylesheet" type="text/css" href="css/print.min.css?v=<?php echo time(); ?>">

	<link rel="stylesheet" type="text/css" href="css/fonts.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">	
</head>
<body>

<div class="header-top-site flex-cntr">
	<div class="header-logo-wrp">
		<div class="header-logo-center">
			<a href="javascript:void(0);" class="header-logo-link get_main_page  flex-cntr">
				<span class="header-logo-bold-style flex-cntr">L</span>ime Store</a>
		</div>
	</div>
	<div class="author_info">
		<div class="link_to_site_info">
			<a href="http://lime-sklad.github.io/" target="_blank" class="link">lime-sklad.github.io</a>
		</div>
		<span>©Emil (tel: 0504213635) <?php echo date("Y"); ?></span>
	</div>

	<div class="preloader">
		<?php echo get_preloader(); ?>
	</div>
	<div class="overlay"></div>
</div>
<?php scroll_to_top(); ?>





















<?php
	//модальное окно успешно выполнено функция
	success_done();
	//модальное коно не выполнено функция
	fail_notify();

include 'lib_include.php'; 

require_once GET_ROOT_DIRS.'/core/main/update_check.php';
//опросник
require_once  $_SERVER['DOCUMENT_ROOT'].'/core/modal_action/show_quiz.php';

?>


<!-- <script defer src="/js/check_update.js?v=<?php echo time(); ?>"></script> -->
