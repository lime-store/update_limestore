<?php

	define('root_dir', $_SERVER['DOCUMENT_ROOT']);
	//корневая папка программы
	$root_dir = root_dir;
	//путь к папке с бэкапами
	$backup_dir = $root_dir.'/backup/';
	//путь к фалам с обновами
	$update_dir = $root_dir.'/update/';

	//версия пользоватея
	$current_version = file_get_contents($root_dir.'/version.txt');
	$current_version = trim(stripcslashes(strip_tags(htmlspecialchars($current_version))));
	//версия на сервере
	$url_version = 'https://raw.githubusercontent.com/lime-sklad/update_limestore/master/version.txt';
	//ссылка на архив
	$url_zip = "https://github.com/lime-sklad/update_limestore/raw/master/last_update.zip"; 

	//получем версию на сайте
	$get_verison = check_last_version($url_version, $current_version);


	if($current_version !== $get_verison) {
	   if(!isset($_POST['download_upd'])) {
	   		show_upd_notify();
	   }

	   if(isset($_POST['download_upd'])) {
			if(!file_exists($backup_dir)) {
				mkdir($backup_dir, 0700);
			}
			//если если нет папкм updates то создаем и скачмвем
			if(!file_exists($update_dir)) {
				mkdir($update_dir, 0700);
			} 

			donwload_update($update_dir, $url_zip);
							
			//запускаем установку обнов.
			ls_install_update($update_dir, $root_dir, $backup_dir);
	    }
	} 



	function check_last_version($url_version, $current_version) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url_version);
		curl_setopt($ch, CURLPROTO_HTTPS,1);	
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);// таймаут в секундах
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134');

		$get_verison = curl_exec($ch);
		$info = curl_getinfo($ch);
		curl_close($ch);

		if($info['http_code'] == '200') {
			$get_verison = trim(stripcslashes(strip_tags(htmlspecialchars($get_verison))));
		} else {
			$get_verison = $current_version;
		}
		return $get_verison;
	}


	//делаем бэкап
	function get_backup($source, $destination){
	  if (!extension_loaded('zip') || !file_exists($source)) {
	    return false;
	  }
	 
	  $zip = new ZipArchive();
	  if (!$zip->open($destination, ZIPARCHIVE::CREATE)) {
	    return false;
	  }
	 
	  $source = str_replace('\\', '/', realpath($source));
	 
	  if (is_dir($source) === true){
	    $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);
	 
	    foreach ($files as $file){
	        $file = str_replace('\\', '/', $file);
	 		$strip_folders = array('backup', 'ajax_page_php', 'akssesuar', 'update', 'charts', 'backup.zip', 'charts');
	 		$file = str_replace($strip_folders, ' ', $file);
	        // Ignore "." and ".." folders
	        if( in_array(substr($file, strrpos($file, '/')+1), array('.', '..')) )
	            continue;

	        $file = realpath($file);
	        $file = str_replace('\\', '/', $file);
	         
	        if (is_dir($file) === true){
	            $zip->addEmptyDir(str_replace($source . '/', '', $file . '/'));
	        }else if (is_file($file) === true){
	            $zip->addFromString(str_replace($source . '/', '', $file), file_get_contents($file));
	        }
	    }
	  }else if (is_file($source) === true){
	    $zip->addFromString(basename($source), file_get_contents($source));
	  }
	  return $zip->close();
	}

	function donwload_update($update_dir, $url) {
		$zipFile = $update_dir."update.zip"; // Rename .zip file
		$zipResource = fopen($zipFile, "w");

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_FAILONERROR, true);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_AUTOREFERER, true);
		curl_setopt($ch, CURLOPT_BINARYTRANSFER,true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
		curl_setopt($ch, CURLOPT_FILE, $zipResource);

		$page = curl_exec($ch);

		curl_close($ch);
		return $page;		
	}


	
	//извлекаем архив и устанавливем обновление 
	function ls_install_update($update_dir, $root_dir, $backup_dir) {	 
		$zip = new ZipArchive;
		if($zip->open($update_dir.'update.zip') === TRUE) {
			//делаем бэкап
			get_backup($root_dir, $backup_dir.'backup_'.date("d.m.Y").'.zip');		
				
			$zip->extractTo($root_dir);
		    $zip->close();
		    echo "Удачно";
		}
	}




	//показывает блок оповещение об обновлении
	function show_upd_notify() {
	?>
		<div class="update_modal">
		  <div class="update_modal_wrapper">
		    <div class="update_modal_content upd_modal_console">
		      
		      <div class="upd_console_header">
		        <div class="upd_console_hdr_list">
		          <div class="upd_console_logo">LS$</div>
		          <div class="upd_console_name">LS:\limestore\update</div>
		        </div>
		      </div>
		      
		      <div class="upd_console_content_wrp">
		        <div class="upd_console_cmd_list">
		          <div class="upd_console_cmd">
		            <div class="upd_console_cmd_name">$lime@store></div>
		            <div class="upd_console_content_descripton">Yeniləmə yüklənir</div>
		            <div class="upd_console_load">
		              <div></div> 
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>
		              <div></div>            
		            </div>            
		          </div>
		          
		          <div class="upd_console_cmd">
		            <div class="upd_console_cmd_name">$lime@store></div>
		            <div class="upd_console_content_descripton upd_warning_notify">PROQRAMI BAĞLAMAYIN!</div>   
		          </div> 
		          
		        </div>  
		      </div>
		      
		    </div>
		  </div>
		</div>
		<div class="update_block">
			<div class="upd_wrapper">
				<div class="upd_header">
					<span class="">Yeniləmə mövcuddur</span>
				</div>
				<div class="upd_dwnld">
					<button class="btn download_btn_s download_btn">Yükləyin</button>
				</div>
			</div>
		</div>
	<?php
	}

?> 

<script type="text/javascript">
	$('body').on('click', '.download_btn', function(){	
		var $get_preloader = $('.update_modal');
		$get_preloader.fadeIn();
		alert('Yeniləmələr yüklənir, zəhmət olmasa yükləmənin sonuna qədər gözləyin. \n Davam etmək üçün "OK" düyməsini basın');

		setTimeout(function(){
			get_request_upd();
		}, 3000);

		function get_request_upd() {
			var download_upd = 'dsfds';
			var link_path = 'core/main/update_check';
			$.ajax({
				type: 'POST',
				url: link_path,
				data: {
					download_upd: download_upd
				},
				cache: false,
				async: false,
				success: (data) => {
					document.location.href = "./";
				}			

			});
		}

	});
</script>

<style type="text/css">
.update_modal * {
	font-family: monospace;
}
.update_modal {
	position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    right: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: none;
    z-index: 100;
}

.update_modal_wrapper {
    display: flex;
    width: 100%;
    height: 100%;
    justify-content: center;
    align-items: center;
}

.upd_modal_console {
    width: 660px;
    height: 340px;
    background: #000;
    display: flex;
    flex-direction: column;
    border: 3px solid #555;
}

.upd_console_header {
    width: 100%;
    height: 50px;
    background: #555;
}

.upd_console_hdr_list {
    width: 100%;
    display: flex;
    height: 100%;
    align-items: center;
    margin-left: 10px;
}

.upd_console_logo {
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid #333;
    background: #000;
    color: green;
    font-size: 11px;
    border-radius: 7px;
    margin-right: 7px;
}

.upd_console_name {
    font-size: 14px;
    color: #fff;
}

.upd_console_cmd_name {
    color: green;
    font-size: 16px;
    margin-right: 10px;
}

.upd_console_content_wrp {
    width: 100%;
    height: 100%;
    overflow: hidden;
    overflow-y: scroll;  
}

.upd_console_cmd_list {
    padding: 15px 10px;
    width: 100%;
    height: 100%;
}

.upd_console_cmd {
    display: flex;
    align-items: center;
    width: 100%;
    height: 44px;
    flex-direction: row;
}

.upd_console_content_descripton {
    font-size: 14px;
    color: #dddd;
}

.upd_console_load {
    display: flex;
    margin-left: 10px;
}
.upd_console_load div {
    width: 20px;
    height: 20px;
    background: #ddd;
    animation: upd_load 1.5s infinite ease;
    opacity: 0;
}
.upd_warning_notify {
   color: rgba(255, 0, 0, 0.5)!important;
}

.upd_console_load div:nth-child(1) {
    animation-delay: 0.6s;
}

.upd_console_load div:nth-child(2) {
    animation-delay: 0.7s;
}

.upd_console_load div:nth-child(3) {
    animation-delay: 0.8s;
}
.upd_console_load div:nth-child(4) {
    animation-delay: 0.9s;
}
.upd_console_load div:nth-child(5) {
    animation-delay: 1s;
}
.upd_console_load div:nth-child(6) {
    animation-delay: 1.1s;
}

.upd_console_load div:nth-child(7) {
    animation-delay: 1.2s;
}

.upd_console_load div:nth-child(8) {
    animation-delay: 1.3s;
}

.upd_console_load div:nth-child(9) {
    animation-delay: 1.4s;
}
.upd_console_load div:nth-child(10) {
    animation-delay: 1.5s;
}
.upd_console_load div:nth-child(11) {
    animation-delay: 1.6s;
}
.upd_console_load div:nth-child(12) {
    animation-delay: 1.7s;
}


@keyframes upd_load {
    0% {
        opacity: 0;
    }                     
    100% {
        opacity: 100%;
    }  
}	

	.update_block {
	    position: absolute;
	    right: 12px;
	    top: 5px;
	}

	.update_block div {
	    box-sizing: border-box;
	}

	.upd_wrapper {
	    width: 350px;
	    height: 55px;
	    /* margin: 21px; */
	    display: flex;
	    justify-content: unset;
	    align-items: center;
	    padding: 18px;
	    /* background: red; */
	    box-sizing: border-box;
	    z-index: 20;
	    background: #f2f2f2f2;
	    box-shadow: 0 0 20px 0px rgba(197, 197, 197, 0.6);
	    border-radius: 10px;
	    position: relative;
	    transition: .5s;
	}

	.upd_wrapper:hover {
	    box-shadow: 0 0 20px 0px rgb(34, 111, 181, 0.5);
	}

	.upd_header {
	    /* padding: 0 10px; */
	    width: 50%;
	    height: 100%;
	    display: flex;
	    align-items: center;
	}

	.upd_header>span {
	    font-size: 16px;
	    color: #333;
	}

	.upd_dwnld {
	    position: absolute;
	    right: 10px;
	    transition: .5s;
	}

	.upd_dwnld:hover {
	    right: 15px;
	}

	.download_btn_s {
	    border-radius: 22px;
	    border: 0;
	    background: #226fb5;
	    color: #fff;
	    width: 113px;
	    height: 38px;
	    font-size: 16px;
	    text-transform: uppercase;
	    cursor: pointer;
	    outline: 0;
	    opacity: 0.8;
	    transition: .5s;
	}

	.download_btn_s:hover {
	    opacity: 1;
	} </style>