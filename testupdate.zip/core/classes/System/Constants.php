<?php

namespace core\classes\System;

class Constants
{
    public const ROOT_DIR = __DIR__.'/../../../';

    public const RETAIL_CONTROLLER_DIR = self::ROOT_DIR.'/core/controller/RetailController';
    public const WHOLESALE_CONTROLLER_DIR = self::ROOT_DIR.'/core/controller/WholesaleController';
    public const MIGRATION_FILE_DIR = SELF::ROOT_DIR.'/core/main/dbMigration/migrationFile/';
    public const CLOUD_MIGRATION_FILE_DIR = self::ROOT_DIR.'/core/main/dbMigration/cloud_migrationFIle/';
    public const CLOUD_DIR = self::ROOT_DIR.'/core/Cloud/';

}