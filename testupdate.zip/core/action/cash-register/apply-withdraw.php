<?php

use core\classes\Privates\CashRegisters;
use core\classes\Privates\User;
use core\classes\Utils\Utils;

header('Content-type: application/json');

if(!isset($_POST['amount']) || empty($_POST['amount']) || $_POST['amount'] <= 0) {
    return Utils::errorAbort('Сумма не указана');
}
    
$amount = $_POST['amount'];
$comment = $_POST['comment'] ?: '';
$paymentMethod = $_POST['paymentMethod'];
CashRegisters::withdraw(
    $amount,
    'withdraw',
    User::getCurrentUser('get_id'),
    $paymentMethod,
    null,
    $comment
);

$page = $_POST['page'];
$type = $_POST['type'];


$this_data = $init->initController($page);

$page_config = $this_data['page_data_list'];


$list = Utils::formatReferenceList([CashRegisters::getLast()], 'amount_change', 'type');

$table_result = $main->prepareCustomData($list, $page_config);

$table = $Render->view('/component/include_component.twig', [
    'renderComponent' => [
        '/component/table/table_row.twig' => [		
            'table' => $table_result['result'],
            'table_tab' => $page,
            'table_type' => $type
        ]
    ]
]);

Utils::abort([
    'type' => 'success',
    'text' => 'Ok',
    'table' => $table
]);