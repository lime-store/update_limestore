<?php
namespace core\classes\Services\LocalSync\Traits;

use core\classes\Products;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\dbWrapper\db;
use core\classes\Utils\Utils;

trait SyncBarcodes
{
    private static function syncProductBarcodes(array $barcodes, int $localStockId): void 
    {
        $product = new Products;

        $currentRemoteIds = self::getCurrentBarcodeRemoteIds($localStockId);
        $newRemoteIds = array_column($barcodes, 'barcode_id'); 
        
        $toAddIds = array_diff($newRemoteIds, $currentRemoteIds);
        $toRemoveIds = array_diff($currentRemoteIds, $newRemoteIds);    

        // Добавляем новые
        foreach ($barcodes as $barcode) {
            if (in_array($barcode['barcode_id'], $toAddIds)) {
                self::linkProductToBarcode($barcode, $localStockId);
            }
        }    
        
        // Убираем лишние
        foreach ($toRemoveIds as $remoteId) {
            self::unlinkBarcodeByRemoteId($remoteId, $localStockId);
        }        
    }

    /**
     * Привязывает категорию к товару (если связки ещё нет)
     */
    private static function linkProductToBarcode($barcode, int $localStockId): void
    {
        $exists = qb::select('barcode_id')
            ->from('stock_barcode_list')
            ->where('barcode_value = :bar_val AND br_stock_id = :stock_id')
            ->bindList([
                ':bar_val'   => $barcode['barcode_value'],
                ':stock_id' => $localStockId,
            ])
            ->execute()
            ->first()
            ->get();

        if (!empty($exists)) {
            return;
        }

        db::insert('stock_barcode_list', [
            [
                'barcode_value' => $barcode['barcode_value'],
                'br_stock_id'   => $localStockId,
                'remote_id'     => $barcode['barcode_id'],
            ]
        ]);
    }    

    /**
     * Удаляет связь товара с категорией по remote_id категории
     */
    private static function unlinkBarcodeByRemoteId(int $remoteBarcodeId, int $localStockId): void
    {
        $barcode = qb::select('barcode_id')
            ->from('stock_barcode_list')
            ->where('remote_id = :remote_id AND br_stock_id = :stock_id')
            ->bindList([
                ':remote_id' => $remoteBarcodeId,
                ':stock_id'  => $localStockId,
            ])
            ->execute() 
            ->first()
            ->get();

        if (empty($barcode)) {
            return; 
        }

        db::delete([
            [
                'table_name' => 'stock_barcode_list',
                'where' => ' barcode_id = :barcode_id ',
                'bindList' => [
                    ':barcode_id' => $barcode['barcode_id'],
                ]
            ]
        ]);
    }    


    /**
     * Текущие remote_id категорий, привязанных к товару
     */
    private static function getCurrentBarcodeRemoteIds(int $localStockId): array
    {
        $rows = qb::select('remote_id')
            ->from('stock_barcode_list')
            ->where('br_stock_id = :stock_id')
            ->bindList([':stock_id' => $localStockId])
            ->execute()
            ->get();

        return array_column($rows ?: [], 'remote_id');
    }    
        
}