<?php 
header('Content-type: Application/json');

$total = $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/modal/custom_modal/u_modal.twig' => [
			'containerClassList' => 'small-modal',
			'modalController' => [
				'title' => 'Kateqoriya əlavə et',
				'closeButtonClassList' => 'removeModal',
			],
			'modalContent' => [
				'classList' => 'modal-form',
				'path' => '/component/form/fields/category/add_category_name_fields.twig ',
            ],
		]
	]
]);


$utils::abort([
	'res' => $total,
]);
