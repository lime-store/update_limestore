<?php 

namespace core\classes\Traits;

use core\classes\Privates\AccessManager;

trait TableHeaderList {
	/**
	 * 
	 * old function name get_th_list
	 */
    public static function getTableHeaderList() 
    {
		$th_list = [
			'id' => array(
				'is_title' 			=> '№',
				'modify_class'	 	=> 'th_w40 dom-sort-table',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both',
				'data_sort' 		=> 'id',
				'mark'				=> false				
			),
			'name' => array(
				'is_title'  		=> 'Malın adı',
				'modify_class' 		=> 'th_w200',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both filter-hotkey-sort res-stock-name',
				'data_sort' 		=> 'name',
				'mark'				=> false
			),									
			'description' => array(
				'is_title' 			=> 'Təsvir',
				'modify_class' 		=> 'th_w150',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-stock-description',
				'data_sort' 		=> 'imeis',
				'mark'				=> false
			),
			'first_price' => array(
				'is_title'  		=> AccessManager::checkDataPremission('th_buy_price'),
				'modify_class'		=> 'th_w80',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-stock-first-price',
				'data_sort' 		=> '',
				'mark_text' 		=> '',
				'mark'				=> array(
					'mark_text' 		=> '',
					'mark_modify_class' => 'manat-icon--black button-icon-right stock-list-icon'
				)	
			),
			'second_price' => array(
				'is_title'  		=> 'Qiymət',
				'modify_class'		=> 'th_w80',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-stock-second-price',
				'data_sort' 		=> '',
				'mark'				=> array(
					'mark_text' 		=> '',
					'mark_title'		=> 'hekk',
					'mark_modify_class' => 'manat-icon--black button-icon-right stock-list-icon'
				)	
			),	
			'stock_barcode' => array(
				'is_title'  		=> 'Barcode',
				'modify_class'		=> 'th_w80',
				'td_class' 			=> '',
				'link_class' 		=> ' stock-link-text-both res-stock-barcode-list',
				'data_sort' 		=> 'stock-barcode-sort',
				'mark'				=> false	
			),
			'report_barcode' => array(
				'is_title'  		=> 'Barcode',
				'modify_class'		=> 'th_w80 hide',
				'td_class' 			=> 'hide',
				'link_class' 		=> 'hide stock-link-text-both res-stock-barcode-list',
				'data_sort' 		=> 'stock-barcode-sort',
				'mark'				=> false	
			),			
			'provider' => array(
				'is_title'  		=> 'Təchizatçı',
				'modify_class'		=> 'th_w130',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-stock-provider',
				'data_sort' 		=> false,
				'mark'				=> false
			),
			'return_status' => array(
				'is_title'  		=>  'Qaytarma',
				'modify_class'		=> 'th_w40',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both',
				'data_sort' 		=> '',
				'mark'				=> array(
					'mark_modify_class' => 'mark-tags mark-danger width-100 height-100',
					'mark_text' 		=> 'Bəli',
					'mark_title'		=> 'Bu mall vazvrat olunub',
				)
			),												
			'discount' => array(
				'is_title' 			=> 'Endirim',
				'modify_class' 		=> 'th_w70 text-center',
				'td_class' 			=> '',
				'link_class' 		=> 'res-stock-discount',
				'data_sort' 		=> '',
				'mark'				=> array(
					'mark_modify_class' => '',
					'mark_text' 		=> '%',
					'mark_title'		=> '',
				)	
			),
			'count' => array(
				'is_title' 			=> AccessManager::checkDataPremission('th_count'),
				'modify_class' 		=> 'th_w80',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-stock-count',
				'data_sort' 		=> '',
				'mark'				=> array(
					'mark_text'			=> "ədəd",
					'mark_title'		=> false,
					'mark_modify_class' => 'button-icon-left mark stock-list-mark'
				)	
			),
			'category' => array(
				'is_title' 			=> 'Kategoriya',
				'modify_class' 		=> 'th_w140',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-stock-category',
				'data_sort' 		=> false,
				'mark'				=> false	
			),
			'stock_add_date' => array(
				'is_title' 			=> 'Alış günü',
				'modify_class' 		=> 'th_w120',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res_buy_date',
				'data_sort' 		=> 'buy_date',
				'mark'				=> false					
			),
			'sales_date' => array(
				'is_title' 			=> 'Satış günü',
				'modify_class' 		=> 'th_w100',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res_buy_date',
				'data_sort' 		=> 'buy_date',
				'mark'				=> false
			),
			'sales_time' => array(
				'is_title'			=> 'Saat',
				'modify_class'		=> 'th_120',
				'td_class'			=> '',
				'link_class'		=> 'stock-link-text-both',
				'data_sort'			=> '',
				'mark'				=> false,
			),

			'report_note' => array(
				'is_title' 			=> 'Qeyd',
				'modify_class' 		=> 'th_w100',
				'td_class' 			=> '',
				'link_class' 		=> ' stock-link-text-both res_note',
				'data_sort' 		=> '',
				'mark'				=> false				
			),

			'report_profit' => array(
				'is_title' 			=> AccessManager::checkDataPremission('th_profit'),
				'modify_class' 		=> 'th_w80',
				'td_class' 			=> 'mark-success',
				'link_class' 		=> 'stock-link-text-both res-report-profit',
				'data_sort' 		=> '',
				'mark'				=> array(
					'mark_text' 		=> '',
					'mark_modify_class' => 'manat-icon--black button-icon-right stock-list-icon'
				)	
			),	
			'report_sum_amount' => array(
				'is_title' 			=> AccessManager::checkDataPremission('th_profit'),
				'modify_class' 		=> 'th_w100',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both',
				'data_sort'			=> '',
				'mark' 				=> false
			),			
			'report_total_amount' => array(
				'is_title' 			=> 'Ümumi məbləğ',
				'modify_class' 		=> 'th_w100',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both  res-report-total	',
				'data_sort'			=> '',
				'mark'				=> array(
					'mark_text' 		=> '',
					'mark_modify_class' => 'manat-icon--black button-icon-left stock-list-icon'
				)	
			),	
			'report_period_amount' => array(
				'is_title' 			=> 'Toplam məbləğ',
				'modify_class' 		=> 'th_w100',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both  res-report-total	',
				'data_sort'			=> '',
				'mark'				=> array(
					'mark_text' 		=> '',
					'mark_modify_class' => 'manat-icon--black button-icon-left stock-list-icon'
				)	
			),						
			'report_period_profit' => array(
				'is_title' 			=> 'Toplam mənfəət',
				'modify_class' 		=> 'th_w80',
				'td_class' 			=> 'mark-success',
				'link_class' 		=> 'stock-link-text-both res-report-profit',
				'data_sort' 		=> '',
				'mark'				=> array(
					'mark_text' 		=> '',
					'mark_modify_class' => 'manat-icon--black button-icon-right stock-list-icon'
				)	
			),	
			'report_period_count' => array(
				'is_title' 			=> 'Toplam say',
				'modify_class' 		=> 'th_w80',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-stock-count',
				'data_sort' 		=> '',
				'mark'				=> array(
					'mark_text'			=> 'ədəd',
					'mark_title'		=> false,
					'mark_modify_class' => 'button-icon-left mark stock-list-mark'
				)	
			),						
			'report_date_year' => array(
				'is_title' 			=> false,
				'modify_class' 		=> 'th_w80',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both',
				'data_sort' 		=> 'date_year',
				'mark'				=> false
			),
			'report_order_id' => array(
				'is_title' 			=> '№',
				'modify_class' 		=> 'th_w60',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both get_report_order_id',
				'data_sort' 		=> '',
				'mark'				=> false
			),
			'report_order_date' => array(
				'is_title' 			=> '№',
				'modify_class' 		=> 'hide',
				'td_class' 			=> 'hide',
				'link_class' 		=> 'hide',
				'data_sort' 		=> 'date',
				'mark'				=> false				
			),
			'report_order_edit' => [
				'is_title' 			=> 'Redaktə',
				'modify_class' 		=> 'th_w70',
				'td_class' 			=> 'table-ui-reset',
				'link_class' 		=> 'las la-pen btn btn-secondary width-100 table-ui-btn info-stock open-edit-modal',
				'data_sort' 		=> '',
				'mark'				=> false				
			],	
			'payment_method' => array(
				'is_title'  		=> 'Ödəniş üsulu',
				'modify_class'		=> 'th_w80',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-payment-tags',
				'data_sort' 		=> '',
				'mark'				=> array(
					'mark_modify_class' => 'mark-tags mark-warning width-100 height-100 zsdljkfsjfklsj',
					'mark_text' 		=> 'u',
					'mark_title'		=> '',
				)
			),
			
			'payment_method_form' => array(
				'is_title'  		=> 'Ödəniş üsulu',
				'modify_class'		=> 'th_w300',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-payment-method-title',
				'data_sort' 		=> '',
				'mark'				=> array(
					'mark_modify_class' => '',
					'mark_text' 		=> '',
					'mark_title'		=> '',
				)
			),			
			
			'report_sales_man' => array(
				'is_title' 			=> 'Satici',
				'modify_class' 		=> 'th_w70 text-center',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both',
				'data_sort' 		=> '',
				'mark_is_title'		=> true,
				'mark'				=> array(
					'mark_modify_class' => 'mark mark-tags mark-primary width-100 height-100',
					'mark_text' 		=> 'u',
					'mark_title'		=> '',
				)
			),
			'seller' => array(
				'is_title' 			=> 'Satici',
				'modify_class' 		=> 'width-auto',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both',
				'data_sort' 		=> '',
				'mark_is_title'		=> true,
				'mark'				=> array(
					'mark_modify_class' => '',
					'mark_text' 		=> '',
					'mark_title'		=> '',
				)
			),
			'terminal_add_basket' => array(
				'is_title' 			=> ' ',
				'modify_class' 		=> 'th_w60',
				'td_class' 			=> 'table-ui-reset',
				'link_class' 		=> 'las btn add-basket-btn-icon add-basket-button width-100 table-ui-btn la-cart-plus btn-secondary add-to-cart',
				'data_sort' 		=> '',
				'mark'				=> false
			),
			'terminal_basket_count_plus' => array(
				'is_title' 			=> ' ',
				'modify_class' 		=> 'th_w60',
				'td_class' 			=> 'table-ui-reset',
				'link_class' 		=> 'las las la-info-circle btn btn-primary width-100 table-ui-btn info-stock open-edit-modal',
				'data_sort' 		=> '',
				'mark'				=> false
			),	
			'terminal_stock_info' => array(
				'is_title' 			=> ' ',
				'modify_class' 		=> 'th_w60',
				'td_class' 			=> 'table-ui-reset',
				'link_class' 		=> 'las la-plus btn btn-primary add-basket-btn-icon width-100 card-plus-count table-ui-btn',
				'data_sort' 		=> '',
				'mark'				=> false
			),							
			'edit_stock_btn' => [
				'is_title' 			=> 'Redaktə',
				'modify_class' 		=> 'th_w60',
				'td_class' 			=> 'table-ui-reset',
				'link_class' 		=> 'las la-pen btn btn-secondary width-100 table-ui-btn info-stock open-edit-modal open-edit-modal',
				'data_sort' 		=> '',
				'mark'				=> false				
			],
			'seller_id' => array(
				'is_title' 			=> 'id',
				'modify_class' 		=> 'th_w40',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both',
				'data_sort' 		=> false,
				'mark'				=> false
			),
			'seller_name' => array(
				'is_title' => 'Логин',
				'modify_class' 		=> 'th_w300',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-seller-name',
				'data_sort' 		=> 'user_name',
				'mark'				=> false
			),
			'seller_password' => array(
				'is_title' 			=> AccessManager::checkDataPremission('th_admin_password'),
				'modify_class' 		=> 'th_w70',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-seller-password',
				'data_sort' 		=> false,
				'mark'				=> false
			),
			'seller_role' => array(
				'is_title' 			=> 'Роль',
				'modify_class' 		=> 'th_w70',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-seller-role',
				'data_sort' 		=> false,
				'mark'				=> false
			),
			'seller_edit' => array(
				'is_title' 			=> 'Redaktə',
				'modify_class' 		=> 'th_w40',
				'td_class' 			=> 'table-ui-reset',
				'link_class' 		=> 'las la-pen btn btn-secondary width-100 table-ui-btn info-stock open-edit-modal',
				'data_sort' 		=> '',
				'mark'				=> false	
			),
			'category_name' => array(
				'is_title' 			=> 'Название Категории',
				'modify_class' 		=> 'w100',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-category-name',
				'data_sort' 		=> 'category',
				'mark'				=> false
			),
			'provider_name' => array(
				'is_title' 			=> 'Təchizatçı',
				'modify_class' 		=> 'w100',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-edit-provider-name',
				'data_sort' 		=> 'provider',
				'mark'				=> false
			),			
			'edit' => array(
				'is_title' 			=> 'Redaktə',
				'modify_class' 		=> 'th_w60',
				'td_class' 			=> 'table-ui-reset',
				'link_class' 		=> 'las la-pen btn btn-secondary width-100 table-ui-btn info-stock open-edit-modal',
				'data_sort' 		=> '',
				'mark'				=> false				
			),
			'rasxod_date' => array(
				'is_title' 			=> '№',
				'modify_class' 		=> 'hide',
				'td_class' 			=> 'hide',
				'link_class' 		=> 'hide',
				'data_sort' 		=> 'rasxod-date',
				'mark'				=> false
			),
			'rasxod_day_date' => array(
				'is_title' 			=> 'Tarix',
				'modify_class'		=> 'th_w120',
				'td_class'			=> '',
				'link_class'		=> 'stock-link-text-both res-rasxod-date',
				'data_sort'			=> 'rasxod-day-date',
				'mark'				=> false
			),
			'transfer_full_date' => array(
				'is_title' 			=> 'Tarix',
				'modify_class'		=> 'th_w120',
				'td_class'			=> '',
				'link_class'		=> 'stock-link-text-both',
				'data_sort'			=> 'transfer-day-date',
				'mark'				=> false
			),			

			'rasxod_description' => array(
				'is_title' 			=> 'Tesvir',
				'modify_class'		=> 'th_w300',
				'td_class'			=> '',
				'link_class'		=> 'stock-link-text-both res-rasxod-description',
				'data_sort'			=> 'rasxod-description',
				'mark'				=> false
			),
			'rasxod_amount' => array(
				'is_title' 			=> 'Amount',
				'modify_class'		=> 'th_w60',
				'td_class'			=> 'mark-danger',
				'link_class'		=> 'stock-link-text-both res-rasxod-amount',
				'data_sort'			=> false,
				'mark'				=> [
					'mark_text' 		=> '',
					'mark_modify_class' => 'manat-icon--black button-icon-right stock-list-icon'
				]
			),

			'warehouse_name' => array(
				'is_title' 			=> 'Anbar adı',
				'modify_class'		=> 'th_w200',
				'td_class'			=> '',
				'link_class'		=> 'stock-link-text-both res-warehouse-name',
				'data_sort'			=> false,
				'mark'				=> [
				]
			),	


			'warehouse_contact' => array(
				'is_title' 			=> 'Əlaqə',
				'modify_class'		=> 'th_w100',
				'td_class'			=> '',
				'link_class'		=> 'stock-link-text-both',
				'data_sort'			=> false,
				'mark'				=> [
				]
			),						

			'td_filters_title' => array(
				'is_title' 			=> 'Filter adı',
				'modify_class' 		=> 'width-100',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-filter-name',
				'data_sort' 		=> 'name',
				'mark'				=> false
			),

			'arrival_added_date' => array(
				'is_title' => 'Alış tarıxı',
				'modify_class' => 'width-60',
				'td_class' => '',
				'link_class' => 'stock-link-text-both res-',
				'data_sort' => 'arrival-date-month-srot',
				'mark' => false
			),
			'total_sales' => [
				'is_title' 			=> 'Toplam satış',
				'modify_class' 		=> 'th_w100',
				'td_class' 			=> 'mark-success',
				'link_class' 		=> 'stock-link-text-both  	',
				'data_sort'			=> '',
				'mark'				=> array(
					'mark_text' 		=> '',
					'mark_modify_class' => 'manat-icon--black button-icon-left stock-list-icon'
				)
			],
			'total_refaund' => [
				'is_title' 			=> 'Toplam qeri qaytarma',
				'modify_class' 		=> 'th_w100',
				'td_class' 			=> 'mark-danger',
				'link_class' 		=> 'stock-link-text-both  	',
				'data_sort'			=> '',
				'mark'				=> array(
					'mark_text' 		=> '',
					'mark_modify_class' => 'manat-icon--black button-icon-left stock-list-icon'
				)
			],
			'remaining_quantity' => [
				'is_title' 			=> 'Qalıq',
				'modify_class' 		=> 'th_w80',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-stock-count',
				'data_sort' 		=> '',
				'mark'				=> array(
					'mark_text'			=> 'ədəd',
					'mark_title'		=> false,
					'mark_modify_class' => 'button-icon-left mark stock-list-mark'
				)
			],			

			//wholesale
			'wholesale_price' => array(
				'is_title'  		=> 'Topdan qiymet',
				'modify_class'		=> 'th_w80',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-',
				'data_sort' 		=> '',
				'mark_text' 		=> '',
				'mark'				=> array(
					'mark_text' 		=> '',
					'mark_modify_class' => 'manat-icon--black button-icon-right stock-list-icon'
				)	
			),

			'wholesale_total_order' => array(
				'is_title'  		=> 'Məbləğ',
				'modify_class'		=> 'th_w80',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-stock-second-price',
				'data_sort' 		=> '',
				'mark'				=> array(
					'mark_text' 		=> '',
					'mark_title'		=> 'hekk',
					'mark_modify_class' => 'manat-icon--black button-icon-right stock-list-icon'
				)	
			),		
			
			'wholesale_customer_name' => array(
				'is_title' 			=> 'Müştəri',
				'modify_class' 		=> 'th_w200',
				'td_class' 			=> '',
				'link_class' 		=> 'stock-link-text-both res-name',
				'data_sort' 		=> '',
				'mark_is_title'		=> true,
				'mark'				=> array(
					'mark_modify_class' => 'mark mark-tags mark-primary width-100 height-100',
					'mark_text' 		=> 'u',
					'mark_title'		=> '',
				)
			),			
			'wholesale_show_order' => [
				'is_title' 			=> 'Redaktə',
				'modify_class' 		=> 'th_w60',
				'td_class' 			=> 'table-ui-reset',
				'link_class' 		=> 'las la-pen btn btn-primary width-100 table-ui-btn info-stock get-wholesale-order-report-modal',
				'data_sort' 		=> '',
				'mark'				=> false				
			],	
			'wholesale_transaction_id' => array(
				'is_title'  		=> 'transaction_id',
				'modify_class'		=> 'th_w80 hide',
				'td_class' 			=> 'hide',
				'link_class' 		=> 'hide stock-link-text-both wholesale-transaction-id',
				'data_sort' 		=> '',
				'mark'				=> false	
			),	
			'customer_name' => array(
				'is_title'  		=> 'Müştəri adı',
				'modify_class'		=> 'th_w300 ',
				'td_class' 			=> '',
				'link_class' 		=> ' stock-link-text-both res-name',
				'data_sort' 		=> true,
				'mark'				=> false	
			),	
			'customer_contact' => array(
				'is_title'  		=> 'Əlaqə',
				'modify_class'		=> 'th_w150 ',
				'td_class' 			=> '',
				'link_class' 		=> ' stock-link-text-both res-contact',
				'data_sort' 		=> true,
				'mark'				=> false	
			),							
			'customer_cashback_percent' => array(
				'is_title'  		=> 'Bonus faizi',
				'modify_class'		=> 'th_w50 ',
				'td_class' 			=> '',
				'link_class' 		=> ' stock-link-text-both res-cashback-percent',
				'data_sort' 		=> false,
				'mark'				=> false	
			),							
			'customer_cashback_balance' => array(
				'is_title'  		=> 'Balans',
				'modify_class'		=> 'th_w60 ',
				'td_class' 			=> '',
				'link_class' 		=> ' stock-link-text-both',
				'data_sort' 		=> false,
				'mark'				=> [
					'mark_modify_class' => 'manat-icon--black button-icon-right stock-list-icon'
				]	
			),	
			'used_cashback_amount' => array(
				'is_title'			=> 'Bonus',
				'hideIfNotValue'	=> true,
				'modify_class'		=> 'th_w100 text-center',
                'link_class'    	=> 'mark mark-tags mark-text mark-danger',
                'td_class'  		=> 'text-center',
				'data_sort' 		=> false,
                'mark' => array(
                    'mark_text'         	=> '',
                    'mark_modify_class' 	=> 'manat-icon--font',
                    // 'mark_operation_class' 	=> true
                )  
			),
			'customer_card_code' => array(
				'is_title'  		=> 'Kod',
				'modify_class'		=> 'th_w150 ',
				'td_class' 			=> '',
				'link_class' 		=> ' stock-link-text-both res-card-code',
				'data_sort' 		=> true,
				'mark'				=> false	
			),
			'customer_balance_history' => array(
				'is_title' 			=> 'Tarixce ',
				'modify_class' 		=> 'th_w40',
				'td_class' 			=> 'table-ui-reset',
				'link_class' 		=> 'las las la-info-circle btn btn-primary width-100 table-ui-btn get-customer-balance-history',
				'data_sort' 		=> '',
				'mark'				=> false
			),	
		];
		return $th_list;
	}

	/**
	 *  'td_class' 			=> '',
	 * 	'link_class' 		=> 'stock-link-text-both res-stock-second-price',
	 * 	'data_sort' 		=> '',
	 * 	'mark'				=> array(
	 * 		'mark_text' 		=> '',
	 * 		'mark_title'		=> 'hekk',
	 * 		'mark_modify_class' => 'manat-icon--black button-icon-right stock-list-icon'
	 * 	)
	 */
	public static function getTableHeaderByTemplate(string $title = '', string $width = 'th_w100', array $options = []) :array
	{
		$defaultOption = [
			'td_class' 		=> '',
			'link_class' 	=> '',
			'data_sort' 	=> '',
			'mark' 			=> array()			
		];

		$options = array_merge($defaultOption, $options);
		
		$arr = [
			'is_title'  		=> $title,
			'modify_class'		=> $width,		
		];

		return array_merge($arr, $options);
	}
}