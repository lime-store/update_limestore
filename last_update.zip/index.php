<?php 
	require_once 'include/header.php';

?>
<div class="container">
	<div class="sidebar_menu_wrp">
		<?php require_once 'core/main/menu_sidebar.php'; ?>
	</div>

	<div class="main">
		<div class="main-wrapper" id="main_wrapper">
			<?php require_once 'core/main/options.php'; ?>
		</div>
	</div>

</div>

