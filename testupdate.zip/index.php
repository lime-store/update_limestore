<?php
header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

use core\classes\System\Init;
use core\classes\Privates\CashRegisters;
use core\classes\Services\Notify;
use core\classes\System\Config;
use core\classes\System\LicenseManager;
use core\classes\System\Settings;
use core\classes\Utils\Utils;

require_once 'start.php';

Init::initDefaultControllerList();

$licenseManager->hasLicenseExpired(Utils::getDateDMY(), LicenseManager::getLicenseExpiredDate(), function($expired) {
    if($expired) {
        header("Location: license.php");   
		die;
    }
});


if (!isset($_SESSION['user'])) {
	$login_dir = '/login.php';
	header("Location: $login_dir");
	exit();
}

$settings_json = (array) Settings::getSettingsJSON();

$updater = new \core\classes\System\Updater;

$image_dir = array_diff(scandir('assets/img/pattern/'), array('.', '..'));

$random_main_background_image = $image_dir[array_rand($image_dir, 1)];


$hasAlmostLiscenseExpired = false;

$getLicenseRemainingDays = LicenseManager::getLicenseRemainingDays();

if($getLicenseRemainingDays <= 3) {
	$hasAlmostLiscenseExpired = [
									'/component/parts/alert.twig' => [
										'classList' => 'mark-danger height-auto flex-align-self-center',
										'value' => "Lisenziyanın müddəti  $getLicenseRemainingDays gündən sonra bitir"
									]
								];
}


echo $Render->view('/component/include_component.twig', [
	'renderComponent' => [
		'/component/index/head.twig' => [
			'lib_list' => Config::loadAssets(),
			'v' => time()
		],
		'/component/widget/notice.twig' => [
			//code
		],
		'/component/related_component/body_preloader.twig' => [
			//data
		],
		'/component/related_component/overlay.twig' => [
			//data
		],
	]
]);


echo $Render->view('/component/related_component/main_page.twig', [
	'renderComponent' => [
		'/component/index/show_current_version.twig' => [
			'current_version' => $updater->getCurrentVersion()
		],

		// sidebar
		'/component/index/sidebar.twig' => [
			'menu_list' => [
				'data' => $main->getMenuList()
			],
		],

		// main content
		'/component/container.twig' => [
			'includs' => [
				'renderMain' => [
					// header
					'/component/index/top_nav_content/top_nav.twig' => [
						'includs' => [		
							$hasAlmostLiscenseExpired, 

							'renderTopNavComponent' => [
								'/component/index/top_nav_content/nav_list_options.twig' => [
									'username' => $user->getCurrentUser('get_name'),
									// вложеность в шаблоне, рендерим друигие шаблоны
									'includs' => [		
										'branch' => [
											'/component/branch/chooseBranchButton.twig' => [
												'function_state' => $settings_json['branch']['function_state'] ?? false
											]
										],							
										'stories' => [
											'/component/stories/stories.twig' => [
											]
										],	
										'cashRegister' => [
											'/component/cash-register/cash-register-nav.twig' => [
												'balance' => CashRegisters::getCurrentBalance()
											]
										],																					
										'renderUpdateNotify' => [
											'/component/notify/notify.twig' => [
												'notifyList' => Notify::getNotifyList(),
												'hasNewNotify' => Notify::hasUnreadableNotification()
											]
										],
									],
								]
							],
						]
					],

					// menu
					'/component/main/menu_list.twig' => [
						'menu' => $main->getMenuList(),
						'main_image' => $random_main_background_image
					],

					// main
					'/component/main/main.twig' => [
						//data
					],

					// modal
					'/component/modal/modal_wrapper.twig' => [
						//data
					],


				]
			]
		]
	],
]);
