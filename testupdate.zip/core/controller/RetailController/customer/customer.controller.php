<?php 
use \core\classes\Privates\AccessManager;

return [
    'tab' => [
        'is_main' => false,
        'title' 			=> 'Müştəri',
        'icon'				=> [
            'img_big'		 	=> 'assets/img/svg/sidebar/1.svg',
            'img_small'			=> 'assets/img/svg-icon/sidebar/1.svg',
            'modify_class' 		=> 'las la-cart-arrow-down'
        ],
        'link'  			=> '/page/base.php',
        'template_src'      => 'page/base_tpl.twig',
        'background_color'  => 'rgba(0, 150, 136, 0.1)',
        'tab' => array(
            'list' => [
                'tab_customer'
            ],
            'active' => 'tab_customer'
        )
    ],
    'sql' => [
        'table_name' => 'user_control',
        'col_list'	=> '    c.id,
                            c.name,
                            c.contact_number,
                            c.cashback_card_code,
                            COALESCE(cb.balance_amount, 0) AS balance',
        'query' => array(
            'base_query' =>  "",
            'body' =>  " INNER JOIN customer as c ON c.visible = 0  
            ",
            "joins" => "             
                LEFT JOIN (
                    SELECT 
                        customer_id,
                        balance_amount,
                        ROW_NUMBER() OVER (
                            PARTITION BY customer_id
                            ORDER BY id DESC
                        ) AS rn
                    FROM customer_balance
                ) cb
                    ON cb.customer_id = c.id
                AND cb.rn = 1
            ",				  
            'sort_by' => " 
                    GROUP BY c.id DESC
                    ORDER BY c.id DESC
            ",
            'limit' => ""
        ),	
        'bindList' => array()   
    ],
    'page_data_list' => [
        'sort_key' => 'id',
        'get_data' => [
            'id' 				            => 'id',
            'customer_name'			        => 'name',
            'customer_contact'              => 'contact_number',
            'customer_card_code'            => 'cashback_card_code',
            'customer_cashback_balance'     => 'balance',
            'report_order_edit'             => null,    
            'customer_balance_history'      => null
          ],
        'autocomplete' => [
            [
                'display' => 'name',
                'search' => [
                    // 'id'                => 'id',
                    'name'			 	=> 'name',
                    'description' 		    => 'description',
                    'customer_card_code'    => 'cashback_card_code'
                ]
            ]
        ],
        'table_total_list' => [
        ],
        'modal' => [
            'template_block' => 'edit_product',
            'modal_fields' => array(
                'edit_customer' => [
                    'db' 			=> 'false', 
                    'class_list'	=> 'edit',
                    'custom_data' 	=> false, 
                    'user_function' => [
                        'function_name' => [new \core\classes\Services\Customer\Customer, 'getCustomerInfo'],
                        'function_args' => 'id',
                    ],							
                    'premission'	=> true                    
                ]
            )
        ],
        'filter_fields' => [
            // 'color',
            // 'used',
            // 'storage',
            // 'ram',
            // 'brand'
        ]					
    ],

];