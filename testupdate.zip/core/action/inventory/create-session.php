<?php
header('Content-type: Application/json');

use core\classes\Inventory\InventorySession;
use core\classes\Utils\Utils;

$postData = $_POST['post_data'] ?? [];

$inventoryId = (int) ($postData['inventory_id'] ?? 0);
$comment = trim($postData['comment'] ?? '');

if($inventoryId <= 0) {
    Utils::errorAbort('Sayim seçilməyib');
    return;
}

try {
    InventorySession::create($inventoryId, $user->getCurrentUser('get_id'), $comment !== '' ? $comment : null);

    Utils::successAbort('Sessiya yaradıldı');
} catch (\Throwable $e) {
    Utils::errorAbort(inventoryErrorMessage($e));
}