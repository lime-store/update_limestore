<?php
use core\Cloud\classes\Sync\CloudSyncQueue;

$providerId = $_POST['providerId'] ?? null;

if(!empty($providerId)) {
    CloudSyncQueue::deleteProviderTask($providerId);
}