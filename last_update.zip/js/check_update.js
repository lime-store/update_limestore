//загружаем обновление
$(document).ready(function(){
	$.ajax({
		type: 'POST',
		url: 'core/main/update_check.php',
		success: (data) => {
			$('body').append(data);
		}
	});
});
