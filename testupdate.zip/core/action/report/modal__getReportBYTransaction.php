<?php 

use core\classes\Products;
use core\classes\Report;
use core\classes\Services\Warehouse\Traits\Arrival;
use core\classes\Utils\Utils;
use core\classes\System\Main;
use core\classes\Traits\TableHeaderList as TH;
use LDAP\Result;

header('Content-type: Application/json');

$data = Report::getReportByTransactionPrepareData($_POST['transactionId']);

    $total = $Render->view('/component/include_component.twig', [
        'renderComponent' => [
            '/component/modal/custom_modal/u_modal.twig' => [
                'modalController' => [
                    'title' => "Hesabat",
                    'closeButtonClassList' => 'removeModal',
                ],
                'modalContent' => [
                    'path' => '/component/include_once_component.twig',
                ],
                'includs' => [
                    'd' => [
                        // '/component/widget/title.twig' => [
                        //     'title' => 'dsd',
                        //     'classList' => 'margin-0 mrgn-top-100 sub-title',
                        // ],
                        '/component/table/table_wrapper.twig' => [
                            'table' => $data['result']
                        ],
                    ]
                ],
                'containerClassList' => 'large-modal',  
            ]  
        ]
    ]);
    
    
    $utils::abort([
        'res' => $total,
    ]);
