$(document).ready(function(){

	$('body').on('click', '.close_modal_btn', function(){
		$('.module_fix_right_side').fadeOut('slow');
		$('.modal_view_stock_order').html('');
		// $('.main').attr("style", "padding-right: 0px");
		$('.add_profit_modal').fadeOut();
		//убираем активированный продукт
		remove_selected_product();
		$('.overlay').fadeOut();
		$('body').css('overflow', 'auto');		
	});

});

$(document).ready(function(){
	$('body').on('click', '.delete_btn_link', function(){
		$('.delete_stock_module').show().attr("style", "display: flex;");
	});
});

$(document).ready(function(){
	$('body').on('click', '.module_delete_btn_cancle', function(){
		$('.delete_stock_module').hide('slow');
	});
});


$(document).ready(function(){
	$('body').on('click', '.module_nav_btn', function (){
		$('.module_sidebar').toggleClass('open_menu');
		$('.module_nav_first_image').toggleClass('menu_close_img');
		$('.module_nav_second_image').toggleClass('menu_open_img');
		$('.modle_menu_btn').toggleClass('menu_btn_active');
	});
});



$(document).ready(function(){
	$('body').on('click', '.close_print_module', function(){
		$('.print_div').fadeOut();
	});
});


$(document).ready(function(){
	$('body').on('click', '.report_action', function(){
		var report_action_id = $(this).attr("id");
		$('.module_fix_right_side').fadeIn();
		$('.phone_modal_view').fadeIn();
		$('.akss_modal_view').fadeOut();
		$('.add_to_recipert').attr('id',report_action_id);
		$('.stock_return_accept_button').attr('id', report_action_id);
		$('.receipet_success').fadeOut();
		$('.stock_return_accept_form').fadeOut();
	});
});



$(document).ready(function(){
	$('body').on('click', '.akss_report_action', function(){
		var report_action_id = $(this).attr("id");
		$('.module_fix_right_side').fadeIn();
		$('.akss_modal_view').fadeIn();
		$('.phone_modal_view').fadeOut();
		$('.akss_stock_return_accpet_action_btn').attr('id', report_action_id);
		$('.akss_stock_return_accept_form').fadeOut();
	});
});



$(document).ready(function(){
	$('body').on('click', '.link_stock_return_btn', function(){
		$('.stock_return_accept_form').attr("style", "display: flex").fadeIn();
	});
});

$(document).ready(function(){
	$('body').on('click', '.akss_link_stock_return_btn', function(){
		$('.akss_stock_return_accept_form').attr("style", "display: flex").fadeIn();
	});
});


$(document).ready(function(){
	$('body').on('click', '.stock_return_cancle', function(){
		$('.stock_return_accept_form').fadeOut();
		$('.akss_stock_return_accept_form').fadeOut();
	});	
});


$(document).ready(function(){
	$('body').on('click', '.close_report_print', function(){
		$('.receipt_order_rerport_list').fadeOut();
		$(this).fadeOut();
	});
});


$(document).ready(function(){
	$('body').on('click', '.close_error_module_action', function(){
		$('.add_stock_module_error').fadeOut();
	});



	$('body').on('click', '.fastOptionOpenAction', function(){
		$('.select_option_name_wrp').fadeIn();
	});

	$('body').on('click', '.close_option_name', function(){
		$('.select_option_name_wrp').fadeOut();
	});
	
	$('body').on('click', '.selectOptionName', function(){
		let selectedoption = $(this).html();

		$('.add_stock_name_input').val(selectedoption);

		$('.select_option_name_wrp').fadeOut();
	});


	$('body').on('click', '.reminder_delete_hdr', function(){
		$('.reminder_wrapper_header').fadeOut();
	});



});



function addLeftPaddingModal() {
	$('.module_fix_right_side').fadeIn().attr("style", "display: flex");

	$('.overlay').fadeIn();
	$('body').css('overflow', 'hidden');
}



/**********update start******/

$(document).ready(function(){

$(window).scroll(function(){
	var $height = $(this).scrollTop();
	var maxheight = 600;

	if($height > maxheight) {
		$('.scroll_to_top_wrapper').fadeIn().addClass('flex-cntr');
		$('body thead').css({'position': 'fiexd', 'left': '0', 'top' : '0'});
	} else {
		$('.scroll_to_top_wrapper').fadeOut().removeClass('flex-cntr');
	}
});

	//при навелении на модально окно убирать прокуртку у боди
	$('body').on('click', '.scroll_top', function(){
		var body = $("html, body");

		 body.stop().animate({scrollTop:0}, 500, 'swing', function() {
		 	console.log('done');
		 });

	});


	//фильтруем данные инпута от муора
	$('body').on('keyup', '.order_input', function(){
		//получаем цену заказа
		var order_price = $('.order_price_action').val();
		
		//получаем количество заказа
		var $order_count = $('.order_count_action');

		//количество заказа	
		var order_count_value = $order_count.val();
		//функция очищает цену от лишнего 
		preg_order_price_value(order_price);

		//функция очищает количество от лишнего
		preg_order_count_value(order_count_value);

		//проверка на валидность
		product_count_not_valid(order_count_value, $order_count);

		var order_total_res = order_price*order_count_value;
		var order_total_res = order_total_res.toFixed(1);

		$('.get_order_action').removeClass('click');

		$('.show_total_sum_order_action').html(order_total_res);
		$('.total_sum_order_stock').val(order_total_res);

	});




	//очищаем цену для заказа
	function preg_order_price_value(order_price) {
		//заменяем все запятне на точку 
		var order_price = order_price.replace(',', '.' );

		//удалаяем все буквы и символы кроме цифр
		var order_price = order_price.replace(/[^.\d]+/g,"")

		//удаляем все лишние точки и оставяем тоько одну
		var order_price = order_price.replace( /^([^\.]*\.)|\./g, '$1');

		$('.add_stock_submit').removeClass('click');
		$('.order_price_action').val(order_price);
		return order_price;	
	}

	//очишаю цену при доавлении в базу 
	$('body').on('keyup', '.input_preg_action', function(){
		add_price = $(this).val();
		//вызываем функция очищаем инпут
		preg_order_price_value(add_price);

		//получем очищеный инпут из функции
		var price = preg_order_price_value(add_price);
		
		//выводим в инпут
		$(this).val(price);

	});
	//очищаем количество заказа
	function preg_order_count_value(order_count) {
		//очищаем от точки\запятой и любого символа кроме цифр
		var order_count = order_count.replace(/[^.\d]+/g,"").replace(/[^,\d]+/g,"");

		//удаляем 0  в начале строки
		var order_count = order_count.replace(/^0/,'');

		$('.order_count_action').val(order_count);
	}

	//если количество товра не валидна
	function product_count_not_valid(order_count_value, $order_count) {
		if(order_count_value.length === 0 || order_count_value == 0) {
			//добавляем класс не активного инпута
			$order_count.addClass('not_valid_input');
		} else {
			//удаляем класс не активного инпута
			$order_count.removeClass('not_valid_input');			
		}
	}



	$('body').on('click', '.add_prfit_action', function(){
		$('.add_profit_modal').fadeIn().css('display', 'flex');
	});

});

function remove_selected_product() {
	$('.overlay').fadeOut();
	$('body').css('overflow', 'auto');
	$('.o_product_selected').each(function(){
		$('.o_product_selected').removeClass('o_product_selected');
	});
}


//прибавить/отнять количество товра дя акссеуаров
$(document).ready(function(){
	$('body').on('click', '.edit_custom_count', function(){
		$(this).hide('slow');
		$(this).parent().attr("style", "opacity: 1");
		$(this).parent().find('.edited_custom_stock_count').prop("disabled", false);
	});
});

//при изменении на страницк


//если таблица пуста
$('body').on('DOMSubtreeModified', '.stock_list_tbody', function(){
	table_data_empty_check();
});


function table_data_empty_check() {
	$table_name = $('.stock_list_tbody');
	$empty_show_block = $('.empty_table_row');	

	var table = $table_name.html().trim();


	if(table.length <= 0) {
		$empty_show_block.show();
	} else {
		$empty_show_block.hide();
	}	

	console.log(table.length);
}


function add_table_empty_block() {
	var table_row = '<div class="empty_table_row"></div>';
	var table_data = '<h3 class="table_empty_text">Məlumat tapılmadı</h3>';
	$('table').append(table_row);
	$('.empty_table_row').append(table_data);
	table_data_empty_check();
}








//************************test stats card report *******************************//


function get_stats_info(param, type) {
	$date_block = $('.stats-date');
	var param = $date_block.data('cur-date');
	var type = $('.stock_list_tbody').data('category');

	$.ajax({
		type: 'GET',
		url: 'core/pulgin/stats_card/stats_action/get_stats_data',
		data: {
			param: param,
			type: type
		},
		success: (data) => {
			$date_block.html(param);

			if(type == 'phone') {
				var cardData = generateCardObj_phone(data);
				console.log(cardData);
			}
			if(type === 'akss') {
				var cardData = generateCardObj_akss(data);
			}

			//собираем карточку
			generateCard(cardData);
			//добавляем на страницу
			renderToDom(cardData);

		}
	});

}
function generateCardObj_phone(data) {
	let cardData = [
		{
			title: 'Ümumi dövriyyə',
			value: data.total_money,
			img:   '<img src="/img/icon/manat-white.png" class="manat_icon_white_stats">',
			color: '--stats-card-primary-color: #8d47ff'
		},
		{
			title: 'Xeyir',
			value: data.total_profit,
			img:   '<img src="/img/icon/manat-white.png" class="manat_icon_white_stats">',
			color: '--stats-card-primary-color: #88d498'
		},
		{
			title: 'XERC',
			value: data.total_rasxod,
			img:   '<img src="/img/icon/manat-white.png" class="manat_icon_white_stats">',
			color: '--stats-card-primary-color: #de8f8f'
		},
		{
			title: 'Cəmi satış (sayı)',
			value: data.total_sell_count,
			img: '',
			color: '--stats-card-primary-color: #565264'
		}
	];
	return cardData;
}


function generateCardObj_akss(data) {
	let cardData = [
		{
			title: 'Ümumi dövriyyə',
			value: data.total_money,
			img:   '<img src="/img/icon/manat-white.png" class="manat_icon_white_stats">',
			color: '--stats-card-primary-color: #8d47ff'
		},
		{
			title: 'Xeyir',
			value: data.total_profit,
			img:   '<img src="/img/icon/manat-white.png" class="manat_icon_white_stats">',
			color: '--stats-card-primary-color: #88d498'
		},
		{
			title: 'Cəmi satış (sayı)',
			value: data.total_sell_count,
			img: '',
			color: '--stats-card-primary-color: #565264'
		}
	];

	return cardData;
}

function generateCard(data){
    var title = data.title;
    var value = data.value;
    var img = data.img;
    var color = data.color;
    return ('<li class="stas_card" style="'+color+'"><div class="stats--crad-header h3">'+title+'</div><div class="stats--card-value-box flex-cntr"><span class="stats--value">'+value+'</span><span class="mark">'+img+'</span></div></li>');
  }

function clearCardList() {
	$('.stas_crad_list').empty();
}

function renderToDom(data){
	clearCardList();
  data.forEach(function(item){
    var card = generateCard(item);
    //render card to dom
    //console.log(card);
    $('.stas_crad_list').append(card);
  });
}

/************************************stats end********************************************************************/








/**********update end********/



//кастомынй селект
$(document).ready(function(){
	$('body').on('click', '.drop_down_btn', function(){
		var $this = $(this);
		//класс активной кнопки
		var click_button =  'click-dropdown';
		var slected_option = 'active-dropdown';

		if(!$this.hasClass(slected_option)) {
			$this.toggleClass(click_button);
			if($this.hasClass(click_button)) {

				$('.ls-select-option-list').each(function(){
					$(this).fadeOut();
				});

				$('.drop_down_btn').each(function(){
					$(this).not($this).removeClass(click_button);
				});

				$this.closest('.ls-select-list').find('.ls-select-option-list').fadeIn();
			} else {
				$this.closest('.ls-select-list').find('.ls-select-option-list').fadeOut();
			}
		}

	});


	$('body').on('click', '.choice-option',function(){
		var $this = $(this);
		var selected_id = $this.attr('id');
		var selected_value = $this.attr('value');
		var $option_block  = $('.ls-select-option-list');
		var $drop_down_btn = $('.drop_down_btn');
		var click_button =  'click-dropdown';
		var active_dropdown = 'active-dropdown';
		var $reset_btn = $('.reset_option');

		$this.closest('.ls-select-list').find('.drop_down_btn')
			 .attr('id',  selected_id)
			 .attr('value', selected_value)
			 .removeClass(click_button)
			 .addClass(active_dropdown)
			 .closest('.select-drop-down')
			 .find('.reset_option').fadeIn();

		$this.closest('.ls-select-option-list').fadeOut();
	});

	$('body').on('click', '.ls-reset-option', function(){
		$this = $(this);
		//var $reset_btn = $('.reset_option');
		var $drop_down_btn = $this.closest('.ls-select-list').find('.drop_down_btn');
		var active_dropdown = 'active-dropdown';
		var default_value_dropdown = $drop_down_btn.attr('default-value');



		$drop_down_btn.removeClass(active_dropdown)
					  .attr('value', default_value_dropdown)
					  .attr('id', '')
					  .closest('.ls-select-list');
	});
});


function reset_all_filter_add() {
	$('.drop_down_btn').each(function(){
		var def_value = $(this).attr('default-value');
		var active_dropdown = 'active-dropdown';

		$(this).removeClass(active_dropdown)
			   .attr('value', def_value)
			   .attr('id', '');

	});
}




$(document).ready(function(){


	//open filter hidden block
	$('body').on('click', '.open_filter_widjet', function(e){
		var active_dropdown = 'active-dropdown';
		var $filter_content = $('.filter_content');

		$filter_content.fadeToggle();
	});

	$(document).mouseup(function (e){
		var $filter_content = $('.filter_content');
		if (!$filter_content.is(e.target)
		    && $filter_content.has(e.target).length === 0) { 
			$filter_content.hide(); 
		}
	});

	//открывекм выпадающий списко еси инпут активный
	$('body').on('focusin', '.auto-cmplt-input', function(e){
		$(this).closest('.auto-cmplt-parent')
		.find('.auto-cmplt-select').fadeIn();

		console.log('focused');
	}).focusout(function(){
		hide_autocomplte_list();
	});

	//закрываем все октрытые авто-списки
	function hide_autocomplte_list() {
		$('.auto-cmplt-select').each(function(){
			$(this).fadeOut();
		});					
	}


	//если пользователь выбрал вариант
	$('body').on('click', '.auto-cmplt-list', function(){
		var $this = $(this);

		//получем общий родитель
		var $parent = $('.auto-cmplt-parent');
		//получем инпут
		var $input = $('.auto-cmplt-input');
		//выбраный вариант
		var value = $this.text().trim();

		$this.closest($parent).find($input).val(value);

	});


});