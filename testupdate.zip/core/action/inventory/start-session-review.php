<?php
header('Content-type: Application/json');

use core\classes\Inventory\InventorySession;
use core\classes\Utils\Utils;

require __DIR__.'/_helpers.php';

$sessionId = (int) ($_POST['session_id'] ?? 0);

if($sessionId <= 0) {
    Utils::errorAbort('Sessiya seçilməyib');
    return;
}

try {
    InventorySession::startReview($sessionId);
} catch (\Throwable $e) {
    Utils::errorAbort(inventoryErrorMessage($e));
    return;
}

$result = renderInventorySessionItems($sessionId);

Utils::abort([
    'type'        => 'success',
    'text'        => 'Yoxlama başladı — sayları əl ilə düzəltmək olar',
    'items_table' => $result['items_table'],
    'review'      => true,
]);