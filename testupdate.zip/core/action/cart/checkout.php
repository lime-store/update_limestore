<?php
use Core\Classes\Cart\Checkout;
use core\classes\dbWrapper\db;
use Core\Classes\Privates\accessManager;
use Core\Classes\Privates\User;
use Core\Classes\Report;
use Core\Classes\Services\Notify;
use Core\Classes\Services\RenderTemplate;
use Core\Classes\Utils\Utils;

header('Content-Type: application/json');

$Checkout = new \Core\Classes\Cart\Checkout;

$postData = $_POST['data'] ?? [];

// если корзина пустая, то выводим сообщение
if(!isset($postData['cart'])) {
    return Utils::errorAbort('Səbət boşdur');
}

if(!isset($_POST['dataMode']) || Report::isValidReportType($_POST['dataMode']) == false) {
    return Utils::errorAbort('System Error');
}

$reportType            = $_POST['dataMode'];
$payment_method        = $postData['payment_method'] ?? 0;
$sales_man             = $postData['sales_man'] ?? 0;
$cart_list             = $postData['cart'];
$full_date             = $utils->getDateDMY();
$short_date            = $utils->getDateMY();
$transaction_id        = $utils::generateTransactionId();
$notify_list           = [];
$discount              = $postData['discount'] ?? 0;
$canChangePrice        = accessManager::hasUserAccessAction('changeSalePriceOnCart', $sales_man) ?? false;


if($discount) {
    $hasDiscount = accessManager::hasUserAccessAction('canDiscount', $sales_man);
    $discountLimit = accessManager::hasUserAccessAction('discountLimit', $sales_man);

    $getUserInfo = User::getUserInfo($sales_man);
    $getUserName = $getUserInfo['user_name'];

    if(!$hasDiscount) {
        Utils::errorAbort("Istifadəçinin ($getUserName) endirim tətbiq etmək icazəsi yoxdur");
        exit;
    }

    if($discountLimit && $discount > $discountLimit['description']) {
        $maxDiscountLimit = $discountLimit['description'];

        Utils::errorAbort("Zəhmət olmasa düzgün endirim məbləği daxil edin. max - $maxDiscountLimit%");
        exit;
    }
}


db::$dbpdo->beginTransaction();

try {
    if($reportType == 'WHOLESALE') {
        if(!isset($postData['customer_id']) || empty($postData['customer_id'])) {
            return $utils::errorAbort('Choose customer');

            exit;
        }

        $customer_id = $postData['customer_id'];

        Checkout::addWholesaleTransaction([
            'customer_id' => $customer_id,
            'transaction_id' => $transaction_id
        ]);
    }

    foreach($cart_list as $row) {
        Checkout::validateOrder($row);

        
        $id = (int) $row['id'];
        // цена товара
        $order_price = $row['price'];
        // количество товара
        $order_count = $row['count'];  
        // заметка продажи
        $description = $row['description'];
        
        $stock_row = $products->getProductById($id);
        
        if($canChangePrice) {
            $order_price = $stock_row['stock_second_price'];
        }


        $Checkout->checkoutOrder([
            'ProductsData'      => $stock_row,
            'id'                => $id,
            'order_price'       => $order_price,
            'order_count'       => $order_count,
            'description'       => $description,
            'payment_method'    => $payment_method,
            'sales_man'         => $sales_man,
            'transaction_id'    => $transaction_id,
            'reportType'        => $reportType,
            'discount'          => $discount,
        ]);


        $notify_count = $stock_row['stock_count'] - $order_count;

        if($notify_count < 3) {
            $text = $stock_row['stock_name'];
            $NotifyType = 'almostOutOfStock'; 

            if($notify_count <= 0) {
                $NotifyType = 'outOfStock'; 
                $text = $stock_row['stock_name'] . ' ' .$stock_row['stock_phone_imei'];
            } 
        
            Notify::addNotify([
                'type' => $NotifyType,
                'text' => $text,
                'id' => $id
            ]);

            array_push($notify_list, Notify::getLastAddedNotify());
        }
    }

    db::$dbpdo->commit();
}
catch(\Exception $e) {  
    db::$dbpdo->rollBack();

    return Utils::errorAbort($e->getMessage());
}



$notify_tmp = '';

if($notify_list) {
    foreach($notify_list as $key => $row) {
        $notify_tmp.= RenderTemplate::view('/component/notify/notify-items.twig', [
            'data' => $row
        ]);
    }    
}

return $utils::abort([
    'type' => 'success',
    'text' => 'Ok!',
    'notifyList' => $notify_tmp
]);
