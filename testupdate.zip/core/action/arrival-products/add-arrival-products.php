<?php header('Content-type: Application/json');

use core\classes\Services\Warehouse\Warehouse;
use core\classes\Utils\Utils;

$Warehouse = new Warehouse;

if(empty($_POST['list'])) {
    $utils::abort('Səbət boşdur'); exit;
}


$list = $_POST['list'];

$Warehouse->handleProductArrival($list);

echo Utils::abort([
    'text' => 'Əlavə edildi',
    'type' => 'success'
]);