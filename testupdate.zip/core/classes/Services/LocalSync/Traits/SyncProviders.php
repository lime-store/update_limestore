<?php

namespace core\classes\Services\LocalSync\Traits;
use core\classes\dbWrapper\db;
use core\classes\dbWrapper\queryBuilder as qb;
use core\classes\dbWrapper\updateBuilder as ub;
use core\classes\Services\Provider;
use core\classes\Services\BaseService;

trait SyncProviders
{
    /**
     * Находит/создаёт и привязывает всех поставщиков товара
     */
    private static function syncProductProviders(array $providers, int $localStockId)
    {
        $currentRemoteIds = self::getCurrentProviderRemoteIds($localStockId);
        $newRemoteIds = array_column($providers, 'provider_id');

        $toAddIds = array_diff($newRemoteIds, $currentRemoteIds);
        $toRemoveIds = array_diff($currentRemoteIds, $newRemoteIds);

        foreach ($providers as $provider) {
            if (in_array($provider['provider_id'], $toAddIds)) {
                $localProviderId = self::findOrCreateProvider($provider);
                self::linkProductToProvider($localProviderId, $localStockId);
            }
        }

        foreach ($toRemoveIds as $remoteId) {
            self::unlinkProviderByRemoteId($remoteId, $localStockId);
        }
    }

    private static function getCurrentProviderRemoteIds(int $localStockId): array
    {
        $rows = qb::select('sp.remote_id')
            ->from('products_provider_list ppl')
            ->join('stock_provider sp ON sp.provider_id = ppl.id_from_provider')
            ->where('ppl.id_from_stock = :stock_id')
            ->bindList([':stock_id' => $localStockId])
            ->execute()
            ->get();

        return array_column($rows ?: [], 'remote_id');
    }


    private static function unlinkProviderByRemoteId($remoteProviderId, int $localStockId): void
    {
        $provider = qb::select('provider_id')
            ->from('stock_provider')
            ->where('remote_id = :remote_id')
            ->bindList([':remote_id' => $remoteProviderId])
            ->execute()
            ->first()
            ->get();

        if (empty($provider)) {
            return;
        }

        db::delete([
            [
                'table_name' => 'products_provider_list',
                'where' => ' id_from_provider = :prov_id AND id_from_stock = :stock_id ',
                'bindList' => [
                    'prov_id'   => $provider['provider_id'],
                    'stock_id' => $localStockId,
                ]
            ]
        ]);
    }

    /**
     * Привязывает поставщика к товару (если связки ещё нет)
     */
    private static function linkProductToProvider(int $localProviderId, int $localStockId): void
    {
        $exists = qb::select('id')
            ->from('products_provider_list')
            ->where('id_from_provider = :prov_id AND id_from_stock = :stock_id')
            ->bindList([
                ':prov_id'  => $localProviderId,
                ':stock_id' => $localStockId,
            ])
            ->execute()
            ->first()
            ->get();

        if (!empty($exists)) {
            return;
        }

        db::insert('products_provider_list', [
            [
                'id_from_provider' => $localProviderId,
                'id_from_stock'    => $localStockId,
            ]
        ]);
    }

    /**
     * Находит локального поставщика по remote_id, либо создаёт нового
     */
    private static function findOrCreateProvider(array $providerInfo)
    {
        $provider = new Provider;

        $remoteProviderId = $providerInfo['provider_id'];

        $existing = qb::select('provider_id')
            ->from('stock_provider')
            ->where('remote_id = :remote_id')
            ->bindList([':remote_id' => $remoteProviderId])
            ->execute()
            ->first()
            ->get();

        if (!empty($existing)) {
            return $existing['provider_id'];
        }

        db::insert('stock_provider', [
            [
                'provider_name' => $providerInfo['provider_name'],
                'visible'       => $providerInfo['visible'] ?? 'visible',
                'remote_id'     => $remoteProviderId,
            ]
        ]);

        return $provider->getLastAddedProvider()['provider_id'];
    }

    /**
     * 
     */
    public static function editProvider(array $task)
    {
        $providerInfo = $task['payload']['providerInfo'];

        if (!empty($providerInfo)) {
            ub::table('stock_provider')
                ->set('provider_name', $providerInfo['provider_name'])
                ->set('visible', $providerInfo['visible'])
                ->where('remote_id', $providerInfo['provider_id'])
                ->execute();
        }
    }

    /**
     * 
     */
    public static function deleteProvider(array $task)
    {
        $providerInfo = $task['payload']['providerInfo'];

        if (!empty($providerInfo)) {
            $localProviderId = qb::select('*')
                                    ->from('stock_provider')
                                    ->where('remote_id', $providerInfo['provider_id'])
                                    ->first()
                                    ->columnName('provider_id')
                                    ->get();
                                    
            if(!empty($localProviderId)) {
                $provider = new Provider;
                $provider->deleteProvider($localProviderId);
            }
        }       
    }    
}
