<?php 
use Core\Classes\Traits\Barcode;
use Core\Classes\Utils\Utils;

header('Content-Type: application/json');

return Utils::abort([
    'res' => Barcode::generateBarcodeNumber()
]);