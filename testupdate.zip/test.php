<?php
require_once  "vendor/autoload.php";

$token = '323030333639363632373a414148557a67433454476b4b4b783267753076347159594f63785955467134525f534d';	

$token = hex2bin($token);

$apiUrl = "https://api.telegram.org/bot$token/getUpdates";
$response = file_get_contents($apiUrl);
$data = json_decode($response, true);

echo '<pre>';
var_dump($data);
echo '</pre>';

if($data['ok'] && !empty($data['result'])) {
    $resultArray = $data['result'];

    foreach($resultArray as $row ) {
            echo "<div style='border: 2px solid #000; margin-bottom: 10px;'>";
                //текстовое сообщение
            if(!empty($row['message']['text'])) {

                
                echo str_replace('/res ', '', $row['message']['text']).'<br>';
            }

            $link_preview = !empty($row['message']['link_preview_options']) ?? false;

            if($link_preview) {
                if(!array_key_exists('is_disabled', $row['message']['link_preview_options'])) {
                    echo "<img width='400' height='400' src=".$row["message"]["link_preview_options"]['url']. " alt='Telegram Image'>";
                }
            }

            echo "</div>";
        }
    }



exit;

if($data['ok'] && !empty($data['result'])) {
    $resultArray = $data['result'];

    foreach($resultArray as $row ) {
                //текстовое сообщение
            if(!empty($row['message']['text'])) {
                echo $row['message']['text'].'<br>';
            }

            // поучаем фото
            if(!empty($row['message']['photo'])) {
                $rowPhoto = $row['message']['photo'];
                
                $file_id = $rowPhoto[2]['file_id'] ?? $rowPhoto[0]['file_id'];

                $photoUri = "https://api.telegram.org/bot$token/getFile?file_id=$file_id";
                $phoroRes = file_get_contents($photoUri);
                $photoData = json_decode($phoroRes, true);


                $file_path = $photoData['result']['file_path'];

                $imageUrl = "https://api.telegram.org/file/bot$token/$file_path";

                $imageData = base64_encode(file_get_contents($imageUrl));

                // var_dump($imageData);
                // Format the image SRC:  data:{mime};base64,{data};
                $src = 'data: '.';base64,'.$imageData;

                
                // Echo out a sample image

                echo "<img src=\"$src\" alt=\"Telegram Image\">";
                echo "<br>". $row['message']['caption'];

            }

            if(!empty($row['message']['animation'])) {
                // if(!empty($row['message']['animation'])) {
                //     echo '<pre>';
                //     var_dump($row['message']['animation']);
                //     echo '</pre>';
    
                // }                     
                $rowPhoto = $row['message']['animation'];

                $file_id = $rowPhoto['file_id'];

                $photoUri = "https://api.telegram.org/bot$token/getFile?file_id=$file_id";
                $phoroRes = file_get_contents($photoUri);
                $photoData = json_decode($phoroRes, true);

                // https://api.telegram.org/bot$token/getFile?file_id=$file_id

                $file_path = $photoData['result']['file_path'];

                $imageUrl = "https://api.telegram.org/file/bot$token/$file_path";

                // $imageData = base64_encode(file_get_contents($imageUrl));

                // var_dump($imageData);
                // Format the image SRC:  data:{mime};base64,{data};
                // $src = 'data: '.';base64,'.$imageData;

                echo "<video src=".$imageUrl."  loop autoplay muted></video>";
                // echo "<br>". $row['message']['caption'];                
            }
        }
}



// if ($data && $data['ok'] && isset($data['result']['file_path'])) {
//     $filePath = $data['result']['file_path'];

//     // Построение URL изображения
//     $imageUrl = "https://api.telegram.org/file/bot$token/$filePath";

//     // Вывод изображения на странице
//     echo "<img src=\"$imageUrl\" alt=\"Telegram Image\">";
// } else {
//     echo "Не удалось получить информацию о файле из Telegram API.";
// }



// // Проверяем, есть ли данные в ответе
// if ($data && $data['ok'] && !empty($data['result'])) {
//     // Получаем информацию о последней записи
//     $latestUpdate = $data['result'];

//     // Проверяем, является ли последнее обновление сообщением
//     if (isset($latestUpdate['message'])) {
//         $message = $latestUpdate['message'];
        
//         // Теперь у вас есть информация о последнем сообщении
//         $chatId = $message['chat']['id'];
//         $messageId = $message['message_id'];
//         $text = $message['text'];

//         // Выводите информацию на вашем сайте
//         echo "Последнее сообщение в чате $chatId с ID $messageId: $text";
//     } else {
//         echo "Последнее обновление не является сообщением.";
//     }
// } else {
//     echo "Не удалось получить данные из Telegram API.";
// }







// use \TelegramBot\Api\BotApi;


// // Создаем экземпляр класса Api
// $telegram = new BotApi($token);

// // Получаем обновления
// $response = $telegram->getUpdates();

// // Перебираем сообщения
// foreach ($response as $update) {
//     $message = $update->getMessage();    
//     // Выводим текст сообщения
//     echo $message->getText() . PHP_EOL . '</br>';
// }



exit;

require_once $_SERVER['DOCUMENT_ROOT'].'/vendor/autoload.php';

use Spatie\Dropbox\Client as DropboxClient;
use Spatie\Dropbox\RefreshableTokenProvider;
use Spatie\Dropbox\TokenProvider;
use GuzzleHttp\Client;  


$appKey = '0cno2oumcf4kt5g';
$appSecret =  'tek71f5tf84ri9n';





// $refressh_token = 'RucxgS1pHDAAAAAAAAAAKaqaCr4DLLwHmKsVowXQ6qQ';
// $token = 'sl.BlTXV5NA8u0KnEvmktBB3aXiE59M1Z2cYBM4wPB5N7j4Ra7f7lXyRp83R_gqr0VlTKNUKvw_vM86bkevNS8nmiFqgb9dTt_EOgrTPPkQMMxsTE1_kWmZQ2VN8gdCMmoXsWV2_BLZMT0Yqb6L6Z_wsAk';
// // sl.BlQAjITCyJ2PICbzBHVXOGNJvv9k4v8i1RZyw64PgejO_RMHXshPdURj9Ayz8pSg0A-vxh8cHOS_OGj87fWtLvcWjKHKbsURVIC9HearJkKnLydHNtxsbcIIWgTs8I_ZpzXLriXVzP62C2IlTK6xlxg

$client = new DropboxClient([$appKey, $appSecret]);


// $tokenProvider =  new RefreshableTokenProvider('sl.BlR-OixW-oOm3wx4WzytkdYR2c2y_cD703gIkqCnUpSBey7eUfAVz5sr9JyroRJEO9xnQAE-7c410c6-qeNgqJts74Iea06A8P9kviOAyNVoq67XoPOjhj6Lf4JRFnjXDk9JjffVBEoX-FrflQ7VrBM');


$tokenProvider = $client->createConfiguredMock(RefreshableTokenProvider::class, [
    'getToken' => 'test_token',
]);


var_dump($tokenProvider);

exit;

// этот код работает он реворкает токен, но после того как он изменил токен мы не можеи если увидить и использовать сука
$response = $client->post('https://api.dropboxapi.com/2/auth/token/revoke', [
    'headers' => [
        'Authorization' => 'Bearer ' . 'sl.BlR-OixW-oOm3wx4WzytkdYR2c2y_cD703gIkqCnUpSBey7eUfAVz5sr9JyroRJEO9xnQAE-7c410c6-qeNgqJts74Iea06A8P9kviOAyNVoq67XoPOjhj6Lf4JRFnjXDk9JjffVBEoX-FrflQ7VrBM',
    ],
]);

// Проверьте ответ на ошибки
if ($response->getStatusCode() !== 200) {
    $error = json_decode($response->getBody(), true);
    echo 'Error: ' . $error['error_summary'];
} else {

    echo '<pre>';
        var_dump($response);
    echo '</pre>';

    echo 'Token revoked successfully.';
}







// use Spatie\Dropbox\Client as DropboxClient;
// use Spatie\Dropbox\TokenProvider;
// use GuzzleHttp\Client;


// // $token = 'sl.BktV5UaHcj26Bw7oTfKTI-lUcGHeyqpOHkx7LH6zm7hfUImY4A2bNu4RTGK9Oh5nmy6J2qfO8EQ2J63MSZ-1EmIUtR0MQvfJrSXU4AKY9i4U_8sTb1WNatpbB8ezi-iT4rhKVLAgKMNvfmY';
// $token = '0cno2oumcf4kt5g';

// // $client = new DropboxClient($token);
// $client = new DropboxClient($token);

// $date = date('d.Y');


// $client = new Client();

// $response = $client->post('https://api.dropboxapi.com/oauth2/token', [
//     'form_params' => [
//         'grant_type' => 'refresh_token',
//         'refresh_token' => 'YOUR_REFRESH_TOKEN',
//         'client_id' => 'YOUR_CLIENT_ID',
//         'client_secret' => 'YOUR_CLIENT_SECRET',
//     ],
// ]);

// $data = json_decode($response->getBody(), true);

// // Extract the new access token from the response
// $newAccessToken = $data['access_token'];


// var_dump($newAccessToken);
// // $client->upload("/filename_$date.txt", file_get_contents('file.txt'), $mode='add');