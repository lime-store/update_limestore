/* инвентаризация (sayim) */

window.inventoryContext = {
	inventory_id: null,
	session_id: null
};

// навигация внутри раздела (список -> сессии -> скан)
function loadInventoryView(data) {
	window.inventoryContext = Object.assign({
		inventory_id: null,
		session_id: null
	}, data);

	$.ajax({
		type: 'POST',
		url: 'page/route.php',
		data: {
			page: 'inventory',
			tab: 'tab_inventory_list',
			inventory_id: data.inventory_id || null,
			session_id: data.session_id || null
		},
		success: (html) => {
			$('.content').remove();
			$('.main').append(html);
			ui_selected_tab();

			const $input = $('.inventory-scan-input').first();

			if($input.length) {
				$input.focus();
			}
		}
	});
}

// обновление таблицы позиций сессии
function replaceInventorySessionItems(items_table, review) {
	$('.inventory-session-wrap').html(items_table);
	$('.inventory-scan-view').attr('data-review', review ? '1' : '0');

	$('.inventory-scan-view').find('.start-session-review').toggle(!review);

	$('.inventory-scan-input').first().focus();

	// сохранить активные сортировку/фильтр/поиск после перерисовки (режим проверки)
	if(review) {
		inventoryApplyTableUI($('.inventory-session-wrap'));
	}
}

/* ===== сортировка / фильтры / поиск / экспорт таблиц инвентаризации ===== */

const inventoryTableState = {
	filter: 'all',
	search: ''
};

const inventorySortState = {
	key: null,
	dir: 1
};

// значение ячейки для сортировки: инпут проверки -> data-sort-value -> текст
function inventoryGetCellValue($td) {
	const $input = $td.find('.input-counted-quantity');

	if($input.length) {
		return parseFloat($input.val()) || 0;
	}

	const v = $td.attr('data-sort-value');

	if(v !== undefined) {
		const n = parseFloat(v);
		return isNaN(n) ? v.toLowerCase() : n;
	}

	return $td.text().trim().toLowerCase();
}

function inventorySortTable($table, $th) {
	const key = $th.data('sort');

	if(inventorySortState.key === key) {
		inventorySortState.dir = -inventorySortState.dir;
	} else {
		inventorySortState.key = key;
		inventorySortState.dir = 1;
	}

	inventoryApplySort($table, $th);
}

// применить текущее состояние сортировки (без переключения направления)
function inventoryApplySort($table, $th) {
	const idx = $th.index();
	const dir = inventorySortState.dir;
	const $tbody = $table.find('tbody').first();
	const rows = $tbody.find('tr.stock-list').get();

	rows.sort(function(a, b) {
		const va = inventoryGetCellValue($(a).find('td').eq(idx));
		const vb = inventoryGetCellValue($(b).find('td').eq(idx));

		if(va < vb) return -dir;
		if(va > vb) return dir;
		return 0;
	});

	$tbody.append(rows);

	$table.find('.sortable-inv-th').removeClass('sort-inv-asc sort-inv-desc');
	$th.addClass(dir === 1 ? 'sort-inv-asc' : 'sort-inv-desc');
}

// применить текущие фильтр + поиск к строкам таблицы
function inventoryRefreshRows($scope) {
	const q = inventoryTableState.search.toLowerCase();

	$scope.find('tr.stock-list').each(function() {
		const $tr = $(this);
		let show = true;

		if(inventoryTableState.filter === 'diff' && (parseFloat($tr.attr('data-diff')) || 0) === 0) {
			show = false;
		} else if(['shortage', 'surplus', 'match'].indexOf(inventoryTableState.filter) !== -1
			&& $tr.attr('data-type') !== inventoryTableState.filter) {
			show = false;
		}

		if(show && q && $tr.find('td').first().text().toLowerCase().indexOf(q) === -1) {
			show = false;
		}

		$tr.toggle(show);
	});
}

// восстановить сортировку/фильтр/поиск после перерисовки таблицы
function inventoryApplyTableUI($scope) {
	inventoryRefreshRows($scope);

	$scope.find('.inventory-table-search').val(inventoryTableState.search);

	$scope.find('.inventory-filter-chip[data-filter="' + inventoryTableState.filter + '"]')
		.removeClass('btn-secondary').addClass('btn-primary')
		.siblings('.inventory-filter-chip').removeClass('btn-primary').addClass('btn-secondary');

	if(inventorySortState.key) {
		const $th = $scope.find('th.sortable-inv-th[data-sort="' + inventorySortState.key + '"]').first();

		if($th.length) {
			inventoryApplySort($scope.find('table').first(), $th);
		}
	}
}

function scan(barcode) {
	const $view = $('.inventory-scan-view');

	if($view.length < 1 || $view.attr('data-review') == '1') {
		return;
	}

	const session_id = $view.attr('data-session-id');

	$('.inventory-scan-input').val('');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/inventory/scan-session-item.php',
			route: 'scanSessionItem',
			session_id: session_id,
			barcode: barcode
		},
		dataType: 'json',
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type != 'success') {
				return;
			}

			if(data.items_table) {
				replaceInventorySessionItems(data.items_table, false);
			} else if(data.row_html) {
				const tbody = $('.inventory-session-tbody').first();

				tbody.find('tr.stock-list[data-stock-id="' + data.stock_id + '"]').remove();
				tbody.prepend(data.row_html);
				tbody.find('tr.stock-list').slice(50).remove();

				$('.inventory-scan-input').first().focus();
			}
		}
	});
}

// клик по заголовку колонки — сортировка
$(document).on('click', '.sortable-inv-th', function() {
	inventorySortTable($(this).closest('table'), $(this));
});

// фильтр-чипы (все / с разницей / недостача / излишек / совпадение)
$(document).on('click', '.inventory-filter-chip', function() {
	const $btn = $(this);

	inventoryTableState.filter = $btn.data('filter');

	$btn.closest('.input-container').find('.inventory-filter-chip')
		.removeClass('btn-primary').addClass('btn-secondary');
	$btn.removeClass('btn-secondary').addClass('btn-primary');

	inventoryRefreshRows($btn.closest('.report-modal, .inventory-session-wrap'));
});

// поиск по названию товара
$(document).on('keyup', '.inventory-table-search', function() {
	inventoryTableState.search = $(this).val();

	inventoryRefreshRows($(this).closest('.report-modal, .inventory-session-wrap'));
});

// экспорт отчёта в Excel (.xlsx, как на остальных отчётах проекта)
$(document).on('click', '.export-inventory-report', function() {
	const $table = $(this).closest('.report-modal').find('table').first();
	const rows = [];
	const headers = [];

	$table.find('thead th').each(function() {
		headers.push($(this).text().trim());
	});

	rows.push(headers);

	$table.find('tbody tr.stock-list:visible').each(function() {
		const row = [];

		$(this).find('td').each(function() {
			const $td = $(this);
			const exportVal = $td.attr('data-export');

			if(exportVal === undefined) {
				row.push($td.text().trim());
			} else if(exportVal === '') {
				row.push('');
			} else {
				const n = parseFloat(exportVal);
				row.push(isNaN(n) ? exportVal : n);
			}
		});

		rows.push(row);
	});

	const ws = XLSX.utils.aoa_to_sheet(rows);
	const wb = XLSX.utils.book_new();

	XLSX.utils.book_append_sheet(wb, ws, 'Sayim');

	const title = $('.report-modal .modal-title-text').first().text().trim() || 'Sayim hesabati';

	XLSX.writeFile(wb, title + '.xlsx');
});


/** открыть модалку создания инвентаризации */
$(document).on('click', '.load-inventory-add-modal', function() {
	remove_modal();

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/inventory/create-inventory-modal.php',
			route: 'createInventoryModal',
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);
		}
	});
});

/** сохранить инвентаризацию */
$(document).on('click', '.add-submit-inventory', function() {
	let prepare_data = {};

	if($(this).closest('.modal-form').length) {
		if(is_required_input($(this).closest('.modal-form').find('.form-input'))) {
			prepare_data = prepare_form_fields($(this).closest('.modal-form'));

			$.ajax({
				type: 'POST',
				url: 'ajax_route.php',
				data: {
					url: '/core/action/inventory/create-inventory.php',
					route: 'createInventory',
					post_data: prepare_data,
					page: pageData.page(),
					type: pageData.type()
				},
				dataType: 'json',
				success: (data) => {
					pageData.alert_notice(data.type, data.text);

					if(data.type == 'success') {
						closeAndRemoveModal();

						if(data.table) {
							return pageData.prependTable(data.table);
						}

						createBackup();
					}
				}
			});
		}
	}
});

/** отменить инвентаризацию */
$(document).on('click', '.cancel-inventory', function() {
	const id = $(this).closest('.stock-list').attr('id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/inventory/cancel-inventory.php',
			route: 'cancelInventory',
			id: id
		},
		dataType: 'json',
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success') {
				loadInventoryView({});
			}
		}
	});
});

/** открыть инвентаризацию (список сессий) */
$(document).on('click', '.open-inventory', function() {
	const id = $(this).closest('.stock-list').attr('id');

	loadInventoryView({ inventory_id: id });
});

/** назад к списку инвентаризаций */
$(document).on('click', '.inventory-back', function() {
	loadInventoryView({});
});


/** открыть модалку создания сессии */
$(document).on('click', '.load-session-add-modal', function() {
	const inventory_id = $(this).data('inventory-id');

	remove_modal();

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/inventory/create-session-modal.php',
			route: 'createSessionModal',
		},
		dataType: 'json',
		success: (data) => {
			$('.container').append(data.res);

			$('.modal').find('input[data-fields-name="inventory_id"]').val(inventory_id);
		}
	});
});

/** сохранить сессию */
$(document).on('click', '.add-submit-session', function() {
	let prepare_data = {};

	if($(this).closest('.modal-form').length) {
		if(is_required_input($(this).closest('.modal-form').find('.form-input'))) {
			prepare_data = prepare_form_fields($(this).closest('.modal-form'));

			$.ajax({
				type: 'POST',
				url: 'ajax_route.php',
				data: {
					url: '/core/action/inventory/create-session.php',
					route: 'createSession',
					post_data: prepare_data,
					page: pageData.page(),
					type: pageData.type()
				},
				dataType: 'json',
				success: (data) => {
					pageData.alert_notice(data.type, data.text);

					if(data.type == 'success') {
						closeAndRemoveModal();

						loadInventoryView({ inventory_id: prepare_data.inventory_id });
					}
				}
			});
		}
	}
});

/** отменить сессию */
$(document).on('click', '.cancel-session', function() {
	const id = $(this).closest('.stock-list').attr('id');
	const inventory_id = window.inventoryContext.inventory_id;

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/inventory/cancel-session.php',
			route: 'cancelSession',
			id: id
		},
		dataType: 'json',
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success') {
				loadInventoryView({ inventory_id });
			}
		}
	});
});

/** открыть сессию (экран сканирования) */
$(document).on('click', '.open-session', function() {
	const id = $(this).closest('.stock-list').attr('id');
	const inventory_id = window.inventoryContext.inventory_id;

	loadInventoryView({ inventory_id, session_id: id });
});

/** назад из сессии к списку сессий */
$(document).on('click', '.session-back', function() {
	loadInventoryView({ inventory_id: $(this).data('inventory-id') });
});


/** сканирование штрихкода */
// $(document).on('scan.pos.barcode', function(event) {
// 	return scan(event.code);
// });

$(document).on('keyup', '.inventory-scan-input', function() {
	const barcode = $(this).val();

	return scan(barcode);
});


/** начать ручную проверку сессии */
$(document).on('click', '.start-session-review', function() {
	const session_id = $(this).data('session-id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/inventory/start-session-review.php',
			route: 'startSessionReview',
			session_id: session_id
		},
		dataType: 'json',
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success' && data.items_table) {
				replaceInventorySessionItems(data.items_table, true);
			}
		}
	});
});

/** ручная правка посчитанного количества */
$(document).on('keydown', '.input-counted-quantity', function(e) {
	if(e.key == 'Enter') {
		$(this).blur();
	}
});

$(document).on('change', '.input-counted-quantity', function() {
	const $this = $(this);

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/inventory/update-counted-quantity.php',
			route: 'updateCountedQuantity',
			session_id: $this.data('session-id'),
			stock_id: $this.data('stock-id'),
			counted_quantity: $this.val()
		},
		dataType: 'json',
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success' && data.items_table) {
				replaceInventorySessionItems(data.items_table, data.review);
			}
		}
	});
});

/** закрыть сессию (применить корректировки стока) */
$(document).on('click', '.close-session', function() {
	const session_id = $(this).data('session-id');

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/inventory/close-session.php',
			route: 'closeSession',
			id: session_id
		},
		dataType: 'json',
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success') {
				loadInventoryView({ inventory_id: data.inventory_id || window.inventoryContext.inventory_id });
			}
		}
	});
});

/** завершить инвентаризацию (с отчётом) */
$(document).on('click', '.close-inventory', function() {
	const inventory_id = $(this).data('inventory-id');

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/inventory/close-inventory.php',
			route: 'closeInventory',
			inventory_id: inventory_id
		},
		dataType: 'json',
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success' && data.action == 'missing_items' && data.modal) {
				$('.container').append(data.modal);
			} else if(data.type == 'success' && data.report_modal) {
				$('.container').append(data.report_modal);
			} else if(data.type == 'success') {
				loadInventoryView({});
			}
		}
	});
});

/** создать сессию с не посчитанными товарами и автоматически открыть её */
$(document).on('click', '.create-missing-session', function() {
	const inventory_id = $(this).data('inventory-id');

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/inventory/create-missing-session.php',
			route: 'createMissingSession',
			inventory_id: inventory_id
		},
		dataType: 'json',
		success: (data) => {
			pageData.alert_notice(data.type, data.text);

			if(data.type == 'success') {
				closeAndRemoveModal();

				loadInventoryView({ inventory_id: data.inventory_id, session_id: data.session_id });
			}
		}
	});
});

/** показать отчёт завершённой инвентаризации */
$(document).on('click', '.show-report', function() {
	const inventory_id = $(this).closest('.stock-list').attr('id');

	pageData.overlayShow();

	$.ajax({
		type: 'POST',
		url: 'ajax_route.php',
		data: {
			url: '/core/action/inventory/get-inventory-report.php',
			route: 'getInventoryReport',
			inventory_id: inventory_id
		},
		dataType: 'json',
		success: (data) => {
			if(data.type == 'success' && data.report_modal) {
				$('.container').append(data.report_modal);
			}
		}
	});
});

/* после закрытия модалки отчёта вернуться к списку инвентаризаций */
$(document).on('click', '.report-modal .removeModal', function() {
	loadInventoryView({});
});
